package com.novanet.nusaterm.ui.components

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.sp
import com.novanet.nusaterm.terminal.AnsiColor
import com.novanet.nusaterm.terminal.TerminalEmulator

@Composable
fun TerminalView(
    terminal: TerminalEmulator,
    renderTick: Long,
    modifier: Modifier = Modifier,
    fontSizeSp: Float = 13f,
    onMeasured: (cols: Int, rows: Int) -> Unit = { _, _ -> }
) {
    val density = LocalDensity.current
    val textPaint = remember {
        Paint().apply {
            typeface = Typeface.MONOSPACE
            isAntiAlias = true
        }
    }

    // renderTick dibaca agar composable ini diulang setiap ada output baru dari SSH.
    @Suppress("UNUSED_EXPRESSION") val forceRedrawKey = renderTick

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .onSizeChanged { size ->
                val sizePx = with(density) { fontSizeSp.sp.toPx() }
                textPaint.textSize = sizePx
                val cw = textPaint.measureText("M")
                val fm = textPaint.fontMetrics
                val ch = fm.descent - fm.ascent
                if (cw > 0f && ch > 0f) {
                    val cols = (size.width / cw).toInt().coerceAtLeast(1)
                    val rows = (size.height / ch).toInt().coerceAtLeast(1)
                    onMeasured(cols, rows)
                }
            }
    ) {
        val sizePx = with(density) { fontSizeSp.sp.toPx() }
        textPaint.textSize = sizePx
        val charWidth = textPaint.measureText("M")
        val fm = textPaint.fontMetrics
        val charHeight = fm.descent - fm.ascent

        drawRect(color = AnsiColor.defaultBackground, size = this.size)

        val grid = terminal.buffer.grid
        for (r in grid.indices) {
            val row = grid[r]
            val rowTop = r * charHeight
            for (c in row.indices) {
                val cell = row[c]
                val x = c * charWidth

                val bgIndex = if (cell.reverse) cell.fg else cell.bg
                if (bgIndex >= 0 || cell.reverse) {
                    val bgColor = if (bgIndex >= 0) AnsiColor.fromIndex(bgIndex) else AnsiColor.defaultForeground
                    drawRect(
                        color = bgColor,
                        topLeft = Offset(x, rowTop),
                        size = Size(charWidth, charHeight)
                    )
                }

                if (cell.char != ' ') {
                    val fgIndex = if (cell.reverse) cell.bg else cell.fg
                    val fgColor = if (fgIndex >= 0) AnsiColor.fromIndex(fgIndex) else {
                        if (cell.reverse) AnsiColor.defaultBackground else AnsiColor.defaultForeground
                    }
                    textPaint.color = fgColor.toArgb()
                    textPaint.isFakeBoldText = cell.bold
                    textPaint.isUnderlineText = cell.underline
                    drawContext.canvas.nativeCanvas.drawText(
                        cell.char.toString(),
                        x,
                        rowTop - fm.ascent,
                        textPaint
                    )
                }
            }
        }

        // Kursor blok semi-transparan
        val cursorX = terminal.buffer.cursorCol * charWidth
        val cursorY = terminal.buffer.cursorRow * charHeight
        drawRect(
            color = AnsiColor.normal[2].copy(alpha = 0.45f),
            topLeft = Offset(cursorX, cursorY),
            size = Size(charWidth, charHeight)
        )
    }
}
