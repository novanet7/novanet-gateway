package id.fr3velora.network

import id.fr3velora.model.User
import id.fr3velora.model.Group
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ApiResult<T>(
    val isSuccess: Boolean,
    val data: T? = null,
    val errorMessage: String? = null,
    val sessionCookie: String? = null,
    val httpCode: Int = 0
)

/**
 * Client REST ke server fr3velora, mengikuti persis pola auth project lama
 * (novanet.uno): login pakai idToken Google → server balas objek user + header
 * Set-Cookie "fr3v_session=...", cookie itu dikirim ulang sebagai header "Cookie"
 * di setiap request yang butuh login.
 *
 * BASE_URL sengaja bisa diganti (bukan konstanta) karena chat butuh server baru —
 * backend novanet.uno yang lama belum punya endpoint chat sama sekali.
 */
class ApiClient(private val baseUrl: String) {

    private val JSON_TYPE = "application/json; charset=utf-8".toMediaType()

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private fun userFromJson(json: JSONObject): User = User(
        id = json.optString("id", ""),
        username = json.optString("username", ""),
        email = json.optString("email", ""),
        api_key = json.optString("api_key", ""),
        avatar_url = json.optString("avatar_url", "").takeIf { it.isNotBlank() },
        created_at = if (json.has("created_at") && !json.isNull("created_at")) json.optString("created_at") else null
    )

    /** Login pakai ID token Google (dari Credential Manager / Google Sign-In di LoginActivity).
     *  Kalau email Google ini belum pernah login, server otomatis membuatkan akunnya. */
    fun loginWithGoogle(idToken: String): ApiResult<User> {
        return try {
            val payload = JSONObject().apply { put("idToken", idToken) }.toString()
            val req = Request.Builder()
                .url("$baseUrl/api/auth/google/mobile")
                .post(payload.toRequestBody(JSON_TYPE))
                .header("Content-Type", "application/json")
                .header("User-Agent", "fr3velora/1.0 (Android)")
                .build()

            client.newCall(req).execute().use { response ->
                val body = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    val errMsg = try {
                        JSONObject(body).optString("error", "Login Google gagal (HTTP ${response.code})")
                    } catch (_: Exception) {
                        "Login Google gagal (HTTP ${response.code})"
                    }
                    return ApiResult(isSuccess = false, errorMessage = errMsg, httpCode = response.code)
                }

                // Ambil cuma pasangan "<nama_cookie>=<token>" dari Set-Cookie (nama cookie-nya
                // ditentukan server lewat SESSION_COOKIE_NAME, default "fr3v_session"), tanpa
                // atribut Path/HttpOnly/SameSite yang ikut nempel, biar aman dipakai ulang sebagai Cookie.
                val rawSetCookie = response.header("Set-Cookie") ?: ""
                val cookie = rawSetCookie.substringBefore(";").trim()

                val user = userFromJson(JSONObject(body))
                ApiResult(isSuccess = true, data = user, sessionCookie = cookie, httpCode = response.code)
            }
        } catch (e: Exception) {
            ApiResult(isSuccess = false, errorMessage = "Tidak dapat terhubung ke server: ${e.localizedMessage}")
        }
    }

    /** Daftar user lain untuk diajak chat. Butuh session cookie hasil login. */
    fun getUsers(sessionCookie: String): ApiResult<List<User>> {
        return try {
            val req = Request.Builder()
                .url("$baseUrl/api/users")
                .get()
                .header("Cookie", sessionCookie)
                .build()

            client.newCall(req).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return ApiResult(isSuccess = false, errorMessage = "Gagal memuat daftar user (HTTP ${response.code})", httpCode = response.code)
                }
                val arr = org.json.JSONArray(body)
                val list = mutableListOf<User>()
                for (i in 0 until arr.length()) list.add(userFromJson(arr.getJSONObject(i)))
                ApiResult(isSuccess = true, data = list)
            }
        } catch (e: Exception) {
            ApiResult(isSuccess = false, errorMessage = e.localizedMessage)
        }
    }

    /** Riwayat pesan dengan satu peer. Butuh session cookie hasil login. */
    fun getMessages(sessionCookie: String, peerId: String): ApiResult<List<JSONObject>> {
        return try {
            val req = Request.Builder()
                .url("$baseUrl/api/messages/$peerId")
                .get()
                .header("Cookie", sessionCookie)
                .build()

            client.newCall(req).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return ApiResult(isSuccess = false, errorMessage = "Gagal memuat riwayat pesan (HTTP ${response.code})", httpCode = response.code)
                }
                val arr = org.json.JSONArray(body)
                val list = mutableListOf<JSONObject>()
                for (i in 0 until arr.length()) list.add(arr.getJSONObject(i))
                ApiResult(isSuccess = true, data = list)
            }
        } catch (e: Exception) {
            ApiResult(isSuccess = false, errorMessage = e.localizedMessage)
        }
    }

    /** Daftarkan/perbarui FCM token perangkat ini ke server, supaya push notification
     *  bisa dikirim ke device yang benar walau app-nya sedang tidak jalan. */
    fun registerFcmToken(sessionCookie: String, fcmToken: String): ApiResult<Unit> {
        return try {
            val payload = JSONObject().apply { put("token", fcmToken) }.toString()
            val req = Request.Builder()
                .url("$baseUrl/api/fcm-token")
                .post(payload.toRequestBody(JSON_TYPE))
                .header("Content-Type", "application/json")
                .header("Cookie", sessionCookie)
                .build()

            client.newCall(req).execute().use { response ->
                if (!response.isSuccessful) {
                    return ApiResult(isSuccess = false, errorMessage = "Gagal mendaftarkan FCM token (HTTP ${response.code})", httpCode = response.code)
                }
                ApiResult(isSuccess = true, data = Unit)
            }
        } catch (e: Exception) {
            ApiResult(isSuccess = false, errorMessage = e.localizedMessage)
        }
    }

    private fun groupFromJson(json: JSONObject) = Group(json.optString("id"), json.optString("name"), json.optString("description"), json.optString("kind", "group"), json.optString("owner_id"), json.optInt("is_closed", 0), json.optString("created_at").takeIf { it.isNotBlank() })

    fun getGroups(sessionCookie: String): ApiResult<List<Group>> = try {
        val req = Request.Builder().url("$baseUrl/api/groups").get().header("Cookie", sessionCookie).build()
        client.newCall(req).execute().use { response -> val body = response.body?.string().orEmpty(); if (!response.isSuccessful) return ApiResult(false, errorMessage = "Gagal memuat grup (HTTP ${response.code})"); val arr = org.json.JSONArray(body); ApiResult(true, (0 until arr.length()).map { groupFromJson(arr.getJSONObject(it)) }) }
    } catch (e: Exception) { ApiResult(false, errorMessage = e.localizedMessage) }

    fun createGroup(sessionCookie: String, name: String, description: String, kind: String): ApiResult<Group> = try {
        val payload = JSONObject().apply { put("name", name); put("description", description); put("kind", kind) }
        val req = Request.Builder().url("$baseUrl/api/groups").post(payload.toString().toRequestBody(JSON_TYPE)).header("Cookie", sessionCookie).build()
        client.newCall(req).execute().use { response -> val body = response.body?.string().orEmpty(); if (!response.isSuccessful) return ApiResult(false, errorMessage = "Gagal membuat ruang (HTTP ${response.code})"); ApiResult(true, groupFromJson(JSONObject(body))) }
    } catch (e: Exception) { ApiResult(false, errorMessage = e.localizedMessage) }

    fun createInvite(sessionCookie: String, groupId: String): ApiResult<String> = try {
        val req = Request.Builder().url("$baseUrl/api/groups/$groupId/invites").post("{}".toRequestBody(JSON_TYPE)).header("Cookie", sessionCookie).build()
        client.newCall(req).execute().use { response -> val body = response.body?.string().orEmpty(); if (!response.isSuccessful) return ApiResult(false, errorMessage = "Gagal membuat undangan"); ApiResult(true, JSONObject(body).optString("link")) }
    } catch (e: Exception) { ApiResult(false, errorMessage = e.localizedMessage) }

    fun joinGroup(sessionCookie: String, token: String): ApiResult<Group> = try {
        val req = Request.Builder().url("$baseUrl/api/groups/join/$token").post("{}".toRequestBody(JSON_TYPE)).header("Cookie", sessionCookie).build()
        client.newCall(req).execute().use { response -> val body = response.body?.string().orEmpty(); if (!response.isSuccessful) return ApiResult(false, errorMessage = "Link undangan tidak valid"); ApiResult(true, groupFromJson(JSONObject(body))) }
    } catch (e: Exception) { ApiResult(false, errorMessage = e.localizedMessage) }

    fun setGroupClosed(sessionCookie: String, groupId: String, closed: Boolean): ApiResult<Group> = try {
        val body = JSONObject().put("isClosed", closed).toString().toRequestBody(JSON_TYPE); val req = Request.Builder().url("$baseUrl/api/groups/$groupId/settings").patch(body).header("Cookie", sessionCookie).build()
        client.newCall(req).execute().use { response -> val text = response.body?.string().orEmpty(); if (!response.isSuccessful) return ApiResult(false, errorMessage = "Hanya admin yang dapat mengubah pengaturan"); ApiResult(true, groupFromJson(JSONObject(text))) }
    } catch (e: Exception) { ApiResult(false, errorMessage = e.localizedMessage) }

    fun addGroupAdmin(sessionCookie: String, groupId: String, username: String): ApiResult<Unit> = try {
        val body = JSONObject().put("username", username).toString().toRequestBody(JSON_TYPE); val req = Request.Builder().url("$baseUrl/api/groups/$groupId/admins").post(body).header("Cookie", sessionCookie).build()
        client.newCall(req).execute().use { response -> if (!response.isSuccessful) return ApiResult(false, errorMessage = "Gagal menambahkan admin"); ApiResult(true, Unit) }
    } catch (e: Exception) { ApiResult(false, errorMessage = e.localizedMessage) }

    fun logout(sessionCookie: String) {
        try {
            val req = Request.Builder()
                .url("$baseUrl/api/auth/logout")
                .post("{}".toRequestBody(JSON_TYPE))
                .header("Cookie", sessionCookie)
                .build()
            client.newCall(req).execute().close()
        } catch (_: Exception) {
            // logout gagal terkirim bukan masalah besar — cookie lokal tetap dihapus di client
        }
    }
}
