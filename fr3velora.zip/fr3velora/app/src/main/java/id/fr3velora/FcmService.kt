package id.fr3velora

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import id.fr3velora.network.ApiClient

/**
 * Menerima push dari FCM. Bedanya dengan ChatConnectionService (WebSocket):
 * FCM tetap bisa membangunkan aplikasi walau prosesnya sudah mati (app di-swipe
 * dari recent apps) — dikirim lewat Google Play Services di level sistem, bukan
 * lewat koneksi yang kita pegang sendiri. Ini yang bikin notifikasi tetap masuk
 * meski app "ditutup total".
 *
 * Catatan jujur: ini tidak berlaku kalau user secara eksplisit "Force stop" app
 * dari Setelan Android — itu batas keras yang berlaku untuk SEMUA aplikasi
 * (termasuk WhatsApp, Telegram, dll), bukan sesuatu yang bisa dilewati kode
 * aplikasi manapun.
 *
 * Pesan dikirim server sebagai "data message" (bukan "notification message"),
 * supaya kita yang kontrol penuh tampilannya lewat NotificationHelper, dan supaya
 * onMessageReceived tetap terpanggil walau app di background/mati (data message
 * prioritas tinggi dari server).
 */
class FcmService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        registerTokenWithServer(token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val data = message.data
        val from = data["from"] ?: return
        val fromName = data["fromName"] ?: from
        val text = data["text"] ?: return

        val myUserId = SessionManager(applicationContext).userId
        if (myUserId == null || from == myUserId) return

        // Kalau chat room dengan pengirim ini sedang dibuka di layar, tidak perlu
        // notifikasi pop-up (sama seperti logic di ChatConnectionService).
        if (ChatState.activePeerId == from) return

        NotificationHelper.showMessageNotification(
            context = applicationContext,
            fromUserId = from,
            fromName = fromName,
            text = text
        )
    }

    private fun registerTokenWithServer(token: String) {
        val session = SessionManager(applicationContext)
        val cookie = session.sessionCookie ?: return // belum login, daftarkan nanti setelah login

        Thread {
            ApiClient(getString(R.string.api_base_url)).registerFcmToken(cookie, token)
        }.start()
    }
}
