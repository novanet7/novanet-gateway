package id.fr3velora.model

data class Message(
    val id: String? = null,
    val type: String = "message",
    val from: String = "",
    val to: String = "",
    val roomId: String? = null,
    val roomKind: String? = null,
    val text: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val attachmentName: String? = null,
    val attachmentMime: String? = null,
    val attachmentBase64: String? = null,
    val attachmentPath: String? = null,
    val status: String = "pending", // pending | sent | delivered | read
    val messageId: String? = null, // dipakai oleh event ACK/receipt/delete
    val mode: String? = null // delete: me | everyone
) {
    val hasAttachment: Boolean get() = !attachmentName.isNullOrBlank() && !attachmentMime.isNullOrBlank()
}
