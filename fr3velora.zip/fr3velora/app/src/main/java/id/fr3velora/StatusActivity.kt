package id.fr3velora

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class StatusActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_status)
        val input = findViewById<EditText>(R.id.etStatus); input.setText(getPreferences(0).getString("status", ""))
        findViewById<Button>(R.id.btnSaveStatus).setOnClickListener { getPreferences(0).edit().putString("status", input.text.toString().trim()).apply(); Toast.makeText(this, "Status disimpan di perangkat", Toast.LENGTH_SHORT).show(); finish() }
    }
}
