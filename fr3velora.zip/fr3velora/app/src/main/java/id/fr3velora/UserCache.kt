package id.fr3velora

/** Cache sederhana userId -> username, diisi ChatConnectionService dari GET /api/users,
 *  dipakai supaya notifikasi pesan masuk menampilkan nama, bukan ID mentah. */
object UserCache {
    @Volatile
    var map: Map<String, String> = emptyMap()

    fun nameFor(userId: String): String = map[userId] ?: userId
}
