package id.fr3velora.model

// Field ini mengikuti persis field yang dibalikin server novanet.uno di
// POST /api/auth/google/mobile dan endpoint lain yang butuh data user publik.
data class User(
    val id: String,
    val username: String,
    val email: String = "",
    val api_key: String = "",
    val avatar_url: String? = null,
    val created_at: String? = null
)
