package id.fr3velora

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import id.fr3velora.model.Group
import id.fr3velora.network.ApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GroupsActivity : AppCompatActivity() {
    private lateinit var session: SessionManager; private lateinit var adapter: GroupAdapter
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_groups); session = SessionManager(this); val rv = findViewById<RecyclerView>(R.id.rvGroups); rv.layoutManager = LinearLayoutManager(this); adapter = GroupAdapter(mutableListOf(), { openGroup(it) }, { showAdminMenu(it) }); rv.adapter = adapter; findViewById<android.view.View>(R.id.btnCreateGroup).setOnClickListener { showCreateDialog() }; loadGroups() }
    private fun loadGroups() { val cookie = session.sessionCookie ?: return; lifecycleScope.launch { val result = withContext(Dispatchers.IO) { ApiClient(getString(R.string.api_base_url)).getGroups(cookie) }; if (result.isSuccess) adapter.replace(result.data ?: emptyList()) else Toast.makeText(this@GroupsActivity, result.errorMessage, Toast.LENGTH_SHORT).show() } }
    private fun showCreateDialog() { val input = EditText(this); input.hint = "Nama grup/channel"; AlertDialog.Builder(this).setTitle("Buat ruang").setView(input).setSingleChoiceItems(arrayOf("Grup", "Channel"), 0) { _, _ -> }.setPositiveButton("Buat") { _, _ -> create(input.text.toString().trim(), "group") }.setNeutralButton("Channel") { _, _ -> create(input.text.toString().trim(), "channel") }.setNegativeButton("Batal", null).show() }
    private fun create(name: String, kind: String) { if (name.isBlank()) return; val cookie = session.sessionCookie ?: return; lifecycleScope.launch { val result = withContext(Dispatchers.IO) { ApiClient(getString(R.string.api_base_url)).createGroup(cookie, name, "", kind) }; if (result.isSuccess) { loadGroups(); Toast.makeText(this@GroupsActivity, "Berhasil dibuat", Toast.LENGTH_SHORT).show() } else Toast.makeText(this@GroupsActivity, result.errorMessage, Toast.LENGTH_SHORT).show() } }
    private fun openGroup(group: Group) { startActivity(Intent(this, ChatRoomActivity::class.java).putExtra("roomId", group.id).putExtra("roomKind", group.kind).putExtra("peerName", if (group.isChannel) "# ${group.name}" else group.name)) }
    private fun shareInvite(group: Group) { val cookie = session.sessionCookie ?: return; lifecycleScope.launch { val result = withContext(Dispatchers.IO) { ApiClient(getString(R.string.api_base_url)).createInvite(cookie, group.id) }; if (result.isSuccess) startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "Gabung ${group.name}: ${result.data}"), "Bagikan link undangan")) else Toast.makeText(this@GroupsActivity, result.errorMessage, Toast.LENGTH_SHORT).show() } }
    private fun showAdminMenu(group: Group) { val labels = arrayOf("Bagikan link undangan", if (group.isClosed) "Buka grup" else "Tutup grup", "Tambahkan admin"); AlertDialog.Builder(this).setTitle("Admin ${group.name}").setItems(labels) { _, which -> when (which) { 0 -> shareInvite(group); 1 -> toggleClosed(group); 2 -> addAdminDialog(group) } }.show() }
    private fun toggleClosed(group: Group) { val cookie = session.sessionCookie ?: return; lifecycleScope.launch { val result = withContext(Dispatchers.IO) { ApiClient(getString(R.string.api_base_url)).setGroupClosed(cookie, group.id, !group.isClosed) }; Toast.makeText(this@GroupsActivity, result.errorMessage ?: if (!group.isClosed) "Grup ditutup" else "Grup dibuka", Toast.LENGTH_SHORT).show(); loadGroups() } }
    private fun addAdminDialog(group: Group) { val input = EditText(this); input.hint = "@username anggota"; AlertDialog.Builder(this).setTitle("Tambahkan admin").setView(input).setPositiveButton("Tambahkan") { _, _ -> val cookie = session.sessionCookie ?: return@setPositiveButton; lifecycleScope.launch { val result = withContext(Dispatchers.IO) { ApiClient(getString(R.string.api_base_url)).addGroupAdmin(cookie, group.id, input.text.toString().trim()) }; Toast.makeText(this@GroupsActivity, result.errorMessage ?: "Admin ditambahkan", Toast.LENGTH_SHORT).show() } }.setNegativeButton("Batal", null).show() }
}
