package id.fr3velora.network

import com.google.gson.Gson
import id.fr3velora.model.Message
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

// Koneksi WebSocket real-time untuk chat. Otentikasi memakai session cookie yang
// sama dengan REST (fr3v_session=...), dikirim lewat header "Cookie" saat handshake —
// konsisten dengan pola auth cookie-based di project lama, bukan token di query string.
class WebSocketManager(
    private val wsUrl: String,
    private val sessionCookie: String,
    private val onMessage: (Message) -> Unit,
    private val onStateChange: (connected: Boolean) -> Unit
) {
    private val gson = Gson()
    private var webSocket: WebSocket? = null

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS) // koneksi WS tetap terbuka
        .build()

    fun connect() {
        val request = Request.Builder()
            .url(wsUrl)
            .header("Cookie", sessionCookie)
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                onStateChange(true)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val message = gson.fromJson(text, Message::class.java)
                    onMessage(message)
                } catch (_: Exception) {
                    // abaikan payload yang tidak sesuai format
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                onStateChange(false)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                onStateChange(false)
            }
        })
    }

    fun send(message: Message) {
        webSocket?.send(gson.toJson(message))
    }

    fun disconnect() {
        webSocket?.close(1000, "closed")
        client.dispatcher.executorService.shutdown()
    }
}
