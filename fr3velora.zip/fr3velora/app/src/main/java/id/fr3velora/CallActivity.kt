package id.fr3velora

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import id.fr3velora.model.Message
import java.util.UUID

/** Layar panggilan dan signaling. Media WebRTC dapat dipasang pada titik status offer/answer. */
class CallActivity : AppCompatActivity() {
    private lateinit var peerId: String; private lateinit var mode: String; private var callId: String = UUID.randomUUID().toString(); private var incoming = false
    private lateinit var status: TextView
    private val callPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.all { it } && !incoming) sendOffer() else if (result.values.any { !it }) status.text = "Izin kamera/mikrofon diperlukan untuk panggilan"
    }
    private val events = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.getStringExtra("callId") != callId && callId.isNotBlank()) return
            when (intent?.getStringExtra("type")) {
                "call_answer" -> status.text = "Terhubung"
                "call_reject" -> { status.text = "Panggilan ditolak"; finish() }
                "call_end" -> { status.text = "Panggilan berakhir"; finish() }
                "call_ice", "call_offer" -> if (incoming) status.text = "Berdering..."
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_call)
        peerId = intent.getStringExtra("peerId") ?: intent.getStringExtra("from") ?: ""; mode = intent.getStringExtra("mode") ?: "voice"; incoming = intent.getBooleanExtra("incoming", false); callId = intent.getStringExtra("callId") ?: callId
        findViewById<TextView>(R.id.tvCallTitle).text = if (mode == "video") "Panggilan video" else "Panggilan suara"
        status = findViewById(R.id.tvCallStatus); status.text = if (incoming) "Panggilan masuk — berdering..." else "Memanggil..."
        findViewById<Button>(R.id.btnAccept).setOnClickListener { incoming = false; status.text = "Terhubung"; ChatConnectionService.send(Message(type = "call_answer", to = peerId, messageId = callId, mode = mode)) }
        findViewById<Button>(R.id.btnReject).setOnClickListener { ChatConnectionService.send(Message(type = "call_reject", to = peerId, messageId = callId, mode = mode)); finish() }
        findViewById<Button>(R.id.btnMute).setOnClickListener { it.isSelected = !it.isSelected; (it as Button).text = if (it.isSelected) "Unmute" else "Mute" }
        findViewById<Button>(R.id.btnEnd).setOnClickListener { ChatConnectionService.send(Message(type = "call_end", to = peerId, messageId = callId, mode = mode)); finish() }
        if (needsCallPermissions()) callPermissionLauncher.launch(arrayOf(android.Manifest.permission.CAMERA, android.Manifest.permission.RECORD_AUDIO)) else if (!incoming) sendOffer()
    }
    private fun needsCallPermissions() = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED
    private fun sendOffer() { ChatConnectionService.send(Message(type = "call_offer", to = peerId, messageId = callId, mode = mode, text = "offer")) }
    override fun onResume() { super.onResume(); val filter = IntentFilter("id.fr3velora.CALL_EVENT"); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) registerReceiver(events, filter, Context.RECEIVER_NOT_EXPORTED) else @Suppress("UnspecifiedRegisterReceiverFlag") registerReceiver(events, filter) }
    override fun onPause() { super.onPause(); runCatching { unregisterReceiver(events) } }
}
