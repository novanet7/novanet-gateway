package id.fr3velora

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import id.fr3velora.model.Message
import id.fr3velora.network.ApiClient
import id.fr3velora.network.WebSocketManager

class ChatConnectionService : Service() {
    companion object {
        private const val NOTIF_ID = 1
        private var wsManager: WebSocketManager? = null
        fun send(message: Message) { wsManager?.send(message) }
        fun isConnected(): Boolean = wsManager != null
    }
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var store: LocalChatStore
    private var retryStarted = false
    private val retryTask = object : Runnable {
        override fun run() { if (wsManager != null) flushOutbox(); handler.postDelayed(this, 5000) }
    }

    override fun onCreate() { super.onCreate(); store = LocalChatStore(this); NotificationHelper.createChannel(this) }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { startForeground(NOTIF_ID, buildForegroundNotification()); connectIfNeeded(); if (!retryStarted) { retryStarted = true; handler.postDelayed(retryTask, 5000) }; return START_STICKY }
    private fun buildForegroundNotification(): Notification = NotificationCompat.Builder(this, "fr3velora_messages").setSmallIcon(R.drawable.ic_notification).setContentTitle("fr3velora aktif").setContentText("Menunggu pesan masuk...").setPriority(NotificationCompat.PRIORITY_MIN).setOngoing(true).build()

    private fun connectIfNeeded() {
        if (wsManager != null) return
        val session = SessionManager(applicationContext); val cookie = session.sessionCookie ?: return
        refreshUserCache(cookie)
        wsManager = WebSocketManager(getString(R.string.ws_base_url), cookie, { handleIncoming(it) }) { connected ->
            if (connected) flushOutbox() else { wsManager = null; handler.postDelayed({ connectIfNeeded() }, 3000) }
        }
        wsManager?.connect()
    }
    private fun refreshUserCache(cookie: String) { Thread { val result = ApiClient(getString(R.string.api_base_url)).getUsers(cookie); if (result.isSuccess) UserCache.map = (result.data ?: emptyList()).associate { it.id to it.username } }.start() }
    private fun flushOutbox() { Thread { store.pending().forEach { wsManager?.send(store.wireMessage(it)) } }.start() }

    private fun handleIncoming(event: Message) {
        when (event.type) {
            "ack" -> { if (event.status == "sent") store.updateStatus(event.messageId, "sent"); broadcast(event.messageId) }
            "delivered" -> { store.updateStatus(event.messageId, "delivered"); broadcast(event.messageId) }
            "read" -> { store.updateStatus(event.messageId, "read"); broadcast(event.messageId) }
            "delete" -> { if (event.mode == "everyone") store.deleteForEveryone(event.messageId); broadcast(event.messageId) }
            "call_offer", "call_answer", "call_ice", "call_end", "call_reject" -> broadcastCall(event)
            "error" -> Unit
            else -> receiveMessage(event)
        }
    }
    private fun receiveMessage(message: Message) {
        val myUserId = SessionManager(applicationContext).userId ?: return
        if (message.to != myUserId && message.roomId == null) return
        val stored = store.saveIncoming(message)
        send(Message(type = "delivered", from = myUserId, to = message.from, messageId = stored.id))
        if (ChatState.activePeerId == message.from) { store.updateStatus(stored.id, "read"); send(Message(type = "read", from = myUserId, to = message.from, messageId = stored.id)) }
        broadcast(stored.id)
        if (ChatState.activePeerId != message.from) NotificationHelper.showMessageNotification(applicationContext, message.from, UserCache.nameFor(message.from), message.text.ifBlank { message.attachmentName ?: "Lampiran" })
    }
    private fun broadcast(id: String?) { if (id == null) return; Intent("id.fr3velora.NEW_MESSAGE").apply { putExtra("messageId", id); setPackage(packageName) }.also { sendBroadcast(it) } }
    private fun broadcastCall(event: Message) {
        Intent("id.fr3velora.CALL_EVENT").apply {
            putExtra("type", event.type); putExtra("from", event.from); putExtra("to", event.to); putExtra("mode", event.mode); putExtra("callId", event.messageId); putExtra("payload", event.text); setPackage(packageName)
        }.also { sendBroadcast(it) }
    }
    override fun onDestroy() { super.onDestroy(); handler.removeCallbacksAndMessages(null); wsManager?.disconnect(); wsManager = null }
    override fun onBind(intent: Intent?) = null
}
