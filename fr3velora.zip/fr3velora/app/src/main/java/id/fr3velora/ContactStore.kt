package id.fr3velora

import android.content.Context
import id.fr3velora.model.User

class ContactStore(context: Context) {
    private val prefs = context.getSharedPreferences("contacts", Context.MODE_PRIVATE)
    fun allIds(): Set<String> = prefs.getStringSet("ids", emptySet()) ?: emptySet()
    fun add(user: User) { prefs.edit().putStringSet("ids", allIds() + user.id).apply() }
    fun remove(user: User) { prefs.edit().putStringSet("ids", allIds() - user.id).apply() }
}
