package id.fr3velora

/**
 * Menyimpan peerId dari room chat yang sedang dibuka di layar (kalau ada).
 * Dipakai ChatConnectionService untuk memutuskan: kalau pesan baru datang dari
 * peer yang chat room-nya SEDANG dibuka, tidak perlu tampilkan notifikasi pop-up
 * (cukup update UI langsung) — persis seperti perilaku app chat pada umumnya.
 */
object ChatState {
    @Volatile
    var activePeerId: String? = null
}
