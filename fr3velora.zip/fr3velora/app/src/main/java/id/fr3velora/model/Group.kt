package id.fr3velora.model

data class Group(
    val id: String,
    val name: String,
    val description: String = "",
    val kind: String = "group",
    val owner_id: String = "",
    val is_closed: Int = 0,
    val created_at: String? = null
) {
    val isChannel: Boolean get() = kind == "channel"
    val isClosed: Boolean get() = is_closed == 1
}
