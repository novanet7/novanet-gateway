package id.fr3velora

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import id.fr3velora.network.ApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Login dengan memilih salah satu akun Google di perangkat (account picker).
// idToken dikirim ke POST /api/auth/google/mobile — server membalas objek user +
// session cookie lewat header Set-Cookie. Akun baru dibuat otomatis kalau email Google-nya
// belum pernah login.
class LoginActivity : AppCompatActivity() {

    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var session: SessionManager
    private val animators = mutableListOf<Animator>()

    private val signInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            val idToken = account?.idToken
            if (idToken != null) {
                sendTokenToServer(idToken)
            } else {
                showError("Gagal mengambil token dari Google. Coba lagi.")
            }
        } catch (e: ApiException) {
            showError(
                when (e.statusCode) {
                    12501 -> "Login dibatalkan."
                    7 -> "Tidak ada koneksi internet. Periksa jaringan lalu coba lagi."
                    10 -> "Konfigurasi login belum cocok (kode 10). Cek SHA-1 dan Web client ID."
                    else -> "Login gagal (kode ${e.statusCode}). Coba lagi."
                }
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        session = SessionManager(this)
        if (session.isLoggedIn()) {
            goToChatList()
            return
        }

        setupSystemBars()

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.google_web_client_id))
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)

        val btn = findViewById<View>(R.id.btnGoogleSignIn)
        btn.setOnClickListener {
            // signOut dulu supaya pemilih akun Google selalu muncul, bukan langsung
            // memakai akun terakhir.
            googleSignInClient.signOut().addOnCompleteListener {
                signInLauncher.launch(googleSignInClient.signInIntent)
            }
        }
        enablePressFeedback(btn)

        playEntrance()
        startAmbientMotion()
    }

    // ---------- UI ----------

    private fun setupSystemBars() {
        window.statusBarColor = Color.parseColor("#070F1A")
        window.navigationBarColor = Color.parseColor("#0F3D91")
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = false
    }

    private fun dp(value: Int): Float = value * resources.displayMetrics.density

    /** Satu rangkaian masuk: logo muncul membal, lalu elemen lain naik berurutan. */
    private fun playEntrance() {
        val logo = findViewById<View>(R.id.logoWrap)
        logo.alpha = 0f
        logo.scaleX = 0.6f
        logo.scaleY = 0.6f
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(650)
            .setInterpolator(OvershootInterpolator(1.8f))
            .start()

        val rest = listOf(
            R.id.tvTitle, R.id.tvTagline, R.id.chip1, R.id.chip2, R.id.chip3,
            R.id.btnGoogleSignIn, R.id.tvNote
        ).map { findViewById<View>(it) }

        rest.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dp(26)
            v.animate().alpha(1f).translationY(0f)
                .setDuration(520)
                .setStartDelay(260L + i * 90L)
                .setInterpolator(DecelerateInterpolator(1.6f))
                .start()
        }
    }

    /** Gerak latar yang pelan: gelembung melayang + cincin logo berdenyut. */
    private fun startAmbientMotion() {
        drift(findViewById(R.id.bubbleA), dp(14), dp(18), 6200)
        drift(findViewById(R.id.bubbleB), dp(12), dp(16), 7400)
        drift(findViewById(R.id.bubbleC), dp(18), dp(14), 8600)

        val ring = findViewById<View>(R.id.logoRing)
        val pulse = ObjectAnimator.ofPropertyValuesHolder(
            ring,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.4f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.4f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.9f, 0f)
        ).apply {
            duration = 2400
            startDelay = 900
            repeatCount = ValueAnimator.INFINITE
            interpolator = DecelerateInterpolator()
            start()
        }
        animators += pulse
    }

    private fun drift(view: View, dx: Float, dy: Float, duration: Long) {
        val a = ObjectAnimator.ofPropertyValuesHolder(
            view,
            PropertyValuesHolder.ofFloat(View.TRANSLATION_X, -dx, dx),
            PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, -dy, dy)
        ).apply {
            this.duration = duration
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        animators += a
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun enablePressFeedback(view: View) {
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false // biarkan klik tetap diproses
        }
    }

    // ---------- Login ----------

    private fun sendTokenToServer(idToken: String) {
        setLoading(true)
        val api = ApiClient(getString(R.string.api_base_url))

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { api.loginWithGoogle(idToken) }
            setLoading(false)

            if (result.isSuccess && result.data != null) {
                val user = result.data
                session.sessionCookie = result.sessionCookie
                session.userId = user.id
                session.username = user.username
                session.email = user.email
                session.apiKey = user.api_key
                session.avatarUrl = user.avatar_url
                goToChatList()
            } else {
                showError(result.errorMessage ?: "Login gagal. Coba lagi.")
            }
        }
    }

    private fun goToChatList() {
        startActivity(Intent(this, ChatListActivity::class.java))
        finish()
    }

    private fun setLoading(loading: Boolean) {
        findViewById<View>(R.id.progressBar).visibility = if (loading) View.VISIBLE else View.GONE
        findViewById<View>(R.id.ivGoogle).visibility = if (loading) View.INVISIBLE else View.VISIBLE
        findViewById<TextView>(R.id.btnText).text =
            if (loading) "Menghubungkan…" else "Lanjutkan dengan Google"
        findViewById<View>(R.id.btnGoogleSignIn).isEnabled = !loading
        if (loading) findViewById<View>(R.id.tvError).visibility = View.GONE
    }

    private fun showError(message: String) {
        val tv = findViewById<TextView>(R.id.tvError)
        tv.text = message
        tv.visibility = View.VISIBLE
        tv.alpha = 0f
        tv.animate().alpha(1f).setDuration(220).start()

        // Tombol bergetar sebentar sebagai tanda gagal.
        ObjectAnimator.ofFloat(
            findViewById<View>(R.id.btnGoogleSignIn), View.TRANSLATION_X,
            0f, -dp(10), dp(10), -dp(7), dp(7), -dp(3), 0f
        ).setDuration(420).start()
    }

    override fun onDestroy() {
        animators.forEach { it.cancel() }
        animators.clear()
        super.onDestroy()
    }
}
