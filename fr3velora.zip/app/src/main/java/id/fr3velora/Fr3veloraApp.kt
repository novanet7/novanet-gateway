package id.fr3velora

import android.app.Application

class Fr3veloraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createChannel(this)
        // Jadwalkan keep-alive jika sudah login (aman dipanggil berulang)
        if (!SessionManager(this).sessionCookie.isNullOrBlank()) {
            KeepAliveScheduler.schedule(this)
        }
    }
}
