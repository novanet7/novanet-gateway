package id.fr3velora

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import id.fr3velora.model.Message
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/** Penyimpanan privat APK: isi chat, outbox, dan attachment tidak masuk database server. */
class LocalChatStore(context: Context) {
    private val appContext = context.applicationContext
    private val gson = Gson()
    private val root = File(appContext.filesDir, "chat_local").apply { mkdirs() }
    val attachmentDir: File get() = root
    private val messagesFile = File(root, "messages.json")
    private val lock = Any()

    fun all(): MutableList<Message> = synchronized(lock) {
        if (!messagesFile.exists()) return@synchronized mutableListOf()
        runCatching { gson.fromJson<MutableList<Message>>(messagesFile.readText(), object : TypeToken<MutableList<Message>>() {}.type) ?: mutableListOf() }
            .getOrDefault(mutableListOf())
    }
    fun conversation(myId: String, peerId: String): List<Message> = all().filter { (it.from == myId && it.to == peerId) || (it.from == peerId && it.to == myId) }.sortedBy { it.timestamp }
    fun conversationRoom(roomId: String): List<Message> = all().filter { it.roomId == roomId }.sortedBy { it.timestamp }
    fun find(id: String?): Message? = id?.let { value -> all().firstOrNull { it.id == value } }
    fun pending(): List<Message> = all().filter { it.from.isNotBlank() && it.status == "pending" }

    fun save(message: Message) = synchronized(lock) {
        val list = all(); val stored = message.copy(attachmentBase64 = null, id = message.id ?: UUID.randomUUID().toString())
        val index = list.indexOfFirst { it.id == stored.id }
        if (index >= 0) list[index] = stored else list.add(stored)
        messagesFile.writeText(gson.toJson(list))
    }

    fun updateText(id: String?, text: String, edited: Boolean = true) = synchronized(lock) {
        if (id == null) return@synchronized
        val list = all(); val index = list.indexOfFirst { it.id == id }
        if (index >= 0) {
            list[index] = list[index].copy(text = text, edited = edited, editedAt = System.currentTimeMillis())
            messagesFile.writeText(gson.toJson(list))
        }
    }

    fun updateReactions(id: String?, reactions: String?) = synchronized(lock) {
        if (id == null) return@synchronized
        val list = all(); val index = list.indexOfFirst { it.id == id }
        if (index >= 0) {
            list[index] = list[index].copy(reactions = reactions)
            messagesFile.writeText(gson.toJson(list))
        }
    }

    fun updatePinned(id: String?, pinned: Boolean) = synchronized(lock) {
        if (id == null) return@synchronized
        val list = all(); val index = list.indexOfFirst { it.id == id }
        if (index >= 0) {
            list[index] = list[index].copy(pinned = pinned)
            messagesFile.writeText(gson.toJson(list))
        }
    }

    fun clearConversation(myId: String, peerId: String) = synchronized(lock) {
        val list = all().filterNot {
            (it.from == myId && it.to == peerId) || (it.from == peerId && it.to == myId)
        }.toMutableList()
        messagesFile.writeText(gson.toJson(list))
    }

    fun updateStatus(id: String?, status: String) = synchronized(lock) {
        if (id == null) return@synchronized
        val list = all(); val index = list.indexOfFirst { it.id == id }
        if (index >= 0) { list[index] = list[index].copy(status = status); messagesFile.writeText(gson.toJson(list)) }
    }

    fun deleteForMe(id: String?) = synchronized(lock) {
        if (id == null) return@synchronized
        val list = all().filterNot { it.id == id }.toMutableList(); messagesFile.writeText(gson.toJson(list))
    }

    fun deleteForEveryone(id: String?) = synchronized(lock) {
        if (id == null) return@synchronized
        val list = all(); val index = list.indexOfFirst { it.id == id }
        if (index >= 0) { list[index] = list[index].copy(text = "Pesan ini dihapus", attachmentName = null, attachmentMime = null, attachmentPath = null, attachmentBase64 = null, status = "read"); messagesFile.writeText(gson.toJson(list)) }
    }

    fun saveIncoming(message: Message): Message {
        if (!message.hasAttachment || message.attachmentBase64.isNullOrBlank()) { save(message.copy(status = "delivered")); return message.copy(status = "delivered") }
        val file = File(root, "${System.currentTimeMillis()}_${UUID.randomUUID()}_${safeFileName(message.attachmentName!!)}")
        return runCatching {
            FileOutputStream(file).use { it.write(Base64.decode(message.attachmentBase64, Base64.DEFAULT)) }
            message.copy(attachmentBase64 = null, attachmentPath = file.name, status = "delivered").also { save(it) }
        }.getOrElse { message.copy(attachmentBase64 = null, status = "delivered").also { save(it) } }
    }

    fun wireMessage(message: Message): Message {
        if (!message.hasAttachment || message.attachmentPath.isNullOrBlank()) return message.copy(attachmentBase64 = null)
        val file = file(message.attachmentPath) ?: return message.copy(attachmentBase64 = null)
        val encoded = runCatching { Base64.encodeToString(file.readBytes(), Base64.NO_WRAP) }.getOrNull()
        return message.copy(attachmentBase64 = encoded, attachmentPath = null)
    }

    fun copyAttachment(uri: Uri, suggestedName: String?): String? = runCatching {
        val file = File(root, "${System.currentTimeMillis()}_${UUID.randomUUID()}_${safeFileName(suggestedName ?: "attachment")}")
        appContext.contentResolver.openInputStream(uri).use { input -> requireNotNull(input); FileOutputStream(file).use { output -> input.copyTo(output) } }
        file.name
    }.getOrNull()
    fun file(relativePath: String?): File? = relativePath?.let { File(root, it).takeIf(File::exists) }

    /** Salin file lokal (mis. hasil rekam suara) ke storage chat. */
    fun importFile(source: File, suggestedName: String?): String? = runCatching {
        val file = File(root, "${System.currentTimeMillis()}_${UUID.randomUUID()}_${safeFileName(suggestedName ?: "voice.m4a")}")
        source.copyTo(file, overwrite = true)
        file.name
    }.getOrNull()
    private fun safeFileName(value: String) = value.replace(Regex("[^A-Za-z0-9._-]"), "_")
}
