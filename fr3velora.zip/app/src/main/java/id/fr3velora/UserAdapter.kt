package id.fr3velora

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import id.fr3velora.model.User

/** Satu baris di tab Chat: user + pratinjau pesan terakhir, waktu, dan jumlah belum dibaca. */
data class ChatRow(val user: User, val preview: String, val time: String, val unread: Int, val timestamp: Long = 0L)

class UserAdapter(private val rows: MutableList<ChatRow>, private val onClick: (User) -> Unit) : RecyclerView.Adapter<UserAdapter.VH>() {
    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val avatar: ImageView = view.findViewById(R.id.ivAvatar)
        val initial: TextView = view.findViewById(R.id.tvInitial)
        val name: TextView = view.findViewById(R.id.tvName)
        val preview: TextView = view.findViewById(R.id.tvPreview)
        val time: TextView = view.findViewById(R.id.tvTime)
        val unread: TextView = view.findViewById(R.id.tvUnread)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_user, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val row = rows[position]; val user = row.user
        holder.name.text = "@${user.username}"
        holder.preview.text = row.preview.ifBlank { user.email }
        holder.time.text = row.time
        holder.time.visibility = if (row.time.isBlank()) View.GONE else View.VISIBLE
        holder.unread.text = if (row.unread > 99) "99+" else row.unread.toString()
        holder.unread.visibility = if (row.unread > 0) View.VISIBLE else View.GONE
        holder.time.setTextColor(holder.time.context.getColor(if (row.unread > 0) R.color.brand_primary else R.color.text_secondary))
        bindAvatar(holder.avatar, holder.initial, user.username, user.avatar_url)
        holder.itemView.setOnClickListener { onClick(user) }
    }

    override fun getItemCount() = rows.size
    fun replace(newRows: List<ChatRow>) { rows.clear(); rows.addAll(newRows); notifyDataSetChanged() }
}
