package id.fr3velora

import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import id.fr3velora.model.User
import java.net.URL

class UserAdapter(private val users: MutableList<User>, private val onClick: (User) -> Unit) : RecyclerView.Adapter<UserAdapter.VH>() {
    class VH(view: android.view.View) : RecyclerView.ViewHolder(view) { val avatar: android.widget.ImageView = view.findViewById(R.id.ivAvatar); val initial: android.widget.TextView = view.findViewById(R.id.tvInitial); val name: android.widget.TextView = view.findViewById(R.id.tvName); val email: android.widget.TextView = view.findViewById(R.id.tvEmail) }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_user, parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) {
        val user = users[position]; holder.name.text = "@${user.username}"; holder.email.text = user.email
        holder.avatar.setImageDrawable(null); holder.avatar.backgroundTintList = ColorStateList.valueOf(avatarColor(user.username)); holder.initial.text = avatarInitial(user.username); holder.initial.visibility = android.view.View.VISIBLE; holder.itemView.tag = user.id
        if (!user.avatar_url.isNullOrBlank()) Thread { runCatching { BitmapFactory.decodeStream(URL(user.avatar_url).openStream()) }.getOrNull()?.let { bitmap -> holder.avatar.post { if (holder.itemView.tag == user.id) { holder.avatar.setImageBitmap(bitmap); holder.initial.visibility = android.view.View.GONE } } } }.start()
        holder.itemView.setOnClickListener { onClick(user) }
    }
    override fun getItemCount() = users.size
    fun replace(newUsers: List<User>) { users.clear(); users.addAll(newUsers); notifyDataSetChanged() }
}
