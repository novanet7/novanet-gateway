package id.fr3velora.network

import id.fr3velora.model.User
import id.fr3velora.model.Group
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ApiResult<T>(
    val isSuccess: Boolean,
    val data: T? = null,
    val errorMessage: String? = null,
    val sessionCookie: String? = null,
    val httpCode: Int = 0
)

/**
 * Client REST ke server fr3velora.
 * BASE_URL bisa diganti. Session pakai cookie "fr3v_session=...".
 */
class ApiClient(private val baseUrl: String) {

    private val JSON_TYPE = "application/json; charset=utf-8".toMediaType()

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    val serverBase: String get() = baseUrl.trimEnd('/')

    private fun userFromJson(json: JSONObject): User = User(
        id = json.optString("id", ""),
        username = json.optString("username", ""),
        email = json.optString("email", ""),
        api_key = json.optString("api_key", ""),
        avatar_url = json.optString("avatar_url", "").takeIf { it.isNotBlank() },
        display_name = json.optString("display_name", ""),
        bio = json.optString("bio", ""),
        created_at = if (json.has("created_at") && !json.isNull("created_at")) json.optString("created_at") else null
    )

    private fun groupFromJson(json: JSONObject): Group = Group(
        id = json.optString("id", ""),
        name = json.optString("name", ""),
        description = json.optString("description", ""),
        kind = json.optString("kind", "group"),
        owner_id = json.optString("owner_id", ""),
        is_closed = json.optInt("is_closed", 0),
        
        created_at = json.optString("created_at", "")
    )

    /** Absolute avatar URL (server relative path → full URL). */
    fun absoluteAvatarUrl(avatarUrl: String?): String? {
        if (avatarUrl.isNullOrBlank()) return null
        if (avatarUrl.startsWith("http://") || avatarUrl.startsWith("https://")) return avatarUrl
        return serverBase + if (avatarUrl.startsWith("/")) avatarUrl else "/$avatarUrl"
    }

    fun loginWithGoogle(idToken: String): ApiResult<User> {
        return try {
            val payload = JSONObject().apply { put("idToken", idToken) }.toString()
            val req = Request.Builder()
                .url("$baseUrl/api/auth/google/mobile")
                .post(payload.toRequestBody(JSON_TYPE))
                .header("Content-Type", "application/json")
                .header("User-Agent", "fr3velora/1.0 (Android)")
                .build()

            client.newCall(req).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errMsg = try {
                        JSONObject(body).optString("error", "Login Google gagal (HTTP ${response.code})")
                    } catch (_: Exception) {
                        "Login Google gagal (HTTP ${response.code})"
                    }
                    return ApiResult(isSuccess = false, errorMessage = errMsg, httpCode = response.code)
                }
                val rawSetCookie = response.header("Set-Cookie") ?: ""
                val cookie = rawSetCookie.substringBefore(";").trim()
                val user = userFromJson(JSONObject(body))
                ApiResult(isSuccess = true, data = user, sessionCookie = cookie, httpCode = response.code)
            }
        } catch (e: Exception) {
            ApiResult(isSuccess = false, errorMessage = "Tidak dapat terhubung ke server: ${e.localizedMessage}")
        }
    }

    fun getUsers(sessionCookie: String): ApiResult<List<User>> {
        return try {
            val req = Request.Builder()
                .url("$baseUrl/api/users")
                .get()
                .header("Cookie", sessionCookie)
                .build()
            client.newCall(req).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return ApiResult(isSuccess = false, errorMessage = "Gagal memuat daftar user (HTTP ${response.code})", httpCode = response.code)
                }
                val arr = org.json.JSONArray(body)
                val list = mutableListOf<User>()
                for (i in 0 until arr.length()) list.add(userFromJson(arr.getJSONObject(i)))
                ApiResult(isSuccess = true, data = list)
            }
        } catch (e: Exception) {
            ApiResult(isSuccess = false, errorMessage = e.localizedMessage)
        }
    }


    fun getUser(sessionCookie: String, userId: String): ApiResult<User> {
        return try {
            val req = Request.Builder()
                .url("$baseUrl/api/users/$userId")
                .get()
                .header("Cookie", sessionCookie)
                .build()
            client.newCall(req).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return ApiResult(false, errorMessage = "Gagal memuat profil (HTTP ${response.code})", httpCode = response.code)
                }
                ApiResult(true, userFromJson(JSONObject(body)))
            }
        } catch (e: Exception) {
            ApiResult(false, errorMessage = e.localizedMessage)
        }
    }

    fun getMe(sessionCookie: String): ApiResult<User> {
        return try {
            val req = Request.Builder()
                .url("$baseUrl/api/users/me")
                .get()
                .header("Cookie", sessionCookie)
                .build()
            client.newCall(req).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return ApiResult(false, errorMessage = "Gagal memuat profil (HTTP ${response.code})", httpCode = response.code)
                }
                ApiResult(true, userFromJson(JSONObject(body)))
            }
        } catch (e: Exception) {
            ApiResult(false, errorMessage = e.localizedMessage)
        }
    }

    /** Update display_name + bio ke server (bisa dilihat semua orang). */
    fun updateProfile(sessionCookie: String, displayName: String, bio: String): ApiResult<User> {
        return try {
            val payload = JSONObject().apply {
                put("display_name", displayName)
                put("bio", bio)
            }.toString()
            val req = Request.Builder()
                .url("$baseUrl/api/users/me")
                .put(payload.toRequestBody(JSON_TYPE))
                .header("Content-Type", "application/json")
                .header("Cookie", sessionCookie)
                .build()
            client.newCall(req).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val err = try { JSONObject(body).optString("error", "Gagal update profil") } catch (_: Exception) { "Gagal update profil" }
                    return ApiResult(false, errorMessage = err, httpCode = response.code)
                }
                ApiResult(true, userFromJson(JSONObject(body)))
            }
        } catch (e: Exception) {
            ApiResult(false, errorMessage = e.localizedMessage)
        }
    }

    /** Upload avatar (JPEG base64) ke server. */
    fun uploadAvatar(sessionCookie: String, imageBase64: String): ApiResult<User> {
        return try {
            val payload = JSONObject().apply { put("imageBase64", imageBase64) }.toString()
            val req = Request.Builder()
                .url("$baseUrl/api/users/me/avatar")
                .post(payload.toRequestBody(JSON_TYPE))
                .header("Content-Type", "application/json")
                .header("Cookie", sessionCookie)
                .build()
            client.newCall(req).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val err = try { JSONObject(body).optString("error", "Gagal upload foto") } catch (_: Exception) { "Gagal upload foto" }
                    return ApiResult(false, errorMessage = err, httpCode = response.code)
                }
                ApiResult(true, userFromJson(JSONObject(body)))
            }
        } catch (e: Exception) {
            ApiResult(false, errorMessage = e.localizedMessage)
        }
    }

    fun deleteAvatar(sessionCookie: String): ApiResult<User> {
        return try {
            val req = Request.Builder()
                .url("$baseUrl/api/users/me/avatar")
                .delete()
                .header("Cookie", sessionCookie)
                .build()
            client.newCall(req).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return ApiResult(false, errorMessage = "Gagal hapus foto", httpCode = response.code)
                }
                ApiResult(true, userFromJson(JSONObject(body)))
            }
        } catch (e: Exception) {
            ApiResult(false, errorMessage = e.localizedMessage)
        }
    }

    fun getMessages(sessionCookie: String, peerId: String): ApiResult<List<JSONObject>> {
        return try {
            val req = Request.Builder()
                .url("$baseUrl/api/messages/$peerId")
                .get()
                .header("Cookie", sessionCookie)
                .build()
            client.newCall(req).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return ApiResult(isSuccess = false, errorMessage = "Gagal memuat riwayat pesan (HTTP ${response.code})", httpCode = response.code)
                }
                val arr = org.json.JSONArray(body)
                val list = mutableListOf<JSONObject>()
                for (i in 0 until arr.length()) list.add(arr.getJSONObject(i))
                ApiResult(isSuccess = true, data = list)
            }
        } catch (e: Exception) {
            ApiResult(isSuccess = false, errorMessage = e.localizedMessage)
        }
    }

    fun registerFcmToken(sessionCookie: String, fcmToken: String): ApiResult<Unit> {
        return try {
            val payload = JSONObject().apply { put("token", fcmToken) }.toString()
            val req = Request.Builder()
                .url("$baseUrl/api/fcm-token")
                .post(payload.toRequestBody(JSON_TYPE))
                .header("Content-Type", "application/json")
                .header("Cookie", sessionCookie)
                .build()
            client.newCall(req).execute().use { response ->
                if (!response.isSuccessful) {
                    return ApiResult(isSuccess = false, errorMessage = "Gagal mendaftarkan FCM token (HTTP ${response.code})", httpCode = response.code)
                }
                ApiResult(isSuccess = true, data = Unit)
            }
        } catch (e: Exception) {
            ApiResult(isSuccess = false, errorMessage = e.localizedMessage)
        }
    }

    fun getGroups(sessionCookie: String): ApiResult<List<Group>> = try {
        val req = Request.Builder().url("$baseUrl/api/groups").get().header("Cookie", sessionCookie).build()
        client.newCall(req).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) return ApiResult(false, errorMessage = "Gagal memuat grup")
            val arr = org.json.JSONArray(body)
            val list = mutableListOf<Group>()
            for (i in 0 until arr.length()) list.add(groupFromJson(arr.getJSONObject(i)))
            ApiResult(true, list)
        }
    } catch (e: Exception) { ApiResult(false, errorMessage = e.localizedMessage) }

    fun createGroup(sessionCookie: String, name: String, description: String, kind: String): ApiResult<Group> = try {
        val body = JSONObject().put("name", name).put("description", description).put("kind", kind).toString().toRequestBody(JSON_TYPE)
        val req = Request.Builder().url("$baseUrl/api/groups").post(body).header("Cookie", sessionCookie).build()
        client.newCall(req).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) return ApiResult(false, errorMessage = "Gagal membuat grup")
            ApiResult(true, groupFromJson(JSONObject(text)))
        }
    } catch (e: Exception) { ApiResult(false, errorMessage = e.localizedMessage) }

    fun createInvite(sessionCookie: String, groupId: String): ApiResult<String> = try {
        val req = Request.Builder().url("$baseUrl/api/groups/$groupId/invite").post("{}".toRequestBody(JSON_TYPE)).header("Cookie", sessionCookie).build()
        client.newCall(req).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) return ApiResult(false, errorMessage = "Gagal membuat undangan")
            ApiResult(true, JSONObject(body).optString("link"))
        }
    } catch (e: Exception) { ApiResult(false, errorMessage = e.localizedMessage) }

    fun joinGroup(sessionCookie: String, token: String): ApiResult<Group> = try {
        val req = Request.Builder().url("$baseUrl/api/groups/join/$token").post("{}".toRequestBody(JSON_TYPE)).header("Cookie", sessionCookie).build()
        client.newCall(req).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) return ApiResult(false, errorMessage = "Link undangan tidak valid")
            ApiResult(true, groupFromJson(JSONObject(body)))
        }
    } catch (e: Exception) { ApiResult(false, errorMessage = e.localizedMessage) }

    fun setGroupClosed(sessionCookie: String, groupId: String, closed: Boolean): ApiResult<Group> = try {
        val body = JSONObject().put("isClosed", closed).toString().toRequestBody(JSON_TYPE)
        val req = Request.Builder().url("$baseUrl/api/groups/$groupId/settings").patch(body).header("Cookie", sessionCookie).build()
        client.newCall(req).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) return ApiResult(false, errorMessage = "Hanya admin yang dapat mengubah pengaturan")
            ApiResult(true, groupFromJson(JSONObject(text)))
        }
    } catch (e: Exception) { ApiResult(false, errorMessage = e.localizedMessage) }

    fun addGroupAdmin(sessionCookie: String, groupId: String, username: String): ApiResult<Unit> = try {
        val body = JSONObject().put("username", username).toString().toRequestBody(JSON_TYPE)
        val req = Request.Builder().url("$baseUrl/api/groups/$groupId/admins").post(body).header("Cookie", sessionCookie).build()
        client.newCall(req).execute().use { response ->
            if (!response.isSuccessful) return ApiResult(false, errorMessage = "Gagal menambahkan admin")
            ApiResult(true, Unit)
        }
    } catch (e: Exception) { ApiResult(false, errorMessage = e.localizedMessage) }

    fun logout(sessionCookie: String) {
        try {
            val req = Request.Builder()
                .url("$baseUrl/api/auth/logout")
                .post("{}".toRequestBody(JSON_TYPE))
                .header("Cookie", sessionCookie)
                .build()
            client.newCall(req).execute().close()
        } catch (_: Exception) { }
    }
}
