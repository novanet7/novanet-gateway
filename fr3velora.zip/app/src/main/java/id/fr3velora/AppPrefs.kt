package id.fr3velora

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.View
import android.widget.ImageView
import java.io.File
import java.io.FileOutputStream

/**
 * Preferensi tampilan yang disimpan di perangkat: profil (nama tampilan, bio, foto)
 * dan latar belakang chat (warna, gradien, atau foto sendiri + tingkat redup).
 */
class AppPrefs(context: Context) {
    private val ctx = context.applicationContext
    private val prefs = ctx.getSharedPreferences("fr3velora_ui", Context.MODE_PRIVATE)

    var displayName: String
        get() = prefs.getString("displayName", "") ?: ""
        set(v) = prefs.edit().putString("displayName", v).apply()

    var bio: String
        get() = prefs.getString("bio", "") ?: ""
        set(v) = prefs.edit().putString("bio", v).apply()

    var avatarFileName: String?
        get() = prefs.getString("avatarFile", null)
        set(v) = prefs.edit().putString("avatarFile", v).apply()

    /** default | color | gradient | image */
    var bgType: String
        get() = prefs.getString("bgType", "default") ?: "default"
        set(v) = prefs.edit().putString("bgType", v).apply()

    var bgColor: Int
        get() = prefs.getInt("bgColor", BG_COLORS[0])
        set(v) = prefs.edit().putInt("bgColor", v).apply()

    var bgGradient: Int
        get() = prefs.getInt("bgGradient", 0)
        set(v) = prefs.edit().putInt("bgGradient", v).apply()

    /** 0..70 (persen gelap yang ditimpa di atas foto latar) */
    var bgDim: Int
        get() = prefs.getInt("bgDim", 20)
        set(v) = prefs.edit().putInt("bgDim", v).apply()

    fun avatarFile(): File? = avatarFileName?.let { File(ctx.filesDir, it) }?.takeIf { it.exists() }

    fun clearAvatar() { avatarFile()?.delete(); avatarFileName = null }

    fun resetBackground() { File(ctx.filesDir, BG_FILE).delete(); bgType = "default" }

    fun setBackgroundColor(color: Int) { bgColor = color; bgType = "color" }

    fun setBackgroundGradient(index: Int) { bgGradient = index; bgType = "gradient" }

    fun importBackground(uri: Uri): Boolean {
        val ok = importImage(uri, BG_FILE, 1600, false)
        if (ok) bgType = "image"
        return ok
    }

    fun importAvatar(uri: Uri): Boolean {
        val ok = importImage(uri, AVATAR_FILE, 512, true)
        if (ok) avatarFileName = AVATAR_FILE
        return ok
    }

    /** Terapkan latar belakang ke ImageView + lapisan redup. */
    fun applyBackground(bg: ImageView, dim: View) {
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        when (bgType) {
            "color" -> bg.setImageDrawable(ColorDrawable(bgColor))
            "gradient" -> bg.setImageDrawable(gradientFor(bgGradient))
            "image" -> {
                val file = File(ctx.filesDir, BG_FILE)
                val bmp = if (file.exists()) BitmapFactory.decodeFile(file.path) else null
                if (bmp != null) bg.setImageBitmap(bmp) else bg.setImageDrawable(ColorDrawable(ctx.getColor(R.color.chat_bg)))
            }
            else -> bg.setImageDrawable(ColorDrawable(ctx.getColor(R.color.chat_bg)))
        }
        dim.alpha = if (bgType == "image") bgDim / 100f else 0f
    }

    private fun importImage(uri: Uri, fileName: String, maxSide: Int, square: Boolean): Boolean = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp: Bitmap = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false
        if (square) {
            val side = minOf(bmp.width, bmp.height)
            bmp = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        }
        val scale = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
        if (scale < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
        FileOutputStream(File(ctx.filesDir, fileName)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        true
    }.getOrDefault(false)

    companion object {
        private const val BG_FILE = "chat_bg.jpg"
        private const val AVATAR_FILE = "avatar_me.jpg"

        val BG_COLORS = intArrayOf(
            Color.parseColor("#ECE5DD"), Color.parseColor("#E9EEF5"), Color.parseColor("#D6EAF8"),
            Color.parseColor("#DFF5E1"), Color.parseColor("#FDEBD0"), Color.parseColor("#F5D5E0"),
            Color.parseColor("#E8DAEF"), Color.parseColor("#2B2F36"), Color.parseColor("#0E1621"),
            Color.parseColor("#000000")
        )

        private val BG_GRADIENTS = arrayOf(
            intArrayOf(Color.parseColor("#667EEA"), Color.parseColor("#764BA2")),
            intArrayOf(Color.parseColor("#11998E"), Color.parseColor("#38EF7D")),
            intArrayOf(Color.parseColor("#FC5C7D"), Color.parseColor("#6A82FB")),
            intArrayOf(Color.parseColor("#F2994A"), Color.parseColor("#F2C94C")),
            intArrayOf(Color.parseColor("#0F2027"), Color.parseColor("#2C5364")),
            intArrayOf(Color.parseColor("#1F1C2C"), Color.parseColor("#928DAB"))
        )

        val GRADIENT_COUNT: Int get() = BG_GRADIENTS.size

        fun gradientFor(index: Int): GradientDrawable =
            GradientDrawable(GradientDrawable.Orientation.TL_BR, BG_GRADIENTS[index.coerceIn(0, BG_GRADIENTS.size - 1)])
    }
}
