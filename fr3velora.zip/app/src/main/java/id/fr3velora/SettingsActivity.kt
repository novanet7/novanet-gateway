package id.fr3velora

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.switchmaterial.SwitchMaterial

/**
 * Pengaturan bergaya Telegram: ikon berwarna + kartu gelap + subtitle.
 */
class SettingsActivity : AppCompatActivity() {
    private lateinit var session: SessionManager
    private lateinit var settings: SettingsStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        session = SessionManager(this)
        settings = SettingsStore(this)

        findViewById<Toolbar>(R.id.toolbarSettings).setNavigationOnClickListener { finish() }
        bindProfileHeader()
        bindSwitches()
        bindRows()
    }

    override fun onResume() {
        super.onResume()
        bindProfileHeader()
    }

    private fun bindProfileHeader() {
        val name = session.displayName?.ifBlank { null } ?: session.username ?: "Pengguna"
        findViewById<TextView>(R.id.tvSettingsName).text = name
        findViewById<TextView>(R.id.tvSettingsUsername).text = "@${session.username ?: ""}"
        bindAvatar(
            findViewById(R.id.ivSettingsAvatar),
            findViewById(R.id.tvSettingsInitial),
            name,
            session.avatarUrl
        )
        findViewById<android.view.View>(R.id.rowSettingsProfile).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
    }

    private fun bindSwitches() {
        val swNotif = findViewById<SwitchMaterial>(R.id.swNotif)
        val swRead = findViewById<SwitchMaterial>(R.id.swReadReceipts)
        val swEnter = findViewById<SwitchMaterial>(R.id.swEnterSend)

        swNotif.isChecked = settings.notificationsEnabled
        swRead.isChecked = settings.sendReadReceipts
        swEnter.isChecked = settings.enterIsSend

        swNotif.setOnCheckedChangeListener { _, v -> settings.notificationsEnabled = v }
        swRead.setOnCheckedChangeListener { _, v ->
            settings.sendReadReceipts = v
            Toast.makeText(
                this,
                if (v) "Centang baca aktif" else "Centang baca dimatikan",
                Toast.LENGTH_SHORT
            ).show()
        }
        swEnter.setOnCheckedChangeListener { _, v -> settings.enterIsSend = v }
    }

    private fun bindRows() {
        findViewById<android.view.View>(R.id.rowEditProfile).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
        findViewById<android.view.View>(R.id.rowChatSettings).setOnClickListener {
            val opts = arrayOf(
                "Latar belakang chat",
                "Ukuran teks: ${settings.chatFontSize}",
                "Unduh media: ${settings.mediaAutoDownload}",
                "Suara notifikasi: ${if (settings.notificationSound) "on" else "off"}",
                "Getar: ${if (settings.notificationVibrate) "on" else "off"}"
            )
            MaterialAlertDialogBuilder(this)
                .setTitle("Pengaturan Obrolan")
                .setItems(opts) { _, which ->
                    when (which) {
                        0 -> startActivity(Intent(this, ChatBackgroundActivity::class.java))
                        1 -> pickFontSize()
                        2 -> pickMediaDl()
                        3 -> {
                            settings.notificationSound = !settings.notificationSound
                            Toast.makeText(this, "Suara: ${settings.notificationSound}", Toast.LENGTH_SHORT).show()
                        }
                        4 -> {
                            settings.notificationVibrate = !settings.notificationVibrate
                            Toast.makeText(this, "Getar: ${settings.notificationVibrate}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                .show()
        }
        findViewById<android.view.View>(R.id.rowPrivacy).setOnClickListener {
            val extras = ChatExtrasStore(this)
            val opts = arrayOf("Semua orang", "Tidak ada", "Kontak saja")
            val cur = when (extras.lastSeenPrivacy) {
                "nobody" -> 1
                "contacts" -> 2
                else -> 0
            }
            MaterialAlertDialogBuilder(this)
                .setTitle("Privasi & Keamanan")
                .setSingleChoiceItems(opts, cur) { d, which ->
                    extras.lastSeenPrivacy = when (which) {
                        1 -> "nobody"
                        2 -> "contacts"
                        else -> "everybody"
                    }
                    d.dismiss()
                    Toast.makeText(this, "Last seen: ${opts[which]}", Toast.LENGTH_SHORT).show()
                }
                .setMessage(
                    "• Centang baca dikontrol di pintasan cepat\n" +
                        "• Catatan privat kontak hanya di perangkat ini\n" +
                        "• Pesan senyap tidak memicu notifikasi\n" +
                        "• Sesi login tersimpan aman di perangkat"
                )
                .setPositiveButton("OK", null)
                .show()
        }
        findViewById<android.view.View>(R.id.rowNotifSection).setOnClickListener {
            val items = arrayOf(
                "Notifikasi: ${if (settings.notificationsEnabled) "Aktif" else "Mati"}",
                "Suara: ${if (settings.notificationSound) "Aktif" else "Mati"}",
                "Getar: ${if (settings.notificationVibrate) "Aktif" else "Mati"}"
            )
            MaterialAlertDialogBuilder(this)
                .setTitle("Notifikasi")
                .setItems(items) { _, which ->
                    when (which) {
                        0 -> {
                            settings.notificationsEnabled = !settings.notificationsEnabled
                            findViewById<SwitchMaterial>(R.id.swNotif).isChecked = settings.notificationsEnabled
                        }
                        1 -> settings.notificationSound = !settings.notificationSound
                        2 -> settings.notificationVibrate = !settings.notificationVibrate
                    }
                }
                .show()
        }
        findViewById<android.view.View>(R.id.rowDataSection).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Data dan Penyimpanan")
                .setItems(
                    arrayOf(
                        "Unduh media otomatis",
                        "Simpan ke galeri: ${if (settings.saveToGallery) "on" else "off"}",
                        "Bersihkan cache"
                    )
                ) { _, which ->
                    when (which) {
                        0 -> pickMediaDl()
                        1 -> {
                            settings.saveToGallery = !settings.saveToGallery
                            Toast.makeText(this, "Galeri: ${settings.saveToGallery}", Toast.LENGTH_SHORT).show()
                        }
                        2 -> {
                            runCatching { cacheDir.listFiles()?.forEach { it.deleteRecursively() } }
                            Toast.makeText(this, "Cache dibersihkan", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                .show()
        }
        findViewById<android.view.View>(R.id.rowArchive).setOnClickListener {
            startActivity(
                Intent(this, ChatListActivity::class.java)
                    .putExtra("openArchive", true)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
            finish()
        }
        findViewById<android.view.View>(R.id.rowBattery).setOnClickListener {
            requestBatteryExemption()
        }
        findViewById<android.view.View>(R.id.rowAbout).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("fr3velora")
                .setMessage("Bahasa: Indonesia\n\nChat real-time gaya Telegram/WhatsApp.")
                .setPositiveButton("OK", null)
                .show()
        }
        findViewById<android.view.View>(R.id.rowLogout).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Keluar")
                .setMessage("Kamu akan keluar dari akun di perangkat ini.")
                .setPositiveButton("Keluar") { _, _ ->
                    val cookie = session.sessionCookie
                    if (cookie != null) {
                        Thread {
                            runCatching {
                                id.fr3velora.network.ApiClient(getString(R.string.api_base_url)).logout(cookie)
                            }
                        }.start()
                    }
                    KeepAliveScheduler.cancel(this)
                    stopService(Intent(this, ChatConnectionService::class.java))
                    session.clear()
                    startActivity(
                        Intent(this, LoginActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    )
                    finish()
                }
                .setNegativeButton("Batal", null)
                .show()
        }
    }

    private fun pickFontSize() {
        val opts = arrayOf("Kecil", "Normal", "Besar")
        val cur = when (settings.chatFontSize) {
            "small" -> 0
            "large" -> 2
            else -> 1
        }
        AlertDialog.Builder(this)
            .setTitle("Ukuran teks pesan")
            .setSingleChoiceItems(opts, cur) { d, which ->
                settings.chatFontSize = when (which) {
                    0 -> "small"
                    2 -> "large"
                    else -> "normal"
                }
                d.dismiss()
            }
            .show()
    }

    private fun pickMediaDl() {
        val opts = arrayOf("Selalu", "Hanya Wi‑Fi", "Jangan otomatis")
        val cur = when (settings.mediaAutoDownload) {
            "always" -> 0
            "never" -> 2
            else -> 1
        }
        AlertDialog.Builder(this)
            .setTitle("Unduh media otomatis")
            .setSingleChoiceItems(opts, cur) { d, which ->
                settings.mediaAutoDownload = when (which) {
                    0 -> "always"
                    2 -> "never"
                    else -> "wifi"
                }
                d.dismiss()
            }
            .show()
    }

    private fun requestBatteryExemption() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            Toast.makeText(this, "Tidak diperlukan di Android ini", Toast.LENGTH_SHORT).show()
            return
        }
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "Sudah diizinkan berjalan di latar", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }
}
