package id.fr3velora

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextWatcher
import android.util.Base64
import android.view.MotionEvent
import android.view.View
import android.view.animation.AnimationUtils
import android.view.animation.AlphaAnimation
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import id.fr3velora.model.Message
import java.io.File
import java.util.UUID

/**
 * Room chat gaya WhatsApp:
 * - Teks + lampiran (foto/video/file)
 * - Hold-to-record pesan suara (mic ↔ kirim otomatis)
 * - Voice / video call
 * - Hapus pesan, centang baca
 */
class ChatRoomActivity : AppCompatActivity() {
    private lateinit var session: SessionManager
    private lateinit var store: LocalChatStore
    private lateinit var adapter: MessageAdapter
    private lateinit var peerId: String
    private var roomId: String? = null
    private var roomKind: String? = null
    private lateinit var rv: RecyclerView
    private lateinit var etMessage: EditText
    private lateinit var btnSend: FloatingActionButton
    private lateinit var recordBar: View
    private lateinit var inputBar: View
    private lateinit var tvRecordTime: TextView
    private lateinit var recordDot: View
    private var pendingAttachment: Uri? = null
    private var replyTarget: Message? = null
    private var composeSilent = false
    private var composeUnlockAt: Long? = null
    private var composeLabel: String? = null
    private lateinit var contactStore: ContactStore
    private lateinit var extras: ChatExtrasStore
    private lateinit var bgPrefs: AppPrefs

    // Voice note
    private var recorder: MediaRecorder? = null
    private var recordFile: File? = null
    private var recording = false
    private var recordStart = 0L
    private var cancelRecord = false
    private var touchStartX = 0f
    private val handler = Handler(Looper.getMainLooper())
    private var pulseAnim: ObjectAnimator? = null
    private val tickRunnable = object : Runnable {
        override fun run() {
            if (!recording) return
            val sec = ((SystemClock.elapsedRealtime() - recordStart) / 1000).toInt()
            tvRecordTime.text = "%d:%02d".format(sec / 60, sec % 60)
            handler.postDelayed(this, 250)
        }
    }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        pendingAttachment = uri
        showAttachment(uri)
        updateSendButton()
    }

    private val cameraPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        pendingAttachment = uri
        showAttachment(uri)
        updateSendButton()
    }

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) Toast.makeText(this, "Izin mikrofon diperlukan untuk pesan suara", Toast.LENGTH_SHORT).show()
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val message = store.find(intent?.getStringExtra("messageId")) ?: return
            if (roomId != null && message.roomId != roomId) return
            if (roomId == null && message.from != peerId && message.to != peerId) return
            adapter.upsertMessage(message)
            rv.scrollToPosition(adapter.itemCount - 1)
        }
    }
    private val callReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.getStringExtra("type") == "call_offer" && intent.getStringExtra("from") == peerId) {
                val name = findViewById<TextView>(R.id.tvPeerName).text?.toString()
                startActivity(
                    Intent(this@ChatRoomActivity, CallActivity::class.java)
                        .putExtra("peerId", peerId)
                        .putExtra("mode", intent.getStringExtra("mode") ?: "voice")
                        .putExtra("callId", intent.getStringExtra("callId"))
                        .putExtra("incoming", true)
                        .putExtra("peerName", name)
                        .putExtra("peerAvatar", getIntent().getStringExtra("peerAvatar"))
                )
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_room)
        session = SessionManager(this)
        store = LocalChatStore(this)
        contactStore = ContactStore(this)
        extras = ChatExtrasStore(this)
        peerId = intent.getStringExtra("peerId") ?: ""
        roomId = intent.getStringExtra("roomId")
        roomKind = intent.getStringExtra("roomKind")
        bgPrefs = AppPrefs(this)

        findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }
        val peerName = intent.getStringExtra("peerName") ?: "Chat"
        findViewById<TextView>(R.id.tvPeerName).text = peerName
        findViewById<TextView>(R.id.tvPeerSub).text = when {
            roomId == null -> "ketuk untuk info kontak"
            roomKind == "channel" -> "Channel"
            else -> "Grup"
        }
        bindAvatar(
            findViewById(R.id.ivPeerAvatar),
            findViewById(R.id.tvPeerInitial),
            peerName,
            intent.getStringExtra("peerAvatar")
        )
        // Ketuk header / avatar → lihat profil (read-only) untuk chat pribadi
        val openPeerProfile = View.OnClickListener {
            if (roomId != null) return@OnClickListener // grup: belum ada profil grup
            startActivity(
                Intent(this, ViewProfileActivity::class.java)
                    .putExtra("userId", peerId)
                    .putExtra("displayName", peerName)
                    .putExtra("username", intent.getStringExtra("peerUsername").orEmpty())
                    .putExtra("avatarUrl", intent.getStringExtra("peerAvatar"))
                    .putExtra("bio", intent.getStringExtra("peerBio").orEmpty())
            )
        }
        findViewById<View>(R.id.ivPeerAvatar).setOnClickListener(openPeerProfile)
        findViewById<View>(R.id.tvPeerName).setOnClickListener(openPeerProfile)
        findViewById<View>(R.id.tvPeerSub).setOnClickListener(openPeerProfile)
        bgPrefs.applyBackground(findViewById(R.id.ivChatBg), findViewById(R.id.viewChatDim))

        rv = findViewById(R.id.rvMessages)
        rv.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        val initial = if (roomId != null) store.conversationRoom(roomId!!)
        else store.conversation(session.userId ?: "", peerId)
        adapter = MessageAdapter(
            initial.toMutableList(),
            session.userId ?: "",
            store.attachmentDir,
            { openAttachment(it) },
            { showDeleteDialog(it) }
        )
        rv.adapter = adapter
        rv.scrollToPosition(maxOf(adapter.itemCount - 1, 0))
        runCatching { rv.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in)) }
        setupSwipeToReply()

        etMessage = findViewById(R.id.etMessage)
        val draftKey = roomId ?: peerId
        val draft = extras.getDraft(draftKey)
        if (draft.isNotBlank()) etMessage.setText(draft)
        btnSend = findViewById(R.id.btnSend)
        recordBar = findViewById(R.id.recordBar)
        inputBar = findViewById(R.id.inputBar)
        tvRecordTime = findViewById(R.id.tvRecordTime)
        recordDot = findViewById(R.id.recordDot)

        findViewById<View>(R.id.btnAttach).setOnClickListener {
            val opts = arrayOf("📷  Galeri / Foto", "🎬  Video", "📄  Dokumen", "🎵  Audio")
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Kirim file")
                .setItems(opts) { _, which ->
                    val mime = when (which) {
                        0 -> arrayOf("image/*")
                        1 -> arrayOf("video/*")
                        2 -> arrayOf("application/pdf", "text/*", "application/*")
                        else -> arrayOf("audio/*")
                    }
                    picker.launch(mime)
                }
                .show()
        }
        findViewById<View>(R.id.btnEmoji)?.setOnClickListener {
            // Buka keyboard emoji sistem (hint) + quick insert
            val quick = arrayOf("😀", "😂", "❤️", "👍", "🔥", "🙏", "🎉", "😊")
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Emoji cepat")
                .setItems(quick) { _, which ->
                    val start = etMessage.selectionStart.coerceAtLeast(0)
                    etMessage.text?.insert(start, quick[which])
                }
                .show()
        }
        findViewById<View>(R.id.btnCamera).setOnClickListener {
            cameraPicker.launch("image/*")
        }
        findViewById<View>(R.id.btnClearAttach).setOnClickListener {
            pendingAttachment = null
            hideAttachment()
            updateSendButton()
        }
        findViewById<View>(R.id.btnClearReply).setOnClickListener { clearReply() }
        // Satu tombol call → pilih suara / video (UX WhatsApp)
        findViewById<View>(R.id.btnVoiceCall).setOnClickListener { showCallTypePicker() }
        findViewById<View>(R.id.btnVideoCall)?.visibility = View.GONE
        findViewById<View>(R.id.btnRoomMenu).setOnClickListener { anchor ->
            val popup = PopupMenu(this, anchor, android.view.Gravity.END)
            popup.menuInflater.inflate(R.menu.room_menu, popup.menu)
            popup.setOnMenuItemClickListener {
                when (it.itemId) {
                    R.id.menu_private_note -> showPrivateNoteDialog()
                    R.id.menu_compose_options -> toggleComposeOptions()
                    R.id.menu_search_chat -> searchInChat()
                    R.id.menu_mute -> toggleMute()
                    R.id.menu_block -> toggleBlock()
                    R.id.menu_disappear -> pickDisappear()
                    R.id.menu_clear_chat -> clearChat()
                    R.id.menu_mark_unread -> {
                        extras.markUnread(chatKey(), true)
                        Toast.makeText(this, "Ditandai belum dibaca", Toast.LENGTH_SHORT).show()
                    }
                    R.id.menu_room_bg -> startActivity(Intent(this, ChatBackgroundActivity::class.java))
                }
                true
            }
            popup.show()
        }
        setupComposeChips()

        // Teks berubah → ganti ikon mic / kirim
        if (SettingsStore(this).enterIsSend) {
            etMessage.setOnEditorActionListener { _, actionId, event ->
                val isEnter = event != null && event.keyCode == android.view.KeyEvent.KEYCODE_ENTER && event.action == android.view.KeyEvent.ACTION_DOWN
                val isSend = actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND
                if ((isEnter || isSend) && hasOutgoingText()) {
                    sendCurrent()
                    true
                } else false
            }
        }
        etMessage.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                updateSendButton()
                extras.setDraft(roomId ?: peerId, s?.toString().orEmpty())
                sendTyping()
            }
        })

        // Klik = kirim teks (kalau ada isi). Tahan = rekam suara (kalau kosong).
        btnSend.setOnClickListener {
            if (hasOutgoingText()) sendCurrent()
        }
        btnSend.setOnTouchListener { _, event ->
            if (hasOutgoingText()) return@setOnTouchListener false // biar click listener yang handle
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    touchStartX = event.rawX
                    cancelRecord = false
                    if (ensureMicPermission()) startRecording()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (recording) {
                        val dx = touchStartX - event.rawX
                        if (dx > 120f) {
                            cancelRecord = true
                            tvRecordTime.text = "Batal"
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (recording) stopRecording(send = !cancelRecord && event.action == MotionEvent.ACTION_UP)
                    true
                }
                else -> false
            }
        }

        updateSendButton()
        markIncomingRead()
    }

    private fun hasOutgoingText(): Boolean =
        etMessage.text?.toString()?.trim().orEmpty().isNotEmpty() || pendingAttachment != null

    private var sendMode = false
    private fun updateSendButton() {
        val wantSend = hasOutgoingText()
        if (wantSend == sendMode) return
        sendMode = wantSend
        if (wantSend) {
            btnSend.setImageResource(R.drawable.ic_send)
            btnSend.contentDescription = "Kirim"
            btnSend.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF00A884.toInt())
        } else {
            btnSend.setImageResource(R.drawable.ic_mic)
            btnSend.contentDescription = "Tahan untuk rekam"
            btnSend.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF00A884.toInt())
        }
        runCatching {
            btnSend.startAnimation(AnimationUtils.loadAnimation(this, R.anim.scale_pop))
        }
    }

    private fun ensureMicPermission(): Boolean {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            return true
        }
        micPermission.launch(Manifest.permission.RECORD_AUDIO)
        return false
    }

    private fun startRecording() {
        if (recording) return
        try {
            val dir = File(cacheDir, "voice").apply { mkdirs() }
            recordFile = File(dir, "vn_${System.currentTimeMillis()}.m4a")
            @Suppress("DEPRECATION")
            recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(this)
            } else {
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(recordFile!!.absolutePath)
                prepare()
                start()
            }
            recording = true
        runCatching {
            recordDot.startAnimation(AnimationUtils.loadAnimation(this, R.anim.pulse))
        }
            recordStart = SystemClock.elapsedRealtime()
            cancelRecord = false
            recordBar.visibility = View.VISIBLE
            inputBar.visibility = View.GONE
            tvRecordTime.text = "0:00"
            handler.post(tickRunnable)
            pulseAnim = ObjectAnimator.ofFloat(recordDot, View.ALPHA, 1f, 0.2f).apply {
                duration = 600
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                start()
            }
        } catch (e: Exception) {
            recording = false
            recorder?.release()
            recorder = null
            recordFile?.delete()
            recordFile = null
            Toast.makeText(this, "Gagal mulai rekam: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            showInputBars()
        }
    }

    private fun stopRecording(send: Boolean) {
        runCatching { recordDot.clearAnimation() }
        if (!recording) return
        recording = false
        handler.removeCallbacks(tickRunnable)
        pulseAnim?.cancel()
        pulseAnim = null
        recordDot.alpha = 1f

        val durationMs = SystemClock.elapsedRealtime() - recordStart
        try {
            recorder?.apply {
                stop()
                release()
            }
        } catch (_: Exception) {
        }
        recorder = null

        val file = recordFile
        recordFile = null
        showInputBars()

        if (!send || file == null || !file.exists() || durationMs < 700) {
            file?.delete()
            if (send && durationMs < 700) {
                Toast.makeText(this, "Tahan lebih lama untuk merekam", Toast.LENGTH_SHORT).show()
            }
            return
        }

        // Kirim sebagai attachment audio
        sendVoiceNote(file, durationMs)
    }

    private fun showInputBars() {
        recordBar.visibility = View.GONE
        inputBar.visibility = View.VISIBLE
    }

    private fun sendVoiceNote(file: File, durationMs: Long) {
        val from = session.userId ?: return
        val id = UUID.randomUUID().toString()
        val sec = (durationMs / 1000).toInt().coerceAtLeast(1)
        val durationLabel = "%d:%02d".format(sec / 60, sec % 60)
        val name = "Pesan suara ($durationLabel).m4a"
        val mime = "audio/mp4"

        // Simpan lewat LocalChatStore (folder chat_local) supaya path konsisten
        val path = store.importFile(file, name)
        if (path == null) {
            Toast.makeText(this, "Gagal menyimpan pesan suara", Toast.LENGTH_SHORT).show()
            file.delete()
            return
        }
        file.delete()

        val stored = store.file(path)
        val bytes = stored?.readBytes()
        if (bytes == null || bytes.isEmpty()) {
            Toast.makeText(this, "Gagal membaca pesan suara", Toast.LENGTH_SHORT).show()
            return
        }

        val local = Message(
            id = id,
            from = from,
            to = peerId,
            roomId = roomId,
            roomKind = roomKind,
            text = "",
            attachmentName = name,
            attachmentMime = mime,
            attachmentPath = path,
            status = "pending"
        )
        val wire = local.copy(
            attachmentPath = null,
            attachmentBase64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        )
        store.save(local)
        adapter.upsertMessage(local)
        rv.scrollToPosition(adapter.itemCount - 1)
        ChatConnectionService.send(wire)
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter("id.fr3velora.NEW_MESSAGE")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            registerReceiver(callReceiver, IntentFilter("id.fr3velora.CALL_EVENT"), Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(receiver, filter)
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(callReceiver, IntentFilter("id.fr3velora.CALL_EVENT"))
            val presenceFilter = IntentFilter("id.fr3velora.PRESENCE")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(presenceReceiver, presenceFilter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                registerReceiver(presenceReceiver, presenceFilter)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        runCatching { unregisterReceiver(receiver) }
        runCatching { unregisterReceiver(callReceiver) }
        runCatching { unregisterReceiver(presenceReceiver) }
        if (recording) stopRecording(send = false)
    }

    private fun markIncomingRead() {
        val myId = session.userId ?: return
        val sendReceipts = SettingsStore(this).sendReadReceipts
        store.conversation(myId, peerId).filter { it.from == peerId && it.status != "read" }.forEach {
            store.updateStatus(it.id, "read")
            if (sendReceipts) {
                ChatConnectionService.send(Message(type = "read", from = myId, to = peerId, messageId = it.id))
            }
        }
    }

    private fun sendCurrent() {
        val pair = buildOutgoing(etMessage.text?.toString().orEmpty().trim(), pendingAttachment) ?: return
        etMessage.setText("")
        pendingAttachment = null
        hideAttachment()
        clearReply()
        resetComposeFlags()
        updateSendButton()
        val (local, wire) = pair
        store.save(local)
        adapter.upsertMessage(local)
        rv.scrollToPosition(adapter.itemCount - 1)
        ChatConnectionService.send(wire)
    }

    private fun buildOutgoing(text: String, uri: Uri?): Pair<Message, Message>? {
        val from = session.userId ?: return null
        val id = java.util.UUID.randomUUID().toString()
        val reply = replyTarget
        val replyId = reply?.id
        val replyText = when {
            reply == null -> null
            reply.text.isNotBlank() -> reply.text.take(120)
            reply.hasAttachment -> {
                val mime = reply.attachmentMime.orEmpty()
                when {
                    mime.startsWith("image/") -> "📷 Foto"
                    mime.startsWith("video/") -> "🎬 Video"
                    mime.startsWith("audio/") -> "🎤 Pesan suara"
                    else -> "📎 ${reply.attachmentName ?: "File"}"
                }
            }
            else -> null
        }
        val replyName = when {
            reply == null -> null
            reply.from == from -> "Anda"
            else -> intent.getStringExtra("peerName") ?: "Pesan"
        }

        if (uri == null) {
            if (text.isBlank()) return null
            val m = Message(
                id = id,
                from = from,
                to = peerId,
                roomId = roomId,
                roomKind = roomKind,
                text = text,
                replyToId = replyId,
                replyToText = replyText,
                replyToName = replyName,
                silent = composeSilent,
                unlockAt = composeUnlockAt,
                label = composeLabel,
                expireAt = extras.disappearSeconds(chatKey()).let { s ->
                    if (s > 0) System.currentTimeMillis() + s * 1000L else null
                }
            )
            return m to m
        }
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        if (bytes.size > 10 * 1024 * 1024) {
            Toast.makeText(this, "File maksimal 10MB", Toast.LENGTH_SHORT).show()
            return null
        }
        val name = displayName(uri)
        val mime = contentResolver.getType(uri) ?: "application/octet-stream"
        val path = store.copyAttachment(uri, name) ?: return null
        val local = Message(
            id = id,
            from = from,
            to = peerId,
            roomId = roomId,
            roomKind = roomKind,
            text = text, // caption
            attachmentName = name,
            attachmentMime = mime,
            attachmentPath = path,
            replyToId = replyId,
            replyToText = replyText,
            replyToName = replyName,
            silent = composeSilent,
            unlockAt = composeUnlockAt,
            label = composeLabel,
            expireAt = extras.disappearSeconds(chatKey()).let { s ->
                if (s > 0) System.currentTimeMillis() + s * 1000L else null
            }
        )
        return local to local.copy(
            attachmentPath = null,
            attachmentBase64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
        )
    }


    private fun showAttachment(uri: Uri) {
        val name = displayName(uri)
        val mime = contentResolver.getType(uri).orEmpty()
        val label = when {
            mime.startsWith("image/") -> "📷 $name — ketik caption di bawah"
            mime.startsWith("video/") -> "🎬 $name — ketik caption di bawah"
            else -> name
        }
        findViewById<TextView>(R.id.tvAttachName).text = label
        findViewById<View>(R.id.attachBar).visibility = View.VISIBLE
        etMessage.hint = if (mime.startsWith("image/") || mime.startsWith("video/")) "Tambahkan caption..." else "Ketik pesan"
        etMessage.requestFocus()
    }

    private fun hideAttachment() {
        findViewById<View>(R.id.attachBar).visibility = View.GONE
        if (replyTarget == null) etMessage.hint = "Ketik pesan"
    }

    private var lastTypingSent = 0L
    private fun sendTyping() {
        val now = System.currentTimeMillis()
        if (now - lastTypingSent < 2500) return
        lastTypingSent = now
        ChatConnectionService.send(
            Message(type = "typing", from = session.userId ?: "", to = peerId, roomId = roomId)
        )
    }

    private fun chatKey() = roomId ?: peerId

    /** Menu pesan ala Telegram (long-press). */
    private fun showDeleteDialog(message: Message) {
        if (message.text == "Pesan ini dihapus") {
            AlertDialog.Builder(this)
                .setTitle("Pesan")
                .setItems(arrayOf("Hapus untuk saya")) { _, _ ->
                    store.deleteForMe(message.id)
                    adapter.removeMessage(message.id)
                }.show()
            return
        }
        val mine = message.from == (session.userId ?: "")
        val starred = message.id != null && extras.isStarred(message.id!!)
        val options = mutableListOf(
            "Balas",
            "Salin teks",
            "Teruskan",
            if (starred) "Hapus bintang" else "Bintang",
            "Reaksi",
            "Sematkan",
            "Info pesan"
        )
        if (mine) options += "Edit"
        options += "Hapus untuk saya"
        if (mine) options += "Hapus untuk semua"

        AlertDialog.Builder(this).setTitle("Pesan").setItems(options.toTypedArray()) { _, which ->
            when (options[which]) {
                "Balas" -> setReply(message)
                "Salin teks" -> {
                    val cm = getSystemService(android.content.ClipboardManager::class.java)
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("pesan", message.text))
                    Toast.makeText(this, "Disalin", Toast.LENGTH_SHORT).show()
                }
                "Teruskan" -> forwardMessage(message)
                "Bintang" -> {
                    message.id?.let { extras.star(it) }
                    Toast.makeText(this, "Ditandai bintang", Toast.LENGTH_SHORT).show()
                }
                "Hapus bintang" -> {
                    message.id?.let { extras.unstar(it) }
                    Toast.makeText(this, "Bintang dihapus", Toast.LENGTH_SHORT).show()
                }
                "Reaksi" -> reactTo(message)
                "Sematkan" -> pinMessage(message)
                "Info pesan" -> showMessageInfo(message)
                "Edit" -> editMessage(message)
                "Hapus untuk saya" -> {
                    store.deleteForMe(message.id)
                    adapter.removeMessage(message.id)
                }
                "Hapus untuk semua" -> {
                    store.deleteForEveryone(message.id)
                    adapter.upsertMessage(store.find(message.id))
                    ChatConnectionService.send(
                        Message(
                            type = "delete",
                            from = session.userId ?: "",
                            to = peerId,
                            roomId = roomId,
                            messageId = message.id,
                            mode = "everyone"
                        )
                    )
                }
            }
        }.show()
    }

    private fun reactTo(message: Message) {
        val emojis = arrayOf("👍", "❤️", "🔥", "😂", "😮", "😢", "🎉", "🙏")
        AlertDialog.Builder(this).setTitle("Reaksi").setItems(emojis) { _, which ->
            val emoji = emojis[which]
            val map = try {
                org.json.JSONObject(message.reactions ?: "{}")
            } catch (_: Exception) {
                org.json.JSONObject()
            }
            map.put(emoji, map.optInt(emoji, 0) + 1)
            val json = map.toString()
            store.updateReactions(message.id, json)
            adapter.upsertMessage(store.find(message.id))
            ChatConnectionService.send(
                Message(
                    type = "react",
                    from = session.userId ?: "",
                    to = peerId,
                    roomId = roomId,
                    messageId = message.id,
                    text = emoji,
                    reactions = json
                )
            )
        }.show()
    }

    private fun pinMessage(message: Message) {
        extras.setPinned(chatKey(), message.id)
        store.updatePinned(message.id, true)
        adapter.upsertMessage(store.find(message.id))
        refreshPinnedBar()
        ChatConnectionService.send(
            Message(
                type = "pin",
                from = session.userId ?: "",
                to = peerId,
                roomId = roomId,
                messageId = message.id,
                text = message.text.take(80),
                pinned = true
            )
        )
        Toast.makeText(this, "Pesan disematkan", Toast.LENGTH_SHORT).show()
    }

    private fun refreshPinnedBar() {
        val pinId = extras.pinnedId(chatKey())
        val bar = findViewById<View?>(R.id.pinnedBar) ?: return
        val tv = findViewById<TextView?>(R.id.tvPinnedText) ?: return
        if (pinId == null) {
            bar.visibility = View.GONE
            return
        }
        val msg = store.find(pinId)
        if (msg == null) {
            bar.visibility = View.GONE
            return
        }
        bar.visibility = View.VISIBLE
        tv.text = "📌 ${msg.text.ifBlank { msg.attachmentName ?: "Media" }.take(60)}"
        bar.setOnClickListener {
            // scroll to message if possible
            val idx = (0 until adapter.itemCount).firstOrNull { adapter.getMessage(it)?.id == pinId }
            if (idx != null) rv.scrollToPosition(idx)
        }
    }

    private fun editMessage(message: Message) {
        val input = EditText(this).apply {
            setText(message.text)
            setSelection(text?.length ?: 0)
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(this)
            .setTitle("Edit pesan")
            .setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                val newText = input.text?.toString().orEmpty().trim()
                if (newText.isBlank()) return@setPositiveButton
                store.updateText(message.id, newText, edited = true)
                adapter.upsertMessage(store.find(message.id))
                ChatConnectionService.send(
                    Message(
                        type = "edit",
                        from = session.userId ?: "",
                        to = peerId,
                        roomId = roomId,
                        messageId = message.id,
                        text = newText,
                        edited = true,
                        editedAt = System.currentTimeMillis()
                    )
                )
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun forwardMessage(message: Message) {
        // Teruskan ke peer yang sama sebagai pesan baru bertanda forward (sederhana)
        val from = session.userId ?: return
        val id = java.util.UUID.randomUUID().toString()
        val local = Message(
            id = id,
            from = from,
            to = peerId,
            roomId = roomId,
            roomKind = roomKind,
            text = message.text,
            attachmentName = message.attachmentName,
            attachmentMime = message.attachmentMime,
            attachmentPath = message.attachmentPath,
            forwardedFrom = message.from,
            forwardedFromName = message.replyToName ?: "Pengguna",
            status = "pending"
        )
        store.save(local)
        adapter.upsertMessage(local)
        rv.scrollToPosition(adapter.itemCount - 1)
        ChatConnectionService.send(store.wireMessage(local).copy(type = "message", forwardedFrom = message.from, forwardedFromName = local.forwardedFromName))
        Toast.makeText(this, "Diteruskan", Toast.LENGTH_SHORT).show()
    }

    private fun showMessageInfo(message: Message) {
        val status = when (message.status) {
            "pending" -> "Mengirim…"
            "sent" -> "Terkirim"
            "delivered" -> "Terkirim (delivered)"
            "read" -> "Dibaca"
            else -> message.status
        }
        val edited = if (message.edited) "
Diedit: ya" else ""
        val fwd = if (!message.forwardedFrom.isNullOrBlank()) "
Diteruskan dari: ${message.forwardedFromName}" else ""
        val react = if (!message.reactions.isNullOrBlank()) "
Reaksi: ${message.reactions}" else ""
        AlertDialog.Builder(this)
            .setTitle("Info pesan")
            .setMessage("Status: $status
Waktu: ${java.text.SimpleDateFormat("dd MMM yyyy HH:mm", java.util.Locale("id","ID")).format(java.util.Date(message.timestamp))}$edited$fwd$react")
            .setPositiveButton("OK", null)
            .show()
    }


    /**
     * Geser bubble ke kanan → reply (UX WhatsApp).
     * Item di-reset setelah swipe supaya tidak hilang dari list.
     */
    private fun setupSwipeToReply() {
        val callback = object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean = false

            override fun getSwipeThreshold(viewHolder: RecyclerView.ViewHolder): Float = 0.28f

            override fun getSwipeEscapeVelocity(defaultValue: Float): Float = defaultValue * 0.8f

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val pos = viewHolder.bindingAdapterPosition
                val msg = if (pos != RecyclerView.NO_POSITION) adapter.getMessage(pos) else null
                // Kembalikan item ke posisi (swipe bukan delete)
                if (pos != RecyclerView.NO_POSITION) adapter.notifyItemChanged(pos)
                if (msg != null && msg.text != "Pesan ini dihapus") {
                    setReply(msg)
                }
            }

            override fun onChildDraw(
                c: android.graphics.Canvas,
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                dX: Float,
                dY: Float,
                actionState: Int,
                isCurrentlyActive: Boolean
            ) {
                // Batasi geser biar tidak terlalu jauh (mirip WA)
                val maxDx = recyclerView.width * 0.22f
                val clamped = dX.coerceIn(0f, maxDx)
                super.onChildDraw(c, recyclerView, viewHolder, clamped, dY, actionState, isCurrentlyActive)
            }
        }
        ItemTouchHelper(callback).attachToRecyclerView(rv)
    }

    private fun setReply(message: Message) {
        replyTarget = message
        val name = when {
            message.from == session.userId -> "Anda"
            else -> intent.getStringExtra("peerName") ?: message.replyToName ?: "Pesan"
        }
        // Preview isi yang di-reply
        val preview = when {
            message.text == "Pesan ini dihapus" -> "Pesan dihapus"
            message.text.isNotBlank() -> message.text
            message.hasAttachment -> {
                val mime = message.attachmentMime.orEmpty()
                when {
                    mime.startsWith("image/") -> "📷 Foto"
                    mime.startsWith("video/") -> "🎬 Video"
                    mime.startsWith("audio/") -> "🎤 Pesan suara"
                    else -> "📎 ${message.attachmentName ?: "File"}"
                }
            }
            else -> "Pesan"
        }
        findViewById<TextView>(R.id.tvReplyToName).text = name
        findViewById<TextView>(R.id.tvReplyToPreview).text = preview
        findViewById<View>(R.id.replyBar).visibility = View.VISIBLE
        etMessage.requestFocus()
    }

    private fun clearReply() {
        replyTarget = null
        findViewById<View>(R.id.replyBar).visibility = View.GONE
    }


    private fun toggleComposeOptions() {
        val bar = findViewById<View>(R.id.composeOptions)
        bar.visibility = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun setupComposeChips() {
        val chipSilent = findViewById<TextView>(R.id.chipSilent)
        val chipCapsule = findViewById<TextView>(R.id.chipCapsule)
        val chipLabel = findViewById<TextView>(R.id.chipLabel)
        fun refreshChips() {
            chipSilent.setBackgroundResource(if (composeSilent) R.drawable.bg_compose_chip_on else R.drawable.bg_compose_chip)
            chipCapsule.setBackgroundResource(if (composeUnlockAt != null) R.drawable.bg_compose_chip_on else R.drawable.bg_compose_chip)
            chipLabel.setBackgroundResource(if (composeLabel != null) R.drawable.bg_compose_chip_on else R.drawable.bg_compose_chip)
            chipCapsule.text = if (composeUnlockAt != null) {
                val fmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
                "⏳ ${fmt.format(java.util.Date(composeUnlockAt!!))}"
            } else "⏳ Kapsul waktu"
            chipLabel.text = when (composeLabel) {
                "question" -> "❓ Pertanyaan"
                "task" -> "✅ Tugas"
                "info" -> "ℹ️ Info"
                else -> "🏷 Label"
            }
        }
        chipSilent.setOnClickListener {
            composeSilent = !composeSilent
            refreshChips()
            Toast.makeText(
                this,
                if (composeSilent) "Mode senyap: tanpa notifikasi ke penerima" else "Notifikasi normal",
                Toast.LENGTH_SHORT
            ).show()
        }
        chipCapsule.setOnClickListener { showCapsulePicker(); refreshChips() }
        chipLabel.setOnClickListener {
            val opts = arrayOf("Tanpa label", "❓ Pertanyaan", "✅ Tugas", "ℹ️ Info")
            AlertDialog.Builder(this).setTitle("Label intent").setItems(opts) { _, which ->
                composeLabel = when (which) {
                    1 -> "question"
                    2 -> "task"
                    3 -> "info"
                    else -> null
                }
                refreshChips()
            }.show()
        }
        refreshChips()
    }

    private fun showCapsulePicker() {
        val opts = arrayOf(
            "Nonaktifkan kapsul",
            "Buka 1 jam lagi",
            "Buka 6 jam lagi",
            "Buka besok pagi (09:00)",
            "Buka 3 hari lagi"
        )
        AlertDialog.Builder(this).setTitle("Kapsul waktu").setItems(opts) { _, which ->
            val now = System.currentTimeMillis()
            composeUnlockAt = when (which) {
                1 -> now + 60L * 60 * 1000
                2 -> now + 6L * 60 * 60 * 1000
                3 -> {
                    val cal = java.util.Calendar.getInstance()
                    cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
                    cal.set(java.util.Calendar.HOUR_OF_DAY, 9)
                    cal.set(java.util.Calendar.MINUTE, 0)
                    cal.set(java.util.Calendar.SECOND, 0)
                    cal.timeInMillis
                }
                4 -> now + 3L * 24 * 60 * 60 * 1000
                else -> null
            }
            findViewById<TextView>(R.id.chipCapsule).let { chip ->
                chip.setBackgroundResource(if (composeUnlockAt != null) R.drawable.bg_compose_chip_on else R.drawable.bg_compose_chip)
                chip.text = if (composeUnlockAt != null) {
                    val fmt = java.text.SimpleDateFormat("dd MMM HH:mm", java.util.Locale("id", "ID"))
                    "⏳ ${fmt.format(java.util.Date(composeUnlockAt!!))}"
                } else "⏳ Kapsul waktu"
            }
            if (composeUnlockAt != null) {
                Toast.makeText(this, "Isi pesan terkunci sampai waktu tersebut", Toast.LENGTH_SHORT).show()
            }
        }.show()
    }

    private fun showPrivateNoteDialog() {
        val input = EditText(this).apply {
            setText(contactStore.getNote(peerId))
            hint = "Catatan hanya terlihat oleh kamu"
            setPadding(48, 32, 48, 32)
            minLines = 3
        }
        AlertDialog.Builder(this)
            .setTitle("Catatan privat")
            .setMessage("Lawan bicara tidak pernah melihat catatan ini.")
            .setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                contactStore.setNote(peerId, input.text?.toString().orEmpty())
                Toast.makeText(this, "Catatan disimpan di perangkat ini", Toast.LENGTH_SHORT).show()
                refreshPrivateNoteHint()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun refreshPrivateNoteHint() {
        val note = contactStore.getNote(peerId)
        val sub = findViewById<TextView>(R.id.tvPeerSub)
        if (note.isNotBlank() && roomId == null) {
            sub.text = "📝 " + note.take(40) + if (note.length > 40) "…" else ""
        }
    }

    private fun resetComposeFlags() {
        composeSilent = false
        composeUnlockAt = null
        composeLabel = null
        if (::contactStore.isInitialized) {
            runCatching {
                findViewById<TextView>(R.id.chipSilent).setBackgroundResource(R.drawable.bg_compose_chip)
                findViewById<TextView>(R.id.chipCapsule).apply {
                    setBackgroundResource(R.drawable.bg_compose_chip)
                    text = "⏳ Kapsul waktu"
                }
                findViewById<TextView>(R.id.chipLabel).apply {
                    setBackgroundResource(R.drawable.bg_compose_chip)
                    text = "🏷 Label"
                }
            }
        }
    }

    private fun displayName(uri: Uri): String =
        runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull() ?: "attachment"

    private fun openAttachment(message: Message) {
        val file = store.file(message.attachmentPath) ?: return
        val mime = message.attachmentMime.orEmpty()
        // Foto: tampilkan fullscreen di dialog (seperti WhatsApp)
        if (mime.startsWith("image/") || listOf(".jpg", ".jpeg", ".png", ".webp", ".gif").any {
                message.attachmentName?.endsWith(it, true) == true
            }) {
            val bmp = runCatching {
                android.graphics.BitmapFactory.decodeFile(file.absolutePath)
            }.getOrNull()
            if (bmp != null) {
                val iv = android.widget.ImageView(this).apply {
                    setImageBitmap(bmp)
                    adjustViewBounds = true
                    scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                    setPadding(0, 24, 0, 24)
                    setBackgroundColor(0xFF000000.toInt())
                }
                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setView(iv)
                    .setPositiveButton("Tutup", null)
                    .show()
                return
            }
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        runCatching {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, mime.ifBlank { "*/*" })
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }.onFailure {
            android.widget.Toast.makeText(this, "Tidak ada aplikasi untuk membuka file ini", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        MessageAdapter.stopPlayback()
        super.onDestroy()
    }


    private fun searchInChat() {
        val input = EditText(this).apply {
            hint = "Cari di chat ini"
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(this).setTitle("Cari pesan").setView(input)
            .setPositiveButton("Cari") { _, _ ->
                val q = input.text?.toString().orEmpty().trim().lowercase()
                if (q.isBlank()) return@setPositiveButton
                val hits = (0 until adapter.itemCount).mapNotNull { i ->
                    val m = adapter.getMessage(i) ?: return@mapNotNull null
                    if (m.text.lowercase().contains(q)) i to m else null
                }
                if (hits.isEmpty()) Toast.makeText(this, "Tidak ditemukan", Toast.LENGTH_SHORT).show()
                else {
                    rv.scrollToPosition(hits.last().first)
                    Toast.makeText(this, "${hits.size} hasil", Toast.LENGTH_SHORT).show()
                }
            }.setNegativeButton("Batal", null).show()
    }

    private fun toggleMute() {
        if (extras.isMuted(chatKey())) {
            extras.unmute(chatKey())
            Toast.makeText(this, "Notifikasi chat aktif", Toast.LENGTH_SHORT).show()
        } else {
            val opts = arrayOf("1 jam", "8 jam", "1 minggu", "Selamanya")
            AlertDialog.Builder(this).setTitle("Bisukan chat").setItems(opts) { _, w ->
                val until = when (w) {
                    0 -> System.currentTimeMillis() + 3600_000L
                    1 -> System.currentTimeMillis() + 8 * 3600_000L
                    2 -> System.currentTimeMillis() + 7 * 24 * 3600_000L
                    else -> Long.MAX_VALUE / 2
                }
                extras.mute(chatKey(), until)
                Toast.makeText(this, "Chat dibisukan", Toast.LENGTH_SHORT).show()
            }.show()
        }
    }

    private fun toggleBlock() {
        if (roomId != null) {
            Toast.makeText(this, "Blokir hanya untuk chat pribadi", Toast.LENGTH_SHORT).show()
            return
        }
        if (extras.isBlocked(peerId)) {
            extras.unblock(peerId)
            Toast.makeText(this, "Pengguna dibuka blokir", Toast.LENGTH_SHORT).show()
        } else {
            AlertDialog.Builder(this).setTitle("Blokir pengguna?")
                .setMessage("Pesan dari pengguna ini tidak akan ditampilkan.")
                .setPositiveButton("Blokir") { _, _ ->
                    extras.block(peerId)
                    Toast.makeText(this, "Diblokir", Toast.LENGTH_SHORT).show()
                    finish()
                }.setNegativeButton("Batal", null).show()
        }
    }

    private fun pickDisappear() {
        val opts = arrayOf("Mati", "24 jam", "7 hari", "30 hari")
        AlertDialog.Builder(this).setTitle("Pesan menghilang").setItems(opts) { _, w ->
            val sec = when (w) {
                1 -> 24 * 3600
                2 -> 7 * 24 * 3600
                3 -> 30 * 24 * 3600
                else -> 0
            }
            extras.setDisappearSeconds(chatKey(), sec)
            Toast.makeText(this, if (sec == 0) "Timer dimatikan" else "Timer aktif", Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun clearChat() {
        AlertDialog.Builder(this).setTitle("Hapus riwayat chat?")
            .setMessage("Pesan di perangkat ini akan dihapus.")
            .setPositiveButton("Hapus") { _, _ ->
                if (roomId != null) {
                    // filter by room in store - clear by deleting all room messages
                    store.all().filter { it.roomId == roomId }.forEach { store.deleteForMe(it.id) }
                } else {
                    store.clearConversation(session.userId ?: "", peerId)
                }
                adapter.setMessages(emptyList())
                Toast.makeText(this, "Chat dikosongkan", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Batal", null).show()
    }


    private fun showCallTypePicker() {
        val peerName = findViewById<TextView>(R.id.tvPeerName).text?.toString().orEmpty()
        val options = arrayOf("Panggilan suara", "Panggilan video")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Panggil")
            .setItems(options) { _, which ->
                startCall(if (which == 1) "video" else "voice", peerName)
            }
            .show()
    }

    private fun startCall(callMode: String, peerName: String? = null) {
        val name = peerName ?: findViewById<TextView>(R.id.tvPeerName).text?.toString()
        startActivity(
            Intent(this, CallActivity::class.java)
                .putExtra("peerId", peerId)
                .putExtra("mode", callMode)
                .putExtra("incoming", false)
                .putExtra("peerName", name)
                .putExtra("peerAvatar", intent.getStringExtra("peerAvatar"))
        )
    }
}
