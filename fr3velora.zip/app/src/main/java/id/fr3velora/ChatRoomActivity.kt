package id.fr3velora

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Base64
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import id.fr3velora.model.Message
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class ChatRoomActivity : AppCompatActivity() {
    private lateinit var session: SessionManager; private lateinit var store: LocalChatStore; private lateinit var adapter: MessageAdapter
    private lateinit var peerId: String; private var roomId: String? = null; private var roomKind: String? = null; private lateinit var rv: RecyclerView; private var pendingAttachment: Uri? = null
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri ?: return@registerForActivityResult; pendingAttachment = uri; findViewById<EditText>(R.id.etMessage).hint = "Lampiran dipilih: ${displayName(uri)}" }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val message = store.find(intent?.getStringExtra("messageId")) ?: return
            if (roomId != null && message.roomId != roomId) return
            if (roomId == null && message.from != peerId && message.to != peerId) return
            adapter.upsertMessage(message); rv.scrollToPosition(adapter.itemCount - 1)
        }
    }
    private val callReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.getStringExtra("type") == "call_offer" && intent.getStringExtra("from") == peerId) startActivity(Intent(this@ChatRoomActivity, CallActivity::class.java).putExtra("peerId", peerId).putExtra("mode", intent.getStringExtra("mode") ?: "voice").putExtra("callId", intent.getStringExtra("callId")).putExtra("incoming", true))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_chat_room)
        session = SessionManager(this); store = LocalChatStore(this); peerId = intent.getStringExtra("peerId") ?: ""; roomId = intent.getStringExtra("roomId"); roomKind = intent.getStringExtra("roomKind")
        findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar).apply { title = intent.getStringExtra("peerName") ?: "Chat"; setNavigationOnClickListener { finish() } }
        rv = findViewById(R.id.rvMessages); rv.layoutManager = LinearLayoutManager(this)
        val initial = if (roomId != null) store.conversationRoom(roomId!!) else store.conversation(session.userId ?: "", peerId)
        adapter = MessageAdapter(initial.toMutableList(), session.userId ?: "", { openAttachment(it) }, { showDeleteDialog(it) })
        rv.adapter = adapter; rv.scrollToPosition(maxOf(adapter.itemCount - 1, 0))
        findViewById<android.view.View>(R.id.btnAttach).setOnClickListener { picker.launch(arrayOf("image/*", "video/*", "audio/*", "application/pdf", "text/*", "application/*")) }
        findViewById<android.view.View>(R.id.btnSend).setOnClickListener { sendCurrent() }
        findViewById<android.view.View>(R.id.btnVoiceCall).setOnClickListener { startCall("voice") }
        findViewById<android.view.View>(R.id.btnVideoCall).setOnClickListener { startCall("video") }
        if (roomId != null) { findViewById<android.view.View>(R.id.btnVoiceCall).visibility = android.view.View.GONE; findViewById<android.view.View>(R.id.btnVideoCall).visibility = android.view.View.GONE }
    }

    override fun onResume() {
        super.onResume(); ChatState.activePeerId = peerId.takeIf { roomId == null }
        registerReceiverCompat()
        val myId = session.userId ?: return
        if (roomId != null) { adapter.setMessages(store.conversationRoom(roomId!!)); return }
        store.conversation(myId, peerId).filter { it.from == peerId && it.status != "read" }.forEach { store.updateStatus(it.id, "read"); ChatConnectionService.send(Message(type = "read", from = myId, to = peerId, messageId = it.id)) }
        adapter.setMessages(store.conversation(myId, peerId))
    }
    private fun registerReceiverCompat() { val filter = IntentFilter("id.fr3velora.NEW_MESSAGE"); val callFilter = IntentFilter("id.fr3velora.CALL_EVENT"); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) { registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED); registerReceiver(callReceiver, callFilter, Context.RECEIVER_NOT_EXPORTED) } else @Suppress("UnspecifiedRegisterReceiverFlag") run { registerReceiver(receiver, filter); registerReceiver(callReceiver, callFilter) } }
    override fun onPause() { super.onPause(); if (ChatState.activePeerId == peerId) ChatState.activePeerId = null; runCatching { unregisterReceiver(receiver) }; runCatching { unregisterReceiver(callReceiver) } }

    private fun sendCurrent() {
        val et = findViewById<EditText>(R.id.etMessage); val text = et.text.toString().trim(); val uri = pendingAttachment
        if (text.isEmpty() && uri == null) return
        lifecycleScope.launch {
            val pair = withContext(Dispatchers.IO) { buildMessage(text, uri) }
            if (pair == null) { Toast.makeText(this@ChatRoomActivity, "File gagal dibaca atau lebih besar dari 10 MB", Toast.LENGTH_SHORT).show(); return@launch }
            val (local, wire) = pair; store.save(local); adapter.upsertMessage(local); rv.scrollToPosition(adapter.itemCount - 1); ChatConnectionService.send(wire)
            pendingAttachment = null; et.text.clear(); et.hint = "Tulis pesan..."
        }
    }
    private fun buildMessage(text: String, uri: Uri?): Pair<Message, Message>? {
        val id = UUID.randomUUID().toString(); val from = session.userId ?: return null
        if (uri == null) { val m = Message(id = id, from = from, to = peerId, roomId = roomId, roomKind = roomKind, text = text); return m to m }
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null; if (bytes.size > 10 * 1024 * 1024) return null
        val name = displayName(uri); val mime = contentResolver.getType(uri) ?: "application/octet-stream"; val path = store.copyAttachment(uri, name) ?: return null
        val local = Message(id, from = from, to = peerId, roomId = roomId, roomKind = roomKind, text = text, attachmentName = name, attachmentMime = mime, attachmentPath = path)
        return local to local.copy(attachmentPath = null, attachmentBase64 = Base64.encodeToString(bytes, Base64.NO_WRAP))
    }

    private fun showDeleteDialog(message: Message) {
        val canDeleteEveryone = message.from == (session.userId ?: "") && message.text != "Pesan ini dihapus"
        val options = if (canDeleteEveryone) arrayOf("Hapus untuk saya", "Hapus untuk semua") else arrayOf("Hapus untuk saya")
        AlertDialog.Builder(this).setTitle("Hapus pesan").setItems(options) { _, which ->
            if (which == 0) { store.deleteForMe(message.id); adapter.removeMessage(message.id) }
            else { store.deleteForEveryone(message.id); adapter.upsertMessage(store.find(message.id)); ChatConnectionService.send(Message(type = "delete", from = session.userId ?: "", to = peerId, messageId = message.id, mode = "everyone")) }
        }.show()
    }
    private fun displayName(uri: Uri): String = runCatching { contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null } }.getOrNull() ?: "attachment"
    private fun openAttachment(message: Message) { val file = store.file(message.attachmentPath) ?: return; val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file); startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, message.attachmentMime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
    private fun startCall(callMode: String) { startActivity(Intent(this, CallActivity::class.java).putExtra("peerId", peerId).putExtra("mode", callMode).putExtra("incoming", false)) }
}
