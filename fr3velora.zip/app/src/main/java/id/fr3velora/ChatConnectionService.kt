package id.fr3velora

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import id.fr3velora.model.Message
import id.fr3velora.network.ApiClient
import id.fr3velora.network.WebSocketManager

/**
 * Foreground service WebSocket — pola yang dipakai app chat:
 * - startForeground + notifikasi persisten (wajib Android 8+)
 * - START_STICKY: OS coba hidupkan lagi jika terbunuh karena memori
 * - stopWithTask=false: swipe dari recent tidak otomatis matikan service
 * - NetworkCallback: reconnect saat jaringan kembali
 * - WakeLock singkat hanya saat reconnect (bukan terus-menerus)
 *
 * Pesan saat app mati total tetap andalkan FCM (lihat FcmService).
 */
class ChatConnectionService : Service() {
    companion object {
        private const val NOTIF_ID = 1
        private var wsManager: WebSocketManager? = null
        fun send(message: Message) { wsManager?.send(message) }
        fun isConnected(): Boolean = wsManager != null

        fun ensureRunning(context: Context) {
            if (SessionManager(context).sessionCookie.isNullOrBlank()) return
            runCatching {
                androidx.core.content.ContextCompat.startForegroundService(
                    context,
                    Intent(context, ChatConnectionService::class.java)
                )
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var store: LocalChatStore
    private var retryStarted = false
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private val retryTask = object : Runnable {
        override fun run() {
            if (wsManager == null) connectIfNeeded()
            else flushOutbox()
            handler.postDelayed(this, 8_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        store = LocalChatStore(this)
        NotificationHelper.createChannel(this)
        registerNetworkCallback()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildForegroundNotification())
        connectIfNeeded()
        if (!retryStarted) {
            retryStarted = true
            handler.postDelayed(retryTask, 5_000)
        }
        KeepAliveScheduler.schedule(this)
        return START_STICKY
    }

    private fun buildForegroundNotification(): Notification {
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, ChatListActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, "fr3velora_messages")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("fr3velora terhubung")
            .setContentText("Menunggu pesan masuk…")
            .setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun registerNetworkCallback() {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                handler.post {
                    // Jaringan kembali → pastikan socket hidup
                    if (wsManager == null) {
                        acquireBriefWakeLock()
                        connectIfNeeded()
                    }
                }
            }

            override fun onLost(network: Network) {
                // Biarkan retry loop yang reconnect
            }
        }
        runCatching { cm.registerNetworkCallback(req, networkCallback!!) }
    }

    private fun acquireBriefWakeLock() {
        runCatching {
            if (wakeLock == null) {
                val pm = getSystemService(PowerManager::class.java)
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "fr3velora:reconnect")
                wakeLock?.setReferenceCounted(false)
            }
            wakeLock?.acquire(10_000L) // max 10 detik — bukan abadi
        }
    }

    private fun connectIfNeeded() {
        if (wsManager != null) return
        val session = SessionManager(applicationContext)
        val cookie = session.sessionCookie ?: return
        refreshUserCache(cookie)
        wsManager = WebSocketManager(getString(R.string.ws_base_url), cookie, { handleIncoming(it) }) { connected ->
            if (connected) {
                flushOutbox()
            } else {
                wsManager = null
                handler.postDelayed({ connectIfNeeded() }, 3_000)
            }
        }
        wsManager?.connect()
    }

    private fun refreshUserCache(cookie: String) {
        Thread {
            val result = ApiClient(getString(R.string.api_base_url)).getUsers(cookie)
            if (result.isSuccess) {
                UserCache.map = (result.data ?: emptyList()).associate { it.id to it.username }
            }
        }.start()
    }

    private fun flushOutbox() {
        Thread { store.pending().forEach { wsManager?.send(store.wireMessage(it)) } }.start()
    }

    private fun handleIncoming(event: Message) {
        when (event.type) {
            "call_upgrade", "call_upgrade_accept" -> {
                broadcastCall(event)
                return
            }
            "typing", "presence" -> {
                broadcast(event.messageId ?: event.from)
                Intent("id.fr3velora.PRESENCE").apply {
                    putExtra("type", event.type)
                    putExtra("from", event.from)
                    putExtra("to", event.to)
                    putExtra("text", event.text)
                    setPackage(packageName)
                }.also { sendBroadcast(it) }
                return
            }
            "edit" -> {
                store.updateText(event.messageId, event.text, edited = true)
                broadcast(event.messageId)
                return
            }
            "react" -> {
                store.updateReactions(event.messageId, event.reactions ?: event.text)
                broadcast(event.messageId)
                return
            }
            "pin" -> {
                store.updatePinned(event.messageId, true)
                broadcast(event.messageId)
                return
            }
            "ack" -> {
                if (event.status == "sent") store.updateStatus(event.messageId, "sent")
                broadcast(event.messageId)
            }
            "delivered" -> {
                store.updateStatus(event.messageId, "delivered")
                broadcast(event.messageId)
            }
            "read" -> {
                store.updateStatus(event.messageId, "read")
                broadcast(event.messageId)
            }
            "delete" -> {
                if (event.mode == "everyone") store.deleteForEveryone(event.messageId)
                broadcast(event.messageId)
            }
            "call_offer", "call_answer", "call_ice", "call_end", "call_reject" -> broadcastCall(event)
            "error" -> Unit
            else -> receiveMessage(event)
        }
    }

    private fun receiveMessage(message: Message) {
        val myUserId = SessionManager(applicationContext).userId ?: return
        if (message.to != myUserId && message.roomId == null) return
        val extras = ChatExtrasStore(applicationContext)
        if (message.from.isNotBlank() && extras.isBlocked(message.from)) return
        if (message.isExpired()) return
        if (message.roomId == null && message.from.isNotBlank()) {
            val archive = ArchiveStore(applicationContext)
            if (archive.isChatArchived(message.from)) archive.unarchiveChat(message.from)
        }
        val stored = store.saveIncoming(message)
        send(Message(type = "delivered", from = myUserId, to = message.from, messageId = stored.id))
        if (ChatState.activePeerId == message.from) {
            store.updateStatus(stored.id, "read")
            if (SettingsStore(this).sendReadReceipts) {
                send(Message(type = "read", from = myUserId, to = message.from, messageId = stored.id))
            }
        }
        broadcast(stored.id)
        val muteKey = message.roomId ?: message.from
        if (ChatState.activePeerId != message.from && !message.silent && !extras.isMuted(muteKey)) {
            val body = when {
                message.isLockedNow() -> "⏳ Kapsul waktu (terkunci)"
                message.text.isNotBlank() -> message.text
                else -> message.attachmentName ?: "Lampiran"
            }
            val prefix = when (message.label) {
                "question" -> "❓ "
                "task" -> "✅ "
                "info" -> "ℹ️ "
                else -> ""
            }
            NotificationHelper.showMessageNotification(
                applicationContext,
                message.from,
                UserCache.nameFor(message.from),
                prefix + body
            )
        }
    }

    private fun broadcast(id: String?) {
        if (id == null) return
        Intent("id.fr3velora.NEW_MESSAGE").apply {
            putExtra("messageId", id)
            setPackage(packageName)
        }.also { sendBroadcast(it) }
    }

    private fun broadcastCall(event: Message) {
        Intent("id.fr3velora.CALL_EVENT").apply {
            putExtra("type", event.type)
            putExtra("from", event.from)
            putExtra("to", event.to)
            putExtra("mode", event.mode)
            putExtra("callId", event.messageId)
            putExtra("payload", event.text)
            setPackage(packageName)
        }.also { sendBroadcast(it) }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        networkCallback?.let { cb ->
            runCatching {
                getSystemService(ConnectivityManager::class.java)?.unregisterNetworkCallback(cb)
            }
        }
        networkCallback = null
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        wsManager?.disconnect()
        wsManager = null
        // START_STICKY: OS boleh restart service; WorkManager juga akan coba lagi
    }

    override fun onBind(intent: Intent?) = null
}
