package id.fr3velora

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.slider.Slider

/** Pengaturan latar belakang chat: warna polos, gradien, atau foto sendiri (+ redupkan). */
class ChatBackgroundActivity : AppCompatActivity() {
    private lateinit var prefs: AppPrefs
    private lateinit var previewBg: ImageView
    private lateinit var previewDim: View
    private lateinit var llColors: LinearLayout
    private lateinit var llGradients: LinearLayout
    private lateinit var slider: Slider

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        if (prefs.importBackground(uri)) refresh() else Toast.makeText(this, "Foto gagal dibaca", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_background)
        prefs = AppPrefs(this)
        findViewById<Toolbar>(R.id.toolbarBg).setNavigationOnClickListener { finish() }
        previewBg = findViewById(R.id.ivPreviewBg); previewDim = findViewById(R.id.viewPreviewDim)
        llColors = findViewById(R.id.llColors); llGradients = findViewById(R.id.llGradients); slider = findViewById(R.id.sliderDim)
        slider.value = prefs.bgDim.toFloat().coerceIn(0f, 70f)
        slider.addOnChangeListener { _, value, fromUser -> if (fromUser) { prefs.bgDim = value.toInt(); prefs.applyBackground(previewBg, previewDim) } }
        findViewById<View>(R.id.btnPickBg).setOnClickListener { picker.launch(arrayOf("image/*")) }
        findViewById<View>(R.id.btnResetBg).setOnClickListener { prefs.resetBackground(); refresh() }
        refresh()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun swatch(selected: Boolean, fill: GradientDrawable, onClick: () -> Unit): View {
        val v = View(this)
        val size = dp(56)
        v.layoutParams = LinearLayout.LayoutParams(size, size).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
        fill.shape = GradientDrawable.OVAL
        fill.setStroke(if (selected) dp(3) else dp(1), if (selected) getColor(R.color.brand_primary) else getColor(R.color.divider))
        v.background = fill
        v.setOnClickListener { onClick() }
        return v
    }

    private fun refresh() {
        prefs.applyBackground(previewBg, previewDim)
        slider.isEnabled = prefs.bgType == "image"
        llColors.removeAllViews(); llGradients.removeAllViews()
        AppPrefs.BG_COLORS.forEach { color ->
            val d = GradientDrawable().apply { setColor(color) }
            llColors.addView(swatch(prefs.bgType == "color" && prefs.bgColor == color, d) { prefs.setBackgroundColor(color); refresh() })
        }
        for (i in 0 until AppPrefs.GRADIENT_COUNT) {
            val d = AppPrefs.gradientFor(i)
            llGradients.addView(swatch(prefs.bgType == "gradient" && prefs.bgGradient == i, d) { prefs.setBackgroundGradient(i); refresh() })
        }
    }
}
