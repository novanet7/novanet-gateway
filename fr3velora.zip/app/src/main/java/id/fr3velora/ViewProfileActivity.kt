package id.fr3velora

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import id.fr3velora.model.User
import id.fr3velora.network.ApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Lihat profil orang lain (read-only): foto, nama, username, bio.
 * Tidak bisa mengedit — hanya pemilik yang edit lewat ProfileActivity.
 */
class ViewProfileActivity : AppCompatActivity() {
    private lateinit var session: SessionManager
    private lateinit var api: ApiClient
    private lateinit var contactStore: ContactStore
    private var userId: String = ""
    private var user: User? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_profile)
        session = SessionManager(this)
        api = ApiClient(getString(R.string.api_base_url))
        contactStore = ContactStore(this)

        userId = intent.getStringExtra("userId").orEmpty()
        if (userId.isBlank()) {
            Toast.makeText(this, "Profil tidak ditemukan", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Prefill dari intent (cepat), lalu refresh dari server
        val preName = intent.getStringExtra("displayName").orEmpty()
        val preUser = intent.getStringExtra("username").orEmpty()
        val preBio = intent.getStringExtra("bio").orEmpty()
        val preAvatar = intent.getStringExtra("avatarUrl")

        findViewById<Toolbar>(R.id.toolbarViewProfile).setNavigationOnClickListener { finish() }

        if (preName.isNotBlank() || preUser.isNotBlank()) {
            bindHeader(preName.ifBlank { preUser }, preUser, preBio, preAvatar)
        }

        findViewById<View>(R.id.actionMessage).setOnClickListener { openChat() }
        findViewById<View>(R.id.actionCall).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Panggil")
                .setItems(arrayOf("Panggilan suara", "Panggilan video")) { _, which ->
                    startCall(if (which == 1) "video" else "voice")
                }.show()
        }
        findViewById<View>(R.id.actionVideo).setOnClickListener { startCall("video") }
        findViewById<View>(R.id.rowPrivateNote).setOnClickListener { editPrivateNote() }
        findViewById<View>(R.id.ivFullAvatar).setOnClickListener {
            // sudah full-bleed; bisa ditambah zoom nanti
        }

        refreshPrivateNote()
        loadFromServer()
    }

    private fun loadFromServer() {
        val cookie = session.sessionCookie ?: return
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { api.getUser(cookie, userId) }
            if (!result.isSuccess || result.data == null) {
                if (user == null) {
                    Toast.makeText(
                        this@ViewProfileActivity,
                        result.errorMessage ?: "Gagal memuat profil",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                return@launch
            }
            user = result.data
            val u = result.data
            bindHeader(u.displayLabel(), u.username, u.bio, u.avatar_url)
            bindMeta(u)
        }
    }

    private fun bindHeader(name: String, username: String, bio: String, avatarUrl: String?) {
        findViewById<TextView>(R.id.tvViewName).text = name.ifBlank { username }
        findViewById<TextView>(R.id.tvViewUsername).text = if (username.isNotBlank()) "@$username" else ""
        findViewById<TextView>(R.id.tvViewUsernameRow).text = if (username.isNotBlank()) "@$username" else "—"
        findViewById<TextView>(R.id.tvViewBio).text =
            bio.ifBlank { "Belum ada bio" }
        findViewById<TextView>(R.id.tvViewBio).setTextColor(
            getColor(if (bio.isBlank()) R.color.text_secondary else R.color.text_primary)
        )

        val iv = findViewById<ImageView>(R.id.ivFullAvatar)
        val initial = findViewById<TextView>(R.id.tvFullInitial)
        initial.text = avatarInitial(name.ifBlank { username })
        initial.setBackgroundColor(avatarColor(name.ifBlank { username }))
        initial.visibility = View.VISIBLE
        iv.setImageDrawable(null)

        val abs = api.absoluteAvatarUrl(avatarUrl)
        if (!abs.isNullOrBlank()) {
            lifecycleScope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    runCatching { URL(abs).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull()
                }
                if (bmp != null) {
                    iv.setImageBitmap(bmp)
                    initial.visibility = View.GONE
                }
            }
        }
    }

    private fun bindMeta(u: User) {
        val created = u.created_at
        val label = if (created.isNullOrBlank()) {
            ""
        } else {
            runCatching {
                // ISO-ish
                val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }
                val date = parser.parse(created.take(19))
                val out = SimpleDateFormat("d MMMM yyyy", Locale("id", "ID"))
                "Bergabung ${out.format(date!!)}"
            }.getOrElse { "" }
        }
        findViewById<TextView>(R.id.tvMemberSince).text = label
    }

    private fun refreshPrivateNote() {
        val note = contactStore.getNote(userId)
        findViewById<TextView>(R.id.tvPrivateNotePreview).text =
            note.ifBlank { "Tambah catatan" }
    }

    private fun editPrivateNote() {
        val input = EditText(this).apply {
            setText(contactStore.getNote(userId))
            hint = "Catatan hanya terlihat oleh kamu"
            setPadding(48, 32, 48, 32)
            minLines = 3
        }
        AlertDialog.Builder(this)
            .setTitle("Catatan privat")
            .setMessage("Lawan bicara tidak pernah melihat ini.")
            .setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                contactStore.setNote(userId, input.text?.toString().orEmpty())
                refreshPrivateNote()
                Toast.makeText(this, "Catatan disimpan", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun openChat() {
        val u = user
        val name = u?.displayLabel()
            ?: intent.getStringExtra("displayName")
            ?: intent.getStringExtra("username")
            ?: "Chat"
        val avatar = u?.avatar_url ?: intent.getStringExtra("avatarUrl")
        startActivity(
            Intent(this, ChatRoomActivity::class.java)
                .putExtra("peerId", userId)
                .putExtra("peerName", name)
                .putExtra("peerAvatar", avatar)
        )
    }

    private fun startCall(mode: String) {
        val name = user?.displayLabel()
            ?: intent.getStringExtra("displayName")
            ?: intent.getStringExtra("username")
            ?: "Kontak"
        startActivity(
            Intent(this, CallActivity::class.java)
                .putExtra("peerId", userId)
                .putExtra("mode", mode)
                .putExtra("incoming", false)
                .putExtra("peerName", name)
                .putExtra("peerAvatar", user?.avatar_url ?: intent.getStringExtra("avatarUrl"))
        )
    }
}
