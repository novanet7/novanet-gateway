package id.fr3velora

import android.content.Context

/**
 * Preferensi app (lokal). Pola mirip Telegram Settings.
 */
class SettingsStore(context: Context) {
    private val p = context.getSharedPreferences("fr3velora_settings", Context.MODE_PRIVATE)

    var notificationsEnabled: Boolean
        get() = p.getBoolean("notif", true)
        set(v) = p.edit().putBoolean("notif", v).apply()

    var notificationSound: Boolean
        get() = p.getBoolean("notif_sound", true)
        set(v) = p.edit().putBoolean("notif_sound", v).apply()

    var notificationVibrate: Boolean
        get() = p.getBoolean("notif_vib", true)
        set(v) = p.edit().putBoolean("notif_vib", v).apply()

    /** Tampilkan centang baca ke lawan bicara */
    var sendReadReceipts: Boolean
        get() = p.getBoolean("read_receipts", true)
        set(v) = p.edit().putBoolean("read_receipts", v).apply()

    /** Enter = kirim (true) atau baris baru (false) */
    var enterIsSend: Boolean
        get() = p.getBoolean("enter_send", true)
        set(v) = p.edit().putBoolean("enter_send", v).apply()

    /** Media auto-download: wifi | always | never */
    var mediaAutoDownload: String
        get() = p.getString("media_dl", "wifi") ?: "wifi"
        set(v) = p.edit().putString("media_dl", v).apply()

    /** Ukuran teks chat: small | normal | large */
    var chatFontSize: String
        get() = p.getString("font", "normal") ?: "normal"
        set(v) = p.edit().putString("font", v).apply()

    /** Simpan media ke galeri otomatis */
    var saveToGallery: Boolean
        get() = p.getBoolean("save_gallery", false)
        set(v) = p.edit().putBoolean("save_gallery", v).apply()

    /** Konfirmasi sebelum menghapus pesan */
    var confirmDelete: Boolean
        get() = p.getBoolean("confirm_delete", true)
        set(v) = p.edit().putBoolean("confirm_delete", v).apply()

    /** Bahasa UI label */
    var languageLabel: String
        get() = p.getString("lang", "Indonesia") ?: "Indonesia"
        set(v) = p.edit().putString("lang", v).apply()
}
