package id.fr3velora

import android.content.Context
import android.content.SharedPreferences

// Menyimpan session cookie (fr3v_session=...) & data user setelah login sukses.
class SessionManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("fr3velora_session", Context.MODE_PRIVATE)

    var sessionCookie: String?
        get() = prefs.getString("sessionCookie", null)
        set(value) = prefs.edit().putString("sessionCookie", value).apply()

    var userId: String?
        get() = prefs.getString("userId", null)
        set(value) = prefs.edit().putString("userId", value).apply()

    var username: String?
        get() = prefs.getString("username", null)
        set(value) = prefs.edit().putString("username", value).apply()

    var email: String?
        get() = prefs.getString("email", null)
        set(value) = prefs.edit().putString("email", value).apply()

    var apiKey: String?
        get() = prefs.getString("apiKey", null)
        set(value) = prefs.edit().putString("apiKey", value).apply()

    var avatarUrl: String?
        get() = prefs.getString("avatarUrl", null)
        set(value) = prefs.edit().putString("avatarUrl", value).apply()

    var displayName: String?
        get() = prefs.getString("displayName", null)
        set(value) = prefs.edit().putString("displayName", value).apply()

    var bio: String?
        get() = prefs.getString("bio", null)
        set(value) = prefs.edit().putString("bio", value).apply()

    fun isLoggedIn(): Boolean = sessionCookie != null && userId != null

    fun clear() = prefs.edit().clear().apply()

    fun applyUser(user: id.fr3velora.model.User, cookie: String?) {
        if (cookie != null) sessionCookie = cookie
        userId = user.id
        username = user.username
        email = user.email
        apiKey = user.api_key.takeIf { it.isNotBlank() }
        avatarUrl = user.avatar_url
        displayName = user.display_name
        bio = user.bio
    }
}
