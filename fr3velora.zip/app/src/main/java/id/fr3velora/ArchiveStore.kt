package id.fr3velora

import android.content.Context

/**
 * Arsip chat ala WhatsApp: disembunyikan dari daftar utama,
 * tetap bisa dibuka lewat menu Arsip. Data hanya di perangkat.
 */
class ArchiveStore(context: Context) {
    private val prefs = context.getSharedPreferences("chat_archive", Context.MODE_PRIVATE)

    fun archivedChats(): Set<String> = prefs.getStringSet("chats", emptySet()) ?: emptySet()
    fun archivedGroups(): Set<String> = prefs.getStringSet("groups", emptySet()) ?: emptySet()

    fun isChatArchived(peerId: String): Boolean = peerId in archivedChats()
    fun isGroupArchived(groupId: String): Boolean = groupId in archivedGroups()

    fun archiveChat(peerId: String) {
        prefs.edit().putStringSet("chats", archivedChats() + peerId).apply()
    }

    fun unarchiveChat(peerId: String) {
        prefs.edit().putStringSet("chats", archivedChats() - peerId).apply()
    }

    fun archiveGroup(groupId: String) {
        prefs.edit().putStringSet("groups", archivedGroups() + groupId).apply()
    }

    fun unarchiveGroup(groupId: String) {
        prefs.edit().putStringSet("groups", archivedGroups() - groupId).apply()
    }

    fun archivedChatCount(): Int = archivedChats().size
}
