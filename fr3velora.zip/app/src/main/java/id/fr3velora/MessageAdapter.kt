package id.fr3velora

import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import id.fr3velora.model.Message
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MessageAdapter(
    private val messages: MutableList<Message>,
    private val myUserId: String,
    private val attachmentDir: File,
    private val onAttachmentClick: (Message) -> Unit,
    private val onLongPress: (Message) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_SENT = 1
        private const val TYPE_RECEIVED = 2
        private var player: MediaPlayer? = null
        private var playingMessageId: String? = null
        private val progressHandler = Handler(Looper.getMainLooper())
        private var progressTick: Runnable? = null

        fun stopPlayback() {
            progressTick?.let { progressHandler.removeCallbacks(it) }
            progressTick = null
            runCatching { player?.stop() }
            runCatching { player?.release() }
            player = null
            playingMessageId = null
        }
    }

    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateFormat = SimpleDateFormat("d MMMM yyyy", Locale("id", "ID"))

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val date: TextView = view.findViewById(R.id.tvDate)
        val bubble: View = view.findViewById(R.id.bubble)
        val text: TextView = view.findViewById(R.id.tvMessage)
        val time: TextView = view.findViewById(R.id.tvTime)
        val status: TextView? = view.findViewById(R.id.tvStatus)
        val replyQuote: View? = view.findViewById(R.id.replyQuote)
        val tvReplyName: TextView? = view.findViewById(R.id.tvReplyName)
        val tvReplyText: TextView? = view.findViewById(R.id.tvReplyText)
        val ivMedia: ImageView? = view.findViewById(R.id.ivMedia)
        val audioPlayer: View? = view.findViewById(R.id.audioPlayer)
        val btnPlayAudio: ImageButton? = view.findViewById(R.id.btnPlayAudio)
        val audioProgress: ProgressBar? = view.findViewById(R.id.audioProgress)
        val tvAudioDuration: TextView? = view.findViewById(R.id.tvAudioDuration)
        val tvFileLabel: TextView? = view.findViewById(R.id.tvFileLabel)
    }

    override fun getItemViewType(position: Int) =
        if (messages[position].from == myUserId) TYPE_SENT else TYPE_RECEIVED

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
        VH(
            LayoutInflater.from(parent.context).inflate(
                if (viewType == TYPE_SENT) R.layout.item_message_sent else R.layout.item_message_received,
                parent,
                false
            )
        )

    private fun sameDay(a: Long, b: Long): Boolean {
        val ca = Calendar.getInstance().apply { timeInMillis = a }
        val cb = Calendar.getInstance().apply { timeInMillis = b }
        return ca.get(Calendar.YEAR) == cb.get(Calendar.YEAR) &&
            ca.get(Calendar.DAY_OF_YEAR) == cb.get(Calendar.DAY_OF_YEAR)
    }

    private fun dayLabel(ts: Long): String {
        val now = System.currentTimeMillis()
        return when {
            sameDay(ts, now) -> "Hari ini"
            sameDay(ts, now - 24L * 60 * 60 * 1000) -> "Kemarin"
            else -> dateFormat.format(Date(ts))
        }
    }

    private fun resolveFile(message: Message): File? {
        val path = message.attachmentPath ?: return null
        val f = File(path)
        if (f.isAbsolute && f.exists()) return f
        val local = File(attachmentDir, path)
        if (local.exists()) return local
        val byName = File(attachmentDir, message.attachmentName ?: return null)
        return if (byName.exists()) byName else null
    }

    private fun formatDuration(ms: Int): String {
        val totalSec = (ms / 1000).coerceAtLeast(0)
        val m = totalSec / 60
        val s = totalSec % 60
        return "%d:%02d".format(m, s)
    }

    private fun loadThumb(file: File, max: Int = 480): android.graphics.Bitmap? {
        return runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var sample = 1
            val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
            while (maxDim / sample > max) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeFile(file.absolutePath, opts)
        }.getOrNull()
    }

    private fun isAudio(message: Message): Boolean {
        val mime = message.attachmentMime.orEmpty()
        val name = message.attachmentName.orEmpty()
        return mime.startsWith("audio/") ||
            name.contains("Pesan suara", ignoreCase = true) ||
            name.endsWith(".m4a", true) ||
            name.endsWith(".ogg", true) ||
            name.endsWith(".mp3", true) ||
            name.endsWith(".aac", true)
    }

    private fun isImage(message: Message): Boolean {
        val mime = message.attachmentMime.orEmpty()
        val name = message.attachmentName.orEmpty()
        return mime.startsWith("image/") ||
            name.endsWith(".jpg", true) ||
            name.endsWith(".jpeg", true) ||
            name.endsWith(".png", true) ||
            name.endsWith(".webp", true) ||
            name.endsWith(".gif", true)
    }

    private fun isVideo(message: Message): Boolean {
        val mime = message.attachmentMime.orEmpty()
        return mime.startsWith("video/")
    }

    private fun captionOrEmpty(message: Message): String {
        if (message.text == "Pesan ini dihapus") return message.text
        if (message.from != myUserId && message.isLockedNow()) {
            val until = message.unlockAt ?: 0L
            val fmt = SimpleDateFormat("dd MMM HH:mm", Locale("id", "ID"))
            return "⏳ Kapsul waktu\nTerbuka ${fmt.format(Date(until))}"
        }
        val tag = when (message.label) {
            "question" -> "❓ "
            "task" -> "✅ "
            "info" -> "ℹ️ "
            else -> ""
        }
        val silent = if (message.silent) "🔕 " else ""
        val fwd = if (!message.forwardedFrom.isNullOrBlank())
            "↗ Diteruskan dari ${message.forwardedFromName ?: ""}
" else ""
        val body = message.text.trim()
        val edited = if (message.edited) " (diedit)" else ""
        val react = message.reactions?.let { r ->
            runCatching {
                val o = org.json.JSONObject(r)
                val keys = o.keys().asSequence().toList()
                if (keys.isEmpty()) "" else "
" + keys.joinToString(" ") { k -> "$k ${o.optInt(k)}" }
            }.getOrDefault("")
        } ?: ""
        return buildString {
            append(fwd)
            append(silent)
            append(tag)
            append(body)
            append(edited)
            append(react)
        }.trim()
    }

    private fun replyPreview(message: Message): String {
        if (!message.replyToText.isNullOrBlank()) return message.replyToText
        return "Pesan"
    }

    private fun statusIcon(status: String): String = when (status) {
        "pending" -> "🕒"
        "sent" -> "✓"
        "delivered" -> "✓✓"
        "read" -> "✓✓"
        else -> "✓"
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message = messages[position]
        val vh = holder as VH
        val showDate = position == 0 || !sameDay(messages[position - 1].timestamp, message.timestamp)
        vh.date.visibility = if (showDate) View.VISIBLE else View.GONE
        if (showDate) vh.date.text = dayLabel(message.timestamp)
        vh.time.text = timeFormat.format(Date(message.timestamp))

        if (message.hasReply && vh.replyQuote != null) {
            vh.replyQuote.visibility = View.VISIBLE
            vh.tvReplyName?.text = message.replyToName ?: "Pesan"
            vh.tvReplyText?.text = replyPreview(message)
        } else {
            vh.replyQuote?.visibility = View.GONE
        }

        // Reset media views
        vh.ivMedia?.visibility = View.GONE
        vh.ivMedia?.setImageDrawable(null)
        vh.audioPlayer?.visibility = View.GONE
        vh.tvFileLabel?.visibility = View.GONE

        val locked = message.from != myUserId && message.isLockedNow()
        val caption = captionOrEmpty(message)

        if (locked) {
            vh.text.visibility = View.VISIBLE
            vh.text.text = caption
        } else if (message.hasAttachment) {
            val file = resolveFile(message)
            when {
                isImage(message) && file != null -> {
                    vh.ivMedia?.visibility = View.VISIBLE
                    val bmp = loadThumb(file)
                    if (bmp != null) vh.ivMedia?.setImageBitmap(bmp)
                    else vh.ivMedia?.setImageResource(R.drawable.ic_wallpaper)
                    vh.ivMedia?.setOnClickListener { onAttachmentClick(message) }
                    if (caption.isNotBlank()) {
                        vh.text.visibility = View.VISIBLE
                        vh.text.text = caption
                    } else {
                        vh.text.visibility = View.GONE
                    }
                }
                isAudio(message) && file != null -> {
                    vh.audioPlayer?.visibility = View.VISIBLE
                    vh.btnPlayAudio?.setImageResource(
                        if (playingMessageId == message.id) R.drawable.ic_pause else R.drawable.ic_play
                    )
                    // Duration
                    val durationMs = runCatching {
                        MediaMetadataRetriever().use { r ->
                            r.setDataSource(file.absolutePath)
                            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toIntOrNull()
                        }
                    }.getOrNull() ?: 0
                    vh.tvAudioDuration?.text = formatDuration(durationMs)
                    vh.audioProgress?.progress =
                        if (playingMessageId == message.id && player != null && (player?.duration ?: 0) > 0) {
                            ((player!!.currentPosition * 100f) / player!!.duration).toInt()
                        } else 0
                    vh.btnPlayAudio?.setOnClickListener {
                        toggleAudio(message, file, vh)
                    }
                    if (caption.isNotBlank()) {
                        vh.text.visibility = View.VISIBLE
                        vh.text.text = caption
                    } else {
                        vh.text.visibility = View.GONE
                    }
                }
                isVideo(message) -> {
                    vh.tvFileLabel?.visibility = View.VISIBLE
                    vh.tvFileLabel?.text = "🎬  ${message.attachmentName ?: "Video"}"
                    vh.tvFileLabel?.setOnClickListener { onAttachmentClick(message) }
                    if (caption.isNotBlank()) {
                        vh.text.visibility = View.VISIBLE
                        vh.text.text = caption
                    } else vh.text.visibility = View.GONE
                }
                else -> {
                    vh.tvFileLabel?.visibility = View.VISIBLE
                    vh.tvFileLabel?.text = "📎  ${message.attachmentName ?: "File"}"
                    vh.tvFileLabel?.setOnClickListener { onAttachmentClick(message) }
                    if (caption.isNotBlank()) {
                        vh.text.visibility = View.VISIBLE
                        vh.text.text = caption
                    } else vh.text.visibility = View.GONE
                }
            }
        } else {
            vh.text.visibility = View.VISIBLE
            vh.text.text = caption.ifBlank { " " }
        }

        vh.bubble.setOnClickListener {
            if (locked) return@setOnClickListener
            if (message.hasAttachment && isImage(message)) onAttachmentClick(message)
            else if (message.hasAttachment && !isAudio(message)) onAttachmentClick(message)
        }
        vh.bubble.setOnLongClickListener { onLongPress(message); true }
        vh.status?.let { status ->
            status.text = statusIcon(message.status)
            status.setTextColor(
                status.context.getColor(
                    if (message.status == "read") R.color.tick_read else R.color.tick_idle
                )
            )
        }
    }

    private fun toggleAudio(message: Message, file: File, vh: VH) {
        if (playingMessageId == message.id && player?.isPlaying == true) {
            player?.pause()
            vh.btnPlayAudio?.setImageResource(R.drawable.ic_play)
            progressTick?.let { progressHandler.removeCallbacks(it) }
            return
        }
        if (playingMessageId == message.id && player != null && player?.isPlaying == false) {
            player?.start()
            vh.btnPlayAudio?.setImageResource(R.drawable.ic_pause)
            startProgressUpdates(vh, message.id)
            return
        }
        stopPlayback()
        runCatching {
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener {
                    stopPlayback()
                    notifyDataSetChanged()
                }
                prepare()
                start()
            }
            playingMessageId = message.id
            vh.btnPlayAudio?.setImageResource(R.drawable.ic_pause)
            startProgressUpdates(vh, message.id)
        }
    }

    private fun startProgressUpdates(vh: VH, messageId: String?) {
        progressTick?.let { progressHandler.removeCallbacks(it) }
        val tick = object : Runnable {
            override fun run() {
                val p = player
                if (p == null || playingMessageId != messageId) return
                val dur = p.duration.coerceAtLeast(1)
                vh.audioProgress?.progress = ((p.currentPosition * 100f) / dur).toInt()
                vh.tvAudioDuration?.text = formatDuration(p.currentPosition)
                progressHandler.postDelayed(this, 200)
            }
        }
        progressTick = tick
        progressHandler.post(tick)
    }

    override fun getItemCount() = messages.size

    fun upsertMessage(message: Message?) {
        if (message == null) return
        val index = messages.indexOfFirst { it.id == message.id }
        if (index >= 0) {
            messages[index] = message
            notifyItemChanged(index)
        } else {
            messages.add(message)
            notifyItemInserted(messages.size - 1)
        }
    }

    fun removeMessage(id: String?) {
        val index = messages.indexOfFirst { it.id == id }
        if (index >= 0) {
            messages.removeAt(index)
            notifyItemRemoved(index)
            if (index < messages.size) notifyItemChanged(index)
        }
    }

    fun getMessage(position: Int): Message? =
        if (position in messages.indices) messages[position] else null

    fun setMessages(newMessages: List<Message>) {
        messages.clear()
        messages.addAll(newMessages)
        notifyDataSetChanged()
    }
}
