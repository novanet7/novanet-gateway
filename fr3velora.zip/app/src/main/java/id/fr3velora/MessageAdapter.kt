package id.fr3velora

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import id.fr3velora.model.Message
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MessageAdapter(private val messages: MutableList<Message>, private val myUserId: String, private val onAttachmentClick: (Message) -> Unit, private val onLongPress: (Message) -> Unit) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    companion object { private const val TYPE_SENT = 1; private const val TYPE_RECEIVED = 2 }
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    class VH(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val bubble: android.view.View = view.findViewById(R.id.bubble)
        val text: android.widget.TextView = view.findViewById(R.id.tvMessage)
        val time: android.widget.TextView = view.findViewById(R.id.tvTime)
        val status: android.widget.TextView? = view.findViewById(R.id.tvStatus)
    }
    override fun getItemViewType(position: Int) = if (messages[position].from == myUserId) TYPE_SENT else TYPE_RECEIVED
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder = VH(LayoutInflater.from(parent.context).inflate(if (viewType == TYPE_SENT) R.layout.item_message_sent else R.layout.item_message_received, parent, false))
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message = messages[position]; val label = if (message.text == "Pesan ini dihapus") message.text else buildString {
            if (message.hasAttachment) append(when { message.attachmentMime!!.startsWith("image/") -> "Foto"; message.attachmentMime.startsWith("video/") -> "Video"; message.attachmentMime.startsWith("audio/") -> "Audio"; else -> "File" }).append(" · ").append(message.attachmentName)
            if (message.text.isNotBlank()) { if (isNotEmpty()) append("\n"); append(message.text) }
        }
        val vh = holder as VH; vh.text.text = label; vh.time.text = timeFormat.format(Date(message.timestamp)); vh.bubble.setOnClickListener { if (message.hasAttachment) onAttachmentClick(message) }; vh.bubble.setOnLongClickListener { onLongPress(message); true }
        vh.status?.let { status -> status.text = if (message.status == "pending") "✓" else "✓✓"; status.setTextColor(status.context.getColor(if (message.status == "read") R.color.tick_read else R.color.tick_idle)) }
    }
    override fun getItemCount() = messages.size
    fun upsertMessage(message: Message?) { if (message == null) return; val index = messages.indexOfFirst { it.id == message.id }; if (index >= 0) { messages[index] = message; notifyItemChanged(index) } else { messages.add(message); notifyItemInserted(messages.size - 1) } }
    fun removeMessage(id: String?) { val index = messages.indexOfFirst { it.id == id }; if (index >= 0) { messages.removeAt(index); notifyItemRemoved(index) } }
    fun setMessages(newMessages: List<Message>) { messages.clear(); messages.addAll(newMessages); notifyDataSetChanged() }
}
