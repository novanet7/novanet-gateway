package id.fr3velora

import android.content.Intent
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import id.fr3velora.network.ApiClient

/**
 * FCM = cara utama WhatsApp/Telegram membangunkan app saat proses mati.
 * Data message prioritas tinggi → onMessageReceived tetap jalan di background.
 * Force stop dari Settings Android tetap mematikan SEMUA app (batas sistem).
 */
class FcmService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        registerTokenWithServer(token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)

        // Bangunkan / pastikan WebSocket service hidup untuk sync berikutnya
        ChatConnectionService.ensureRunning(applicationContext)

        val data = message.data
        val from = data["from"] ?: return
        val fromName = data["fromName"] ?: from
        val text = data["text"] ?: return

        val myUserId = SessionManager(applicationContext).userId
        if (myUserId == null || from == myUserId) return
        if (ChatState.activePeerId == from) return

        NotificationHelper.showMessageNotification(
            context = applicationContext,
            fromUserId = from,
            fromName = fromName,
            text = text
        )
    }

    private fun registerTokenWithServer(token: String) {
        val session = SessionManager(applicationContext)
        val cookie = session.sessionCookie ?: return
        Thread {
            ApiClient(getString(R.string.api_base_url)).registerFcmToken(cookie, token)
        }.start()
    }
}
