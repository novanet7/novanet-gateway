package id.fr3velora

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import id.fr3velora.model.Message
import java.util.UUID

/**
 * Alur panggilan ala WhatsApp / Telegram (signaling):
 *
 * 1. Satu tombol Call di chat → pilih Suara atau Video.
 * 2. call_offer (mode=voice|video) dikirim ke peer.
 * 3. Peer Terima → call_answer → status Terhubung.
 * 4. Saat voice terhubung, tombol "Video" meminta upgrade (call_upgrade).
 * 5. Peer otomatis menerima upgrade di sisi UI (call_upgrade_accept),
 *    mode jadi video tanpa putus panggilan.
 *
 * Media WebRTC bisa dipasang di titik offer/answer/upgrade.
 */
class CallActivity : AppCompatActivity() {
    private lateinit var peerId: String
    private var mode: String = "voice"
    private var callId: String = UUID.randomUUID().toString()
    private var incoming = false
    private var connected = false
    private var muted = false

    private lateinit var status: TextView
    private lateinit var title: TextView
    private lateinit var peerNameView: TextView
    private lateinit var btnSwitchVideo: MaterialButton
    private lateinit var rowConnected: View

    private val callPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val ok = result.values.all { it }
            if (!ok) {
                status.text = "Izin kamera/mikrofon diperlukan"
                return@registerForActivityResult
            }
            if (!incoming && !connected) sendOffer()
        }

    private val events = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val id = intent?.getStringExtra("callId").orEmpty()
            if (id.isNotBlank() && id != callId) return
            when (intent?.getStringExtra("type")) {
                "call_answer" -> {
                    connected = true
                    status.text = "Terhubung"
                    renderButtons()
                }
                "call_reject" -> {
                    status.text = "Panggilan ditolak"
                    finishDelayed()
                }
                "call_end" -> {
                    status.text = "Panggilan berakhir"
                    finishDelayed()
                }
                "call_offer" -> if (incoming) status.text = "Berdering…"
                "call_upgrade" -> {
                    // Peer minta ganti mode (biasanya voice → video)
                    val newMode = intent.getStringExtra("mode") ?: "video"
                    onUpgradeRequested(newMode)
                }
                "call_upgrade_accept" -> {
                    val newMode = intent.getStringExtra("mode") ?: mode
                    applyMode(newMode, notifyPeer = false)
                    status.text = "Terhubung · ${if (newMode == "video") "Video" else "Suara"}"
                    Toast.makeText(this@CallActivity, "Mode diubah ke $newMode", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_call)

        peerId = intent.getStringExtra("peerId")
            ?: intent.getStringExtra("from")
            ?: ""
        mode = intent.getStringExtra("mode") ?: "voice"
        incoming = intent.getBooleanExtra("incoming", false)
        callId = intent.getStringExtra("callId") ?: callId

        status = findViewById(R.id.tvCallStatus)
        title = findViewById(R.id.tvCallTitle)
        peerNameView = findViewById(R.id.tvCallPeer)
        btnSwitchVideo = findViewById(R.id.btnSwitchVideo)
        rowConnected = findViewById(R.id.rowConnectedControls)

        val name = intent.getStringExtra("peerName")
            ?: intent.getStringExtra("fromName")
            ?: "Kontak"
        peerNameView.text = name
        bindAvatar(name, intent.getStringExtra("peerAvatar"))
        refreshModeLabels()

        status.text = if (incoming) "Panggilan masuk…" else "Memanggil…"
        renderButtons()

        findViewById<MaterialButton>(R.id.btnAccept).setOnClickListener {
            incoming = false
            connected = true
            ChatConnectionService.send(
                Message(type = "call_answer", to = peerId, messageId = callId, mode = mode, text = "answer")
            )
            status.text = "Terhubung"
            renderButtons()
        }
        findViewById<MaterialButton>(R.id.btnReject).setOnClickListener {
            ChatConnectionService.send(
                Message(type = "call_reject", to = peerId, messageId = callId, mode = mode)
            )
            finish()
        }
        findViewById<MaterialButton>(R.id.btnEnd).setOnClickListener {
            ChatConnectionService.send(
                Message(type = "call_end", to = peerId, messageId = callId, mode = mode)
            )
            finish()
        }
        findViewById<MaterialButton>(R.id.btnMute).setOnClickListener {
            muted = !muted
            (it as MaterialButton).text = if (muted) "Unmute" else "Mute"
        }
        btnSwitchVideo.setOnClickListener { requestOrToggleVideo() }

        if (needsCallPermissions()) {
            callPermissionLauncher.launch(
                arrayOf(
                    android.Manifest.permission.CAMERA,
                    android.Manifest.permission.RECORD_AUDIO
                )
            )
        } else if (!incoming) {
            sendOffer()
        }
    }

    private fun bindAvatar(name: String, url: String?) {
        val initial = findViewById<TextView>(R.id.tvCallInitial)
        initial.text = avatarInitial(name)
        initial.setBackgroundColor(avatarColor(name))
        bindAvatar(findViewById(R.id.ivCallAvatar), initial, name, url)
    }

    private fun refreshModeLabels() {
        title.text = if (mode == "video") "Panggilan video" else "Panggilan suara"
        btnSwitchVideo.text = if (mode == "video") "Suara saja" else "Video"
        btnSwitchVideo.setIconResource(
            if (mode == "video") R.drawable.ic_call else R.drawable.ic_videocam
        )
    }

    private fun applyMode(newMode: String, notifyPeer: Boolean) {
        mode = newMode
        refreshModeLabels()
        if (notifyPeer) {
            ChatConnectionService.send(
                Message(
                    type = "call_upgrade_accept",
                    to = peerId,
                    messageId = callId,
                    mode = mode,
                    text = "upgrade_accept"
                )
            )
        }
    }

    /**
     * Saat voice: kirim permintaan upgrade ke video.
     * Saat video: kembali ke suara (toggle lokal + notify peer).
     */
    private fun requestOrToggleVideo() {
        if (!connected) {
            Toast.makeText(this, "Tunggu sampai panggilan terhubung", Toast.LENGTH_SHORT).show()
            return
        }
        if (mode == "voice") {
            // Minta peer upgrade ke video (seperti tombol kamera WA saat call)
            ChatConnectionService.send(
                Message(
                    type = "call_upgrade",
                    to = peerId,
                    messageId = callId,
                    mode = "video",
                    text = "upgrade_request"
                )
            )
            status.text = "Meminta video…"
            // Optimistically switch setelah delay singkat jika peer online
            // Peer akan balas call_upgrade_accept; kita juga apply lokal agar UX responsif
            applyMode("video", notifyPeer = false)
            status.text = "Terhubung · Video"
            ChatConnectionService.send(
                Message(
                    type = "call_upgrade_accept",
                    to = peerId,
                    messageId = callId,
                    mode = "video",
                    text = "upgrade_accept"
                )
            )
        } else {
            applyMode("voice", notifyPeer = true)
            status.text = "Terhubung · Suara"
        }
    }

    private fun onUpgradeRequested(newMode: String) {
        if (!connected && !incoming) {
            // masih ringing — abaikan
        }
        // WA-style: upgrade langsung diterapkan (dialog opsional)
        AlertDialog.Builder(this)
            .setTitle(if (newMode == "video") "Aktifkan video?" else "Ganti ke suara?")
            .setMessage("Lawan bicara ingin mengubah mode panggilan.")
            .setPositiveButton("Ya") { _, _ ->
                connected = true
                applyMode(newMode, notifyPeer = true)
                status.text = "Terhubung · ${if (newMode == "video") "Video" else "Suara"}"
                renderButtons()
            }
            .setNegativeButton("Tidak", null)
            .show()
    }

    private fun renderButtons() {
        val showIncoming = incoming && !connected
        findViewById<View>(R.id.btnAccept).visibility = if (showIncoming) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btnReject).visibility = if (showIncoming) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btnEnd).visibility = if (showIncoming) View.GONE else View.VISIBLE
        rowConnected.visibility = if (connected) View.VISIBLE else View.GONE
    }

    private fun needsCallPermissions(): Boolean {
        val cam = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)
        val mic = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
        return cam != android.content.pm.PackageManager.PERMISSION_GRANTED ||
            mic != android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    private fun sendOffer() {
        ChatConnectionService.send(
            Message(type = "call_offer", to = peerId, messageId = callId, mode = mode, text = "offer")
        )
    }

    private fun finishDelayed() {
        status.postDelayed({ finish() }, 900)
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter("id.fr3velora.CALL_EVENT")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(events, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(events, filter)
        }
    }

    override fun onPause() {
        super.onPause()
        runCatching { unregisterReceiver(events) }
    }
}
