package id.fr3velora

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

/**
 * Menampilkan pop-up notifikasi saat ada pesan chat baru masuk.
 *
 * Catatan penting soal izin notifikasi:
 * - Android 12 ke bawah: notifikasi aktif otomatis, tidak ada dialog izin sama sekali.
 * - Android 13+ (API 33+): OS MEWAJIBKAN izin runtime POST_NOTIFICATIONS lewat dialog
 *   sistem sekali — ini kontrol privasi di level Android sendiri dan TIDAK BISA
 *   dilewati oleh kode aplikasi manapun. Yang kita lakukan di sini adalah memicu
 *   dialog itu otomatis begitu ChatListActivity dibuka (lihat requestNotificationPermission
 *   di sana), jadi user langsung ditanya sekali tanpa perlu cari menu izin manual.
 */
object NotificationHelper {

    private const val CHANNEL_ID = "fr3velora_messages"
    private const val CHANNEL_NAME = "Pesan Chat"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifikasi saat ada pesan chat fr3velora masuk"
                enableVibration(true)
            }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    fun showMessageNotification(
        context: Context,
        fromUserId: String,
        fromName: String,
        text: String
    ) {
        val st = SettingsStore(context)
        if (!st.notificationsEnabled) return

        val intent = Intent(context, ChatRoomActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("peerId", fromUserId)
            putExtra("peerName", fromName)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            fromUserId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(fromName)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(fromUserId.hashCode(), notification)
    }
}
