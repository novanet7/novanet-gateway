package id.fr3velora

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import id.fr3velora.model.Group

class GroupAdapter(private val groups: MutableList<Group>, private val onClick: (Group) -> Unit, private val onLongClick: (Group) -> Unit) : RecyclerView.Adapter<GroupAdapter.VH>() {
    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val avatar: ImageView = view.findViewById(R.id.ivGroupAvatar)
        val initial: TextView = view.findViewById(R.id.tvGroupInitial)
        val name: TextView = view.findViewById(R.id.tvGroupName)
        val description: TextView = view.findViewById(R.id.tvGroupDescription)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_group, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val group = groups[position]
        bindAvatar(holder.avatar, holder.initial, group.name, null)
        holder.name.text = group.name
        val kind = if (group.isChannel) "Channel" else "Grup"
        val base = if (group.description.isBlank()) kind else "$kind · ${group.description}"
        holder.description.text = if (group.isClosed) "$base · Ditutup" else base
        holder.itemView.setOnClickListener { onClick(group) }
        holder.itemView.setOnLongClickListener { onLongClick(group); true }
    }

    override fun getItemCount() = groups.size
    fun replace(items: List<Group>) { groups.clear(); groups.addAll(items); notifyDataSetChanged() }
}
