package id.fr3velora

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import id.fr3velora.model.Group

class GroupAdapter(private val groups: MutableList<Group>, private val onClick: (Group) -> Unit, private val onLongClick: (Group) -> Unit) : RecyclerView.Adapter<GroupAdapter.VH>() {
    class VH(view: android.view.View) : RecyclerView.ViewHolder(view) { val avatar: android.widget.TextView = view.findViewById(R.id.tvGroupAvatar); val name: android.widget.TextView = view.findViewById(R.id.tvGroupName); val description: android.widget.TextView = view.findViewById(R.id.tvGroupDescription) }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_group, parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) { val group = groups[position]; holder.avatar.text = avatarInitial(group.name); holder.avatar.backgroundTintList = ColorStateList.valueOf(avatarColor(group.name)); holder.name.text = group.name; val kind = if (group.isChannel) "Channel" else "Grup"; holder.description.text = if (group.description.isBlank()) kind else "$kind · ${group.description}"; holder.itemView.setOnClickListener { onClick(group) }; holder.itemView.setOnLongClickListener { onLongClick(group); true } }
    override fun getItemCount() = groups.size
    fun replace(items: List<Group>) { groups.clear(); groups.addAll(items); notifyDataSetChanged() }
}
