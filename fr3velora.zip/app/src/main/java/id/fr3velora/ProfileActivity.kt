package id.fr3velora

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import com.google.android.material.textfield.TextInputEditText
import id.fr3velora.network.ApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/**
 * Edit profil: foto, nama tampilan, bio.
 * SEMUA data disimpan di SERVER (bukan lokal) supaya bisa dilihat semua user.
 */
class ProfileActivity : AppCompatActivity() {
    private lateinit var session: SessionManager
    private lateinit var api: ApiClient
    private lateinit var avatar: ImageView
    private lateinit var initial: TextView
    private lateinit var etName: TextInputEditText
    private lateinit var etBio: TextInputEditText
    private var progress: ProgressBar? = null
    private var pendingAvatarBase64: String? = null
    private var avatarRemoved = false

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        val b64 = encodeAvatar(uri)
        if (b64 == null) {
            Toast.makeText(this, "Foto gagal dibaca", Toast.LENGTH_SHORT).show()
            return@registerForActivityResult
        }
        pendingAvatarBase64 = b64
        avatarRemoved = false
        // Preview lokal dulu
        contentResolver.openInputStream(uri)?.use { stream ->
            val bmp = BitmapFactory.decodeStream(stream)
            if (bmp != null) {
                avatar.setImageBitmap(bmp)
                initial.visibility = View.GONE
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        session = SessionManager(this)
        api = ApiClient(getString(R.string.api_base_url))

        findViewById<Toolbar>(R.id.toolbarProfile).setNavigationOnClickListener { finish() }
        avatar = findViewById(R.id.ivEditAvatar)
        initial = findViewById(R.id.tvEditInitial)
        etName = findViewById(R.id.etDisplayName)
        etBio = findViewById(R.id.etBio)
        progress = findViewById(R.id.progressProfile) // boleh null kalau layout belum punya

        findViewById<TextView>(R.id.tvUsernameValue).text = "@${session.username}"
        findViewById<TextView>(R.id.tvEmailValue).text = session.email ?: ""
        etName.setText(session.displayName ?: session.username ?: "")
        etBio.setText(session.bio ?: "")

        findViewById<View>(R.id.frameAvatar).setOnClickListener { picker.launch(arrayOf("image/*")) }
        findViewById<View>(R.id.btnPickPhoto).setOnClickListener { picker.launch(arrayOf("image/*")) }
        findViewById<View>(R.id.btnRemovePhoto).setOnClickListener {
            pendingAvatarBase64 = null
            avatarRemoved = true
            avatar.setImageDrawable(null)
            renderInitial()
        }
        findViewById<View>(R.id.btnSaveProfile).setOnClickListener { saveToServer() }

        renderAvatarFromSession()
        // Sinkronkan ulang dari server (source of truth)
        refreshFromServer()
    }

    private fun renderInitial() {
        val name = (etName.text?.toString() ?: session.displayName ?: session.username ?: "?").trim()
        initial.text = name.firstOrNull()?.uppercaseChar()?.toString() ?: "?"
        initial.visibility = View.VISIBLE
        initial.setBackgroundColor(avatarColor(name)); initial.text = avatarInitial(name)
    }

    private fun renderAvatarFromSession() {
        val url = session.avatarUrl
        if (url.isNullOrBlank()) {
            avatar.setImageDrawable(null)
            renderInitial()
            return
        }
        // Coba load via network di background sederhana (tanpa library)
        lifecycleScope.launch {
            val abs = api.absoluteAvatarUrl(url)
            val bmp = withContext(Dispatchers.IO) {
                runCatching {
                    java.net.URL(abs).openStream().use { BitmapFactory.decodeStream(it) }
                }.getOrNull()
            }
            if (bmp != null) {
                avatar.setImageBitmap(bmp)
                initial.visibility = View.GONE
            } else {
                renderInitial()
            }
        }
    }

    private fun refreshFromServer() {
        val cookie = session.sessionCookie ?: return
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { api.getMe(cookie) }
            if (result.isSuccess && result.data != null) {
                val u = result.data
                session.applyUser(u, null)
                etName.setText(u.display_name.ifBlank { u.username })
                etBio.setText(u.bio)
                if (pendingAvatarBase64 == null && !avatarRemoved) renderAvatarFromSession()
            }
        }
    }

    private fun encodeAvatar(uri: Uri): String? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val side = minOf(bmp.width, bmp.height)
        bmp = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        if (side > 512) bmp = Bitmap.createScaledBitmap(bmp, 512, 512, true)
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 88, baos)
        Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }.getOrNull()

    private fun setBusy(busy: Boolean) {
        progress?.visibility = if (busy) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btnSaveProfile).isEnabled = !busy
    }

    private fun saveToServer() {
        val cookie = session.sessionCookie
        if (cookie.isNullOrBlank()) {
            Toast.makeText(this, "Sesi habis, login ulang", Toast.LENGTH_SHORT).show()
            return
        }
        val name = etName.text?.toString()?.trim().orEmpty()
        val bio = etBio.text?.toString()?.trim().orEmpty()
        if (name.isBlank()) {
            Toast.makeText(this, "Nama tampilan tidak boleh kosong", Toast.LENGTH_SHORT).show()
            return
        }
        setBusy(true)
        lifecycleScope.launch {
            // 1) Update text fields
            val profileResult = withContext(Dispatchers.IO) { api.updateProfile(cookie, name, bio) }
            if (!profileResult.isSuccess) {
                setBusy(false)
                Toast.makeText(this@ProfileActivity, profileResult.errorMessage ?: "Gagal simpan profil", Toast.LENGTH_SHORT).show()
                return@launch
            }
            var user = profileResult.data!!

            // 2) Avatar
            when {
                pendingAvatarBase64 != null -> {
                    val up = withContext(Dispatchers.IO) { api.uploadAvatar(cookie, pendingAvatarBase64!!) }
                    if (!up.isSuccess) {
                        setBusy(false)
                        Toast.makeText(this@ProfileActivity, up.errorMessage ?: "Profil tersimpan, tapi foto gagal", Toast.LENGTH_LONG).show()
                        session.applyUser(user, null)
                        finish()
                        return@launch
                    }
                    user = up.data!!
                }
                avatarRemoved -> {
                    val del = withContext(Dispatchers.IO) { api.deleteAvatar(cookie) }
                    if (del.isSuccess && del.data != null) user = del.data
                }
            }

            session.applyUser(user, null)
            setBusy(false)
            Toast.makeText(this@ProfileActivity, "Profil disimpan ke server", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
