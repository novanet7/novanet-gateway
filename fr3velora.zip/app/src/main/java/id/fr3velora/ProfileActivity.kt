package id.fr3velora

import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.textfield.TextInputEditText

/** Edit profil: foto, nama tampilan, dan info. Disimpan di perangkat. */
class ProfileActivity : AppCompatActivity() {
    private lateinit var prefs: AppPrefs
    private lateinit var session: SessionManager
    private lateinit var avatar: ImageView
    private lateinit var initial: TextView
    private lateinit var etName: TextInputEditText

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        if (prefs.importAvatar(uri)) renderAvatar() else Toast.makeText(this, "Foto gagal dibaca", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        prefs = AppPrefs(this); session = SessionManager(this)
        findViewById<Toolbar>(R.id.toolbarProfile).setNavigationOnClickListener { finish() }
        avatar = findViewById(R.id.ivEditAvatar); initial = findViewById(R.id.tvEditInitial)
        etName = findViewById(R.id.etDisplayName)
        val etBio = findViewById<TextInputEditText>(R.id.etBio)
        etName.setText(prefs.displayName); etBio.setText(prefs.bio)
        findViewById<TextView>(R.id.tvUsernameValue).text = "@${session.username}"
        findViewById<TextView>(R.id.tvEmailValue).text = session.email ?: ""

        findViewById<android.view.View>(R.id.frameAvatar).setOnClickListener { picker.launch(arrayOf("image/*")) }
        findViewById<android.view.View>(R.id.btnPickPhoto).setOnClickListener { picker.launch(arrayOf("image/*")) }
        findViewById<android.view.View>(R.id.btnRemovePhoto).setOnClickListener { prefs.clearAvatar(); renderAvatar() }
        findViewById<android.view.View>(R.id.btnSaveProfile).setOnClickListener {
            prefs.displayName = etName.text.toString().trim(); prefs.bio = etBio.text.toString().trim()
            Toast.makeText(this, "Profil disimpan", Toast.LENGTH_SHORT).show(); finish()
        }
        renderAvatar()
    }

    private fun renderAvatar() {
        val name = etName.text.toString().trim().ifBlank { session.username ?: "?" }
        bindAvatar(avatar, initial, name, session.avatarUrl, prefs.avatarFile())
    }
}
