package id.fr3velora

import android.graphics.Color

// Warna avatar per nama (palet ala Telegram) supaya daftar chat dan grup konsisten.
private val AVATAR_COLORS = intArrayOf(
    Color.parseColor("#E17076"), Color.parseColor("#4DA33E"), Color.parseColor("#D69A2D"), Color.parseColor("#3E8FD1"),
    Color.parseColor("#8D77D6"), Color.parseColor("#D9639A"), Color.parseColor("#2FA6AB"), Color.parseColor("#E58A4B")
)

fun avatarColor(seed: String): Int = AVATAR_COLORS[(seed.lowercase().hashCode() and Int.MAX_VALUE) % AVATAR_COLORS.size]

fun avatarInitial(name: String): String = name.trim().removePrefix("@").firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "?"
