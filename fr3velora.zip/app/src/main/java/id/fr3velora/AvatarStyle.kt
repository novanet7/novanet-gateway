package id.fr3velora

import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.util.LruCache
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import java.io.File
import java.net.URL

// Warna avatar per nama (palet ala Telegram) supaya daftar chat dan grup konsisten.
private val AVATAR_COLORS = intArrayOf(
    Color.parseColor("#E17076"), Color.parseColor("#4DA33E"), Color.parseColor("#D69A2D"), Color.parseColor("#3E8FD1"),
    Color.parseColor("#8D77D6"), Color.parseColor("#D9639A"), Color.parseColor("#2FA6AB"), Color.parseColor("#E58A4B")
)

private val avatarCache = LruCache<String, Bitmap>(48)

fun avatarColor(seed: String): Int = AVATAR_COLORS[(seed.lowercase().hashCode() and Int.MAX_VALUE) % AVATAR_COLORS.size]

fun avatarInitial(name: String): String = name.trim().removePrefix("@").firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "?"

/**
 * Isi avatar bulat: foto lokal > foto dari URL > huruf awal berwarna.
 * [image] dan [initial] ditumpuk dalam satu FrameLayout.
 */
fun bindAvatar(image: ImageView, initial: TextView, name: String, url: String?, localFile: File? = null) {
    image.setImageDrawable(null)
    image.backgroundTintList = ColorStateList.valueOf(avatarColor(name))
    initial.text = avatarInitial(name)
    initial.visibility = View.VISIBLE
    if (localFile != null && localFile.exists()) {
        BitmapFactory.decodeFile(localFile.path)?.let { image.setImageBitmap(it); initial.visibility = View.GONE }
        return
    }
    if (url.isNullOrBlank()) { image.tag = null; return }
    image.tag = url
    avatarCache.get(url)?.let { image.setImageBitmap(it); initial.visibility = View.GONE; return }
    Thread {
        val bitmap = runCatching { BitmapFactory.decodeStream(URL(url).openStream()) }.getOrNull()
        if (bitmap != null) {
            avatarCache.put(url, bitmap)
            image.post { if (image.tag == url) { image.setImageBitmap(bitmap); initial.visibility = View.GONE } }
        }
    }.start()
}
