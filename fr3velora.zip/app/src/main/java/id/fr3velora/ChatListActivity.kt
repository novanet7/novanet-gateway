package id.fr3velora

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import id.fr3velora.model.User
import id.fr3velora.network.ApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChatListActivity : AppCompatActivity() {
    private lateinit var session: SessionManager; private lateinit var contactStore: ContactStore; private lateinit var adapter: UserAdapter; private var allUsers: List<User> = emptyList()
    private val requiredPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_chat_list); session = SessionManager(this); contactStore = ContactStore(this)
        if (!session.isLoggedIn()) { startActivity(Intent(this, LoginActivity::class.java)); finish(); return }
        requestRequiredPermissionsAfterLogin(); startChatConnectionService(); registerFcmTokenIfAvailable()
        findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar).apply { title = "fr3velora"; subtitle = "@${session.username}" }
        val rv = findViewById<RecyclerView>(R.id.rvUsers); rv.layoutManager = LinearLayoutManager(this); adapter = UserAdapter(mutableListOf()) { openChat(it) }; rv.adapter = adapter
        findViewById<EditText>(R.id.etSearchUser).addTextChangedListener(object : TextWatcher { override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {} override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { applyFilter(s?.toString().orEmpty()) } override fun afterTextChanged(e: Editable?) {} })
        findViewById<android.view.View>(R.id.btnAddContact).setOnClickListener { showAddContactDialog() }; loadUsers()
        findViewById<android.view.View>(R.id.btnStatus).setOnClickListener { startActivity(Intent(this, StatusActivity::class.java)) }
        findViewById<android.view.View>(R.id.btnGroups).setOnClickListener { startActivity(Intent(this, GroupsActivity::class.java)) }; joinInviteFromIntent()
    }
    private fun requestRequiredPermissionsAfterLogin() {
        val permissions = mutableListOf(android.Manifest.permission.CAMERA, android.Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) permissions += android.Manifest.permission.POST_NOTIFICATIONS
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requiredPermissionLauncher.launch(missing.toTypedArray())
    }
    private fun startChatConnectionService() { ContextCompat.startForegroundService(this, Intent(this, ChatConnectionService::class.java)) }
    private fun registerFcmTokenIfAvailable() { val cookie = session.sessionCookie ?: return; runCatching { com.google.firebase.messaging.FirebaseMessaging.getInstance().token.addOnSuccessListener { token -> Thread { ApiClient(getString(R.string.api_base_url)).registerFcmToken(cookie, token) }.start() } } }
    private fun loadUsers() { val cookie = session.sessionCookie ?: return; lifecycleScope.launch { val result = withContext(Dispatchers.IO) { ApiClient(getString(R.string.api_base_url)).getUsers(cookie) }; if (result.isSuccess) { allUsers = result.data ?: emptyList(); applyFilter("") } } }
    private fun applyFilter(query: String) { val q = query.trim().removePrefix("@").lowercase(); adapter.replace(allUsers.filter { q.isBlank() || it.username.lowercase().contains(q) }) }
    private fun showAddContactDialog() { val input = EditText(this); input.hint = "username tanpa @"; AlertDialog.Builder(this).setTitle("Tambah kontak").setView(input).setPositiveButton("Tambah") { _, _ -> val name = input.text.toString().trim().removePrefix("@"); val user = allUsers.firstOrNull { it.username.equals(name, true) }; if (user != null) { contactStore.add(user); Toast.makeText(this, "Kontak @$name ditambahkan", Toast.LENGTH_SHORT).show(); applyFilter(name) } else Toast.makeText(this, "Username tidak ditemukan", Toast.LENGTH_SHORT).show() }.setNegativeButton("Batal", null).show() }
    private fun openChat(user: User) { startActivity(Intent(this, ChatRoomActivity::class.java).putExtra("peerId", user.id).putExtra("peerName", "@${user.username}").putExtra("peerAvatar", user.avatar_url)) }
    private fun joinInviteFromIntent() { val token = intent?.data?.pathSegments?.lastOrNull() ?: return; val cookie = session.sessionCookie ?: return; lifecycleScope.launch { val result = withContext(Dispatchers.IO) { ApiClient(getString(R.string.api_base_url)).joinGroup(cookie, token) }; Toast.makeText(this@ChatListActivity, if (result.isSuccess) "Berhasil bergabung ke ${result.data?.name}" else result.errorMessage, Toast.LENGTH_SHORT).show(); intent.data = null } }
}
