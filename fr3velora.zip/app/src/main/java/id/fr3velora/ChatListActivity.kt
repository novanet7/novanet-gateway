package id.fr3velora

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.android.material.textfield.TextInputEditText
import id.fr3velora.model.Group
import id.fr3velora.model.User
import id.fr3velora.network.ApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ChatListActivity : AppCompatActivity() {
    private lateinit var session: SessionManager
    private lateinit var contactStore: ContactStore
    private lateinit var store: LocalChatStore
    private lateinit var prefs: AppPrefs
    private lateinit var userAdapter: UserAdapter
    private lateinit var groupAdapter: GroupAdapter
    private lateinit var channelAdapter: GroupAdapter
    private lateinit var toolbar: Toolbar
    private lateinit var fab: ExtendedFloatingActionButton
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var pageChats: View
    private lateinit var pageGroups: View
    private lateinit var pageChannels: View
    private lateinit var pageProfile: View
    private lateinit var tvEmptyChats: View
    private lateinit var tvEmptyGroups: View
    private lateinit var tvEmptyChannels: View

    private var ready = false
    private var allUsers: List<User> = emptyList()
    private var query = ""
    private var currentTab = R.id.nav_chat
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dayFormat = SimpleDateFormat("dd/MM/yy", Locale.getDefault())

    private val requiredPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    private val messageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { refreshRows() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_list)
        session = SessionManager(this); contactStore = ContactStore(this); store = LocalChatStore(this); prefs = AppPrefs(this)
        if (!session.isLoggedIn()) { startActivity(Intent(this, LoginActivity::class.java)); finish(); return }
        ready = true
        requestRequiredPermissionsAfterLogin(); startChatConnectionService(); registerFcmTokenIfAvailable()

        toolbar = findViewById(R.id.toolbar)
        fab = findViewById(R.id.fabAction)
        bottomNav = findViewById(R.id.bottomNav)
        pageChats = findViewById(R.id.pageChats); pageGroups = findViewById(R.id.pageGroups)
        pageChannels = findViewById(R.id.pageChannels); pageProfile = findViewById(R.id.pageProfile)
        tvEmptyChats = findViewById(R.id.tvEmptyChats); tvEmptyGroups = findViewById(R.id.tvEmptyGroups); tvEmptyChannels = findViewById(R.id.tvEmptyChannels)

        val rvUsers = findViewById<RecyclerView>(R.id.rvUsers); rvUsers.layoutManager = LinearLayoutManager(this)
        userAdapter = UserAdapter(mutableListOf()) { openChat(it) }; rvUsers.adapter = userAdapter
        val rvGroups = findViewById<RecyclerView>(R.id.rvGroups); rvGroups.layoutManager = LinearLayoutManager(this)
        groupAdapter = GroupAdapter(mutableListOf(), { openGroup(it) }, { showAdminMenu(it) }); rvGroups.adapter = groupAdapter
        val rvChannels = findViewById<RecyclerView>(R.id.rvChannels); rvChannels.layoutManager = LinearLayoutManager(this)
        channelAdapter = GroupAdapter(mutableListOf(), { openGroup(it) }, { showAdminMenu(it) }); rvChannels.adapter = channelAdapter

        findViewById<EditText>(R.id.etSearchUser).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { query = s?.toString().orEmpty().trim().removePrefix("@").lowercase(); refreshRows() }
            override fun afterTextChanged(e: Editable?) {}
        })

        findViewById<View>(R.id.btnMenu).setOnClickListener { showMainMenu(it) }
        findViewById<View>(R.id.btnEditProfile).setOnClickListener { startActivity(Intent(this, ProfileActivity::class.java)) }
        findViewById<View>(R.id.ivProfileAvatar).setOnClickListener { startActivity(Intent(this, ProfileActivity::class.java)) }
        findViewById<View>(R.id.rowChatBg).setOnClickListener { startActivity(Intent(this, ChatBackgroundActivity::class.java)) }
        findViewById<View>(R.id.rowNewGroup).setOnClickListener { showCreateDialog("group") }
        findViewById<View>(R.id.rowNewChannel).setOnClickListener { showCreateDialog("channel") }
        findViewById<View>(R.id.rowLogout).setOnClickListener { confirmLogout() }

        fab.setOnClickListener {
            when (currentTab) {
                R.id.nav_groups -> showCreateDialog("group")
                R.id.nav_channels -> showCreateDialog("channel")
                else -> showAddContactDialog()
            }
        }
        bottomNav.setOnItemSelectedListener { showTab(it.itemId); true }
        showTab(R.id.nav_chat)
        loadUsers(); loadGroups(); joinInviteFromIntent()
    }

    override fun onStart() {
        super.onStart()
        if (!ready) return
        val filter = IntentFilter("id.fr3velora.NEW_MESSAGE")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) registerReceiver(messageReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("UnspecifiedRegisterReceiverFlag") run { registerReceiver(messageReceiver, filter) }
    }

    override fun onStop() { super.onStop(); if (ready) runCatching { unregisterReceiver(messageReceiver) } }

    override fun onResume() { super.onResume(); if (ready) { refreshRows(); refreshProfile() } }

    // ---------- Tab / navigasi bawah ----------
    private fun showTab(id: Int) {
        currentTab = id
        pageChats.visibility = if (id == R.id.nav_chat) View.VISIBLE else View.GONE
        pageGroups.visibility = if (id == R.id.nav_groups) View.VISIBLE else View.GONE
        pageChannels.visibility = if (id == R.id.nav_channels) View.VISIBLE else View.GONE
        pageProfile.visibility = if (id == R.id.nav_profile) View.VISIBLE else View.GONE
        toolbar.title = when (id) { R.id.nav_groups -> "Grup"; R.id.nav_channels -> "Channel"; R.id.nav_profile -> "Profil"; else -> "fr3velora" }
        toolbar.subtitle = if (id == R.id.nav_chat) "@${session.username}" else null
        when (id) {
            R.id.nav_chat -> { fab.text = "Kontak"; fab.setIconResource(R.drawable.ic_person_add); fab.show() }
            R.id.nav_groups -> { fab.text = "Grup baru"; fab.setIconResource(R.drawable.ic_group); fab.show() }
            R.id.nav_channels -> { fab.text = "Channel baru"; fab.setIconResource(R.drawable.ic_channel); fab.show() }
            else -> fab.hide()
        }
    }

    private fun showMainMenu(anchor: View) {
        val popup = PopupMenu(this, anchor, Gravity.END)
        popup.menuInflater.inflate(R.menu.main_menu, popup.menu)
        popup.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.menu_profile -> startActivity(Intent(this, ProfileActivity::class.java))
                R.id.menu_new_group -> showCreateDialog("group")
                R.id.menu_new_channel -> showCreateDialog("channel")
                R.id.menu_add_contact -> showAddContactDialog()
                R.id.menu_chat_bg -> startActivity(Intent(this, ChatBackgroundActivity::class.java))
                R.id.menu_logout -> confirmLogout()
            }
            true
        }
        popup.show()
    }

    // ---------- Tab Chat ----------
    private fun buildRows(): List<ChatRow> {
        val me = session.userId ?: ""
        val messages = store.all().filter { it.roomId == null && it.type == "message" }
        return allUsers.filter { it.id != me }.map { user ->
            val conv = messages.filter { (it.from == me && it.to == user.id) || (it.from == user.id && it.to == me) }
            val last = conv.maxByOrNull { it.timestamp }
            val preview = when {
                last == null -> ""
                else -> {
                    val body = when {
                        last.text == "Pesan ini dihapus" -> last.text
                        last.hasAttachment && last.text.isBlank() -> "📎 ${last.attachmentName}"
                        else -> last.text
                    }
                    if (last.from == me) "Anda: $body" else body
                }
            }
            ChatRow(user, preview, last?.let { formatTime(it.timestamp) } ?: "", conv.count { it.from == user.id && it.status != "read" }, last?.timestamp ?: 0L)
        }.sortedWith(compareByDescending<ChatRow> { it.timestamp }.thenBy { it.user.username.lowercase() })
    }

    private fun refreshRows() {
        if (!ready) return
        val rows = buildRows()
        val visible = rows.filter { query.isBlank() || it.user.username.lowercase().contains(query) }
        userAdapter.replace(visible)
        tvEmptyChats.visibility = if (visible.isEmpty()) View.VISIBLE else View.GONE
        val total = rows.sumOf { it.unread }
        if (total > 0) bottomNav.getOrCreateBadge(R.id.nav_chat).number = total else bottomNav.removeBadge(R.id.nav_chat)
    }

    private fun formatTime(ts: Long): String {
        val now = Calendar.getInstance(); val then = Calendar.getInstance().apply { timeInMillis = ts }
        val sameDay = now.get(Calendar.YEAR) == then.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR)
        return if (sameDay) timeFormat.format(Date(ts)) else dayFormat.format(Date(ts))
    }

    private fun loadUsers() {
        val cookie = session.sessionCookie ?: return
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { ApiClient(getString(R.string.api_base_url)).getUsers(cookie) }
            if (result.isSuccess) { allUsers = result.data ?: emptyList(); refreshRows() }
        }
    }

    private fun showAddContactDialog() {
        val input = EditText(this); input.hint = "username tanpa @"
        val pad = (20 * resources.displayMetrics.density).toInt(); input.setPadding(pad, pad / 2, pad, pad / 2)
        MaterialAlertDialogBuilder(this).setTitle("Tambah kontak").setView(input).setPositiveButton("Tambah") { _, _ ->
            val name = input.text.toString().trim().removePrefix("@")
            val user = allUsers.firstOrNull { it.username.equals(name, true) }
            if (user != null) { contactStore.add(user); Toast.makeText(this, "Kontak @$name ditambahkan", Toast.LENGTH_SHORT).show(); openChat(user) }
            else Toast.makeText(this, "Username tidak ditemukan", Toast.LENGTH_SHORT).show()
        }.setNegativeButton("Batal", null).show()
    }

    private fun openChat(user: User) { startActivity(Intent(this, ChatRoomActivity::class.java).putExtra("peerId", user.id).putExtra("peerName", "@${user.username}").putExtra("peerAvatar", user.avatar_url)) }

    // ---------- Tab Grup & Channel ----------
    private fun loadGroups() {
        val cookie = session.sessionCookie ?: return
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { ApiClient(getString(R.string.api_base_url)).getGroups(cookie) }
            if (result.isSuccess) {
                val list = result.data ?: emptyList()
                val groups = list.filter { !it.isChannel }; val channels = list.filter { it.isChannel }
                groupAdapter.replace(groups); channelAdapter.replace(channels)
                tvEmptyGroups.visibility = if (groups.isEmpty()) View.VISIBLE else View.GONE
                tvEmptyChannels.visibility = if (channels.isEmpty()) View.VISIBLE else View.GONE
            } else Toast.makeText(this@ChatListActivity, result.errorMessage, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showCreateDialog(kind: String) {
        val view = layoutInflater.inflate(R.layout.dialog_create_room, null)
        val etName = view.findViewById<TextInputEditText>(R.id.etRoomName); val etDesc = view.findViewById<TextInputEditText>(R.id.etRoomDesc)
        val label = if (kind == "channel") "Channel" else "Grup"
        MaterialAlertDialogBuilder(this).setTitle("$label baru").setView(view).setPositiveButton("Buat") { _, _ ->
            createRoom(etName.text.toString().trim(), etDesc.text.toString().trim(), kind)
        }.setNegativeButton("Batal", null).show()
    }

    private fun createRoom(name: String, description: String, kind: String) {
        if (name.isBlank()) { Toast.makeText(this, "Nama tidak boleh kosong", Toast.LENGTH_SHORT).show(); return }
        val cookie = session.sessionCookie ?: return
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { ApiClient(getString(R.string.api_base_url)).createGroup(cookie, name, description, kind) }
            if (result.isSuccess) {
                loadGroups(); Toast.makeText(this@ChatListActivity, if (kind == "channel") "Channel dibuat" else "Grup dibuat", Toast.LENGTH_SHORT).show()
                bottomNav.selectedItemId = if (kind == "channel") R.id.nav_channels else R.id.nav_groups
            } else Toast.makeText(this@ChatListActivity, result.errorMessage, Toast.LENGTH_SHORT).show()
        }
    }

    private fun openGroup(group: Group) { startActivity(Intent(this, ChatRoomActivity::class.java).putExtra("roomId", group.id).putExtra("roomKind", group.kind).putExtra("peerName", if (group.isChannel) "# ${group.name}" else group.name)) }

    private fun shareInvite(group: Group) {
        val cookie = session.sessionCookie ?: return
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { ApiClient(getString(R.string.api_base_url)).createInvite(cookie, group.id) }
            if (result.isSuccess) startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "Gabung ${group.name}: ${result.data}"), "Bagikan link undangan"))
            else Toast.makeText(this@ChatListActivity, result.errorMessage, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAdminMenu(group: Group) {
        val labels = arrayOf("Bagikan link undangan", if (group.isClosed) "Buka ${if (group.isChannel) "channel" else "grup"}" else "Tutup ${if (group.isChannel) "channel" else "grup"}", "Tambahkan admin")
        MaterialAlertDialogBuilder(this).setTitle(group.name).setItems(labels) { _, which -> when (which) { 0 -> shareInvite(group); 1 -> toggleClosed(group); 2 -> addAdminDialog(group) } }.show()
    }

    private fun toggleClosed(group: Group) {
        val cookie = session.sessionCookie ?: return
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { ApiClient(getString(R.string.api_base_url)).setGroupClosed(cookie, group.id, !group.isClosed) }
            Toast.makeText(this@ChatListActivity, result.errorMessage ?: if (!group.isClosed) "Ditutup" else "Dibuka", Toast.LENGTH_SHORT).show(); loadGroups()
        }
    }

    private fun addAdminDialog(group: Group) {
        val input = EditText(this); input.hint = "@username anggota"
        val pad = (20 * resources.displayMetrics.density).toInt(); input.setPadding(pad, pad / 2, pad, pad / 2)
        MaterialAlertDialogBuilder(this).setTitle("Tambahkan admin").setView(input).setPositiveButton("Tambahkan") { _, _ ->
            val cookie = session.sessionCookie ?: return@setPositiveButton
            lifecycleScope.launch {
                val result = withContext(Dispatchers.IO) { ApiClient(getString(R.string.api_base_url)).addGroupAdmin(cookie, group.id, input.text.toString().trim()) }
                Toast.makeText(this@ChatListActivity, result.errorMessage ?: "Admin ditambahkan", Toast.LENGTH_SHORT).show()
            }
        }.setNegativeButton("Batal", null).show()
    }

    // ---------- Tab Profil ----------
    private fun refreshProfile() {
        val username = session.username ?: ""
        val shown = prefs.displayName.ifBlank { "@$username" }
        findViewById<TextView>(R.id.tvProfileName).text = shown
        findViewById<TextView>(R.id.tvProfileUsername).text = "@$username"
        findViewById<TextView>(R.id.tvProfileBio).text = prefs.bio.ifBlank { "Belum ada info. Ketuk Edit profil untuk menambahkan." }
        bindAvatar(findViewById<ImageView>(R.id.ivProfileAvatar), findViewById(R.id.tvProfileInitial), shown.ifBlank { username }, session.avatarUrl, prefs.avatarFile())
    }

    private fun confirmLogout() {
        MaterialAlertDialogBuilder(this).setTitle("Keluar").setMessage("Kamu akan keluar dari akun ini di perangkat ini.").setPositiveButton("Keluar") { _, _ ->
            val cookie = session.sessionCookie
            if (cookie != null) Thread { runCatching { ApiClient(getString(R.string.api_base_url)).logout(cookie) } }.start()
            stopService(Intent(this, ChatConnectionService::class.java))
            session.clear()
            startActivity(Intent(this, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            finish()
        }.setNegativeButton("Batal", null).show()
    }

    // ---------- Izin, service, FCM, undangan ----------
    private fun requestRequiredPermissionsAfterLogin() {
        val permissions = mutableListOf(android.Manifest.permission.CAMERA, android.Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) permissions += android.Manifest.permission.POST_NOTIFICATIONS
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requiredPermissionLauncher.launch(missing.toTypedArray())
    }
    private fun startChatConnectionService() { ContextCompat.startForegroundService(this, Intent(this, ChatConnectionService::class.java)) }
    private fun registerFcmTokenIfAvailable() { val cookie = session.sessionCookie ?: return; runCatching { com.google.firebase.messaging.FirebaseMessaging.getInstance().token.addOnSuccessListener { token -> Thread { ApiClient(getString(R.string.api_base_url)).registerFcmToken(cookie, token) }.start() } } }
    private fun joinInviteFromIntent() { val token = intent?.data?.pathSegments?.lastOrNull() ?: return; val cookie = session.sessionCookie ?: return; lifecycleScope.launch { val result = withContext(Dispatchers.IO) { ApiClient(getString(R.string.api_base_url)).joinGroup(cookie, token) }; Toast.makeText(this@ChatListActivity, if (result.isSuccess) "Berhasil bergabung ke ${result.data?.name}" else result.errorMessage, Toast.LENGTH_SHORT).show(); intent.data = null; if (result.isSuccess) loadGroups() } }
}
