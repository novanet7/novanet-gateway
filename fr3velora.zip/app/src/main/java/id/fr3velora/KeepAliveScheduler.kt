package id.fr3velora

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * WorkManager periodik (≈15 menit minimum OS) untuk memastikan service
 * WebSocket masih hidup / reconnect. Bukan wake lock abadi — hemat baterai,
 * sesuai kebijakan Android & mirip praktik chat app modern.
 */
class KeepAliveWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {
    override fun doWork(): Result {
        val session = SessionManager(applicationContext)
        if (session.sessionCookie.isNullOrBlank()) return Result.success()
        return try {
            ContextCompat.startForegroundService(
                applicationContext,
                Intent(applicationContext, ChatConnectionService::class.java)
            )
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}

object KeepAliveScheduler {
    private const val UNIQUE = "fr3velora_keepalive"

    fun schedule(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val req = PeriodicWorkRequestBuilder<KeepAliveWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            UNIQUE,
            ExistingPeriodicWorkPolicy.KEEP,
            req
        )
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(UNIQUE)
    }
}
