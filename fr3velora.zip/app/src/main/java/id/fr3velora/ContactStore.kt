package id.fr3velora

import android.content.Context
import id.fr3velora.model.User

/**
 * Kontak + catatan privat per user.
 * Catatan hanya tersimpan di perangkat ini — lawan bicara TIDAK pernah melihatnya.
 * (Fitur khas: semacam “CRM note” pribadi, tidak ada di WA/Telegram sebagai first-class.)
 */
class ContactStore(context: Context) {
    private val prefs = context.getSharedPreferences("contacts", Context.MODE_PRIVATE)
    private val notes = context.getSharedPreferences("contact_notes", Context.MODE_PRIVATE)

    fun allIds(): Set<String> = prefs.getStringSet("ids", emptySet()) ?: emptySet()
    fun add(user: User) {
        prefs.edit().putStringSet("ids", allIds() + user.id).apply()
    }
    fun remove(user: User) {
        prefs.edit().putStringSet("ids", allIds() - user.id).apply()
    }

    fun getNote(userId: String): String = notes.getString(userId, "") ?: ""
    fun setNote(userId: String, text: String) {
        notes.edit().putString(userId, text.trim()).apply()
    }
}
