package id.fr3velora

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Preferensi per-chat & fitur lokal bergaya Telegram:
 * mute, block, draft, bintang, pin id, folder, mark unread, last typing, dll.
 */
class ChatExtrasStore(context: Context) {
    private val p = context.getSharedPreferences("chat_extras", Context.MODE_PRIVATE)

    // --- Block ---
    fun blockedIds(): Set<String> = p.getStringSet("blocked", emptySet()) ?: emptySet()
    fun isBlocked(id: String) = id in blockedIds()
    fun block(id: String) = p.edit().putStringSet("blocked", blockedIds() + id).apply()
    fun unblock(id: String) = p.edit().putStringSet("blocked", blockedIds() - id).apply()

    // --- Mute (until epoch, 0 = unmuted, Long.MAX = forever) ---
    fun muteUntil(peerOrRoom: String): Long = p.getLong("mute_$peerOrRoom", 0L)
    fun isMuted(peerOrRoom: String, now: Long = System.currentTimeMillis()) =
        muteUntil(peerOrRoom) > now
    fun mute(peerOrRoom: String, until: Long) = p.edit().putLong("mute_$peerOrRoom", until).apply()
    fun unmute(peerOrRoom: String) = p.edit().remove("mute_$peerOrRoom").apply()

    // --- Draft ---
    fun getDraft(key: String): String = p.getString("draft_$key", "") ?: ""
    fun setDraft(key: String, text: String) {
        if (text.isBlank()) p.edit().remove("draft_$key").apply()
        else p.edit().putString("draft_$key", text).apply()
    }

    // --- Starred message ids ---
    fun starredIds(): Set<String> = p.getStringSet("starred", emptySet()) ?: emptySet()
    fun isStarred(id: String) = id in starredIds()
    fun star(id: String) = p.edit().putStringSet("starred", starredIds() + id).apply()
    fun unstar(id: String) = p.edit().putStringSet("starred", starredIds() - id).apply()

    // --- Pinned message id per chat ---
    fun pinnedId(chatKey: String): String? = p.getString("pin_$chatKey", null)
    fun setPinned(chatKey: String, messageId: String?) {
        if (messageId == null) p.edit().remove("pin_$chatKey").apply()
        else p.edit().putString("pin_$chatKey", messageId).apply()
    }

    // --- Mark unread ---
    fun isMarkedUnread(chatKey: String) = p.getBoolean("unread_$chatKey", false)
    fun markUnread(chatKey: String, value: Boolean) =
        p.edit().putBoolean("unread_$chatKey", value).apply()

    // --- Disappearing timer seconds (0 = off) ---
    fun disappearSeconds(chatKey: String): Int = p.getInt("ttl_$chatKey", 0)
    fun setDisappearSeconds(chatKey: String, sec: Int) =
        p.edit().putInt("ttl_$chatKey", sec).apply()

    // --- Chat folders: folderName -> set of chat keys ---
    fun folderNames(): List<String> {
        val raw = p.getString("folders", "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { arr.getString(it) }
    }
    fun saveFolderNames(names: List<String>) {
        val arr = JSONArray()
        names.forEach { arr.put(it) }
        p.edit().putString("folders", arr.toString()).apply()
    }
    fun chatsInFolder(folder: String): Set<String> =
        p.getStringSet("folder_$folder", emptySet()) ?: emptySet()
    fun setChatsInFolder(folder: String, ids: Set<String>) =
        p.edit().putStringSet("folder_$folder", ids).apply()

    // --- Last seen privacy: everybody | nobody | contacts ---
    var lastSeenPrivacy: String
        get() = p.getString("last_seen_privacy", "everybody") ?: "everybody"
        set(v) = p.edit().putString("last_seen_privacy", v).apply()

    // --- Online presence cache (userId -> last online epoch) ---
    fun setLastOnline(userId: String, ts: Long) =
        p.edit().putLong("online_$userId", ts).apply()
    fun getLastOnline(userId: String): Long = p.getLong("online_$userId", 0L)
}
