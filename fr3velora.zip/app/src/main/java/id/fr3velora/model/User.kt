package id.fr3velora.model

/**
 * Field mengikuti response server:
 * POST /api/auth/google/mobile, GET /api/users, GET/PUT /api/users/me, dll.
 * display_name + bio + avatar_url sekarang disimpan di SERVER (bukan lokal APK).
 */
data class User(
    val id: String,
    val username: String,
    val email: String = "",
    val api_key: String = "",
    val avatar_url: String? = null,
    val display_name: String = "",
    val bio: String = "",
    val created_at: String? = null
) {
    /** Nama yang ditampilkan di list chat / profil. Prioritas: display_name → username */
    fun displayLabel(): String = display_name.ifBlank { username }
}
