package id.fr3velora.model

data class Message(
    val id: String? = null,
    val type: String = "message",
    val from: String = "",
    val to: String = "",
    val roomId: String? = null,
    val roomKind: String? = null,
    val text: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val attachmentName: String? = null,
    val attachmentMime: String? = null,
    val attachmentBase64: String? = null,
    val attachmentPath: String? = null,
    val status: String = "pending",
    val messageId: String? = null,
    val mode: String? = null,
    val replyToId: String? = null,
    val replyToText: String? = null,
    val replyToName: String? = null,
    val silent: Boolean = false,
    val unlockAt: Long? = null,
    val label: String? = null,
    // Telegram-style extras
    val edited: Boolean = false,
    val editedAt: Long? = null,
    val pinned: Boolean = false,
    /** JSON map emoji -> count, e.g. {"👍":2,"❤️":1} */
    val reactions: String? = null,
    val forwardedFrom: String? = null,
    val forwardedFromName: String? = null,
    /** Auto-delete after this epoch (disappearing messages) */
    val expireAt: Long? = null,
    val scheduledAt: Long? = null
) {
    val hasAttachment: Boolean get() = !attachmentName.isNullOrBlank() && !attachmentMime.isNullOrBlank()
    val hasReply: Boolean get() = !replyToId.isNullOrBlank()
    val isTimeCapsule: Boolean get() = unlockAt != null && unlockAt > 0L
    fun isLockedNow(now: Long = System.currentTimeMillis()): Boolean =
        isTimeCapsule && (unlockAt ?: 0L) > now
    fun isExpired(now: Long = System.currentTimeMillis()): Boolean =
        expireAt != null && expireAt > 0 && now >= expireAt
}
