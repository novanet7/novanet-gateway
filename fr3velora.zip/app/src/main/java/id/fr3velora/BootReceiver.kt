package id.fr3velora

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/**
 * Setelah HP reboot / app di-update: nyalakan lagi ChatConnectionService
 * jika user masih login. Pola sama dipakai app chat mainstream.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED &&
            action != "android.intent.action.QUICKBOOT_POWERON"
        ) return

        val session = SessionManager(context)
        if (session.sessionCookie.isNullOrBlank()) return

        runCatching {
            ContextCompat.startForegroundService(
                context,
                Intent(context, ChatConnectionService::class.java)
            )
        }
        KeepAliveScheduler.schedule(context)
    }
}
