package com.example.ui.theme

import androidx.compose.foundation.background
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Latar "blueprint grid" ala dashboard novanet.uno: warna dasar gelap + garis
 * kotak-kotak tipis tiap 46dp, ditambah dua radial glow ember lembut di pojok
 * atas — niru persis `background-image` pada `body` di dist/styles.css
 * (novanet.uno), biar Dashboard/Pengaturan/Profil senada sama website.
 */
fun Modifier.novanetBlueprintBackground(
    cellSize: Dp = 46.dp
): Modifier = this
    .background(NovanetBg0)
    .drawBehind {
        // Dua radial glow ember lembut, niru dua radial-gradient di pojok atas web
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(NovanetAccent.copy(alpha = 0.07f), Color.Transparent),
                center = Offset(size.width * 0.82f, -size.height * 0.10f),
                radius = size.width * 0.95f
            )
        )
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(NovanetAccent.copy(alpha = 0.05f), Color.Transparent),
                center = Offset(0f, -size.height * 0.08f),
                radius = size.width * 0.75f
            )
        )

        // Garis kotak-kotak tipis
        val cellPx = cellSize.toPx()
        val gridColor = NovanetText1.copy(alpha = 0.035f)
        val strokeWidth = 1f

        var x = 0f
        while (x <= size.width) {
            drawLine(gridColor, Offset(x, 0f), Offset(x, size.height), strokeWidth)
            x += cellPx
        }

        var y = 0f
        while (y <= size.height) {
            drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth)
            y += cellPx
        }
    }
