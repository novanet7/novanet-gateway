package com.example.ui

import android.content.Context
import android.os.PowerManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.api.ApiResult
import com.example.data.api.DeviceInfoUtil
import com.example.data.api.NovanetApiClient
import com.example.data.api.NovanetApiTransaction
import com.example.data.api.NovanetUnmatchedNotification
import com.example.data.api.NovanetStats
import com.example.data.api.NovanetUser
import com.example.data.pref.AppPreferences
import com.example.service.DanaKeepAliveService
import com.example.service.DanaNotificationListenerService
import com.example.service.DanaNotificationParser
import com.example.service.NotificationHealth
import com.example.service.NotificationHelper
import com.example.service.NovanetFirebaseMessagingService
import com.example.service.WatchdogWorker
import com.example.update.AppUpdater
import com.example.update.UpdateState
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DanaListenerViewModel(
    private val prefs: AppPreferences,
    // Application context (bukan Activity context) — aman disimpan di ViewModel,
    // dipakai buat baca info device (baterai) saat kirim heartbeat.
    private val appContext: Context
) : ViewModel() {

    private val refreshMutex = Mutex()

    // Auth & User State
    private val _isLoggedIn = MutableStateFlow(prefs.isLoggedIn)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _isLoggingIn = MutableStateFlow(false)
    val isLoggingIn: StateFlow<Boolean> = _isLoggingIn.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    private val _currentUser = MutableStateFlow(
        if (prefs.isLoggedIn) {
            NovanetUser(
                id = prefs.userId.ifEmpty { "usr-" + prefs.username.lowercase() },
                username = prefs.username,
                apiKey = prefs.apiKey,
                createdAt = prefs.userCreatedAt.ifEmpty { null },
                avatarUrl = prefs.avatarUrl.ifEmpty { null }
            )
        } else null
    )
    val currentUser: StateFlow<NovanetUser?> = _currentUser.asStateFlow()

    // Navigation: 0 = Dashboard, 1 = Profil
    private val _currentNavTab = MutableStateFlow(0)
    val currentNavTab: StateFlow<Int> = _currentNavTab.asStateFlow()

    // Server Data from novanet.uno
    private val _novanetStats = MutableStateFlow(NovanetStats())
    val novanetStats: StateFlow<NovanetStats> = _novanetStats.asStateFlow()

    private val _serverTransactions = MutableStateFlow<List<NovanetApiTransaction>>(emptyList())
    val serverTransactions: StateFlow<List<NovanetApiTransaction>> = _serverTransactions.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)

    private val _unmatchedNotifications = MutableStateFlow<List<NovanetUnmatchedNotification>>(emptyList())
    val unmatchedNotifications: StateFlow<List<NovanetUnmatchedNotification>> = _unmatchedNotifications.asStateFlow()


    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    // Service & Permission state
    private val _isPermissionGranted = MutableStateFlow(false)
    val isPermissionGranted: StateFlow<Boolean> = _isPermissionGranted.asStateFlow()

    val isServiceConnected: StateFlow<Boolean> = DanaNotificationListenerService.isServiceConnected
    val lastNotification: StateFlow<String?> = DanaNotificationListenerService.lastNotificationInfo

    // Status hidup-mati NYATA dari layanan latar belakang (auto start), bukan cuma
    // preferensi togel-nya — dipakai buat tampilan "Servis Auto Start" di STATUS APLIKASI.
    val isAutoStartRunning: StateFlow<Boolean> = DanaKeepAliveService.isRunning

    // WakeLock CPU nyata sedang dipegang atau tidak — dipakai buat baris
    // "Kunci CPU (WakeLock)" di STATUS APLIKASI, terpisah dari isAutoStartRunning
    // supaya kelihatan kalau service jalan tapi WakeLock-nya entah kenapa gagal diambil.
    val isWakeLockHeld: StateFlow<Boolean> = DanaKeepAliveService.isWakeLockHeld

    // Kapan (elapsedRealtime) service 24/7 mulai berjalan — null kalau lagi mati.
    // Dipakai UI buat hitung "berjalan sejak" di panel monitor sistem.
    val serviceStartElapsedRealtime: StateFlow<Long?> = DanaKeepAliveService.serviceStartElapsedRealtime

    // Settings State



    private val _targetPackageState = MutableStateFlow(prefs.targetPackage)
    val targetPackageState: StateFlow<String> = _targetPackageState.asStateFlow()

    private val _ttsAlertState = MutableStateFlow(prefs.ttsAlertEnabled)
    val ttsAlertState: StateFlow<Boolean> = _ttsAlertState.asStateFlow()

    private val _paymentAlertState = MutableStateFlow(prefs.paymentAlertEnabled)
    val paymentAlertState: StateFlow<Boolean> = _paymentAlertState.asStateFlow()

    // Kesehatan sistem notifikasi (izin, channel, pop-up, Jangan Ganggu) — diperbarui tiap
    // checkPermission() (dipanggil saat app dibuka lagi / kembali dari setelan sistem).
    private val _notificationHealth = MutableStateFlow(NotificationHelper.health(appContext))
    val notificationHealth: StateFlow<NotificationHealth> = _notificationHealth.asStateFlow()

    // Update aplikasi dari server (cek versi → unduh → pasang). Logikanya ada di AppUpdater.
    val updateState: StateFlow<UpdateState> = AppUpdater.state

    private val _isIgnoringBattery = MutableStateFlow(false)
    val isIgnoringBattery: StateFlow<Boolean> = _isIgnoringBattery.asStateFlow()

    private val _keepAliveState = MutableStateFlow(prefs.keepAliveEnabled)
    val keepAliveState: StateFlow<Boolean> = _keepAliveState.asStateFlow()

    // Togel terpisah untuk Watchdog (WorkManager, cek ±15 menit) — hanya
    // relevan/berjalan kalau Layanan Latar Belakang (24/7) juga menyala.
    private val _watchdogState = MutableStateFlow(prefs.watchdogEnabled)
    val watchdogState: StateFlow<Boolean> = _watchdogState.asStateFlow()


    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    private val _sendingTestPaidIds = MutableStateFlow<Set<String>>(emptySet())
    val sendingTestPaidIds: StateFlow<Set<String>> = _sendingTestPaidIds.asStateFlow()

        // ID transaksi server yang sedang diproses tombol "Tandai Lunas (Uji Coba)"
    init {
        // Buang sisa file update lama (mis. setelah update berhasil terpasang).
        AppUpdater.cleanup(appContext)
        if (prefs.isLoggedIn) {
            if (prefs.keepAliveEnabled) {
                DanaKeepAliveService.start(appContext)
                applyWatchdogSchedule(appContext)
            }
            // PENTING: sebelumnya syncFcmToken() cuma dipanggil sekali, di dalam
            // login(). Kalau request pendaftaran token itu gagal (mis. HP baru
            // login lalu langsung offline sebentar, atau server sempat down),
            // hasilnya dibuang begitu saja tanpa retry (lihat syncFcmToken di
            // bawah) — dan karena FirebaseMessaging.onNewToken() cuma terpanggil
            // ulang saat token BENERAN berganti (jarang, bisa berbulan-bulan),
            // device itu jadi TIDAK PERNAH terdaftar utk FCM sampai kapanpun.
            // Akibatnya notifikasi push dari server (permintaan pembayaran baru,
            // konfirmasi lunas, dsb — lihat NovanetFirebaseMessagingService) diam
            // -diam tidak pernah sampai ke device ini. Panggil ulang tiap app
            // dibuka supaya self-healing; registerFcmToken di server memakai
            // SADD (idempotent), jadi aman dipanggil berkali-kali.
            if (prefs.apiKey.isNotBlank()) syncFcmToken(prefs.apiKey)
            refreshServerData()
        }
        viewModelScope.launch {
            NovanetFirebaseMessagingService.events.collect { eventType ->
                if (!prefs.isLoggedIn || eventType.isBlank()) return@collect
                refreshServerData()
            }
        }
    }

    /** Jadwalkan watchdog HANYA kalau layanan 24/7 nyala DAN togel watchdog-nya sendiri nyala. */
    private fun applyWatchdogSchedule(context: Context) {
        if (prefs.isLoggedIn && prefs.keepAliveEnabled && prefs.watchdogEnabled) {
            WatchdogWorker.schedule(context)
        } else {
            WatchdogWorker.cancel(context)
        }
    }

    fun checkPermission(context: Context) {
        _isPermissionGranted.value = DanaNotificationListenerService.isNotificationAccessGranted(context)
        _notificationHealth.value = NotificationHelper.health(context)
        // Lanjutkan update yang menunggu izin pemasangan, atau cek versi baru (dibatasi tiap 15 menit).
        AppUpdater.onAppResumed(context)
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        _isIgnoringBattery.value = powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: false
        if (prefs.isLoggedIn && prefs.keepAliveEnabled) {
            DanaKeepAliveService.start(context)
            applyWatchdogSchedule(context)
        }
    }

    fun toggleKeepAlive(context: Context, enabled: Boolean) {
        prefs.keepAliveEnabled = enabled
        _keepAliveState.value = enabled
        if (enabled) {
            DanaKeepAliveService.start(context)
            applyWatchdogSchedule(context)
            _userMessage.value = "Layanan latar belakang 24/7 diaktifkan"
        } else {
            DanaKeepAliveService.stop(context)
            WatchdogWorker.cancel(context)
            _userMessage.value = "Layanan latar belakang dinonaktifkan"
        }
    }

    /** Togel watchdog terpisah — tidak menyalakan/mematikan layanan 24/7 itu sendiri. */
    fun toggleWatchdog(context: Context, enabled: Boolean) {
        prefs.watchdogEnabled = enabled
        _watchdogState.value = enabled
        applyWatchdogSchedule(context)
        _userMessage.value = if (enabled && prefs.keepAliveEnabled) {
            "Watchdog otomatis diaktifkan"
        } else if (enabled) {
            "Watchdog diaktifkan — akan mulai bekerja saat Layanan Latar Belakang dinyalakan"
        } else {
            "Watchdog otomatis dinonaktifkan"
        }
    }

    fun setNavTab(tabIndex: Int) {
        _currentNavTab.value = tabIndex
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun clearLoginError() {
        _loginError.value = null
    }

    // --- Authentication ---
    /** Dipanggil dari LoginScreen setelah user berhasil pilih akun lewat
     *  Credential Manager & dapat ID token Google. */
    fun loginWithGoogle(idToken: String) {
        if (idToken.isBlank()) {
            _loginError.value = "Gagal membaca token Google, coba lagi"
            return
        }

        viewModelScope.launch {
            _isLoggingIn.value = true
            _loginError.value = null

            val result = NovanetApiClient.loginWithGoogle(idToken)
            _isLoggingIn.value = false

            if (result.isSuccess && result.data != null) {
                val user = result.data
                prefs.isLoggedIn = true
                prefs.username = user.username
                prefs.userId = user.id
                prefs.apiKey = user.apiKey
                prefs.userCreatedAt = user.createdAt ?: ""
                prefs.avatarUrl = user.avatarUrl ?: ""
                if (!result.sessionCookie.isNullOrBlank()) {
                    prefs.sessionCookie = result.sessionCookie
                }

                _currentUser.value = user
                _isLoggedIn.value = true
                _currentNavTab.value = 0
                // Layanan 24/7 mengikuti pilihan pengguna (default MATI).
                // Tidak dipaksa hidup saat login; nyalakan lewat Pengaturan.
                _keepAliveState.value = prefs.keepAliveEnabled
                if (prefs.keepAliveEnabled) {
                    DanaKeepAliveService.start(appContext)
                    applyWatchdogSchedule(appContext)
                }
                syncFcmToken(user.apiKey)
                _userMessage.value = "Selamat datang, ${user.username}!"
                refreshServerData()
            } else {
                _loginError.value = result.errorMessage ?: "Gagal masuk ke akun novanet.uno"
            }
        }
    }

    /** Dipanggil dari LoginScreen kalau Credential Manager gagal/di-cancel sebelum
     *  sempat manggil server sama sekali (mis. tidak ada akun Google di HP). */
    fun setGoogleSignInError(message: String) {
        _loginError.value = message
    }

    private fun syncFcmToken(apiKey: String) {
        if (apiKey.isBlank()) return
        // Bila google-services.json belum dipasang, FirebaseApp tidak terinisialisasi dan
        // getInstance() melempar exception. Ditangkap supaya login tidak membuat aplikasi crash.
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val token = task.result
                    prefs.fcmToken = token
                    viewModelScope.launch { NovanetApiClient.registerFcmToken(apiKey, token) }
                }
            }
        } catch (_: IllegalStateException) {
            // Firebase belum dikonfigurasi: lewati sinkronisasi token FCM.
        }
    }

    fun logout() {
        // Menghentikan DanaKeepAliveService juga menutup socket realtime-nya
        // (lihat DanaKeepAliveService.onDestroy()).
        prefs.keepAliveEnabled = false
        _keepAliveState.value = false
        DanaKeepAliveService.stop(appContext)
        WatchdogWorker.cancel(appContext)
        viewModelScope.launch {
            val cookie = prefs.sessionCookie
            val apiKey = prefs.apiKey
            val fcmToken = prefs.fcmToken
            if (apiKey.isNotBlank() && fcmToken.isNotBlank()) {
                NovanetApiClient.removeFcmToken(apiKey, fcmToken)
            }
            if (cookie.isNotBlank()) {
                NovanetApiClient.logout(cookie)
            }
            prefs.clearSession()
            _currentUser.value = null
            _isLoggedIn.value = false
            _currentNavTab.value = 0
            _userMessage.value = "Berhasil keluar dari akun"
        }
    }

    // --- Refresh Data from novanet.uno ---
    fun refreshServerData() {
        // Avoid stacking refresh jobs from ON_RESUME, manual refresh, and FCM
        // events at the same time. The old jobs could race on _isRefreshing,
        // making the spinner stop while another network refresh was active.
        if (!_isRefreshing.compareAndSet(expect = false, update = true)) return
        val cookie = prefs.sessionCookie

        viewModelScope.launch {
            try {
                refreshMutex.withLock {
                    // Selalu ambil ulang profil (termasuk avatar_url) tiap kali
                    // data disegarkan — bukan cuma sekali waktu apiKey masih
                    // kosong. Sebelumnya avatarUrl cuma terisi sekali saat login
                    // pertama dan tidak pernah di-refresh lagi, jadi kalau foto
                    // profil diganti di website setelah itu, APK tidak pernah
                    // tahu dan selalu jatuh ke logo fallback.
                    if (cookie.isNotBlank()) {
                        val profResult = NovanetApiClient.getProfile(cookie)
                        if (profResult.isSuccess && profResult.data != null) {
                            val p = profResult.data
                            prefs.apiKey = p.apiKey
                            prefs.userId = p.id
                            prefs.userCreatedAt = p.createdAt ?: ""
                            prefs.avatarUrl = p.avatarUrl ?: ""
                            _currentUser.value = p
                        }
                    }

                    // Fetch stats
                    val statsResult = NovanetApiClient.getStats(cookie)
                    if (statsResult.isSuccess && statsResult.data != null) {
                        _novanetStats.value = statsResult.data
                    }

                    // Fetch transactions
                    val txResult = NovanetApiClient.getTransactions(cookie)
                    if (txResult.isSuccess && txResult.data != null) {
                        val transactions = txResult.data.distinctBy {
                            if (it.id.isNotBlank()) it.id
                            else "${it.reference}|${it.createdAt}|${it.uniqueAmount}|${it.status}"
                        }
                        _serverTransactions.value = transactions
                    }

                    val unmatchedResult = NovanetApiClient.getUnmatchedNotifications(prefs.apiKey)
                    if (unmatchedResult.isSuccess && unmatchedResult.data != null) {
                        _unmatchedNotifications.value = unmatchedResult.data
                    }

                    // Heartbeat best-effort ke server (kartu "APK Terhubung" di dashboard
                    // web) - gak perlu ditunggu/di-report ke user kalau gagal.
                    sendHeartbeat()
                }
            } finally {
                _isRefreshing.value = false
            }
        }
    }

    /** Buang satu entri "perlu dicek manual" setelah pengguna mencocokkannya sendiri. */
    fun dismissUnmatchedNotification(id: String) {
        if (id.isBlank()) return
        // Hilangkan dari daftar lokal dulu supaya kartu langsung hilang tanpa
        // menunggu round-trip server (server tetap jadi sumber kebenaran saat
        // refresh berikutnya memuat ulang daftar unmatched).
        _unmatchedNotifications.value = _unmatchedNotifications.value.filterNot { it.id == id }
        viewModelScope.launch {
            val result = NovanetApiClient.dismissUnmatchedNotification(prefs.apiKey, id)
            if (!result.isSuccess) {
                _userMessage.value = result.errorMessage ?: "Gagal membuang notifikasi dari daftar"
            }
        }
    }

    fun markServerTransactionPaidTest(transactionId: String) {
        if (transactionId.isBlank() || transactionId in _sendingTestPaidIds.value) return
        viewModelScope.launch {
            _sendingTestPaidIds.value = _sendingTestPaidIds.value + transactionId
            val result = NovanetApiClient.markPaidTest(prefs.apiKey, transactionId)
            _sendingTestPaidIds.value = _sendingTestPaidIds.value - transactionId
            _userMessage.value = if (result.isSuccess) {
                refreshServerData()
                "Transaksi ${transactionId.take(8)} ditandai lunas (uji coba)"
            } else result.errorMessage ?: "Gagal menandai transaksi lunas"
        }
    }

    /** Kirim status device (nama, IP lokal, persentase baterai) ke server lewat X-Api-Key. */
    private suspend fun sendHeartbeat() {
        val apiKey = prefs.apiKey
        if (apiKey.isBlank()) return
        NovanetApiClient.postDeviceStatus(
            apiKey = apiKey,
            deviceName = DeviceInfoUtil.deviceName(),
            ipAddress = DeviceInfoUtil.localIpAddress(),
            batteryPercent = DeviceInfoUtil.batteryPercent(appContext).let { if (it < 0) 0 else it }
        )
    }

    // --- Settings Management ---
    fun toggleTtsAlert(enabled: Boolean) {
        prefs.ttsAlertEnabled = enabled
        _ttsAlertState.value = enabled
        _userMessage.value = if (enabled) "Suara notifikasi aktif" else "Suara notifikasi nonaktif"
    }

    fun checkForUpdate() = AppUpdater.checkForUpdate(appContext, manual = true)

    fun startUpdate() = AppUpdater.startUpdate(appContext)

    fun openInstallPermissionSettings() = AppUpdater.openInstallPermissionSettings(appContext)

    fun togglePaymentAlert(enabled: Boolean) {
        prefs.paymentAlertEnabled = enabled
        _paymentAlertState.value = enabled
        _userMessage.value = if (enabled) "Pop-up pembayaran aktif" else "Pop-up pembayaran nonaktif"
    }
    // onCleared() sengaja tidak menutup apa pun lagi: socket realtime hidup
    // di DanaKeepAliveService, bukan di ViewModel, jadi ViewModel yang
    // dibuang (mis. rotasi layar, Activity ditutup) tidak memutus koneksi.

    class Factory(
            private val prefs: AppPreferences,
        private val appContext: Context
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DanaListenerViewModel(prefs, appContext) as T
        }
    }
}
