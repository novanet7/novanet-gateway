package com.example.ui.screens

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.ChannelHealth
import com.example.service.NotificationHealth
import com.example.service.NotificationHelper
import com.example.ui.theme.NovanetAccent
import com.example.ui.theme.NovanetBg0
import com.example.ui.theme.NovanetBg1
import com.example.ui.theme.NovanetBg2
import com.example.ui.theme.NovanetDanger
import com.example.ui.theme.NovanetLine
import com.example.ui.theme.NovanetSuccess
import com.example.ui.theme.NovanetText1
import com.example.ui.theme.NovanetText2
import com.example.ui.theme.NovanetText3
import com.example.ui.theme.SystemMonitorPanel
import com.example.ui.theme.novanetBlueprintBackground

// ============================================================
// Konstanta UI — biar konsisten satu tempat
// ============================================================
private val CARD_SHAPE = RoundedCornerShape(10.dp)
private val BTN_SHAPE = RoundedCornerShape(8.dp)
private val ITEM_SHAPE = RoundedCornerShape(6.dp)
private val SCREEN_PADDING = 16.dp
private val CARD_PADDING = 14.dp
private val SECTION_GAP = 14.dp

// ============================================================
// SCREEN UTAMA
// ============================================================
@SuppressLint("BatteryLife")
@Composable
fun SettingsScreen(
    ttsAlert: Boolean,
    paymentAlert: Boolean,
    isPermissionGranted: Boolean,
    notificationHealth: NotificationHealth,
    isServiceConnected: Boolean,
    isIgnoringBattery: Boolean,
    keepAliveEnabled: Boolean,
    isAutoStartRunning: Boolean,
    isWakeLockHeld: Boolean,
    watchdogEnabled: Boolean,
    serviceStartElapsedRealtime: Long?,
    onToggleTtsAlert: (Boolean) -> Unit,
    onTogglePaymentAlert: (Boolean) -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onSendTestNotifications: () -> Unit,
    onToggleKeepAlive: (Boolean) -> Unit,
    onToggleWatchdog: (Boolean) -> Unit,
    onRefreshStatus: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    LaunchedEffect(Unit) { onRefreshStatus() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .novanetBlueprintBackground()
            .verticalScroll(scrollState)
            .padding(horizontal = SCREEN_PADDING)
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Spacer(Modifier.height(16.dp))

        HeaderSection()

        Spacer(Modifier.height(18.dp))

        // ── 1. Autostart vendor ──────────────────────────
        SectionCard {
            SectionHeader(
                icon = Icons.Default.PowerSettingsNew,
                title = "AUTOSTART APLIKASI"
            )
            Text(
                text = "Wajib diaktifkan pada HP tertentu agar layanan tetap hidup setelah restart atau saat aplikasi ditutup.",
                fontSize = 11.sp,
                color = NovanetText2,
                lineHeight = 15.sp
            )
            Spacer(Modifier.height(12.dp))
            ActionButton(
                text = "Buka Pengaturan Autostart (${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }})",
                onClick = { openAutostartSettings(context) },
                showBorder = true,
                testTag = "open_autostart_button"
            )
        }

        Spacer(Modifier.height(SECTION_GAP))

        // ── 2. Notifikasi & Suara ────────────────────────
        SectionCard {
            SectionHeader(title = "NOTIFIKASI & SUARA")

            // Switch listener — seragam sama 24/7 & Pop-up
            SettingToggleRow(
                title = "Akses Listener Notifikasi",
                description = if (isPermissionGranted)
                    "Aktif — aplikasi bisa membaca notifikasi DANA"
                else
                    "Nonaktif — aktifkan agar aplikasi bisa membaca mutasi DANA",
                checked = isPermissionGranted,
                onCheckedChange = { enabled ->
                    // ON saat izin belum ada → langsung ke setelan
                    // OFF saat izin ada → arahkan ke setelan untuk revoke manual
                    if (enabled != isPermissionGranted) {
                        openNotificationListenerSettings(context)
                    }
                },
                testTag = "switch_listener_access"
            )

            Spacer(Modifier.height(12.dp))
            ThinDivider()
            Spacer(Modifier.height(12.dp))

            SettingToggleRow(
                title = "Suara Notifikasi (TTS Alert)",
                description = "Ucapkan nominal & nama pengirim saat pembayaran masuk",
                checked = ttsAlert,
                onCheckedChange = onToggleTtsAlert,
                testTag = "switch_tts_alert"
            )

            Spacer(Modifier.height(12.dp))
            ThinDivider()
            Spacer(Modifier.height(12.dp))

            SettingToggleRow(
                title = "Pop-up Pembayaran",
                description = if (notificationHealth.appEnabled)
                    "Tampilkan banner sistem saat pembayaran baru terdeteksi"
                else
                    "Izin notifikasi belum aktif — pop-up tidak akan tampil sampai diizinkan (lihat kartu di bawah)",
                checked = paymentAlert,
                onCheckedChange = { enabled ->
                    onTogglePaymentAlert(enabled)
                    // Menyalakan pop-up saat izin belum ada → langsung minta izinnya.
                    if (enabled && !notificationHealth.appEnabled) onRequestNotificationPermission()
                },
                testTag = "switch_payment_alert"
            )
        }

        Spacer(Modifier.height(SECTION_GAP))

        // ── 2b. Izin notifikasi & pop-up ─────────────────
        SectionCard(testTag = "notification_popup_card") {
            SectionHeader(
                icon = Icons.Default.Notifications,
                title = "IZIN NOTIFIKASI & POP-UP"
            )
            Text(
                text = "Semua jenis notifikasi aplikasi (pembayaran terdeteksi, permintaan/konfirmasi dari server, peringatan sistem) butuh izin di bawah agar tampil sebagai pop-up.",
                fontSize = 11.sp,
                color = NovanetText2,
                lineHeight = 15.sp
            )
            Spacer(Modifier.height(10.dp))

            InteractivePermissionRow(
                label = "Izin notifikasi aplikasi",
                granted = notificationHealth.appEnabled,
                detail = when {
                    notificationHealth.appEnabled -> "Aktif — notifikasi boleh tampil"
                    !notificationHealth.runtimePermissionGranted -> "Belum diizinkan — ketuk untuk meminta izin"
                    else -> "Diblokir di setelan HP — ketuk untuk membuka"
                },
                onClick = onRequestNotificationPermission
            )

            if (notificationHealth.dndActive) {
                InteractivePermissionRow(
                    label = "Mode Jangan Ganggu / Fokus",
                    granted = false,
                    detail = "Sedang aktif — pop-up & suara bisa tertahan. Ketuk untuk membuka setelan",
                    onClick = { NotificationHelper.openDoNotDisturbSettings(context) }
                )
            }

            if (notificationHealth.channels.isEmpty()) {
                Text(
                    text = "Android 7.x: pop-up mengikuti izin notifikasi aplikasi di atas.",
                    fontSize = 10.5.sp,
                    color = NovanetText3,
                    lineHeight = 14.sp,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp)
                )
            } else {
                notificationHealth.channels.forEach { channel ->
                    InteractivePermissionRow(
                        label = channel.label,
                        granted = channelIsHealthy(channel),
                        detail = channelDetail(channel),
                        onClick = { NotificationHelper.openChannelSettings(context, channel.id) }
                    )
                }
            }

            Spacer(Modifier.height(10.dp))
            ActionButton(
                text = if (notificationHealth.appEnabled)
                    "Buka Pengaturan Notifikasi Aplikasi"
                else
                    "Izinkan Notifikasi Aplikasi",
                onClick = onRequestNotificationPermission,
                containerColor = if (notificationHealth.appEnabled) NovanetBg2 else NovanetAccent,
                contentColor = if (notificationHealth.appEnabled) NovanetText1 else NovanetBg0,
                showBorder = true,
                testTag = "open_notification_settings_button"
            )
            Spacer(Modifier.height(8.dp))
            ActionButton(
                text = "Kirim Notifikasi Uji Coba",
                onClick = onSendTestNotifications,
                showBorder = true,
                testTag = "send_test_notification_button"
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "Tips: di realme, Oppo, Xiaomi, dan Vivo ada sakelar tambahan “Notifikasi mengambang / Banner” dan “Layar kunci” di halaman pengaturan notifikasi aplikasi — aktifkan juga. Tombol uji mengirim 3 pop-up berjeda beberapa detik.",
                fontSize = 10.5.sp,
                color = NovanetText3,
                lineHeight = 14.sp
            )
        }

        Spacer(Modifier.height(SECTION_GAP))

        // ── 3. Status aplikasi ───────────────────────────
        SectionCard(testTag = "permission_status_card") {
            SectionHeader(title = "STATUS APLIKASI")

            // Togel layanan 24/7 — dipindah ke sini, satu bingkai sama tombol
            // status lain, tanpa ikon section header terpisah.
            PriorityToggleRow(
                title = "Layanan Latar Belakang (24/7)",
                description = when {
                    keepAliveEnabled && isIgnoringBattery ->
                        "Aktif & bebas batasan baterai — CPU terkunci 24/7 sampai dimatikan manual di sini"
                    keepAliveEnabled ->
                        "Aktif, tunggu konfirmasi izin baterai di setelan HP..."
                    else ->
                        "Mati — status aplikasi di dashboard akan ditandai offline"
                },
                checked = keepAliveEnabled,
                onCheckedChange = { enabled ->
                    onToggleKeepAlive(enabled)
                    if (enabled && !isIgnoringBattery) {
                        openBatteryOptimizationSettings(context)
                    }
                },
                testTag = "switch_keep_alive"
            )

            Spacer(Modifier.height(12.dp))
            ThinDivider()
            Spacer(Modifier.height(12.dp))

            // Togel terpisah untuk Watchdog — bisa dimatikan sendiri tanpa
            // ikut mematikan Layanan Latar Belakang di atas.
            SettingToggleRow(
                title = "Watchdog Otomatis (Auto-Restart 15 menit)",
                description = when {
                    watchdogEnabled && keepAliveEnabled ->
                        "Aktif — memeriksa & menyalakan ulang layanan tiap ±15 menit bila mati"
                    watchdogEnabled ->
                        "Aktif, tapi baru bekerja setelah Layanan Latar Belakang dinyalakan"
                    else ->
                        "Mati — layanan tidak akan dinyalakan ulang otomatis kalau sistem mematikannya"
                },
                checked = watchdogEnabled,
                onCheckedChange = onToggleWatchdog,
                testTag = "switch_watchdog"
            )

            Spacer(Modifier.height(12.dp))
            ThinDivider()
            Spacer(Modifier.height(12.dp))

            // Status NYATA servis auto start — wajib aktif, ditegaskan lewat warna.
            InteractivePermissionRow(
                label = "Servis Auto Start",
                granted = isAutoStartRunning,
                detail = if (isAutoStartRunning) "Berjalan — layanan latar belakang aktif"
                else "Tidak berjalan — wajib aktif, ketuk untuk cek ulang",
                onClick = onRefreshStatus
            )

            Spacer(Modifier.height(12.dp))
            ThinDivider()
            Spacer(Modifier.height(12.dp))

            // Status NYATA WakeLock CPU — menegaskan bahwa CPU sengaja dikunci
            // menyala selama servis 24/7 hidup, bukan cuma foreground service saja.
            InteractivePermissionRow(
                label = "Kunci CPU (WakeLock)",
                granted = isWakeLockHeld,
                detail = if (isWakeLockHeld) "Terkunci — CPU tidak akan tidur selama servis aktif"
                else if (isAutoStartRunning) "Servis aktif tapi WakeLock belum terkunci, ketuk untuk cek ulang"
                else "Nonaktif — aktifkan Layanan Latar Belakang di atas",
                onClick = onRefreshStatus
            )

            Spacer(Modifier.height(12.dp))
            ThinDivider()
            Spacer(Modifier.height(12.dp))

            InteractivePermissionRow(
                label = "Akses baca notifikasi DANA",
                granted = isPermissionGranted,
                detail = if (isPermissionGranted) "Aktif"
                else "Ketuk untuk membuka Izin Notifikasi",
                onClick = { openNotificationListenerSettings(context) }
            )
            InteractivePermissionRow(
                label = "Aplikasi listener",
                granted = isServiceConnected,
                detail = if (isServiceConnected) "Aplikasi aktif dan berjalan"
                else "Aplikasi belum aktif",
                onClick = onRefreshStatus
            )
            InteractivePermissionRow(
                label = "Izin notifikasi aplikasi",
                granted = notificationHealth.appEnabled,
                detail = if (notificationHealth.appEnabled) "Aktif"
                else "Ketuk untuk mengaktifkan notifikasi",
                onClick = onRequestNotificationPermission
            )
            InteractivePermissionRow(
                label = "Pop-up notifikasi",
                granted = notificationHealth.popupReady,
                detail = if (notificationHealth.popupReady) "Semua jenis pop-up siap tampil"
                else "Ada yang belum siap — cek kartu Izin Notifikasi & Pop-up",
                onClick = onRefreshStatus
            )
            InteractivePermissionRow(
                label = "Bebas batasan baterai",
                granted = isIgnoringBattery,
                detail = if (isIgnoringBattery) "Aktif (Tidak dibatasi)"
                else "Ketuk untuk membebaskan baterai",
                onClick = { openBatteryOptimizationSettings(context) }
            )
        }

        Spacer(Modifier.height(SECTION_GAP))

        // ── 4. Monitor sistem (terminal + gelombang real-time) ───
        SectionCard(testTag = "system_monitor_card") {
            SystemMonitorPanel(
                isServiceRunning = isAutoStartRunning,
                serviceStartElapsedRealtime = serviceStartElapsedRealtime
            )
        }

        Spacer(Modifier.height(28.dp))
    }
}

// ============================================================
// SUB-COMPONENTS
// ============================================================

@Composable
private fun HeaderSection() {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(NovanetBg1)
                .border(1.dp, NovanetLine, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = null,
                tint = NovanetAccent,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(
                text = "Pengaturan",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = NovanetText1
            )
            Text(
                text = "Kontrol & Pemantauan Latar Belakang",
                fontSize = 11.sp,
                color = NovanetText2
            )
        }
    }
}

@Composable
private fun SectionCard(
    modifier: Modifier = Modifier,
    testTag: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        shape = CARD_SHAPE,
        color = NovanetBg1,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, NovanetLine, CARD_SHAPE)
            .then(if (testTag != null) Modifier.testTag(testTag) else Modifier)
    ) {
        Column(
            modifier = Modifier.padding(CARD_PADDING),
            content = content
        )
    }
}

@Composable
private fun SectionHeader(
    title: String,
    icon: ImageVector? = null
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 12.dp)
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = NovanetAccent,
                modifier = Modifier.size(14.dp)
            )
            Spacer(Modifier.width(6.dp))
        }
        Text(
            text = title,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp,
            color = NovanetText2
        )
    }
}

@Composable
private fun ThinDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(NovanetLine.copy(alpha = 0.5f))
    )
}

@Composable
private fun SettingToggleRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    testTag: String? = null
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = NovanetText1
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = description,
                fontSize = 11.sp,
                color = NovanetText2,
                lineHeight = 15.sp
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = NovanetBg0,
                checkedTrackColor = NovanetSuccess,
                uncheckedThumbColor = NovanetText3,
                uncheckedTrackColor = NovanetBg2
            ),
            modifier = if (testTag != null) Modifier.testTag(testTag) else Modifier
        )
    }
}

/** Togel setara [SettingToggleRow], tapi judulnya dikasih badge "WAJIB" — dipakai
 *  untuk layanan yang memang harus tetap aktif (mis. layanan latar belakang 24/7). */
@Composable
private fun PriorityToggleRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    testTag: String? = null
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NovanetText1
                )
                Spacer(Modifier.width(6.dp))
                WajibBadge()
            }
            Spacer(Modifier.height(2.dp))
            Text(
                text = description,
                fontSize = 11.sp,
                color = NovanetText2,
                lineHeight = 15.sp
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = NovanetBg0,
                checkedTrackColor = NovanetSuccess,
                uncheckedThumbColor = NovanetText3,
                uncheckedTrackColor = NovanetBg2
            ),
            modifier = if (testTag != null) Modifier.testTag(testTag) else Modifier
        )
    }
}

@Composable
private fun WajibBadge() {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(NovanetDanger.copy(alpha = 0.15f))
            .border(1.dp, NovanetDanger.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = "WAJIB",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = NovanetDanger,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
private fun ActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    containerColor: Color = NovanetBg2,
    contentColor: Color = NovanetText1,
    showBorder: Boolean = false,   // default: no border (nyatu dengan card)
    testTag: String? = null
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        shape = BTN_SHAPE,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
        modifier = modifier
            .fillMaxWidth()
            .height(40.dp)
            .then(
                if (showBorder && containerColor == NovanetBg2)
                    Modifier.border(1.dp, NovanetLine, BTN_SHAPE)
                else Modifier
            )
            .then(if (testTag != null) Modifier.testTag(testTag) else Modifier)
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = contentColor.copy(alpha = 0.8f),
                modifier = Modifier.size(15.dp)
            )
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = text,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun InteractivePermissionRow(
    label: String,
    granted: Boolean,
    detail: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(ITEM_SHAPE)
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (granted) Icons.Default.CheckCircle else Icons.Default.Close,
            contentDescription = if (granted) "Aktif" else "Belum aktif",
            tint = if (granted) NovanetSuccess else NovanetDanger,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = NovanetText1
            )
            Spacer(Modifier.height(1.dp))
            Text(
                text = detail,
                fontSize = 10.5.sp,
                color = if (granted) NovanetSuccess else NovanetDanger
            )
        }
    }
}

// ============================================================
// HELPER — buka Setelan Sistem dengan fallback aman
// ============================================================

private fun openNotificationListenerSettings(context: Context) {
    runCatching {
        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }
}

/**
 * Banyak vendor Android (MIUI, ColorOS, FuntouchOS/OriginOS, EMUI/MagicOS,
 * dll.) punya daftar "Autostart"/"Aplikasi Latar Belakang" TERPISAH dari
 * pengaturan baterai standar Android — kalau tidak diaktifkan di sana,
 * layanan 24/7 bisa tetap dibunuh sistem walau battery optimization sudah
 * di-exempt lewat API resmi Android. Halaman ini tidak ada di AOSP/API
 * publik, jadi harus ditarget lewat nama activity spesifik tiap vendor.
 * Dicoba satu-satu sampai ada yang berhasil dibuka; kalau semua gagal
 * (vendor lain / activity berubah nama di versi ROM baru), jatuh ke
 * halaman Info Aplikasi biasa sebagai fallback aman.
 */
private fun openAutostartSettings(context: Context) {
    val manufacturer = Build.MANUFACTURER.lowercase()
    val candidates: List<Intent> = when {
        manufacturer.contains("xiaomi") -> listOf(
            Intent().setClassName(
                "com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"
            ),
            Intent().setClassName(
                "com.miui.securitycenter",
                "com.miui.securitycenter.Main"
            )
        )
        manufacturer.contains("oppo") -> listOf(
            Intent().setClassName(
                "com.coloros.safecenter",
                "com.coloros.safecenter.permission.startup.StartupAppListActivity"
            ),
            Intent().setClassName(
                "com.coloros.safecenter",
                "com.coloros.safecenter.startupapp.StartupAppListActivity"
            ),
            Intent().setClassName(
                "com.oppo.safe",
                "com.oppo.safe.permission.startup.StartupAppListActivity"
            )
        )
        manufacturer.contains("vivo") -> listOf(
            Intent().setClassName(
                "com.vivo.permissionmanager",
                "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"
            ),
            Intent().setClassName(
                "com.iqoo.secure",
                "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"
            )
        )
        manufacturer.contains("huawei") || manufacturer.contains("honor") -> listOf(
            Intent().setClassName(
                "com.huawei.systemmanager",
                "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"
            ),
            Intent().setClassName(
                "com.huawei.systemmanager",
                "com.huawei.systemmanager.optimize.process.ProtectActivity"
            )
        )
        manufacturer.contains("oneplus") -> listOf(
            Intent().setClassName(
                "com.oneplus.security",
                "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"
            )
        )
        manufacturer.contains("asus") -> listOf(
            Intent().setClassName(
                "com.asus.mobilemanager",
                "com.asus.mobilemanager.autostart.AutoStartActivity"
            )
        )
        manufacturer.contains("samsung") -> listOf(
            Intent().setClassName(
                "com.samsung.android.lool",
                "com.samsung.android.sm.ui.battery.BatteryActivity"
            )
        )
        else -> emptyList()
    }

    val opened = candidates.any { intent ->
        runCatching {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }.isSuccess
    }

    if (!opened) openAppDetails(context)
}

private fun openAppDetails(context: Context) {
    runCatching {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
        }
        context.startActivity(intent)
    }
}

/** Channel sehat = ada, tidak diblokir, dan (kalau memang untuk pop-up) importance-nya HIGH. */
private fun channelIsHealthy(channel: ChannelHealth): Boolean =
    channel.exists && !channel.blocked && (!channel.expectsPopup || channel.popupCapable)

private fun channelDetail(channel: ChannelHealth): String = when {
    !channel.exists -> "Belum terdaftar — tutup lalu buka ulang aplikasi"
    channel.blocked -> "Diblokir — ketuk untuk mengaktifkan"
    channel.expectsPopup && !channel.popupCapable ->
        "Tanpa pop-up — ketuk, lalu atur ke “Mendesak” / “Muncul sebagai pop-up”"
    channel.expectsPopup -> "Pop-up aktif"
    else -> "Aktif (senyap — memang tanpa pop-up)"
}

private fun openBatteryOptimizationSettings(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        val opened = runCatching {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${context.packageName}")
            }
            context.startActivity(intent)
        }.isSuccess
        if (opened) return
    }
    runCatching {
        context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }
}
