package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.api.AppUpdateInfo
import com.example.ui.theme.NovanetAccent
import com.example.ui.theme.NovanetAccentInk
import com.example.ui.theme.NovanetBg1
import com.example.ui.theme.NovanetBg3
import com.example.ui.theme.NovanetDanger
import com.example.ui.theme.NovanetText1
import com.example.ui.theme.NovanetText2
import com.example.update.UpdateState
import java.util.Locale

/** "12.3 MB" */
fun formatMegabytes(bytes: Long): String =
    String.format(Locale.US, "%.1f MB", bytes / 1024.0 / 1024.0)

private fun UpdateState.bannerInfo(): AppUpdateInfo? = when (this) {
    is UpdateState.Available -> info
    is UpdateState.NeedsInstallPermission -> info
    is UpdateState.Downloading -> info
    is UpdateState.Verifying -> info
    is UpdateState.Installing -> info
    is UpdateState.Failed -> info
    else -> null
}

/**
 * Banner update di Dashboard: tombol Update → tampilan mengunduh (progres) → memasang.
 * Tidak menampilkan apa pun bila tidak ada update / sedang tidak relevan.
 */
@Composable
fun UpdateBanner(
    state: UpdateState,
    onStartUpdate: () -> Unit,
    onOpenInstallSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val info = state.bannerInfo() ?: return
    val isError = state is UpdateState.Failed
    val tint = if (isError) NovanetDanger else NovanetAccent
    val shape = RoundedCornerShape(8.dp)

    val title: String
    val subtitle: String
    when (state) {
        is UpdateState.Available -> {
            title = "Update tersedia · v${info.versionName}"
            subtitle = info.notes.ifBlank { "Versi baru siap diunduh (${formatMegabytes(info.sizeBytes)})" }
        }
        is UpdateState.NeedsInstallPermission -> {
            title = "Izinkan pemasangan update"
            subtitle = "Aktifkan “Izinkan dari sumber ini” untuk Novanet, lalu kembali ke aplikasi — update lanjut otomatis."
        }
        is UpdateState.Downloading -> {
            title = "Mengunduh update…"
            subtitle = "Versi ${info.versionName}"
        }
        is UpdateState.Verifying -> {
            title = "Memeriksa file update…"
            subtitle = "Versi ${info.versionName}"
        }
        is UpdateState.Installing -> {
            title = "Memasang update…"
            subtitle = "Ketuk “Perbarui” / “Pasang” di layar Android. Aplikasi akan tertutup otomatis, lalu buka lagi untuk versi baru."
        }
        is UpdateState.Failed -> {
            title = "Update gagal"
            subtitle = state.message
        }
        else -> return
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(NovanetBg1)
            .border(1.dp, tint.copy(alpha = 0.6f), shape)
            .padding(14.dp)
            .testTag("update_banner")
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Icon(
                imageVector = if (isError) Icons.Default.Warning else Icons.Default.SystemUpdate,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NovanetText1
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    color = NovanetText2,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        when (state) {
            is UpdateState.Downloading -> {
                val total = state.totalBytes.coerceAtLeast(1L)
                val fraction = (state.downloadedBytes.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = NovanetAccent,
                    trackColor = NovanetBg3
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "${(fraction * 100).toInt()}%  ·  ${formatMegabytes(state.downloadedBytes)} / ${formatMegabytes(total)}",
                    fontSize = 11.sp,
                    color = NovanetText2
                )
            }
            is UpdateState.Verifying, is UpdateState.Installing -> {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = NovanetAccent,
                    trackColor = NovanetBg3
                )
            }
            else -> Unit
        }

        val buttonLabel: String? = when (state) {
            is UpdateState.Available -> "Update Sekarang"
            is UpdateState.NeedsInstallPermission -> "Buka Pengaturan Izin"
            is UpdateState.Failed -> "Coba Lagi"
            else -> null
        }
        if (buttonLabel != null) {
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = if (state is UpdateState.NeedsInstallPermission) onOpenInstallSettings else onStartUpdate,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NovanetAccent,
                    contentColor = NovanetAccentInk
                ),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
                    .testTag("update_banner_button")
            ) {
                Text(text = buttonLabel, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
