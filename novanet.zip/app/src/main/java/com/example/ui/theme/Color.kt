package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Novanet Official Design Tokens (from novanet.uno styles.css)
val NovanetBg0 = Color(0xFF0A0D13) // Canvas main
val NovanetBg1 = Color(0xFF10141D) // Surface / Card
val NovanetBg2 = Color(0xFF161C28) // Elevated / Input
val NovanetBg3 = Color(0xFF1C2332) // Hover / subtle line

val NovanetLine = Color(0xFF212A3B)
val NovanetLineStrong = Color(0xFF2E394E)

val NovanetText1 = Color(0xFFE7EBF3) // Primary text
val NovanetText2 = Color(0xFF98A2B6) // Secondary text
val NovanetText3 = Color(0xFF5F6B81) // Muted text

val NovanetAccent = Color(0xFFFF5C3A) // Ember Accent
val NovanetAccentHover = Color(0xFFFF7A5E)
val NovanetAccentSoft = Color(0x26FF5C3A) // Soft ember glow
val NovanetAccentInk = Color(0xFF0A0D13)

val NovanetSuccess = Color(0xFF34D17C)
val NovanetSuccessSoft = Color(0x1F34D17C)

val NovanetDanger = Color(0xFFF0564E)
val NovanetDangerSoft = Color(0x1FF0564E)

val NovanetWarning = Color(0xFFF5A623)
val NovanetWarningSoft = Color(0x1FF5A623)

val NovanetInfo = Color(0xFF4C9EFF)
val NovanetInfoSoft = Color(0x1F4C9EFF)

// Backward compatible aliases
val DanaBlue = NovanetAccent
val DanaBlueDark = Color(0xFFE04323)
val DanaBlueLight = NovanetAccentHover
val CyanAccent = NovanetAccent
val SkyAccent = NovanetInfo

val DarkBackground = NovanetBg0
val DarkSurface = NovanetBg1
val DarkSurfaceCard = NovanetBg1
val DarkSurfaceElevated = NovanetBg2
val DarkBorder = NovanetLine

val SuccessGreen = NovanetSuccess
val SuccessGreenContainer = Color(0xFF0C3822)
val WarningAmber = NovanetWarning
val WarningAmberContainer = Color(0xFF482B0A)
val ErrorRose = NovanetDanger
val ErrorRoseContainer = Color(0xFF461614)

val TextPrimary = NovanetText1
val TextSecondary = NovanetText2
val TextMuted = NovanetText3


