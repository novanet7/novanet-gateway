package com.example.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import id.novanet.listener.R
import com.example.data.api.NovanetApiTransaction
import com.example.data.api.NovanetStats
import com.example.update.UpdateState
import com.example.update.showsBanner
import com.example.data.api.NovanetUnmatchedNotification
import com.example.data.api.NovanetUser
import com.example.service.DanaNotificationParser
import com.example.ui.theme.LiveStatusBadge
import com.example.ui.theme.NovanetAccent
import com.example.ui.theme.NovanetAccentInk
import com.example.ui.theme.NovanetAccentSoft
import com.example.ui.theme.NovanetBg1
import com.example.ui.theme.NovanetBg2
import com.example.ui.theme.NovanetDanger
import com.example.ui.theme.NovanetDangerSoft
import com.example.ui.theme.NovanetLine
import com.example.ui.theme.NovanetSuccess
import com.example.ui.theme.NovanetSuccessSoft
import com.example.ui.theme.NovanetText1
import com.example.ui.theme.NovanetText2
import com.example.ui.theme.NovanetText3
import com.example.ui.theme.NovanetWarning
import com.example.ui.theme.NovanetWarningSoft
import com.example.ui.theme.PulseDot
import com.example.ui.theme.novanetBlueprintBackground
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.floor
import kotlin.math.log10

// ============================================================
// KONFIGURASI EXPIRY
// ============================================================
/**
 * Batas waktu (menit) sebelum transaksi pending dianggap EXPIRED
 * di sisi client. Server novanet.uno kadang belum update status
 * ini secara otomatis, jadi kita hitung manual berdasarkan
 * `created_at` transaksi.
 */
private const val PENDING_EXPIRY_MINUTES = 15L

// Status-status internal untuk grouping di UI
private const val STATUS_PAID = "paid"
private const val STATUS_PENDING = "pending"
private const val STATUS_EXPIRED = "expired"
private const val STATUS_CANCELLED = "cancelled"

// Jumlah maksimum titik (transaksi) yang ditampilkan di chart tren volume,
// supaya tetap enak dibaca di layar kecil walau riwayat transaksinya banyak.
private const val MAX_TREND_POINTS = 12

/**
 * Deteksi status "batal" dari server — beberapa backend pakai
 * variasi penulisan yang berbeda.
 */
private fun isCancelledStatus(raw: String): Boolean {
    val l = raw.lowercase().trim()
    return l == "cancelled" || l == "canceled" || l == "cancel" || l == "batal"
}

/**
 * Titik data volume transaksi untuk chart tren — SATU titik = SATU
 * transaksi (bukan agregat harian), nilainya adalah NOMINAL transaksi
 * tersebut (Rp), bukan jumlah/count. Cuma salah satu dari lunas/batal/
 * expired yang terisi (sesuai status transaksi itu), dua lainnya 0.
 */
private data class VolumePoint(
    val label: String,   // "20 Sep 14:32"
    val lunas: Long,
    val batal: Long,
    val expired: Long
)

/**
 * Pembulatan "cantik" untuk skala Y chart nominal Rupiah — mencari
 * kelipatan bulat terdekat di atas nilai (mis. 1, 2, 5, 10 x 10^n) supaya
 * skala sumbu Y enak dibaca di rentang berapa pun (ratusan s/d jutaan).
 */
private fun niceCeilAmount(v: Long): Long {
    if (v <= 0L) return 1L
    val exponent = floor(log10(v.toDouble())).toInt()
    val magnitude = Math.pow(10.0, exponent.toDouble())
    val residual = v / magnitude
    val niceResidual = when {
        residual <= 1.0 -> 1.0
        residual <= 2.0 -> 2.0
        residual <= 5.0 -> 5.0
        else -> 10.0
    }
    return (niceResidual * magnitude).toLong().coerceAtLeast(1L)
}

// ============================================================
// SCREEN UTAMA
// ============================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    user: NovanetUser?,
    stats: NovanetStats,
    serverTransactions: List<NovanetApiTransaction>,
    unmatchedNotifications: List<NovanetUnmatchedNotification> = emptyList(),
    isPermissionGranted: Boolean,
    isServiceConnected: Boolean,
    isRefreshing: Boolean = false,
    onRefresh: () -> Unit = {},
    sendingTestPaidIds: Set<String> = emptySet(),
    onMarkPaidTest: (String) -> Unit = {},
    onDismissUnmatched: (String) -> Unit = {},
    updateState: UpdateState = UpdateState.Idle,
    onStartUpdate: () -> Unit = {},
    onOpenInstallSettings: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val listenerActive = isPermissionGranted && isServiceConnected
    var selectedFilter by remember { mutableStateOf("Semua") }
    var showExpiredSheet by remember { mutableStateOf(false) }

    // Hitung ulang status tiap transaksi (handle pending yang sudah expired)
    // serta hitung ulang statistik pending supaya konsisten dengan list.
    val now = remember(serverTransactions) { System.currentTimeMillis() }

    val enrichedTransactions = remember(serverTransactions, now) {
        serverTransactions.map { tx -> tx to computeEffectiveStatus(tx, now) }
    }

    // Statistik yang sudah "dibersihkan": pending yang expired dipindah ke expired.
    //
    // PENTING: stats.expired (dari server) SUDAH menghitung transaksi yang raw
    // status-nya memang "expired". Kalau di sini kita tambahkan expiredCount =
    // SEMUA transaksi dengan status efektif "expired" (termasuk yang raw-nya
    // sudah "expired" dari server), transaksi yang sama itu kehitung DUA KALI
    // (sekali dari stats.expired, sekali lagi dari expiredCount) — 1 transaksi
    // expired kebaca jadi 2. Makanya di sini kita cuma tambahkan transaksi yang
    // raw status-nya MASIH "pending" di server tapi sudah lewat waktu menurut
    // jam HP (server belum sempat sweep) — bukan yang raw-nya sudah "expired".
    val effectiveStats = remember(enrichedTransactions, stats) {
        val newlyExpiredCount = enrichedTransactions.count { (tx, effectiveStatus) ->
            effectiveStatus == STATUS_EXPIRED && tx.status.lowercase().trim() == STATUS_PENDING
        }
        val activePending = enrichedTransactions.count { it.second == STATUS_PENDING }
        stats.copy(
            pending = activePending,
            expired = stats.expired + newlyExpiredCount
        )
    }

    val expiredTransactions = remember(enrichedTransactions) {
        enrichedTransactions
            .filter { it.second == STATUS_EXPIRED }
            .sortedByDescending { parseIsoTimestamp(it.first.createdAt) ?: 0L }
    }

    // ============================================================
    // Volume transaksi: SATU titik chart = SATU transaksi, nilainya
    // nominal (Rp) transaksi itu sendiri — bukan jumlah/count per hari.
    // Satu transaksi pun tetap tergambar (naik tajam lalu turun), tinggi
    // tiap titik mengikuti besar-kecilnya nominal (mis. 100rb vs 50rb
    // beda tinggi). Ambil MAX_TREND_POINTS transaksi terakhir
    // (lunas/batal/expired) supaya tetap enak dibaca di layar kecil.
    // Pending tidak dihitung karena belum final.
    // ============================================================
    val volumeTrend = remember(enrichedTransactions) {
        val deviceTz = TimeZone.getDefault()
        val fmt = SimpleDateFormat("dd MMM HH:mm", Locale("id", "ID")).apply { timeZone = deviceTz }

        enrichedTransactions
            .filter {
                it.second == STATUS_PAID ||
                it.second == STATUS_EXPIRED ||
                it.second == STATUS_CANCELLED
            }
            .sortedBy { parseIsoTimestamp(it.first.updatedAt ?: it.first.createdAt) ?: 0L }
            .takeLast(MAX_TREND_POINTS)
            .map { (tx, status) ->
                val ts = parseIsoTimestamp(tx.updatedAt ?: tx.createdAt)
                val amount = tx.uniqueAmount
                VolumePoint(
                    label   = if (ts != null) fmt.format(Date(ts)) else "-",
                    lunas   = if (status == STATUS_PAID) amount else 0L,
                    batal   = if (status == STATUS_CANCELLED) amount else 0L,
                    expired = if (status == STATUS_EXPIRED) amount else 0L
                )
            }
    }

    val filteredServer = remember(enrichedTransactions, selectedFilter) {
        when (selectedFilter) {
            "Semua" -> enrichedTransactions
            "Lunas" -> enrichedTransactions.filter { it.second == STATUS_PAID }
            "Pending" -> enrichedTransactions.filter { it.second == STATUS_PENDING }
            "Expired" -> enrichedTransactions.filter { it.second == STATUS_EXPIRED }
            "Notifikasi" -> emptyList()
            else -> emptyList()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .novanetBlueprintBackground()
    ) {

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                DashboardHeader(
                    isLive = listenerActive,
                    isRefreshing = isRefreshing,
                    onRefresh = onRefresh
                )
            }

            // Banner update aplikasi (tombol Update → mengunduh → memasang).
            if (updateState.showsBanner) {
                item(key = "update_banner") {
                    UpdateBanner(
                        state = updateState,
                        onStartUpdate = onStartUpdate,
                        onOpenInstallSettings = onOpenInstallSettings
                    )
                }
            }

            // Banner cuma muncul saat listener mati (butuh izin/aktivasi).
            // Kalau sudah aktif, cukup indikator ON di header — banner hijau dihapus.
            if (!listenerActive) {
                item {
                    ListenerStatusRow()
                }
            }

            item {
                PaymentSummaryCard(
                    stats = effectiveStats,
                    volumeTrend = volumeTrend,
                    onViewExpired = { showExpiredSheet = true }
                )
            }

            item {
                FilterTabs(
                    selectedFilter = selectedFilter,
                    onSelectFilter = { selectedFilter = it },
                    totalCount = filteredServer.size
                )
            }

            if (selectedFilter == "Notifikasi") {
                if (unmatchedNotifications.isEmpty()) {
                    item { EmptyTransactionState() }
                } else {
                    items(unmatchedNotifications, key = { it.id }) { notification ->
                        UnmatchedNotificationRow(
                            notification = notification,
                            onDismiss = { onDismissUnmatched(notification.id) }
                        )
                    }
                }
            } else if (filteredServer.isEmpty()) {
                item { EmptyTransactionState() }
            } else {
                items(filteredServer, key = { it.first.id }) { (tx, effectiveStatus) ->
                    ServerTransactionRow(
                        tx = tx,
                        effectiveStatus = effectiveStatus,
                        isSendingTestPaid = tx.id in sendingTestPaidIds,
                        onMarkPaidTest = { onMarkPaidTest(tx.id) }
                    )
                }
            }

            item {
                Spacer(Modifier.height(80.dp))
            }
        }

        if (showExpiredSheet) {
            val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            ModalBottomSheet(
                onDismissRequest = { showExpiredSheet = false },
                sheetState = sheetState,
                containerColor = NovanetBg1,
                contentColor = NovanetText1
            ) {
                ExpiredListSheetContent(
                    expiredTransactions = expiredTransactions,
                    onClose = { showExpiredSheet = false }
                )
            }
        }
    }
}

@Composable
private fun UnmatchedNotificationRow(
    notification: NovanetUnmatchedNotification,
    onDismiss: () -> Unit = {}
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = NovanetWarningSoft,
        border = BorderStroke(1.dp, NovanetWarning)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Notifikasi perlu dicek manual", color = NovanetWarning, fontWeight = FontWeight.Bold)
                TextButton(onClick = onDismiss) {
                    Text("Buang", color = NovanetWarning, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Text("Nominal: ${DanaNotificationParser.formatRupiah(notification.amount)}", color = NovanetText1, fontWeight = FontWeight.SemiBold)
            notification.rawText?.takeIf { it.isNotBlank() }?.let {
                Text(it, color = NovanetText2, fontSize = 12.sp, maxLines = 2)
            }
            notification.closestPendingDiff?.let {
                Text("Selisih dari transaksi terdekat: ${DanaNotificationParser.formatRupiah(it)}", color = NovanetText3, fontSize = 11.sp)
            }
        }
    }
}

// ============================================================
// HEADER + STATUS
// ============================================================

@Composable
private fun DashboardHeader(
    isLive: Boolean,
    isRefreshing: Boolean,
    onRefresh: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(NovanetBg1)
                    .border(1.dp, NovanetLine, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.novanet_app_logo),
                    contentDescription = "Novanet Gateway Logo",
                    modifier = Modifier.size(30.dp)
                )
            }

            Spacer(Modifier.width(12.dp))

            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Novanet Gateway",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = NovanetText1
                    )
                    Spacer(Modifier.width(8.dp))
                    LiveStatusBadge(isLive = isLive)
                }
                Text(
                    text = "Otomasi Pembayaran QRIS & DANA",
                    fontSize = 11.sp,
                    color = NovanetText2
                )
            }
        }

        IconButton(
            onClick = onRefresh,
            enabled = !isRefreshing,
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(NovanetBg1)
                .border(1.dp, NovanetLine, RoundedCornerShape(8.dp))
        ) {
            if (isRefreshing) {
                val refreshTransition = rememberInfiniteTransition(label = "dashboard_refresh")
                val refreshRotation by refreshTransition.animateFloat(
                    initialValue = 0f,
                    targetValue = 360f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(800, easing = LinearEasing),
                        repeatMode = RepeatMode.Restart
                    ),
                    label = "dashboard_refresh_rotation"
                )
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Menyegarkan data",
                    tint = NovanetAccent,
                    modifier = Modifier
                        .size(20.dp)
                        .rotate(refreshRotation)
                )
            } else {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Segarkan data",
                    tint = NovanetText1,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun ListenerStatusRow() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(NovanetDangerSoft)
            .border(1.dp, NovanetDanger, RoundedCornerShape(6.dp))
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PulseDot(color = NovanetDanger, size = 7.dp)
        Spacer(Modifier.width(6.dp))
        Text(
            text = "Listener Terputus · Butuh Izin Notifikasi",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = NovanetDanger
        )
    }
}

// ============================================================
// CHART TREN VOLUME TRANSAKSI (Lunas / Batal / Expired)
// ============================================================
@Composable
private fun VolumeTrendChart(
    points: List<VolumePoint>,
    modifier: Modifier = Modifier
) {
    // Empty state — belum ada transaksi sama sekali
    if (points.isEmpty()) {
        Row(
            modifier = modifier
                .fillMaxWidth()
                .height(120.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.ShowChart,
                contentDescription = null,
                tint = NovanetText3,
                modifier = Modifier.size(14.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = "Grafik muncul setelah ada transaksi lunas, batal, atau expired",
                fontSize = 10.sp,
                color = NovanetText3
            )
        }
        return
    }

    // Satu transaksi saja: tambahkan titik nol di kiri-kanan agar garis
    // naik tajam lalu turun (bentuk "gunung" patah-patah), bukan garis datar.
    val zeroPoint = VolumePoint(label = "", lunas = 0L, batal = 0L, expired = 0L)
    val chartPoints = if (points.size == 1) listOf(zeroPoint, points.first(), zeroPoint) else points

    // ==== AUTO SCALE Y (lebih pintar) ====
    val maxVal = chartPoints.maxOf { maxOf(it.lunas, it.batal, it.expired) }.coerceAtLeast(1L)
    val yMax   = niceCeilAmount(maxVal)

    val colorLunas   = NovanetSuccess
    val colorBatal   = NovanetDanger
    val colorExpired = NovanetWarning

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(128.dp)
    ) {
        val stepX     = size.width / (chartPoints.size - 1).coerceAtLeast(1)
        val padTop    = 12f
        val padBottom = 14f
        val chartH    = size.height - padTop - padBottom

        fun yFor(v: Long): Float =
            padTop + chartH * (1f - v.toFloat() / yMax.toFloat())

        val lunasPts   = chartPoints.mapIndexed { i, p -> Offset(i * stepX, yFor(p.lunas)) }
        val batalPts   = chartPoints.mapIndexed { i, p -> Offset(i * stepX, yFor(p.batal)) }
        val expiredPts = chartPoints.mapIndexed { i, p -> Offset(i * stepX, yFor(p.expired)) }

        // Path PATAH-PATAH (linear) — tajam, modern, bukan bergelombang
        fun sharpPath(pts: List<Offset>): Path {
            val path = Path()
            if (pts.isEmpty()) return path
            path.moveTo(pts.first().x, pts.first().y)
            for (i in 1 until pts.size) {
                path.lineTo(pts[i].x, pts[i].y)
            }
            return path
        }

        // ---------- GRID HALUS (horizontal) ----------
        val gridColor = NovanetLine.copy(alpha = 0.45f)
        for (g in 1..3) {
            val gy = padTop + chartH * (g / 4f)
            drawLine(
                color = gridColor,
                start = Offset(0f, gy),
                end = Offset(size.width, gy),
                strokeWidth = 1f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
            )
        }

        // ---------- AREA FILL (Lunas) — versi patah-patah ----------
        val areaPath = sharpPath(lunasPts).apply {
            lineTo(lunasPts.last().x, size.height)
            lineTo(lunasPts.first().x, size.height)
            close()
        }
        drawPath(
            path = areaPath,
            brush = Brush.verticalGradient(
                colors = listOf(
                    colorLunas.copy(alpha = 0.28f),
                    colorLunas.copy(alpha = 0.06f),
                    Color.Transparent
                )
            )
        )

        // ---------- GARIS PATAH-PATAH ----------
        fun drawSeries(pts: List<Offset>, color: Color, width: Float, dash: FloatArray?) {
            drawPath(
                path = sharpPath(pts),
                color = color,
                style = Stroke(
                    width = width,
                    cap = StrokeCap.Butt,          // ujung tajam
                    join = StrokeJoin.Miter,       // sudut patah-patah
                    pathEffect = dash?.let { PathEffect.dashPathEffect(it, 0f) }
                )
            )
        }

        // Lunas   : solid, tebal
        drawSeries(lunasPts, colorLunas, 3.5f, null)
        // Batal   : dotted
        drawSeries(batalPts, colorBatal, 2.5f, floatArrayOf(5f, 5f))
        // Expired : dashed
        drawSeries(expiredPts, colorExpired, 2.8f, floatArrayOf(9f, 5f))

        // ---------- TITIK DATA (lebih premium) ----------
        listOf(
            Triple(lunasPts, colorLunas, chartPoints.map { it.lunas }),
            Triple(batalPts, colorBatal, chartPoints.map { it.batal }),
            Triple(expiredPts, colorExpired, chartPoints.map { it.expired })
        ).forEach { (pts, color, values) ->
            pts.forEachIndexed { i, pt ->
                if (values[i] > 0L) {
                    // Outer glow
                    drawCircle(color = color.copy(alpha = 0.25f), radius = 7.5f, center = pt)
                    // Main dot
                    drawCircle(color = color, radius = 4.2f, center = pt)
                    // Inner core
                    drawCircle(color = NovanetBg1, radius = 1.8f, center = pt)
                }
            }
        }
    }
}

// ============================================================
// KARTU RINGKASAN PEMBAYARAN
// ============================================================
@Composable
private fun PaymentSummaryCard(
    stats: NovanetStats,
    volumeTrend: List<VolumePoint>,
    onViewExpired: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = NovanetBg1,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, NovanetLine, RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "RINGKASAN PEMBAYARAN",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = NovanetText2,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 10.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StatMiniBox(
                    label = "Lunas",
                    count = stats.paid.toString(),
                    color = NovanetSuccess,
                    modifier = Modifier.weight(1f)
                )
                StatMiniBox(
                    label = "Pending",
                    count = stats.pending.toString(),
                    color = NovanetWarning,
                    modifier = Modifier.weight(1f)
                )
                StatMiniBox(
                    label = "Expired",
                    count = stats.expired.toString(),
                    color = NovanetText2,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(NovanetBg2)
                    .border(1.dp, NovanetLine, RoundedCornerShape(6.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(NovanetSuccessSoft)
                        .border(1.dp, NovanetSuccess, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Wallet,
                        contentDescription = null,
                        tint = NovanetSuccess,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(Modifier.width(12.dp))

                Column {
                    Text(
                        text = "Total Pendapatan (Transaksi Lunas)",
                        fontSize = 10.sp,
                        color = NovanetText2
                    )
                    Text(
                        text = DanaNotificationParser.formatRupiah(stats.revenue),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = NovanetText1
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // ================== HEADER CHART ==================
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TREN VOLUME TRANSAKSI",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = NovanetText3,
                    letterSpacing = 1.sp
                )
                val maxTx = volumeTrend
                    .maxOfOrNull { maxOf(it.lunas, it.batal, it.expired) } ?: 0L
                if (maxTx > 0L) {
                    Text(
                        text = "Tertinggi ${DanaNotificationParser.formatRupiah(maxTx)}",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NovanetText3
                    )
                }
            }

            Spacer(Modifier.height(6.dp))

            // ================== CHART ==================
            VolumeTrendChart(points = volumeTrend)

            // ================== LABEL TANGGAL/JAM (X-AXIS) ==================
            // Karena sekarang bisa sampai MAX_TREND_POINTS (per transaksi,
            // bukan per hari), label "dd MMM HH:mm" penuh di tiap titik akan
            // numpuk di layar sempit. Tampilkan sebagian saja (jarang-jarang)
            // supaya tetap rapi, tapi jumlah kolom tetap sama dengan jumlah
            // titik di grafik supaya posisinya tetap sejajar.
            if (volumeTrend.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                val labelStep = when {
                    volumeTrend.size <= 4 -> 1
                    volumeTrend.size <= 8 -> 2
                    else -> 3
                }
                Row(modifier = Modifier.fillMaxWidth()) {
                    volumeTrend.forEachIndexed { idx, point ->
                        val showLabel = idx == 0 || idx == volumeTrend.lastIndex || idx % labelStep == 0
                        Text(
                            text = if (showLabel) point.label else "",
                            fontSize = 8.sp,
                            color = NovanetText3,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // ================== LEGEND ==================
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                LegendDot("Lunas", NovanetSuccess)
                LegendDot("Batal", NovanetDanger)
                LegendDot("Expired", NovanetWarning)
            }

            // Tombol lihat daftar kedaluwarsa — cuma muncul kalau ada datanya
            if (stats.expired > 0) {
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onViewExpired,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = NovanetText1,
                        containerColor = NovanetBg2
                    ),
                    border = BorderStroke(1.dp, NovanetLine),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp),
                        tint = NovanetText2
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "Lihat Daftar Kedaluwarsa (${stats.expired})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

// Helper legend kecil
@Composable
private fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 9.sp,
            color = NovanetText2,
            fontWeight = FontWeight.SemiBold
        )
    }
}

// ============================================================
// BOTTOM SHEET — DAFTAR TRANSAKSI KEDALUWARSA
// ============================================================
@Composable
private fun ExpiredListSheetContent(
    expiredTransactions: List<Pair<NovanetApiTransaction, String>>,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 520.dp)
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Transaksi Kedaluwarsa",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = NovanetText1
                )
                Text(
                    text = "${expiredTransactions.size} transaksi tidak dibayar sebelum batas waktu",
                    fontSize = 11.sp,
                    color = NovanetText2
                )
            }
            IconButton(onClick = onClose) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Tutup",
                    tint = NovanetText2
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        if (expiredTransactions.isEmpty()) {
            EmptyTransactionState()
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(expiredTransactions, key = { it.first.id }) { (tx, status) ->
                    ServerTransactionRow(
                        tx = tx,
                        effectiveStatus = status,
                        isSendingTestPaid = false,
                        onMarkPaidTest = {}
                    )
                }
            }
        }
    }
}

// ============================================================
// FILTER & LIST TRANSAKSI
// ============================================================

@Composable
private fun FilterTabs(
    selectedFilter: String,
    onSelectFilter: (String) -> Unit,
    totalCount: Int
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "DAFTAR TRANSAKSI",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp,
                color = NovanetText2
            )
            Text(
                text = "$totalCount transaksi",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = NovanetText3
            )
        }

        Spacer(Modifier.height(8.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            val filterOptions = listOf("Semua", "Lunas", "Pending", "Expired", "Notifikasi")
            items(filterOptions) { opt ->
                FilterChip(
                    selected = selectedFilter == opt,
                    onClick = { onSelectFilter(opt) },
                    label = { Text(opt, fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NovanetAccent,
                        selectedLabelColor = NovanetAccentInk,
                        containerColor = NovanetBg1,
                        labelColor = NovanetText2
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (selectedFilter == opt) NovanetAccent else NovanetLine
                    ),
                    shape = RoundedCornerShape(6.dp)
                )
            }
        }
    }
}

@Composable
private fun EmptyTransactionState() {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = NovanetBg1,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, NovanetLine, RoundedCornerShape(6.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.HourglassEmpty,
                contentDescription = null,
                tint = NovanetText3,
                modifier = Modifier.size(32.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Belum Ada Transaksi",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = NovanetText2
            )
            Text(
                text = "Transaksi yang masuk lewat notifikasi DANA atau QRIS akan muncul di sini.",
                fontSize = 11.sp,
                color = NovanetText3,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun StatMiniBox(
    label: String,
    count: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = NovanetBg2,
        modifier = modifier.border(1.dp, NovanetLine, RoundedCornerShape(6.dp))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = count,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = color
            )
            Text(
                text = label,
                fontSize = 10.sp,
                color = NovanetText2,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
private fun ServerTransactionRow(
    tx: NovanetApiTransaction,
    effectiveStatus: String,
    isSendingTestPaid: Boolean,
    onMarkPaidTest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isExpired = effectiveStatus == STATUS_EXPIRED
    val isPending = effectiveStatus == STATUS_PENDING
    val isCancelled = effectiveStatus == STATUS_CANCELLED

    // Warna & label dinamis sesuai effective status
    val (statusColor, statusBg, statusText) = when (effectiveStatus) {
        STATUS_PAID -> Triple(NovanetSuccess, NovanetSuccessSoft, "LUNAS")
        STATUS_PENDING -> Triple(NovanetWarning, NovanetWarningSoft, "PENDING")
        STATUS_EXPIRED -> Triple(NovanetText2, NovanetBg2, "KEDALUWARSA")
        STATUS_CANCELLED -> Triple(NovanetDanger, NovanetDangerSoft, "BATAL")
        else -> Triple(NovanetText2, NovanetBg2, effectiveStatus.uppercase())
    }

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = NovanetBg1,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, NovanetLine, RoundedCornerShape(8.dp))
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            // Bar aksen warna status di sisi kiri
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .fillMaxHeight()
                    .background(
                        statusColor.copy(
                            alpha = if (isExpired || isCancelled) 0.35f else 0.9f
                        )
                    )
            )

            Row(
                modifier = Modifier
                    .weight(1f)
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(statusBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Payments,
                                contentDescription = null,
                                tint = statusColor,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = tx.id.take(14) + if (tx.id.length > 14) "…" else "",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            color = NovanetText1
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = statusText,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = statusColor
                        )
                        Text(
                            text = " • ${
                                formatTransactionDate(
                                    if (effectiveStatus == STATUS_PAID)
                                        tx.updatedAt ?: tx.createdAt
                                    else tx.createdAt
                                )
                            }",
                            fontSize = 10.sp,
                            color = NovanetText3
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = DanaNotificationParser.formatRupiah(tx.uniqueAmount),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (isExpired || isCancelled) NovanetText3 else NovanetText1
                    )
                    // Tombol "Tandai Lunas" cuma muncul untuk pending (bukan expired/batal)
                    if (isPending) {
                        Spacer(Modifier.height(6.dp))
                        OutlinedButton(
                            onClick = onMarkPaidTest,
                            enabled = !isSendingTestPaid,
                            modifier = Modifier.height(30.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = NovanetAccent,
                                containerColor = NovanetAccentSoft
                            ),
                            border = BorderStroke(1.dp, NovanetAccent),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            if (isSendingTestPaid) {
                                CircularProgressIndicator(
                                    color = NovanetAccent,
                                    modifier = Modifier.size(10.dp),
                                    strokeWidth = 1.5.dp
                                )
                            } else {
                                Icon(
                                    Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                            Spacer(Modifier.width(4.dp))
                            Text(
                                "Tandai Lunas",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

// ============================================================
// LOGIKA STATUS EFFECTIVE (fix pending yang sudah expired)
// ============================================================

/**
 * Hitung status efektif transaksi dari sisi client.
 *
 * Kasus utama yang diselesaikan:
 * Server kadang masih kirim status "pending" walau transaksi
 * sudah lewat TTL (mis. cron job update status di backend belum
 * jalan / gagal). Function ini otomatis mengubah status jadi
 * "expired" kalau:
 *   - Status dari server = "pending"
 *   - Dan `created_at` lebih tua dari PENDING_EXPIRY_MINUTES
 */
private fun computeEffectiveStatus(
    tx: NovanetApiTransaction,
    nowMs: Long
): String {
    val raw = tx.status.lowercase().trim()

    // 1. Status final (paid / lunas / success)
    if (raw == "paid" || raw == "lunas" || raw == "success") {
        return STATUS_PAID
    }

    // 2. Status expired dari server
    if (raw == "expired" || raw == "kadaluarsa" || raw == "expire") {
        return STATUS_EXPIRED
    }

    // 3. Status batal dari server (variasi penulisan)
    if (isCancelledStatus(raw)) {
        return STATUS_CANCELLED
    }

    // 4. Kalau status server "pending", cek manual berdasar created_at
    if (raw == "pending") {
        val createdMs = parseIsoTimestamp(tx.createdAt)
        if (createdMs != null) {
            val ageMinutes = (nowMs - createdMs) / 60_000L
            if (ageMinutes >= PENDING_EXPIRY_MINUTES) {
                return STATUS_EXPIRED
            }
        }
        return STATUS_PENDING
    }

    // 5. Status lain — pakai apa adanya lowercase
    return raw
}

/**
 * Parse string ISO-8601 dari server ke epoch millis.
 */
private fun parseIsoTimestamp(raw: String?): Long? {
    if (raw.isNullOrBlank()) return null
    val cleaned = raw.trim()
    val patterns = listOf(
        "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'" to TimeZone.getTimeZone("UTC"),
        "yyyy-MM-dd'T'HH:mm:ss'Z'" to TimeZone.getTimeZone("UTC"),
        "yyyy-MM-dd'T'HH:mm:ss" to TimeZone.getTimeZone("UTC"),
        "yyyy-MM-dd HH:mm:ss" to TimeZone.getTimeZone("UTC")
    )
    for ((pattern, tz) in patterns) {
        try {
            val sdf = SimpleDateFormat(pattern, Locale.US).apply { timeZone = tz }
            val date = sdf.parse(cleaned) ?: continue
            return date.time
        } catch (_: Exception) {
            // coba pattern berikutnya
        }
    }
    return null
}

// ============================================================
// HELPER FORMAT
// ============================================================

private fun formatTransactionDate(rawDate: String?): String {
    val ms = parseIsoTimestamp(rawDate) ?: return "-"
    return try {
        val targetFormat = SimpleDateFormat("EEEE, dd MMMM • HH:mm", Locale("id", "ID"))
        targetFormat.format(Date(ms))
    } catch (_: Exception) {
        rawDate ?: "-"
    }
}