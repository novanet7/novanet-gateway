package com.example.ui.theme

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Titik berdenyut (pulse) ala indikator "live" — dipakai untuk menandakan
 * koneksi realtime (FCM push / WebSocket) yang masih aktif, tanpa perlu
 * refresh manual. Cincin luar membesar & memudar terus-menerus, titik inti
 * tetap solid supaya kebaca sebagai sinyal yang "hidup".
 */
@Composable
fun PulseDot(color: Color, size: Dp = 8.dp, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "novanet_pulse")
    val ringScale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 2.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "novanet_pulse_scale"
    )
    val ringAlpha by transition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "novanet_pulse_alpha"
    )
    Box(
        modifier = modifier.size(size * 2.6f),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .size(size)
                .scale(ringScale)
                .clip(CircleShape)
                .background(color.copy(alpha = ringAlpha))
        )
        Box(
            Modifier
                .size(size)
                .clip(CircleShape)
                .background(color)
        )
    }
}

/**
 * Indikator hidup/mati listener: "ON" (hijau, berdenyut) atau "OFF"
 * (merah). Dipakai di header Dashboard untuk memastikan aplikasi benar-benar
 * aktif menangkap notifikasi pembayaran.
 */
@Composable
fun LiveStatusBadge(isLive: Boolean, modifier: Modifier = Modifier) {
    val color = if (isLive) NovanetSuccess else NovanetDanger
    val bg = if (isLive) NovanetSuccessSoft else NovanetDangerSoft
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .border(1.dp, color.copy(alpha = 0.55f), RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PulseDot(color = color, size = 6.dp)
        Spacer(Modifier.width(4.dp))
        Text(
            text = if (isLive) "ON" else "OFF",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp,
            color = color
        )
    }
}

/**
 * Border neon yang berdenyut pelan (glow in-out) + shadow warna senada.
 * Dipakai buat "membingkai" kartu penting (mis. kartu ringkasan pembayaran)
 * supaya kelihatan lebih hidup/canggih dibanding border statis biasa.
 */
fun Modifier.novanetGlowBorder(
    color: Color,
    cornerRadius: Dp = 14.dp,
    maxAlpha: Float = 0.55f
): Modifier = composed {
    val transition = rememberInfiniteTransition(label = "novanet_glow_border")
    val alpha by transition.animateFloat(
        initialValue = maxAlpha * 0.45f,
        targetValue = maxAlpha,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            // Restart avoids the apparent pause that can occur with a
            // reverse cycle when the composable is recomposed or resumed.
            repeatMode = RepeatMode.Restart
        ),
        label = "novanet_glow_alpha"
    )
    this
        .shadow(
            elevation = 14.dp,
            shape = RoundedCornerShape(cornerRadius),
            ambientColor = color.copy(alpha = alpha),
            spotColor = color.copy(alpha = alpha)
        )
        .border(1.dp, color.copy(alpha = alpha), RoundedCornerShape(cornerRadius))
}
