package com.example.ui.theme

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import android.os.Process
import android.os.SystemClock
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import androidx.compose.runtime.LaunchedEffect
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * Sampler ringan buat "beban CPU aplikasi ini" tanpa root/izin khusus.
 *
 * CATATAN JUJUR soal keterbatasannya: sejak Android 8 (Oreo), aplikasi biasa
 * TIDAK BISA lagi membaca /proc/[pid]/stat milik proses lain atau bahkan
 * angka CPU sistem-wide yang presisi (dibatasi hidepid oleh kernel demi
 * privasi). Yang MASIH bisa diakses tanpa root adalah waktu CPU milik
 * proses aplikasi ITU SENDIRI lewat Process.getElapsedCpuTime() (total
 * milidetik CPU yang sudah dipakai proses ini sejak dia mulai). Dengan
 * mengambil selisih angka itu antar-interval dan membaginya dengan waktu
 * dinding (wall time) yang berlalu, didapat estimasi "seberapa sibuk"
 * proses Novanet ini — bukan CPU keseluruhan HP, tapi CPU yang dipakai
 * APK ini saja. Ini pendekatan yang sama dipakai banyak app monitoring
 * pihak ketiga yang tidak minta akses root.
 */
private class CpuSampler {
    private var lastCpuTimeMs = Process.getElapsedCpuTime()
    private var lastWallTimeMs = SystemClock.elapsedRealtime()

    fun sample(): Float {
        val cpuNow = Process.getElapsedCpuTime()
        val wallNow = SystemClock.elapsedRealtime()
        val cpuDelta = (cpuNow - lastCpuTimeMs).coerceAtLeast(0L)
        val wallDelta = (wallNow - lastWallTimeMs).coerceAtLeast(1L)
        lastCpuTimeMs = cpuNow
        lastWallTimeMs = wallNow

        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        // Dinormalisasi ke jumlah core supaya skalanya 0-100% yang wajar
        // (proses multi-thread di HP octa-core bisa "pakai" >100% dari 1 core).
        val rawPercent = (cpuDelta.toFloat() / wallDelta.toFloat()) * 100f
        return (rawPercent / cores).coerceIn(0f, 100f)
    }
}

private fun formatUptime(millis: Long): String {
    if (millis < 0) return "00:00:00"
    val totalSeconds = millis / 1000
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return "%02d:%02d:%02d".format(h, m, s)
}

private fun loadColor(percent: Float): Color = when {
    percent < 30f -> NovanetSuccess
    percent < 70f -> NovanetWarning
    else -> NovanetDanger
}

/**
 * Panel "terminal" + gelombang real-time buat halaman Pengaturan: berapa
 * lama layanan 24/7 sudah berjalan, perkiraan beban CPU aplikasi, dan
 * pemakaian memori heap - dikemas dengan tampilan monospace bergaya
 * konsol supaya senada dengan estetika blueprint/terminal Novanet yang
 * sudah ada (novanetBlueprintBackground, LiveStatusBadge, dsb).
 */
@Composable
fun SystemMonitorPanel(
    isServiceRunning: Boolean,
    serviceStartElapsedRealtime: Long?,
    modifier: Modifier = Modifier
) {
    val cpuSampler = remember { CpuSampler() }
    var cpuLoad by remember { mutableFloatStateOf(0f) }
    var usedMemMb by remember { mutableLongStateOf(0L) }
    var maxMemMb by remember { mutableLongStateOf(0L) }
    var nowElapsed by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    var tickCount by remember { mutableLongStateOf(0L) }

    // Loop sampling tiap 1 detik selama Composable ini ada di layar - berhenti
    // sendiri kalau pengguna pindah tab/tutup halaman (mengikuti lifecycle Compose).
    LaunchedEffect(Unit) {
        while (isActive) {
            cpuLoad = cpuSampler.sample()
            val runtime = Runtime.getRuntime()
            usedMemMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
            maxMemMb = runtime.maxMemory() / (1024 * 1024)
            nowElapsed = SystemClock.elapsedRealtime()
            tickCount++
            delay(1000)
        }
    }

    val uptimeMs = if (isServiceRunning && serviceStartElapsedRealtime != null) {
        (nowElapsed - serviceStartElapsedRealtime).coerceAtLeast(0L)
    } else null

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "MONITOR SISTEM",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = NovanetText2
            )
            LiveStatusBadge(isLive = isServiceRunning)
        }

        Spacer(Modifier.height(10.dp))

        // ── Terminal info block ──────────────────────────
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(NovanetBg0)
                .border(1.dp, NovanetLine, RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            TerminalLine(
                label = "uptime",
                value = uptimeMs?.let { formatUptime(it) } ?: "--:--:--",
                valueColor = if (isServiceRunning) NovanetSuccess else NovanetText3
            )
            TerminalLine(
                label = "cpu_load",
                value = if (isServiceRunning) "${cpuLoad.toInt()}%" else "0%",
                valueColor = if (isServiceRunning) loadColor(cpuLoad) else NovanetText3
            )
            TerminalLine(
                label = "memory",
                value = "$usedMemMb MB / $maxMemMb MB",
                valueColor = NovanetInfo
            )
            TerminalLine(
                label = "wakelock",
                value = if (isServiceRunning) "LOCKED" else "RELEASED",
                valueColor = if (isServiceRunning) NovanetSuccess else NovanetText3
            )
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(
                    text = "> ",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = NovanetText3
                )
                Text(
                    text = "_",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = NovanetAccent.copy(alpha = blinkAlpha(tickCount))
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        // ── Gelombang aktivitas real-time ────────────────
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "AKTIVITAS REAL-TIME",
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 0.5.sp,
                color = NovanetText3
            )
            Text(
                text = if (isServiceRunning) "BEBAN ${cpuLoad.toInt()}%" else "IDLE",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = if (isServiceRunning) loadColor(cpuLoad) else NovanetText3
            )
        }
        Spacer(Modifier.height(6.dp))
        CpuWaveform(
            loadPercent = if (isServiceRunning) cpuLoad else 0f,
            active = isServiceRunning,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(NovanetBg0)
                .border(1.dp, NovanetLine, RoundedCornerShape(8.dp))
        )
    }
}

@Composable
private fun TerminalLine(label: String, value: String, valueColor: Color) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "> ${label.padEnd(9, '.')}: ",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = NovanetText3
        )
        Text(
            text = value,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = valueColor
        )
    }
    Spacer(Modifier.height(2.dp))
}

@Composable
private fun blinkAlpha(tick: Long): Float {
    // Kursor berkedip sederhana mengikuti detak sampling (bukan animasi
    // terpisah) - genap nyala, ganjil redup, ala kursor terminal asli.
    return if (tick % 2L == 0L) 1f else 0.15f
}

/**
 * Garis gelombang ala osiloskop yang terus "mengalir" ke kiri, dengan
 * amplitudo & kecepatan mengikuti beban CPU (loadPercent) - makin berat
 * sistem, makin tinggi & makin cepat gelombangnya. Dipakai sebagai
 * indikator visual "sistem masih hidup & seberapa sibuk", senada dengan
 * PulseDot/LiveStatusBadge yang sudah ada di GlowComponents.kt.
 */
@Composable
fun CpuWaveform(
    loadPercent: Float,
    active: Boolean,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "novanet_cpu_wave")
    // Fase dasar terus berjalan linear supaya gelombang terlihat "mengalir";
    // kecepatannya sedikit dipercepat kalau beban tinggi (durasi lebih pendek).
    val cycleDurationMs = (2600 - (loadPercent.coerceIn(0f, 100f) * 12f)).toInt().coerceAtLeast(700)
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(cycleDurationMs, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "novanet_cpu_wave_phase"
    )

    val color = if (active) loadColor(loadPercent) else NovanetText3
    val amplitudeFraction = if (active) (0.12f + (loadPercent.coerceIn(0f, 100f) / 100f) * 0.78f) else 0.05f

    Canvas(modifier = modifier) {
        val midY = size.height / 2f
        val maxAmplitude = size.height / 2f * amplitudeFraction
        val cycles = 2.4f
        val step = min(4f, size.width / 120f).coerceAtLeast(2f)

        fun buildWavePath(amplitudeScale: Float): Path {
            val path = Path()
            var x = 0f
            var first = true
            while (x <= size.width) {
                val t = x / size.width
                val y = midY + maxAmplitude * amplitudeScale *
                    sin(t * cycles * 2 * PI.toFloat() + phase)
                if (first) {
                    path.moveTo(x, y)
                    first = false
                } else {
                    path.lineTo(x, y)
                }
                x += step
            }
            return path
        }

        // Lapisan "glow" tipis di belakang garis utama - meniru estetika
        // novanetGlowBorder tanpa perlu shadow (Canvas tidak dukung shadow biasa).
        drawPath(
            path = buildWavePath(1f),
            color = color.copy(alpha = 0.18f),
            style = Stroke(width = 7f, cap = StrokeCap.Round)
        )
        drawPath(
            path = buildWavePath(1f),
            color = color,
            style = Stroke(width = 2.4f, cap = StrokeCap.Round)
        )

        // Garis tengah putus-putus tipis sebagai acuan "baseline nol" ala osiloskop.
        drawPath(
            path = Path().apply {
                moveTo(0f, midY)
                lineTo(size.width, midY)
            },
            color = NovanetLine,
            style = Stroke(
                width = 1f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
            )
        )
    }
}
