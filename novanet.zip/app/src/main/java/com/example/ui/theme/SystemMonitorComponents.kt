package com.example.ui.theme

import android.os.Process
import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.min
import kotlin.random.Random

/**
 * Sampler ringan beban CPU proses aplikasi ini (tanpa root).
 * Process.getElapsedCpuTime() / wall time → % per core, dinormalisasi 0–100.
 */
private class CpuSampler {
    private var lastCpuTimeMs = Process.getElapsedCpuTime()
    private var lastWallTimeMs = SystemClock.elapsedRealtime()

    fun sample(): Float {
        val cpuNow = Process.getElapsedCpuTime()
        val wallNow = SystemClock.elapsedRealtime()
        val cpuDelta = (cpuNow - lastCpuTimeMs).coerceAtLeast(0L)
        val wallDelta = (wallNow - lastWallTimeMs).coerceAtLeast(1L)
        lastCpuTimeMs = cpuNow
        lastWallTimeMs = wallNow

        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val rawPercent = (cpuDelta.toFloat() / wallDelta.toFloat()) * 100f
        return (rawPercent / cores).coerceIn(0f, 100f)
    }
}

private fun formatUptime(millis: Long): String {
    if (millis < 0) return "00:00:00"
    val totalSeconds = millis / 1000
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return "%02d:%02d:%02d".format(h, m, s)
}

private fun loadColor(percent: Float): Color = when {
    percent < 30f -> NovanetSuccess
    percent < 70f -> NovanetWarning
    else -> NovanetDanger
}

/** Jumlah sampel yang ditampilkan di gelombang (scroll ke kiri). */
private const val WAVE_HISTORY = 48

/**
 * Panel terminal + gelombang real-time di halaman Pengaturan.
 * Gelombang dibangun dari riwayat sampel CPU asli (bukan sine buatan),
 * digambar dari bawah ke atas ala spektrum/terminal activity.
 */
@Composable
fun SystemMonitorPanel(
    isServiceRunning: Boolean,
    serviceStartElapsedRealtime: Long?,
    modifier: Modifier = Modifier
) {
    val cpuSampler = remember { CpuSampler() }
    var cpuLoad by remember { mutableFloatStateOf(0f) }
    var usedMemMb by remember { mutableLongStateOf(0L) }
    var maxMemMb by remember { mutableLongStateOf(0L) }
    var nowElapsed by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    var tickCount by remember { mutableLongStateOf(0L) }

    // Riwayat beban CPU nyata — tiap detik digeser, nilai terbaru di kanan.
    val history: SnapshotStateList<Float> = remember {
        mutableStateListOf<Float>().also { list ->
            repeat(WAVE_HISTORY) { list.add(0f) }
        }
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            val sample = cpuSampler.sample()
            cpuLoad = sample
            val runtime = Runtime.getRuntime()
            usedMemMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
            maxMemMb = runtime.maxMemory() / (1024 * 1024)
            nowElapsed = SystemClock.elapsedRealtime()
            tickCount++

            // Geser buffer: buang paling kiri, append sampel baru di kanan.
            // Tambah sedikit jitter natural supaya garis tidak kaku saat CPU stabil.
            val displayValue = if (isServiceRunning) {
                val jitter = (Random.nextFloat() - 0.5f) * 2.2f
                (sample + jitter).coerceIn(0f, 100f)
            } else {
                // Idle: noise sangat kecil di lantai, bukan garis mati total.
                Random.nextFloat() * 1.8f
            }
            if (history.size >= WAVE_HISTORY) history.removeAt(0)
            history.add(displayValue)

            delay(450) // sampling lebih cepat biar gelombang terasa "hidup"
        }
    }

    val uptimeMs = if (isServiceRunning && serviceStartElapsedRealtime != null) {
        (nowElapsed - serviceStartElapsedRealtime).coerceAtLeast(0L)
    } else null

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "MONITOR SISTEM",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = NovanetText2
            )
            LiveStatusBadge(isLive = isServiceRunning)
        }

        Spacer(Modifier.height(10.dp))

        // ── Terminal block ──────────────────────────────────────
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(NovanetBg0)
                .border(1.dp, NovanetLine, RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            // Header bar ala terminal
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(NovanetDanger.copy(alpha = 0.85f))
                )
                Spacer(Modifier.width(5.dp))
                Box(
                    Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(NovanetWarning.copy(alpha = 0.85f))
                )
                Spacer(Modifier.width(5.dp))
                Box(
                    Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(NovanetSuccess.copy(alpha = 0.85f))
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = "novanet@device — status",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = NovanetText3
                )
            }

            Spacer(Modifier.height(10.dp))

            TerminalLine(
                label = "uptime",
                value = uptimeMs?.let { formatUptime(it) } ?: "--:--:--",
                valueColor = if (isServiceRunning) NovanetSuccess else NovanetText3
            )
            TerminalLine(
                label = "cpu_load",
                value = if (isServiceRunning) String.format("%.1f%%", cpuLoad) else "0.0%",
                valueColor = if (isServiceRunning) loadColor(cpuLoad) else NovanetText3
            )
            TerminalLine(
                label = "memory",
                value = "$usedMemMb / $maxMemMb MB",
                valueColor = NovanetInfo
            )
            TerminalLine(
                label = "cores",
                value = "${Runtime.getRuntime().availableProcessors()}",
                valueColor = NovanetText2
            )
            TerminalLine(
                label = "wakelock",
                value = if (isServiceRunning) "LOCKED" else "RELEASED",
                valueColor = if (isServiceRunning) NovanetSuccess else NovanetText3
            )

            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "root@novanet:~$ ",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = NovanetAccent
                )
                Text(
                    text = "█",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = NovanetText1.copy(alpha = if (tickCount % 2L == 0L) 1f else 0.12f)
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        // ── Header gelombang ────────────────────────────────────
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "CPU ACTIVITY",
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 0.8.sp,
                color = NovanetText3
            )
            Text(
                text = if (isServiceRunning) {
                    String.format("%.0f%%  ·  LIVE", cpuLoad)
                } else {
                    "IDLE"
                },
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = if (isServiceRunning) loadColor(cpuLoad) else NovanetText3
            )
        }

        Spacer(Modifier.height(6.dp))

        // ── Gelombang dari bawah (riwayat CPU nyata) ────────────
        CpuWaveformRealtime(
            history = history,
            active = isServiceRunning,
            currentLoad = cpuLoad,
            modifier = Modifier
                .fillMaxWidth()
                .height(88.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(NovanetBg0)
                .border(1.dp, NovanetLine, RoundedCornerShape(8.dp))
        )
    }
}

@Composable
private fun TerminalLine(label: String, value: String, valueColor: Color) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "  ${label.padEnd(10, ' ')}",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = NovanetText3
        )
        Text(
            text = value,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = valueColor
        )
    }
    Spacer(Modifier.height(3.dp))
}

/**
 * Gelombang aktivitas dari **riwayat sampel CPU nyata**.
 * - Digambar dari bawah ke atas (bukan center sine).
 * - Bentuk patah-patah / tidak mulus — mengikuti data + jitter ringan.
 * - Area terisi gradien, garis tepi tipis, grid horizontal tipis.
 * - Scroll ke kiri tiap sampel baru (nilai terbaru di kanan).
 */
@Composable
fun CpuWaveformRealtime(
    history: List<Float>,
    active: Boolean,
    currentLoad: Float,
    modifier: Modifier = Modifier
) {
    val strokeColor = if (active) loadColor(currentLoad) else NovanetText3
    val fillTop = strokeColor.copy(alpha = if (active) 0.38f else 0.12f)
    val fillBottom = strokeColor.copy(alpha = 0.02f)

    Canvas(modifier = modifier.padding(horizontal = 2.dp, vertical = 2.dp)) {
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f || history.isEmpty()) return@Canvas

        val count = history.size
        val stepX = w / (count - 1).coerceAtLeast(1).toFloat()
        val bottomPad = 2f
        val topPad = 4f
        val usableH = (h - bottomPad - topPad).coerceAtLeast(1f)

        // Grid horizontal tipis (25% / 50% / 75%)
        val gridColor = NovanetLine.copy(alpha = 0.55f)
        listOf(0.25f, 0.5f, 0.75f).forEach { frac ->
            val gy = h - bottomPad - usableH * frac
            drawLine(
                color = gridColor,
                start = Offset(0f, gy),
                end = Offset(w, gy),
                strokeWidth = 1f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 5f))
            )
        }

        // Baseline bawah
        drawLine(
            color = NovanetLineStrong.copy(alpha = 0.7f),
            start = Offset(0f, h - bottomPad),
            end = Offset(w, h - bottomPad),
            strokeWidth = 1.2f
        )

        // Path gelombang: dari bawah, tinggi proporsional ke sampel CPU
        val linePath = Path()
        val fillPath = Path()

        fun yFor(percent: Float): Float {
            val p = percent.coerceIn(0f, 100f) / 100f
            return h - bottomPad - usableH * p
        }

        // Mulai dari kiri-bawah untuk fill
        fillPath.moveTo(0f, h - bottomPad)

        for (i in 0 until count) {
            val x = i * stepX
            val y = yFor(history[i])
            if (i == 0) {
                linePath.moveTo(x, y)
                fillPath.lineTo(x, y)
            } else {
                // Garis lurus antar titik → terlihat patah-patah / natural
                linePath.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }

        // Tutup fill ke kanan-bawah lalu kiri-bawah
        fillPath.lineTo(w, h - bottomPad)
        fillPath.close()

        // Area fill gradien dari atas (warna beban) ke bawah (transparan)
        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(fillTop, fillBottom),
                startY = topPad,
                endY = h
            )
        )

        // Glow di belakang garis
        drawPath(
            path = linePath,
            color = strokeColor.copy(alpha = 0.22f),
            style = Stroke(width = 6.5f, cap = StrokeCap.Round)
        )

        // Garis utama tajam
        drawPath(
            path = linePath,
            color = strokeColor,
            style = Stroke(width = 2.1f, cap = StrokeCap.Butt)
        )

        // Titik di ujung kanan (sampel terbaru) biar kelihatan "hidup"
        if (active && count > 0) {
            val lastX = (count - 1) * stepX
            val lastY = yFor(history.last())
            drawCircle(
                color = strokeColor.copy(alpha = 0.25f),
                radius = 7f,
                center = Offset(lastX, lastY)
            )
            drawCircle(
                color = strokeColor,
                radius = 3.2f,
                center = Offset(lastX, lastY)
            )
        }
    }
}

/** Alias kompatibilitas — komponen lama CpuWaveform diarahkan ke panel baru. */
@Composable
fun CpuWaveform(
    loadPercent: Float,
    active: Boolean,
    modifier: Modifier = Modifier
) {
    val history = remember {
        mutableStateListOf<Float>().also { list ->
            repeat(WAVE_HISTORY) { list.add(0f) }
        }
    }
    LaunchedEffect(loadPercent, active) {
        val v = if (active) loadPercent.coerceIn(0f, 100f) else Random.nextFloat() * 1.5f
        if (history.size >= WAVE_HISTORY) history.removeAt(0)
        history.add(v)
    }
    CpuWaveformRealtime(
        history = history,
        active = active,
        currentLoad = loadPercent,
        modifier = modifier
    )
}
