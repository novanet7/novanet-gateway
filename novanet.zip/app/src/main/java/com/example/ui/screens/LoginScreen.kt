package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import id.novanet.listener.R
import com.example.ui.theme.NovanetAccent
import com.example.ui.theme.NovanetBg1
import com.example.ui.theme.NovanetBg2
import com.example.ui.theme.NovanetDanger
import com.example.ui.theme.NovanetDangerSoft
import com.example.ui.theme.NovanetLine
import com.example.ui.theme.NovanetText1
import com.example.ui.theme.NovanetText2
import com.example.ui.theme.NovanetText3
import com.example.ui.theme.novanetBlueprintBackground
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.launch

// ============================================================
// Konstanta UI — biar konsisten satu tempat
// ============================================================
private val CARD_SHAPE = RoundedCornerShape(8.dp)
private val BTN_SHAPE = RoundedCornerShape(6.dp)

/**
 * Login SEKARANG cuma lewat Google (Credential Manager / "Sign in with
 * Google") — tidak ada lagi form username/password. Akun di APK wajib sudah
 * pernah dibuat lebih dulu lewat website; kalau email Google yang dipilih
 * belum pernah daftar di web, server akan menolak (lihat pesan error yang
 * dikirim balik lewat `errorMessage`).
 */
@Composable
fun LoginScreen(
    isLoggingIn: Boolean,
    errorMessage: String?,
    onGoogleIdToken: (idToken: String) -> Unit,
    onGoogleSignInError: (message: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    fun launchGoogleSignIn() {
        if (isLoggingIn) return
        coroutineScope.launch {
            try {
                val webClientId = context.getString(R.string.google_web_client_id)
                if (webClientId.isBlank() || webClientId.startsWith("REPLACE_")) {
                    onGoogleSignInError("google_web_client_id belum diisi di strings.xml")
                    return@launch
                }

                val credentialManager = CredentialManager.create(context)
                val signInOption = GetSignInWithGoogleOption.Builder(webClientId).build()
                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(signInOption)
                    .build()

                val result = credentialManager.getCredential(context, request)
                val credential = result.credential

                if (credential is CustomCredential &&
                    credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
                ) {
                    val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                    onGoogleIdToken(googleIdTokenCredential.idToken)
                } else {
                    onGoogleSignInError("Tipe kredensial Google tidak dikenali")
                }
            } catch (e: GetCredentialCancellationException) {
                // User batal milih akun — bukan error, diam saja.
            } catch (e: GetCredentialException) {
                onGoogleSignInError(e.localizedMessage ?: "Gagal masuk dengan Google")
            } catch (e: Exception) {
                onGoogleSignInError(e.localizedMessage ?: "Gagal masuk dengan Google")
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .novanetBlueprintBackground()
            .imePadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 20.dp)
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            BrandHeader()

            Spacer(Modifier.height(24.dp))

            LoginCard(
                errorMessage = errorMessage,
                isLoggingIn = isLoggingIn,
                onGoogleSignInClick = { launchGoogleSignIn() }
            )
        }
    }
}

// ============================================================
// SUB-COMPONENTS
// ============================================================

@Composable
private fun BrandHeader() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(NovanetBg1)
                .border(1.dp, NovanetLine, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.novanet_app_logo),
                contentDescription = "Novanet Gateway Logo",
                modifier = Modifier.size(50.dp)
            )
        }

        Spacer(Modifier.height(14.dp))

        Text(
            text = "NOVANET",
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 2.sp,
            color = NovanetText1
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = "Payment Gateway — Masuk Akun",
            fontSize = 12.sp,
            color = NovanetText2
        )
    }
}

@Composable
private fun LoginCard(
    errorMessage: String?,
    isLoggingIn: Boolean,
    onGoogleSignInClick: () -> Unit
) {
    Surface(
        shape = CARD_SHAPE,
        color = NovanetBg1,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, NovanetLine, CARD_SHAPE)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            SectionHeaderDot(title = "MASUK AKUN")

            Spacer(Modifier.height(2.dp))
            Text(
                text = "Akun ini wajib sudah pernah dibuat lewat website Novanet " +
                    "dulu (login Google di web). Pilih akun Google yang sama di sini.",
                fontSize = 11.sp,
                lineHeight = 15.sp,
                color = NovanetText3
            )

            if (!errorMessage.isNullOrBlank()) {
                Spacer(Modifier.height(12.dp))
                ErrorBanner(message = errorMessage)
            }

            Spacer(Modifier.height(14.dp))

            GoogleSignInButton(
                isLoggingIn = isLoggingIn,
                onClick = onGoogleSignInClick
            )
        }
    }
}

@Composable
private fun SectionHeaderDot(title: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(NovanetAccent)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = title,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp,
            color = NovanetText2
        )
    }
}

@Composable
private fun ErrorBanner(message: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(NovanetDangerSoft)
            .border(1.dp, NovanetDanger, RoundedCornerShape(6.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = null,
            tint = NovanetDanger,
            modifier = Modifier.size(16.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = message,
            fontSize = 11.sp,
            color = NovanetDanger,
            lineHeight = 15.sp
        )
    }
}

@Composable
private fun GoogleSignInButton(
    isLoggingIn: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = !isLoggingIn,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.White,
            contentColor = Color(0xFF1F1F1F),
            disabledContainerColor = NovanetBg2,
            disabledContentColor = NovanetText3
        ),
        shape = BTN_SHAPE,
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .testTag("google_sign_in_button")
    ) {
        if (isLoggingIn) {
            CircularProgressIndicator(
                color = Color(0xFF1F1F1F),
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Menghubungkan...",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        } else {
            GoogleGlyph()
            Spacer(Modifier.width(10.dp))
            Text(
                text = "Lanjutkan dengan Google",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/** Logo "G" empat-warna Google, digambar manual biar gak butuh aset PNG tambahan. */
@Composable
private fun GoogleGlyph() {
    androidx.compose.foundation.Canvas(modifier = Modifier.size(18.dp)) {
        val r = size.minDimension / 2f
        val strokeW = r * 0.62f
        drawArc(
            color = Color(0xFF4285F4),
            startAngle = -50f,
            sweepAngle = 100f,
            useCenter = false,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeW)
        )
        drawArc(
            color = Color(0xFF34A853),
            startAngle = 50f,
            sweepAngle = 90f,
            useCenter = false,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeW)
        )
        drawArc(
            color = Color(0xFFFBBC05),
            startAngle = 140f,
            sweepAngle = 80f,
            useCenter = false,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeW)
        )
        drawArc(
            color = Color(0xFFEA4335),
            startAngle = 220f,
            sweepAngle = 90f,
            useCenter = false,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeW)
        )
    }
}
