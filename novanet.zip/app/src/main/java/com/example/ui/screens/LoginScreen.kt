package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.NovanetAccent
import com.example.ui.theme.NovanetAccentInk
import com.example.ui.theme.NovanetBg1
import com.example.ui.theme.NovanetBg2
import com.example.ui.theme.NovanetDanger
import com.example.ui.theme.NovanetDangerSoft
import com.example.ui.theme.NovanetLine
import com.example.ui.theme.NovanetLineStrong
import com.example.ui.theme.NovanetText1
import com.example.ui.theme.NovanetText2
import com.example.ui.theme.NovanetText3
import com.example.ui.theme.novanetBlueprintBackground

// ============================================================
// Konstanta UI — biar konsisten satu tempat
// ============================================================
private val CARD_SHAPE = RoundedCornerShape(8.dp)
private val FIELD_SHAPE = RoundedCornerShape(6.dp)
private val BTN_SHAPE = RoundedCornerShape(6.dp)
private val INPUT_INNER_PADDING = 10.dp

@Composable
fun LoginScreen(
    isLoggingIn: Boolean,
    errorMessage: String?,
    onLoginSubmit: (username: String, password: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()
    val canSubmit = username.isNotBlank() && password.isNotBlank() && !isLoggingIn

    Box(
        modifier = modifier
            .fillMaxSize()
            .novanetBlueprintBackground()
            .imePadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 20.dp)
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            BrandHeader()

            Spacer(Modifier.height(24.dp))

            LoginCard(
                errorMessage = errorMessage,
                username = username,
                onUsernameChange = { username = it },
                password = password,
                onPasswordChange = { password = it },
                isPasswordVisible = isPasswordVisible,
                onTogglePasswordVisibility = { isPasswordVisible = !isPasswordVisible },
                isLoggingIn = isLoggingIn,
                canSubmit = canSubmit,
                onSubmit = {
                    focusManager.clearFocus()
                    onLoginSubmit(username, password)
                }
            )
        }
    }
}

// ============================================================
// SUB-COMPONENTS
// ============================================================

@Composable
private fun BrandHeader() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(NovanetBg1)
                .border(1.dp, NovanetLine, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.novanet_app_logo),
                contentDescription = "Novanet Store Logo",
                modifier = Modifier
                    .width(62.dp)
                    .height(22.dp)
            )
        }

        Spacer(Modifier.height(14.dp))

        Text(
            text = "NOVANET",
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 2.sp,
            color = NovanetText1
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = "Payment Gateway — Masuk Akun",
            fontSize = 12.sp,
            color = NovanetText2
        )
    }
}

@Composable
private fun LoginCard(
    errorMessage: String?,
    username: String,
    onUsernameChange: (String) -> Unit,
    password: String,
    onPasswordChange: (String) -> Unit,
    isPasswordVisible: Boolean,
    onTogglePasswordVisibility: () -> Unit,
    isLoggingIn: Boolean,
    canSubmit: Boolean,
    onSubmit: () -> Unit
) {
    Surface(
        shape = CARD_SHAPE,
        color = NovanetBg1,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, NovanetLine, CARD_SHAPE)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            SectionHeaderDot(title = "OTENTIKASI WEBSITE")

            if (!errorMessage.isNullOrBlank()) {
                Spacer(Modifier.height(2.dp))
                ErrorBanner(message = errorMessage)
                Spacer(Modifier.height(14.dp))
            } else {
                Spacer(Modifier.height(2.dp))
            }

            LabeledField(label = "USERNAME") {
                OutlinedTextField(
                    value = username,
                    onValueChange = onUsernameChange,
                    placeholder = {
                        Text(
                            text = "username akun website",
                            color = NovanetText3,
                            fontSize = 13.sp
                        )
                    },
                    leadingIcon = {
                        FieldIcon(icon = Icons.Default.Person)
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    ),
                    colors = novanetTextFieldColors(),
                    shape = FIELD_SHAPE,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("username_input")
                )
            }

            Spacer(Modifier.height(14.dp))

            LabeledField(label = "PASSWORD") {
                OutlinedTextField(
                    value = password,
                    onValueChange = onPasswordChange,
                    placeholder = {
                        Text(
                            text = "kata sandi akun",
                            color = NovanetText3,
                            fontSize = 13.sp
                        )
                    },
                    leadingIcon = {
                        FieldIcon(icon = Icons.Default.Lock)
                    },
                    trailingIcon = {
                        IconButton(onClick = onTogglePasswordVisibility) {
                            Icon(
                                imageVector = if (isPasswordVisible)
                                    Icons.Default.Visibility
                                else
                                    Icons.Default.VisibilityOff,
                                contentDescription = if (isPasswordVisible)
                                    "Sembunyikan"
                                else
                                    "Lihat",
                                tint = NovanetText3,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    },
                    singleLine = true,
                    visualTransformation = if (isPasswordVisible)
                        VisualTransformation.None
                    else
                        PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = { if (canSubmit) onSubmit() }
                    ),
                    colors = novanetTextFieldColors(),
                    shape = FIELD_SHAPE,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("password_input")
                )
            }

            Spacer(Modifier.height(20.dp))

            SubmitButton(
                isLoggingIn = isLoggingIn,
                enabled = canSubmit,
                onClick = onSubmit
            )
        }
    }
}

@Composable
private fun SectionHeaderDot(title: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(NovanetAccent)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = title,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp,
            color = NovanetText2
        )
    }
}

@Composable
private fun ErrorBanner(message: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(NovanetDangerSoft)
            .border(1.dp, NovanetDanger, RoundedCornerShape(6.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = null,
            tint = NovanetDanger,
            modifier = Modifier.size(16.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = message,
            fontSize = 11.sp,
            color = NovanetDanger,
            lineHeight = 15.sp
        )
    }
}

@Composable
private fun LabeledField(
    label: String,
    content: @Composable () -> Unit
) {
    Column {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp,
            color = NovanetText3
        )
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
private fun FieldIcon(icon: ImageVector) {
    Icon(
        imageVector = icon,
        contentDescription = null,
        tint = NovanetText3,
        modifier = Modifier.size(18.dp)
    )
}

@Composable
private fun novanetTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = NovanetText1,
    unfocusedTextColor = NovanetText1,
    focusedContainerColor = NovanetBg2,
    unfocusedContainerColor = NovanetBg2,
    focusedBorderColor = NovanetAccent,
    unfocusedBorderColor = NovanetLine
)

@Composable
private fun SubmitButton(
    isLoggingIn: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = NovanetAccent,
            contentColor = NovanetAccentInk,
            disabledContainerColor = NovanetLineStrong,
            disabledContentColor = NovanetText3
        ),
        shape = BTN_SHAPE,
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .testTag("login_button")
    ) {
        if (isLoggingIn) {
            CircularProgressIndicator(
                color = NovanetAccentInk,
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Menghubungkan...",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        } else {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Login,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Masuk ke Akun",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
