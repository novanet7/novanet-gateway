package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = NovanetAccent,
    onPrimary = NovanetAccentInk,
    primaryContainer = NovanetBg2,
    onPrimaryContainer = NovanetAccentHover,
    secondary = NovanetAccent,
    onSecondary = NovanetAccentInk,
    secondaryContainer = NovanetBg2,
    onSecondaryContainer = NovanetAccent,
    tertiary = NovanetInfo,
    onTertiary = Color.White,
    background = NovanetBg0,
    onBackground = NovanetText1,
    surface = NovanetBg1,
    onSurface = NovanetText1,
    surfaceVariant = NovanetBg2,
    onSurfaceVariant = NovanetText2,
    outline = NovanetLine,
    error = NovanetDanger,
    onError = Color.White,
    errorContainer = ErrorRoseContainer,
    onErrorContainer = Color(0xFFFFDAD6)
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
