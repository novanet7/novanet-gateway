package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.NovanetAccent
import com.example.ui.theme.NovanetBg0
import com.example.ui.theme.NovanetBg1
import com.example.ui.theme.NovanetBg2
import com.example.ui.theme.NovanetLine
import com.example.ui.theme.NovanetText1
import com.example.ui.theme.NovanetText3

@Composable
fun DanaListenerApp(
    viewModel: DanaListenerViewModel
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val snackbarHostState = remember { SnackbarHostState() }

    // Observe lifecycle hanya untuk refresh status izin & data saat app
    // dibuka lagi. Notifikasi pembayaran diterima melalui FCM —
    // itu dipegang penuh oleh DanaKeepAliveService yang jalan 24/7 di latar
    // belakang, terlepas dari Activity ini pause/resume/destroy.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.checkPermission(context)
                viewModel.refreshServerData()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Collect States
    val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()
    val isLoggingIn by viewModel.isLoggingIn.collectAsStateWithLifecycle()
    val loginError by viewModel.loginError.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val currentNavTab by viewModel.currentNavTab.collectAsStateWithLifecycle()

    val novanetStats by viewModel.novanetStats.collectAsStateWithLifecycle()
    val serverTransactions by viewModel.serverTransactions.collectAsStateWithLifecycle()
    val unmatchedNotifications by viewModel.unmatchedNotifications.collectAsStateWithLifecycle()

    val isPermissionGranted by viewModel.isPermissionGranted.collectAsStateWithLifecycle()
    val isServiceConnected by viewModel.isServiceConnected.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()
    val sendingTestPaidIds by viewModel.sendingTestPaidIds.collectAsStateWithLifecycle()
    val isIgnoringBattery by viewModel.isIgnoringBattery.collectAsStateWithLifecycle()
    val keepAliveEnabled by viewModel.keepAliveState.collectAsStateWithLifecycle()

    val ttsAlert by viewModel.ttsAlertState.collectAsStateWithLifecycle()
    val paymentAlert by viewModel.paymentAlertState.collectAsStateWithLifecycle()

    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()

    // Handle Snackbars
    LaunchedEffect(userMessage) {
        userMessage?.let { msg ->
            snackbarHostState.showSnackbar(
                message = msg,
                duration = SnackbarDuration.Short
            )
            viewModel.clearUserMessage()
        }
    }

    // If not logged in, display the Login Screen directly
    if (!isLoggedIn) {
        LoginScreen(
            isLoggingIn = isLoggingIn,
            errorMessage = loginError,
            onLoginSubmit = { user, pass ->
                viewModel.login(user, pass)
            }
        )
        return
    }

    // Main App with Bottom Navigation (Dashboard <-> Pengaturan <-> Profil)
    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(NovanetBg0),
        bottomBar = {
            Box(
                modifier = Modifier
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                NavigationBar(
                    containerColor = NovanetBg1,
                    tonalElevation = 0.dp,
                    modifier = Modifier
                        .border(
                            width = 1.dp,
                            color = NovanetLine,
                            shape = RoundedCornerShape(24.dp)
                        )
                        .background(NovanetBg1, RoundedCornerShape(24.dp))
                        .testTag("main_bottom_nav")
                ) {
                    NavigationBarItem(
                        selected = currentNavTab == 0,
                        onClick = { viewModel.setNavTab(0) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Dashboard,
                                contentDescription = "Dashboard",
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        label = {
                            Text(
                                text = "Dashboard",
                                fontWeight = if (currentNavTab == 0) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NovanetAccent,
                            selectedTextColor = NovanetText1,
                            unselectedIconColor = NovanetText3,
                            unselectedTextColor = NovanetText3,
                            indicatorColor = NovanetBg0
                        ),
                        modifier = Modifier.testTag("nav_item_dashboard")
                    )

                    NavigationBarItem(
                        selected = currentNavTab == 1,
                        onClick = { viewModel.setNavTab(1) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Pengaturan",
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        label = {
                            Text(
                                text = "Pengaturan",
                                fontWeight = if (currentNavTab == 1) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NovanetAccent,
                            selectedTextColor = NovanetText1,
                            unselectedIconColor = NovanetText3,
                            unselectedTextColor = NovanetText3,
                            indicatorColor = NovanetBg0
                        ),
                        modifier = Modifier.testTag("nav_item_settings")
                    )

                    NavigationBarItem(
                        selected = currentNavTab == 2,
                        onClick = { viewModel.setNavTab(2) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Profil",
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        label = {
                            Text(
                                text = "Profil",
                                fontWeight = if (currentNavTab == 2) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NovanetAccent,
                            selectedTextColor = NovanetText1,
                            unselectedIconColor = NovanetText3,
                            unselectedTextColor = NovanetText3,
                            indicatorColor = NovanetBg0
                        ),
                        modifier = Modifier.testTag("nav_item_profile")
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = NovanetBg0
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentNavTab) {
                0 -> DashboardScreen(
                    user = currentUser,
                    stats = novanetStats,
                    serverTransactions = serverTransactions,
                    unmatchedNotifications = unmatchedNotifications,
                    isPermissionGranted = isPermissionGranted,
                    isServiceConnected = isServiceConnected,
                    isRefreshing = isRefreshing,
                    onRefresh = { viewModel.refreshServerData() },
                    sendingTestPaidIds = sendingTestPaidIds,
                    onMarkPaidTest = { viewModel.markServerTransactionPaidTest(it) },
                    onDismissUnmatched = { viewModel.dismissUnmatchedNotification(it) }
                )
                1 -> SettingsScreen(
                    ttsAlert = ttsAlert,
                    paymentAlert = paymentAlert,
                    isPermissionGranted = isPermissionGranted,
                    isServiceConnected = isServiceConnected,
                    isIgnoringBattery = isIgnoringBattery,
                    keepAliveEnabled = keepAliveEnabled,
                    onToggleTtsAlert = { viewModel.toggleTtsAlert(it) },
                    onTogglePaymentAlert = { viewModel.togglePaymentAlert(it) },
                    onToggleKeepAlive = { viewModel.toggleKeepAlive(context, it) },
                    onRefreshStatus = { viewModel.checkPermission(context) }
                )
                2 -> ProfileScreen(
                    user = currentUser,
                    onLogout = { viewModel.logout() }
                )
            }
        }
    }

}
