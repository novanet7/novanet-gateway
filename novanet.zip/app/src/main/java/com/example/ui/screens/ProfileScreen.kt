package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.api.NovanetUser
import com.example.ui.theme.NovanetAccent
import com.example.ui.theme.NovanetBg1
import com.example.ui.theme.NovanetBg2
import com.example.ui.theme.NovanetDanger
import com.example.ui.theme.NovanetDangerSoft
import com.example.ui.theme.NovanetLine
import com.example.ui.theme.NovanetText1
import com.example.ui.theme.NovanetText2
import com.example.ui.theme.NovanetText3
import com.example.ui.theme.novanetBlueprintBackground

// ============================================================
// Konstanta UI
// ============================================================
private val CARD_SHAPE = RoundedCornerShape(10.dp)
private val ITEM_SHAPE = RoundedCornerShape(6.dp)
private val BTN_SHAPE = RoundedCornerShape(8.dp)
private const val BASE_URL = "https://novanet.uno"
private const val TAG = "ProfileScreen"

// ============================================================
// SCREEN UTAMA
// ============================================================
@Composable
fun ProfileScreen(
    user: NovanetUser?,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .novanetBlueprintBackground()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))

        AvatarSection(user = user)

        Spacer(Modifier.height(14.dp))

        Text(
            text = user?.username?.takeIf { it.isNotBlank() } ?: "User Novanet",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = NovanetText1
        )

        Spacer(Modifier.height(24.dp))

        AccountInfoCard(user = user, context = context)

        Spacer(Modifier.height(24.dp))

        LogoutButton(onLogout = onLogout)

        Spacer(Modifier.height(28.dp))
    }
}

// ============================================================
// SUB-COMPONENTS
// ============================================================

@Composable
private fun AvatarSection(user: NovanetUser?) {
    Box(
        modifier = Modifier
            .size(88.dp)
            .clip(CircleShape)
            .background(NovanetBg1)
            .border(1.dp, NovanetLine, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            // profileImageUrl() sekarang handle:
            // - "data:image/png;base64,..."  → dipakai langsung (Coil 2.x decode native)
            // - "https://..."                 → dipakai langsung
            // - "/uploads/xxx.jpg"            → di-prefix BASE_URL
            // - "uploads/xxx.jpg"             → di-prefix BASE_URL
            model = profileImageUrl(user?.avatarUrl),
            placeholder = painterResource(id = R.drawable.novanet_profile_logo),
            error = painterResource(id = R.drawable.novanet_profile_logo),
            fallback = painterResource(id = R.drawable.novanet_profile_logo),
            onError = {
                Log.w(
                    TAG,
                    "Gagal memuat avatar dari [${user?.avatarUrl?.take(60)}...]: " +
                            "${it.result.throwable}"
                )
            },
            contentDescription = "Foto profil ${user?.username ?: "Novanet"}",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(88.dp)
                .clip(CircleShape)
        )
    }
}

@Composable
private fun AccountInfoCard(
    user: NovanetUser?,
    context: Context
) {
    Surface(
        shape = CARD_SHAPE,
        color = NovanetBg1,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, NovanetLine, CARD_SHAPE)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "INFORMASI AKUN WEBSITE",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp,
                color = NovanetText3,
                modifier = Modifier.padding(bottom = 14.dp)
            )

            InfoRow(
                icon = Icons.Default.VerifiedUser,
                label = "ID AKUN",
                value = user?.id ?: "-",
                copyValue = user?.id?.takeIf { it.isNotBlank() },
                onCopied = { copyToClipboard(context, it, "ID Akun disalin") }
            )

            ThinDivider()

            InfoRow(
                icon = Icons.Default.Key,
                label = "X-API-KEY GATEWAY",
                value = maskApiKey(user?.apiKey),
                copyValue = user?.apiKey?.takeIf { it.isNotBlank() },
                onCopied = { copyToClipboard(context, it, "API Key disalin") }
            )

            if (!user?.createdAt.isNullOrBlank()) {
                ThinDivider()
                InfoRow(
                    icon = Icons.Default.Schedule,
                    label = "TANGGAL BERGABUNG",
                    value = formatJoinDate(user?.createdAt),
                    copyValue = null,
                    onCopied = {}
                )
            }
        }
    }
}

@Composable
private fun InfoRow(
    icon: ImageVector,
    label: String,
    value: String,
    copyValue: String?,
    onCopied: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(ITEM_SHAPE)
                    .background(NovanetBg2)
                    .border(1.dp, NovanetLine, ITEM_SHAPE),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = NovanetAccent,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(Modifier.width(12.dp))

            Column {
                Text(
                    text = label,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp,
                    color = NovanetText3
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = value,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium,
                    color = NovanetText1
                )
            }
        }

        if (copyValue != null) {
            IconButton(
                onClick = { onCopied(copyValue) },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Salin",
                    tint = NovanetText2,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun ThinDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(NovanetLine.copy(alpha = 0.4f))
    )
}

@Composable
private fun LogoutButton(onLogout: () -> Unit) {
    Button(
        onClick = onLogout,
        colors = ButtonDefaults.buttonColors(
            containerColor = NovanetDangerSoft,
            contentColor = NovanetDanger
        ),
        shape = BTN_SHAPE,
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .border(1.dp, NovanetDanger, BTN_SHAPE)
            .testTag("logout_button")
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Filled.Logout,
            contentDescription = null,
            tint = NovanetDanger,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = "Keluar dari Akun (Logout)",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// ============================================================
// HELPER
// ============================================================

private fun copyToClipboard(context: Context, text: String, toastMsg: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("Novanet", text))
    Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
}

/**
 * Normalisasi sumber avatar dari server.
 *
 * Server novanet.uno mengirim avatar sebagai URL relatif/absolut JPG.
 * Data URI lama tetap didukung sebagai fallback kompatibilitas akun lama.
 *
 * URL relatif seperti `/api/profile/avatar/<id>.jpg` di-prefix ke BASE_URL.
 */
private fun profileImageUrl(rawUrl: String?): String? {
    val url = rawUrl?.trim().orEmpty()
    if (url.isBlank()) return null
    return when {
        // ⬇️ Data URI base64 — pakai langsung, Coil yang decode
        url.startsWith("data:") -> url
        url.startsWith("http://") || url.startsWith("https://") -> url
        url.startsWith("//") -> "https:$url"
        url.startsWith("/") -> "$BASE_URL$url"
        else -> "$BASE_URL/$url"
    }
}

/** Masking API Key: ambil 6 depan + 4 belakang. */
private fun maskApiKey(apiKey: String?): String {
    if (apiKey.isNullOrBlank()) return "Belum dibuat di profil web"
    return if (apiKey.length > 10) {
        apiKey.take(6) + "••••••••" + apiKey.takeLast(4)
    } else apiKey
}

/** "2026-03-01T08:23:11.000Z" → "1 Maret 2026" */
private fun formatJoinDate(rawDate: String?): String {
    if (rawDate.isNullOrBlank()) return "-"
    return try {
        val isoFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US)
            .apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
        val date = isoFormat.parse(rawDate.substringBefore(".")) ?: return rawDate
        java.text.SimpleDateFormat("d MMMM yyyy", java.util.Locale("id", "ID")).format(date)
    } catch (_: Exception) {
        rawDate
    }
}
