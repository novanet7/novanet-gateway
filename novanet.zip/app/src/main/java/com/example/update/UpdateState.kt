package com.example.update

import com.example.data.api.AppUpdateInfo

/** Tahapan update aplikasi (dari server Novanet) — dibaca UI lewat [AppUpdater.state]. */
sealed interface UpdateState {
    object Idle : UpdateState
    object Checking : UpdateState
    object UpToDate : UpdateState

    /** Ada versi lebih baru di server. */
    data class Available(val info: AppUpdateInfo) : UpdateState

    /** Android butuh izin "Pasang aplikasi tidak dikenal" untuk Novanet (sekali saja). */
    data class NeedsInstallPermission(val info: AppUpdateInfo) : UpdateState

    data class Downloading(
        val info: AppUpdateInfo,
        val downloadedBytes: Long,
        val totalBytes: Long
    ) : UpdateState

    data class Verifying(val info: AppUpdateInfo) : UpdateState

    /** File sudah diserahkan ke installer Android; menunggu konfirmasi/penyelesaian. */
    data class Installing(val info: AppUpdateInfo) : UpdateState

    /** [info] null = kegagalan saat memeriksa versi (belum ada update yang bisa dicoba ulang). */
    data class Failed(val info: AppUpdateInfo?, val message: String) : UpdateState
}

/** True bila banner update perlu tampil di Dashboard. */
val UpdateState.showsBanner: Boolean
    get() = when (this) {
        is UpdateState.Available,
        is UpdateState.NeedsInstallPermission,
        is UpdateState.Downloading,
        is UpdateState.Verifying,
        is UpdateState.Installing -> true
        is UpdateState.Failed -> info != null
        else -> false
    }
