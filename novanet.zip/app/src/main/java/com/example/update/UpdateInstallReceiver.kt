package com.example.update

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build

/**
 * Menerima hasil sesi pemasangan dari PackageInstaller:
 *  - PENDING_USER_ACTION : Android meminta konfirmasi "Perbarui" → tampilkan layarnya.
 *  - SUCCESS             : terpasang (proses aplikasi lama biasanya sudah dihentikan sistem).
 *  - lainnya             : gagal / dibatalkan → dilaporkan ke UI.
 */
class UpdateInstallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)

        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            val confirm: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(Intent.EXTRA_INTENT)
            }
            if (confirm != null) {
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    context.startActivity(confirm)
                } catch (e: Exception) {
                    AppUpdater.onInstallResult(PackageInstaller.STATUS_FAILURE, e.localizedMessage)
                }
            }
            return
        }

        AppUpdater.onInstallResult(status, message)
    }
}
