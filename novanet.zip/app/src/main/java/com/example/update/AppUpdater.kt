package com.example.update

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.pm.PackageInfoCompat
import com.example.data.api.AppUpdateInfo
import com.example.data.api.NovanetApiClient
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

/**
 * Update aplikasi otomatis dari server Novanet:
 * cek versi → unduh APK (dengan progres) → verifikasi (checksum, paket, versi, tanda tangan)
 * → serahkan ke installer Android lewat PackageInstaller.
 *
 * Yang TIDAK bisa dilewati: Android tetap meminta konfirmasi "Perbarui" (dan izin
 * "Pasang aplikasi tidak dikenal" sekali). Di Android 12+ konfirmasi kadang dilewati
 * untuk update berikutnya, tetapi itu keputusan sistem.
 */
object AppUpdater {

    const val ACTION_INSTALL_RESULT = "com.example.update.INSTALL_RESULT"

    private const val CHECK_INTERVAL_MS = 15 * 60 * 1000L
    private const val PROGRESS_EMIT_INTERVAL_MS = 200L
    private const val UPDATES_DIR = "updates"

    // Scope sendiri (bukan viewModelScope) supaya unduhan tidak putus saat layar diputar/ViewModel dibuang.
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val downloadClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val _state = MutableStateFlow<UpdateState>(UpdateState.Idle)
    val state: StateFlow<UpdateState> = _state.asStateFlow()

    private var lastCheckAtMs = 0L
    private var job: Job? = null

    @Volatile
    private var installingInfo: AppUpdateInfo? = null

    // ------------------------------------------------------------------
    // INFO VERSI TERPASANG
    // ------------------------------------------------------------------

    fun installedVersionCode(context: Context): Long = try {
        PackageInfoCompat.getLongVersionCode(
            context.packageManager.getPackageInfo(context.packageName, 0)
        )
    } catch (_: Exception) {
        0L
    }

    fun installedVersionName(context: Context): String = try {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "-"
    } catch (_: Exception) {
        "-"
    }

    // ------------------------------------------------------------------
    // CEK VERSI
    // ------------------------------------------------------------------

    private fun isBusy(): Boolean = when (_state.value) {
        is UpdateState.Checking,
        is UpdateState.Downloading,
        is UpdateState.Verifying,
        is UpdateState.Installing -> true
        else -> false
    }

    /** Dipanggil saat aplikasi dibuka/dilanjutkan. Melanjutkan update yang tadi menunggu izin, atau cek versi berkala. */
    fun onAppResumed(context: Context) {
        val current = _state.value
        if (current is UpdateState.NeedsInstallPermission && canInstallPackages(context)) {
            startUpdate(context)
        } else {
            checkForUpdate(context, manual = false)
        }
    }

    fun checkForUpdate(context: Context, manual: Boolean) {
        val app = context.applicationContext
        if (isBusy()) return
        val current = _state.value
        // Otomatis: jangan mengganggu banner yang sedang tampil & jangan terlalu sering.
        if (!manual) {
            if (current !is UpdateState.Idle && current !is UpdateState.UpToDate) return
            if (System.currentTimeMillis() - lastCheckAtMs < CHECK_INTERVAL_MS) return
        }
        lastCheckAtMs = System.currentTimeMillis()

        scope.launch {
            _state.value = UpdateState.Checking
            val result = NovanetApiClient.getLatestApp()
            if (!result.isSuccess) {
                _state.value = if (manual) {
                    UpdateState.Failed(null, "Gagal memeriksa pembaruan: ${result.errorMessage ?: "koneksi gagal"}")
                } else {
                    UpdateState.Idle
                }
                return@launch
            }
            val info = result.data
            _state.value =
                if (info != null && info.versionCode > installedVersionCode(app)) UpdateState.Available(info)
                else UpdateState.UpToDate
        }
    }

    // ------------------------------------------------------------------
    // UNDUH → VERIFIKASI → PASANG
    // ------------------------------------------------------------------

    fun canInstallPackages(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O ||
            context.packageManager.canRequestPackageInstalls()

    /** Buka setelan "Pasang aplikasi tidak dikenal" khusus Novanet. */
    fun openInstallPermissionSettings(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val intent = Intent(
            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
            Uri.parse("package:${context.packageName}")
        )
        if (context !is android.app.Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    fun startUpdate(context: Context) {
        val app = context.applicationContext
        val info = when (val s = _state.value) {
            is UpdateState.Available -> s.info
            is UpdateState.NeedsInstallPermission -> s.info
            is UpdateState.Failed -> s.info
            else -> null
        } ?: return

        if (!canInstallPackages(app)) {
            _state.value = UpdateState.NeedsInstallPermission(info)
            return
        }

        job?.cancel()
        job = scope.launch {
            try {
                _state.value = UpdateState.Downloading(info, 0L, info.sizeBytes)
                val file = downloadApk(app, info)

                _state.value = UpdateState.Verifying(info)
                verifyApk(app, file)

                installingInfo = info
                _state.value = UpdateState.Installing(info)
                installApk(app, file)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                installingInfo = null
                _state.value = UpdateState.Failed(info, e.message ?: "Update gagal")
            }
        }
    }

    private suspend fun downloadApk(context: Context, info: AppUpdateInfo): File {
        val dir = File(context.cacheDir, UPDATES_DIR).apply { mkdirs() }
        val target = File(dir, "novanet-${info.versionCode}.apk")

        // File dari percobaan sebelumnya masih utuh → tidak perlu unduh ulang.
        if (target.exists() && sha256Hex(target).equals(info.sha256, ignoreCase = true)) return target

        dir.listFiles()?.forEach { it.delete() }
        val part = File(dir, "${target.name}.part")

        val request = Request.Builder()
            .url(NovanetApiClient.appDownloadUrl(info.versionCode))
            .header("User-Agent", "NovanetGateway/1.0 (Android)")
            .build()

        val digest = MessageDigest.getInstance("SHA-256")
        downloadClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Server mengembalikan HTTP ${response.code}")
            val body = response.body ?: error("Respons unduhan kosong")
            val total = body.contentLength().takeIf { it > 0 } ?: info.sizeBytes

            body.byteStream().use { input ->
                part.outputStream().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var downloaded = 0L
                    var lastEmit = 0L
                    while (true) {
                        coroutineContext.ensureActive()
                        val read = input.read(buffer)
                        if (read == -1) break
                        output.write(buffer, 0, read)
                        digest.update(buffer, 0, read)
                        downloaded += read
                        val now = System.currentTimeMillis()
                        if (now - lastEmit >= PROGRESS_EMIT_INTERVAL_MS) {
                            lastEmit = now
                            _state.value = UpdateState.Downloading(info, downloaded, total)
                        }
                    }
                    _state.value = UpdateState.Downloading(info, downloaded, total)
                }
            }
        }

        val actual = digest.digest().toHex()
        if (!actual.equals(info.sha256, ignoreCase = true)) {
            part.delete()
            error("File yang diunduh rusak atau tidak sesuai (checksum berbeda). Coba lagi.")
        }
        if (!part.renameTo(target)) error("Gagal menyimpan file update")
        return target
    }

    /** Pemeriksaan sebelum diserahkan ke Android — mencegah APK salah/palsu/lebih lama terpasang. */
    @Suppress("DEPRECATION")
    private fun verifyApk(context: Context, file: File) {
        val pm = context.packageManager
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            PackageManager.GET_SIGNING_CERTIFICATES
        } else {
            PackageManager.GET_SIGNATURES
        }

        val archive = pm.getPackageArchiveInfo(file.absolutePath, flags)
            ?: error("File update tidak bisa dibaca sebagai APK")
        if (archive.packageName != context.packageName) {
            error("File update ini bukan aplikasi Novanet")
        }

        val newCode = PackageInfoCompat.getLongVersionCode(archive)
        val currentCode = installedVersionCode(context)
        if (newCode <= currentCode) {
            error("File update (v$newCode) tidak lebih baru dari yang terpasang (v$currentCode)")
        }

        // Tanda tangan harus sama dengan aplikasi terpasang, kalau tidak Android menolak pemasangannya.
        val installed = signerDigests(pm.getPackageInfo(context.packageName, flags))
        val incoming = signerDigests(archive)
        if (installed != null && incoming != null && installed.isNotEmpty() && incoming.isNotEmpty() &&
            installed.intersect(incoming).isEmpty()
        ) {
            error("Tanda tangan APK baru berbeda dari aplikasi terpasang — build harus memakai kunci (keystore) yang sama")
        }
    }

    @Suppress("DEPRECATION")
    private fun signerDigests(info: PackageInfo): Set<String>? {
        val signatures: Array<Signature>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val signing = info.signingInfo ?: return null
            if (signing.hasMultipleSigners()) signing.apkContentsSigners else signing.signingCertificateHistory
        } else {
            info.signatures
        }
        return signatures?.map { sha256Hex(it.toByteArray()) }?.toSet()
    }

    private fun installApk(context: Context, file: File) {
        val installer = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
            setAppPackageName(context.packageName)
            setSize(file.length())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // Android 12+: minta pemasangan tanpa konfirmasi bila sistem mengizinkan (update oleh installer yang sama).
                setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
            }
        }

        val sessionId = installer.createSession(params)
        try {
            installer.openSession(sessionId).use { session ->
                file.inputStream().use { input ->
                    session.openWrite("novanet-update.apk", 0, file.length()).use { output ->
                        input.copyTo(output)
                        session.fsync(output)
                    }
                }

                val intent = Intent(context, UpdateInstallReceiver::class.java).apply {
                    action = ACTION_INSTALL_RESULT
                }
                var flags = PendingIntent.FLAG_UPDATE_CURRENT
                // Sistem harus bisa menambahkan extra (status, intent konfirmasi) ke PendingIntent ini.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) flags = flags or PendingIntent.FLAG_MUTABLE
                val pending = PendingIntent.getBroadcast(context, sessionId, intent, flags)
                session.commit(pending.intentSender)
            }
        } catch (e: Exception) {
            runCatching { installer.abandonSession(sessionId) }
            throw e
        }
    }

    /** Dipanggil [UpdateInstallReceiver] saat sesi pemasangan selesai/gagal/dibatalkan. */
    fun onInstallResult(status: Int, message: String?) {
        val info = installingInfo ?: return
        when (status) {
            PackageInstaller.STATUS_SUCCESS -> {
                installingInfo = null
                _state.value = UpdateState.Idle
            }
            PackageInstaller.STATUS_FAILURE_ABORTED -> {
                installingInfo = null
                _state.value = UpdateState.Failed(info, "Pemasangan dibatalkan. Ketuk Coba Lagi untuk memasang update.")
            }
            else -> {
                installingInfo = null
                _state.value = UpdateState.Failed(
                    info,
                    "Pemasangan gagal${message?.let { ": $it" } ?: " (kode $status)"}"
                )
            }
        }
    }

    /** Hapus sisa file update (mis. setelah update berhasil). Dipanggil saat aplikasi dibuka. */
    fun cleanup(context: Context) {
        if (isBusy()) return
        scope.launch {
            runCatching { File(context.cacheDir, UPDATES_DIR).deleteRecursively() }
        }
    }

    // ------------------------------------------------------------------
    // UTIL
    // ------------------------------------------------------------------

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

    private fun sha256Hex(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).toHex()

    private fun sha256Hex(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read == -1) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().toHex()
    }
}
