package com.example

import android.app.Application
import com.example.service.NotificationHelper

/**
 * Semua notification channel didaftarkan di sini, begitu proses aplikasi hidup
 * (dibuka user, di-boot, dibangunkan FCM, atau listener ter-bind) — bukan
 * menunggu notifikasi pertama muncul. Sebelumnya channel "Popup Pembayaran"
 * baru dibuat saat pesan FCM pertama tiba, sehingga di Info Aplikasi belum ada
 * kategori notifikasi/pop-up yang bisa diatur user.
 */
class NovanetApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.ensureChannels(this)
    }
}
