package com.example.data.pref

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Penyimpanan sesi login (session cookie & API key) - dua-duanya setara
 * kunci penuh ke akun pembayaran DANA Bisnis milik pengguna, jadi WAJIB
 * dienkripsi di storage, bukan SharedPreferences biasa yang cuma XML
 * plain-text (bisa dibaca langsung di HP root atau lewat ADB backup).
 *
 * Dilindungi 2 lapis:
 * 1) EncryptedSharedPreferences (AndroidX Security) - key & value dienkripsi
 *    pakai kunci yang disimpan di Android Keystore (tidak pernah keluar dari
 *    hardware-backed keystore chip), bukan cuma "disamarkan".
 * 2) android:allowBackup="false" di manifest supaya file preferensinya sendiri
 *    tidak pernah ikut ke-backup (ADB backup / auto cloud backup).
 */
class AppPreferences(context: Context) {
    private val appContext = context.applicationContext
    private val prefs: SharedPreferences = openEncryptedPrefs(appContext)

    val baseUrl: String = "https://novanet.uno"

    var isLoggedIn: Boolean
        get() = prefs.getBoolean(KEY_IS_LOGGED_IN, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_LOGGED_IN, value).apply()

    var sessionCookie: String
        get() = prefs.getString(KEY_SESSION_COOKIE, "") ?: ""
        set(value) = prefs.edit().putString(KEY_SESSION_COOKIE, value).apply()

    var username: String
        get() = prefs.getString(KEY_USERNAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_USERNAME, value).apply()

    var userId: String
        get() = prefs.getString(KEY_USER_ID, "") ?: ""
        set(value) = prefs.edit().putString(KEY_USER_ID, value).apply()

    var apiKey: String
        get() = prefs.getString(KEY_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_API_KEY, value).apply()

    var userCreatedAt: String
        get() = prefs.getString(KEY_USER_CREATED_AT, "") ?: ""
        set(value) = prefs.edit().putString(KEY_USER_CREATED_AT, value).apply()

    var avatarUrl: String
        get() = prefs.getString(KEY_AVATAR_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_AVATAR_URL, value).apply()

    var fcmToken: String
        get() = prefs.getString(KEY_FCM_TOKEN, "") ?: ""
        set(value) = prefs.edit().putString(KEY_FCM_TOKEN, value).apply()



    var targetPackage: String
        get() = prefs.getString(KEY_TARGET_PACKAGE, "id.dana") ?: "id.dana"
        set(value) = prefs.edit().putString(KEY_TARGET_PACKAGE, value).apply()


    var ttsAlertEnabled: Boolean
        get() = prefs.getBoolean(KEY_TTS_ALERT, false)
        set(value) = prefs.edit().putBoolean(KEY_TTS_ALERT, value).apply()

    var paymentAlertEnabled: Boolean
        // Default NYALA: pop-up pembayaran adalah fungsi inti aplikasi. Sebelumnya default-nya
        // mati, sehingga pop-up lokal tidak pernah muncul kecuali user menemukan togelnya sendiri.
        // Pilihan eksplisit user (sudah pernah menyentuh togel) tetap dihormati.
        get() = prefs.getBoolean(KEY_PAYMENT_ALERT, true)
        set(value) = prefs.edit().putBoolean(KEY_PAYMENT_ALERT, value).apply()


    var keepAliveEnabled: Boolean
        // Default MATI: pertama kali aplikasi dipasang, layanan 24/7 tidak
        // langsung hidup. Pengguna menyalakannya sendiri lewat halaman Pengaturan.
        get() = prefs.getBoolean(KEY_KEEP_ALIVE, false)
        set(value) = prefs.edit().putBoolean(KEY_KEEP_ALIVE, value).apply()

    /** True bila pengguna pernah mengubah toggle background secara eksplisit. */
    val keepAliveConfigured: Boolean
        get() = prefs.contains(KEY_KEEP_ALIVE)

    /**
     * Watchdog (WorkManager, cek tiap ±15 menit) — default NYALA begitu
     * Layanan Latar Belakang (24/7) diaktifkan, tapi pengguna boleh
     * mematikannya sendiri secara terpisah lewat togel di Pengaturan kalau
     * memang tidak mau ada auto-restart berkala.
     */
    var watchdogEnabled: Boolean
        get() = prefs.getBoolean(KEY_WATCHDOG_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_WATCHDOG_ENABLED, value).apply()

    fun clearSession() {
        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, false)
            .remove(KEY_SESSION_COOKIE)
            .remove(KEY_USERNAME)
            .remove(KEY_USER_ID)
            .remove(KEY_API_KEY)
            .remove(KEY_USER_CREATED_AT)
            .remove(KEY_AVATAR_URL)
            .remove(KEY_FCM_TOKEN)
            .apply()
    }

    companion object {
        private const val TAG = "AppPreferences"
        private const val LEGACY_PREFS_NAME = "novanet_gateway_prefs"
        private const val SECURE_PREFS_NAME = "novanet_gateway_prefs_secure"

        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_SESSION_COOKIE = "session_cookie"
        private const val KEY_USERNAME = "username"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_API_KEY = "api_key"
        private const val KEY_USER_CREATED_AT = "user_created_at"
        private const val KEY_AVATAR_URL = "avatar_url"
        private const val KEY_FCM_TOKEN = "fcm_token"
        private const val KEY_TARGET_PACKAGE = "target_package"
        private const val KEY_TTS_ALERT = "tts_alert"
        private const val KEY_PAYMENT_ALERT = "payment_alert"
        private const val KEY_KEEP_ALIVE = "keep_alive"
        private const val KEY_WATCHDOG_ENABLED = "watchdog_enabled"

        /**
         * Buka (atau buat) EncryptedSharedPreferences. Kalau file terenkripsi
         * sebelumnya sudah ada, coba migrasi isi lama dari file plain-text
         * (versi APK sebelum fix ini) sekali saja supaya pengguna lama tidak
         * mendadak ter-logout. File plain-text lama langsung dihapus isinya
         * setelah berhasil dipindah, tidak pernah dibiarkan menggantung.
         *
         * Kalau proses baca/tulis EncryptedSharedPreferences gagal (mis. kunci
         * di Android Keystore rusak/hilang setelah restore OS - kasus nyata
         * yang pernah dilaporkan di beberapa perangkat), file terenkripsi yang
         * korup dihapus lalu dibuat ulang dari nol daripada membuat aplikasi
         * crash terus-menerus tiap dibuka. Konsekuensinya cuma pengguna perlu
         * login ulang, bukan kehilangan data pembayaran (semua data transaksi
         * ada di server, bukan di APK).
         */
        private fun openEncryptedPrefs(context: Context): SharedPreferences {
            return try {
                val masterKey = MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build()
                val encrypted = EncryptedSharedPreferences.create(
                    context,
                    SECURE_PREFS_NAME,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
                migrateLegacyPrefsIfNeeded(context, encrypted)
                encrypted
            } catch (e: Exception) {
                Log.w(TAG, "EncryptedSharedPreferences rusak/tidak bisa dibuka, membuat ulang dari nol", e)
                try {
                    context.deleteSharedPreferences(SECURE_PREFS_NAME)
                    val masterKey = MasterKey.Builder(context)
                        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                        .build()
                    EncryptedSharedPreferences.create(
                        context,
                        SECURE_PREFS_NAME,
                        masterKey,
                        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                    )
                } catch (e2: Exception) {
                    // Upaya terakhir: jangan sampai APK ini gagal total dibuka hanya
                    // karena storage sesi bermasalah. Fallback ke SharedPreferences
                    // biasa (tidak terenkripsi) supaya aplikasi tetap bisa dipakai;
                    // ini jauh lebih jarang terjadi daripada kasus normal di atas.
                    Log.e(TAG, "Gagal total membuat EncryptedSharedPreferences, fallback ke penyimpanan biasa", e2)
                    context.getSharedPreferences(SECURE_PREFS_NAME, Context.MODE_PRIVATE)
                }
            }
        }

        private fun migrateLegacyPrefsIfNeeded(context: Context, encrypted: SharedPreferences) {
            if (encrypted.contains(KEY_IS_LOGGED_IN)) return // sudah pernah migrasi/dipakai
            try {
                val legacy = context.getSharedPreferences(LEGACY_PREFS_NAME, Context.MODE_PRIVATE)
                if (legacy.all.isEmpty()) return
                val editor = encrypted.edit()
                for ((key, value) in legacy.all) {
                    when (value) {
                        is String -> editor.putString(key, value)
                        is Boolean -> editor.putBoolean(key, value)
                        is Int -> editor.putInt(key, value)
                        is Long -> editor.putLong(key, value)
                        is Float -> editor.putFloat(key, value)
                    }
                }
                editor.apply()
                // Hapus file plain-text lama - data sensitif tidak boleh ada
                // dua salinan (satu terenkripsi, satu masih plain-text).
                legacy.edit().clear().apply()
            } catch (e: Exception) {
                Log.w(TAG, "Migrasi preferensi lama gagal, lanjut pakai storage terenkripsi kosong", e)
            }
        }
    }
}
