package com.example.data.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class NovanetUser(
    val id: String,
    val username: String,
    val apiKey: String,
    val createdAt: String? = null,
    val avatarUrl: String? = null
)

data class NovanetStats(
    val totalTransactions: Int = 0,
    val paid: Int = 0,
    val pending: Int = 0,
    val expired: Int = 0,
    val cancelled: Int = 0,
    val invalid: Int = 0,
    val revenue: Long = 0L
)

data class NovanetApiTransaction(
    val id: String,
    val reference: String?,
    val baseAmount: Long,
    val uniqueAmount: Long,
    val status: String,
    val createdAt: String?,
    val updatedAt: String? = null
)

/** Notifikasi DANA yang masuk tapi gagal auto-match ke transaksi pending manapun. */
data class NovanetUnmatchedNotification(
    val id: String,
    val amount: Long,
    val rawText: String?,
    val receivedAt: String?,
    val closestPendingId: String?,
    val closestPendingDiff: Long?
)

/** Info rilis APK terbaru di server (GET /api/app/latest). */
data class AppUpdateInfo(
    val versionCode: Long,
    val versionName: String,
    val notes: String,
    val sha256: String,
    val sizeBytes: Long
)

data class ApiResult<T>(
    val isSuccess: Boolean,
    val data: T? = null,
    val errorMessage: String? = null,
    val sessionCookie: String? = null
)

private fun JSONObject.readAvatarUrl(): String? {
    listOf("avatar_url", "avatarUrl", "avatar", "profile_image", "profileImage", "photo_url", "photo")
        .forEach { key ->
            optString(key, "").trim().takeIf { it.isNotBlank() }?.let { return it }
        }
    return null
}

private fun JSONObject.optNullableString(name: String): String? {
    return if (has(name) && !isNull(name)) getString(name) else null
}

object NovanetApiClient {
    private const val BASE_URL = "https://novanet.uno"
    private val JSON_TYPE = "application/json; charset=utf-8".toMediaType()

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    /** Alamat unduh APK versi tertentu — dipakai AppUpdater. */
    fun appDownloadUrl(versionCode: Long): String = "$BASE_URL/api/app/download/$versionCode"

    /** Versi APK terbaru di server. data == null berarti belum ada APK yang di-upload. */
    suspend fun getLatestApp(): ApiResult<AppUpdateInfo?> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("$BASE_URL/api/app/latest")
                .get()
                .header("Cache-Control", "no-cache")
                .build()
            client.newCall(req).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext ApiResult<AppUpdateInfo?>(
                        isSuccess = false,
                        errorMessage = "HTTP ${response.code}"
                    )
                }
                val json = JSONObject(body)
                if (!json.optBoolean("available", false)) {
                    return@withContext ApiResult<AppUpdateInfo?>(isSuccess = true, data = null)
                }
                ApiResult<AppUpdateInfo?>(
                    isSuccess = true,
                    data = AppUpdateInfo(
                        versionCode = json.optLong("version_code"),
                        versionName = json.optString("version_name"),
                        notes = json.optString("notes"),
                        sha256 = json.optString("sha256"),
                        sizeBytes = json.optLong("size")
                    )
                )
            }
        } catch (e: Exception) {
            ApiResult<AppUpdateInfo?>(isSuccess = false, errorMessage = e.localizedMessage ?: "Koneksi gagal")
        }
    }

    /** Login pakai ID token Google (didapat dari Credential Manager di LoginScreen).
     *  Server menolak (403) kalau email Google itu belum pernah bikin akun lewat web. */
    suspend fun loginWithGoogle(idToken: String): ApiResult<NovanetUser> = withContext(Dispatchers.IO) {
        try {
            val reqPayload = JSONObject().apply {
                put("idToken", idToken)
            }.toString()

            val req = Request.Builder()
                .url("$BASE_URL/api/auth/google/mobile")
                .post(reqPayload.toRequestBody(JSON_TYPE))
                .header("Content-Type", "application/json")
                .header("User-Agent", "NovanetGateway/1.0 (Android)")
                .build()

            client.newCall(req).execute().use { response ->
                val code = response.code
                val body = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    val errMsg = try {
                        JSONObject(body).optString("error", "Login Google gagal (HTTP $code)")
                    } catch (_: Exception) {
                        "Login Google gagal (HTTP $code)"
                    }
                    return@withContext ApiResult(isSuccess = false, errorMessage = errMsg)
                }

                // Ambil cuma pasangan "npg_session=<token>" dari header Set-Cookie
                // (bukan seluruh string mentah yang masih ada atribut Path/HttpOnly/
                // SameSite ikut nempel), biar aman dipakai ulang sebagai header Cookie
                // di request berikutnya.
                val rawSetCookie = response.header("Set-Cookie") ?: ""
                val setCookieHeader = Regex("""npg_session=[^;]+""").find(rawSetCookie)?.value ?: rawSetCookie

                // Endpoint ini langsung balikin objek user publik di body (id, username,
                // email, api_key, avatar_url, created_at) — beda dari /api/auth/login
                // lama yang perlu fetch /api/profile terpisah buat dapetin api_key.
                val json = JSONObject(body)
                val user = NovanetUser(
                    id = json.optString("id", ""),
                    username = json.optString("username", ""),
                    apiKey = json.optString("api_key", ""),
                    createdAt = json.optNullableString("created_at"),
                    avatarUrl = json.readAvatarUrl()
                )
                return@withContext ApiResult(isSuccess = true, data = user, sessionCookie = setCookieHeader)
            }
        } catch (e: Exception) {
            ApiResult(isSuccess = false, errorMessage = "Tidak dapat terhubung ke server novanet.uno: ${e.localizedMessage}")
        }
    }

    suspend fun getProfile(sessionCookie: String): ApiResult<NovanetUser> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("$BASE_URL/api/profile")
                .get()
                .apply {
                    if (sessionCookie.isNotBlank()) header("Cookie", sessionCookie)
                }
                .build()

            val response = client.newCall(req).execute()
            val body = response.body?.string().orEmpty()
            if (response.isSuccessful && body.isNotBlank()) {
                val json = JSONObject(body)
                val user = NovanetUser(
                    id = json.optString("id", json.optString("user_id", "")),
                    username = json.optString("username", ""),
                    apiKey = json.optString("api_key", ""),
                    createdAt = json.optNullableString("created_at"),
                    avatarUrl = json.readAvatarUrl()
                )
                ApiResult(isSuccess = true, data = user)
            } else {
                ApiResult(isSuccess = false, errorMessage = "Sesi kedaluwarsa atau gagal mengambil profil")
            }
        } catch (e: Exception) {
            ApiResult(isSuccess = false, errorMessage = e.localizedMessage)
        }
    }

    suspend fun getStats(sessionCookie: String): ApiResult<NovanetStats> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("$BASE_URL/api/profile/stats")
                .get()
                .apply {
                    if (sessionCookie.isNotBlank()) header("Cookie", sessionCookie)
                }
                .build()

            val response = client.newCall(req).execute()
            val body = response.body?.string().orEmpty()
            if (response.isSuccessful && body.isNotBlank()) {
                // Backend (GET /api/profile/stats) balikin field-field ini persis:
                // totalTransactions, paid, pending, expired, cancelled, invalid, totalRevenue
                val json = JSONObject(body)
                val stats = NovanetStats(
                    totalTransactions = json.optInt("totalTransactions", 0),
                    paid = json.optInt("paid", 0),
                    pending = json.optInt("pending", 0),
                    expired = json.optInt("expired", 0),
                    cancelled = json.optInt("cancelled", 0),
                    invalid = json.optInt("invalid", 0),
                    revenue = json.optLong("totalRevenue", 0L)
                )
                ApiResult(isSuccess = true, data = stats)
            } else {
                ApiResult(isSuccess = false, errorMessage = "Gagal memuat statistik")
            }
        } catch (e: Exception) {
            ApiResult(isSuccess = false, errorMessage = e.localizedMessage)
        }
    }

    suspend fun getTransactions(sessionCookie: String): ApiResult<List<NovanetApiTransaction>> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("$BASE_URL/api/profile/transactions")
                .get()
                .apply {
                    if (sessionCookie.isNotBlank()) header("Cookie", sessionCookie)
                }
                .build()

            val response = client.newCall(req).execute()
            val body = response.body?.string().orEmpty()
            if (response.isSuccessful && body.isNotBlank()) {
                // Backend (GET /api/profile/transactions) balikin objek
                // { "transactions": [...] }, BUKAN array JSON mentah.
                val array = JSONObject(body).optJSONArray("transactions") ?: JSONArray()
                val list = mutableListOf<NovanetApiTransaction>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        NovanetApiTransaction(
                            id = obj.optString("id", ""),
                            reference = obj.optNullableString("reference"),
                            baseAmount = obj.optLong("base_amount", 0L),
                            uniqueAmount = obj.optLong("unique_amount", 0L),
                            status = obj.optString("status", "pending"),
                            createdAt = obj.optNullableString("created_at"),
                            updatedAt = obj.optNullableString("updated_at")
                        )
                    )
                }
                ApiResult(isSuccess = true, data = list)
            } else {
                ApiResult(isSuccess = false, errorMessage = "Gagal memuat mutasi")
            }
        } catch (e: Exception) {
            ApiResult(isSuccess = false, errorMessage = e.localizedMessage)
        }
    }

    suspend fun sendDanaWebhook(
        apiKey: String,
        amount: Long,
        rawText: String,
        receivedAt: String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(Date())
    ): ApiResult<String> = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("amount", amount)
                put("raw_text", rawText)
                put("received_at", receivedAt)
            }.toString()

            val req = Request.Builder()
                .url("$BASE_URL/api/webhook/dana-notification")
                .post(payload.toRequestBody(JSON_TYPE))
                .header("Content-Type", "application/json")
                .apply {
                    if (apiKey.isNotBlank()) {
                        header("X-Api-Key", apiKey)
                    }
                }
                .build()

            val response = client.newCall(req).execute()
            val code = response.code
            val body = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                ApiResult(isSuccess = true, data = body)
            } else {
                val errMsg = try {
                    JSONObject(body).optString("error", "Webhook gagal (HTTP $code)")
                } catch (_: Exception) {
                    "Webhook gagal (HTTP $code)"
                }
                ApiResult(isSuccess = false, errorMessage = errMsg)
            }
        } catch (e: Exception) {
            ApiResult(isSuccess = false, errorMessage = e.localizedMessage)
        }
    }

    suspend fun postDeviceStatus(
        apiKey: String,
        deviceName: String,
        ipAddress: String,
        batteryPercent: Int,
        appVersion: String? = null,
        fcmRegistered: Boolean? = null
    ): ApiResult<Unit> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext ApiResult(isSuccess = false, errorMessage = "API key kosong, belum login")
        }
        try {
            val payload = JSONObject().apply {
                put("device_name", deviceName)
                put("ip_address", ipAddress)
                put("battery_percent", batteryPercent)
                appVersion?.let { put("app_version", it) }
                fcmRegistered?.let { put("fcm_registered", it) }
            }.toString()

            val req = Request.Builder()
                .url("$BASE_URL/api/device/status")
                .post(payload.toRequestBody(JSON_TYPE))
                .header("Content-Type", "application/json")
                .header("X-Api-Key", apiKey)
                .build()

            val response = client.newCall(req).execute()
            val body = response.body?.string().orEmpty()
            if (response.isSuccessful) {
                ApiResult(isSuccess = true, data = Unit)
            } else {
                val errMsg = try {
                    JSONObject(body).optString("error", "Gagal kirim status device (HTTP ${response.code})")
                } catch (_: Exception) {
                    "Gagal kirim status device (HTTP ${response.code})"
                }
                ApiResult(isSuccess = false, errorMessage = errMsg)
            }
        } catch (e: Exception) {
            ApiResult(isSuccess = false, errorMessage = e.localizedMessage)
        }
    }

    /** Daftar notifikasi DANA yang gagal auto-match — buat kartu "Perlu Dicek Manual" di dashboard. */
    suspend fun getUnmatchedNotifications(apiKey: String): ApiResult<List<NovanetUnmatchedNotification>> =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) {
                return@withContext ApiResult(isSuccess = false, errorMessage = "API key kosong, belum login")
            }
            try {
                val req = Request.Builder()
                    .url("$BASE_URL/api/payment/unmatched")
                    .get()
                    .header("X-Api-Key", apiKey)
                    .build()

                val response = client.newCall(req).execute()
                val body = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    val arr = JSONObject(body).optJSONArray("unmatched") ?: JSONArray()
                    val list = mutableListOf<NovanetUnmatchedNotification>()
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        list.add(
                            NovanetUnmatchedNotification(
                                id = o.optString("id"),
                                amount = o.optLong("amount"),
                                rawText = o.optString("raw_text", null),
                                receivedAt = o.optString("received_at", null),
                                closestPendingId = if (o.has("closest_pending_id")) o.optString("closest_pending_id") else null,
                                closestPendingDiff = if (o.has("closest_pending_diff")) o.optLong("closest_pending_diff") else null
                            )
                        )
                    }
                    ApiResult(isSuccess = true, data = list)
                } else {
                    val errMsg = try {
                        JSONObject(body).optString("error", "Gagal mengambil daftar tak cocok (HTTP ${response.code})")
                    } catch (_: Exception) {
                        "Gagal mengambil daftar tak cocok (HTTP ${response.code})"
                    }
                    ApiResult(isSuccess = false, errorMessage = errMsg)
                }
            } catch (e: Exception) {
                ApiResult(isSuccess = false, errorMessage = e.localizedMessage)
            }
        }

    /** Buang satu entri unmatched dari daftar setelah dicocokkan manual. */
    suspend fun dismissUnmatchedNotification(apiKey: String, id: String): ApiResult<Unit> =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank() || id.isBlank()) {
                return@withContext ApiResult(isSuccess = false, errorMessage = "Parameter tidak lengkap")
            }
            try {
                val req = Request.Builder()
                    .url("$BASE_URL/api/payment/unmatched/$id/dismiss")
                    .post("".toRequestBody(JSON_TYPE))
                    .header("X-Api-Key", apiKey)
                    .build()
                val response = client.newCall(req).execute()
                if (response.isSuccessful) ApiResult(isSuccess = true, data = Unit)
                else ApiResult(isSuccess = false, errorMessage = "Gagal membuang entri (HTTP ${response.code})")
            } catch (e: Exception) {
                ApiResult(isSuccess = false, errorMessage = e.localizedMessage)
            }
        }

    suspend fun registerFcmToken(apiKey: String, token: String): ApiResult<Unit> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || token.isBlank()) return@withContext ApiResult(false, errorMessage = "API key/token kosong")
        try {
            val payload = JSONObject().put("token", token).toString()
            val req = Request.Builder()
                .url("$BASE_URL/api/device/fcm-token")
                .post(payload.toRequestBody(JSON_TYPE))
                .header("Content-Type", "application/json")
                .header("X-Api-Key", apiKey)
                .header("User-Agent", "NovanetGateway/1.0 (Android)")
                .build()
            client.newCall(req).execute().use { response ->
                if (response.isSuccessful) {
                    ApiResult(isSuccess = true, data = Unit)
                } else {
                    val errBody = response.body?.string().orEmpty()
                    val errMsg = try {
                        JSONObject(errBody).optString("error", "Gagal mendaftarkan FCM (HTTP ${response.code})")
                    } catch (_: Exception) {
                        "Gagal mendaftarkan FCM (HTTP ${response.code})"
                    }
                    ApiResult(isSuccess = false, errorMessage = errMsg)
                }
            }
        } catch (e: Exception) {
            ApiResult(false, errorMessage = e.localizedMessage)
        }
    }

    suspend fun removeFcmToken(apiKey: String, token: String): ApiResult<Unit> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || token.isBlank()) return@withContext ApiResult(false)
        try {
            val payload = JSONObject().put("token", token).toString()
            val req = Request.Builder()
                .url("$BASE_URL/api/device/fcm-token")
                .delete(payload.toRequestBody(JSON_TYPE))
                .header("Content-Type", "application/json")
                .header("X-Api-Key", apiKey)
                .build()
            client.newCall(req).execute().use { response ->
                ApiResult(response.isSuccessful, data = if (response.isSuccessful) Unit else null)
            }
        } catch (e: Exception) {
            ApiResult(false, errorMessage = e.localizedMessage)
        }
    }

    /**
     * Mode uji: tandai satu transaksi pending sebagai lunas tanpa perlu
     * notifikasi DANA asli. Sama seperti endpoint POST /api/payment/manual-paid/:id
     * di server novanet.uno — butuh X-Api-Key, dan server yang otomatis
     * mengirim webhook "paid" ke integrasi merchant begitu berhasil.
     */
    suspend fun markPaidTest(apiKey: String, transactionId: String): ApiResult<String> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("$BASE_URL/api/payment/manual-paid/$transactionId")
                .post("{}".toRequestBody(JSON_TYPE))
                .header("X-Api-Key", apiKey)
                .header("Content-Type", "application/json")
                .build()
            val response = client.newCall(req).execute()
            val body = response.body?.string().orEmpty()
            if (response.isSuccessful) ApiResult(true, body)
            else ApiResult(false, errorMessage = "Gagal menandai lunas (HTTP ${response.code})")
        } catch (e: Exception) {
            ApiResult(false, errorMessage = e.localizedMessage ?: "Koneksi gagal")
        }
    }

    suspend fun logout(sessionCookie: String): ApiResult<Unit> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("$BASE_URL/api/auth/logout")
                .post("{}".toRequestBody(JSON_TYPE))
                .apply {
                    if (sessionCookie.isNotBlank()) header("Cookie", sessionCookie)
                }
                .build()
            client.newCall(req).execute()
            ApiResult(isSuccess = true, data = Unit)
        } catch (e: Exception) {
            ApiResult(isSuccess = true, data = Unit)
        }
    }
}
