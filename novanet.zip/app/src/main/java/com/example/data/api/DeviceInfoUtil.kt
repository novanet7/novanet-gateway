package com.example.data.api

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import java.net.NetworkInterface
import java.util.Collections

/**
 * Ambil info device buat dikirim ke POST /api/device/status. Semua best-effort:
 * kalau gagal, balikin nilai fallback yang aman (bukan exception) supaya
 * heartbeat tetap bisa jalan walau salah satu info gak kebaca.
 */
object DeviceInfoUtil {

    fun deviceName(): String {
        // MODEL biasanya berisi kode internal (contoh: SM-A556E), sedangkan
        // BRAND/MANUFACTURER berisi merek yang benar-benar dikenal pengguna.
        // Pakai BRAND lebih dulu karena pada beberapa perangkat OEM nilai
        // MANUFACTURER dapat berupa nama vendor/platform, bukan merek produk.
        val model = Build.MODEL.trim().ifBlank { "Android" }
        val brand = Build.BRAND.trim().ifBlank { Build.MANUFACTURER.trim() }
        val normalizedBrand = brand
            .replace('_', ' ')
            .replace('-', ' ')
            .trim()
            .lowercase()
            .replaceFirstChar { it.titlecase() }
        return if (normalizedBrand.isNotBlank() &&
            !model.startsWith(normalizedBrand, ignoreCase = true) &&
            normalizedBrand.lowercase() !in setOf("unknown", "generic", "android")) {
            "$normalizedBrand $model"
        } else {
            model
        }
    }

    fun batteryPercent(context: Context): Int {
        return try {
            val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = context.registerReceiver(null, intentFilter)
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (level >= 0 && scale > 0) ((level * 100) / scale) else -1
        } catch (_: Exception) {
            -1
        }
    }

    fun appVersion(context: Context): String {
        return try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "unknown"
        } catch (_: Exception) { "unknown" }
    }

    /** Alamat IP lokal (WiFi/data) perangkat, buat ditampilkan di dashboard. */
    fun localIpAddress(): String {
        return try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                val addrs = Collections.list(intf.inetAddresses)
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress && addr.hostAddress?.contains(":") == false) {
                        return addr.hostAddress ?: "unknown"
                    }
                }
            }
            "unknown"
        } catch (_: Exception) {
            "unknown"
        }
    }
}
