package com.example.service

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import com.example.data.api.DeviceInfoUtil
import com.example.data.api.NovanetApiClient
import com.example.data.pref.AppPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.cancel
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class DanaNotificationListenerService : NotificationListenerService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false

    override fun onCreate() {
        super.onCreate()
        initTts()
        NotificationHelper.ensureChannels(this)
        loadPersistedDedupCache()
        startPendingQueueRetry()
    }

    private fun initTts() {
        try {
            textToSpeech = TextToSpeech(applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val result = textToSpeech?.setLanguage(Locale("id", "ID"))
                    isTtsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                            result != TextToSpeech.LANG_NOT_SUPPORTED
                }
            }
        } catch (_: Exception) {
            isTtsReady = false
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        _isServiceConnected.value = true
        // Backup layer: begitu listener (re)connect, ada kemungkinan notifikasi
        // pembayaran sudah masuk SEBELUM listener ini tersambung (mis. baru
        // saja rebind setelah sempat terputus) sehingga onNotificationPosted()
        // tidak pernah dipanggil untuk notifikasi itu. Pindai notifikasi yang
        // MASIH ada di shade sekarang supaya tidak ada pembayaran yang lolos.
        scanActiveNotifications()
        startActiveNotificationRescan()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        _isServiceConnected.value = false
        rescanJob?.cancel()
        rescanJob = null
        // Sistem kadang meng-unbind listener ini diam-diam (RAM rendah, OEM
        // agresif, dsb.) dan jadwal rebind otomatis Android sendiri bisa
        // lambat. Minta rebind lebih cepat daripada menunggu WatchdogWorker
        // (yang baru jalan tiap ±15 menit).
        reconnectHandler.removeCallbacksAndMessages(null)
        reconnectHandler.postDelayed({
            requestRebindSafely(applicationContext)
        }, LISTENER_REBIND_DELAY_MS)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return
        processStatusBarNotification(sbn)
    }

    /**
     * Logika parse + dispatch bersama, dipakai baik oleh callback normal
     * (onNotificationPosted, real-time) maupun oleh pemindaian cadangan
     * (scanActiveNotifications, dipanggil saat listener connect/reconnect
     * dan berkala) supaya perilakunya identik di kedua jalur.
     */
    private fun processStatusBarNotification(sbn: StatusBarNotification) {
        val pkgName = sbn.packageName ?: ""
        val notification = sbn.notification ?: return

        // Never process notifications emitted by this listener application itself.
        // This remains safe even if the configured target package is changed later.
        if (pkgName.equals(applicationContext.packageName, ignoreCase = true)) return

        // Android (atau DANA sendiri) bisa membuat SATU notifikasi "ringkasan"
        // yang menggabungkan beberapa notifikasi individual jadi satu (FLAG_GROUP_SUMMARY) —
        // isinya gabungan beberapa baris transaksi lama+baru. Kalau ini ikut
        // diparse, satu ringkasan bisa kebaca sebagai pembayaran baru
        // (biasanya nominal transaksi PALING AWAL di grup itu), padahal
        // masing-masing notifikasi individunya SUDAH diproses sendiri-sendiri
        // lewat pemanggilan onNotificationPosted() yang terpisah. Abaikan
        // ringkasan grup ini sepenuhnya supaya tidak jadi transaksi hantu.
        if (notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        // Jaring pengaman tambahan: kalau notifikasi ini SANGAT tua (leftover
        // dari jauh sebelumnya, mis. masih nangkring di shade berhari-hari),
        // abaikan sepenuhnya — tidak ada gunanya dikirim sama sekali. Batas
        // ini SENGAJA dilonggarkan (dari semula 10 menit) karena perlindungan
        // utama terhadap "notifikasi lama salah melunasi transaksi baru"
        // sekarang ada di SERVER (waktu posting notifikasi dibandingkan
        // dengan created_at transaksi — lihat findPendingByAmount di
        // backend), bukan di sini lagi. Filter umur di APK ini kini murni
        // buat efisiensi (skip notifikasi basi supaya tidak buang-buang
        // request), bukan lapisan keamanan.
        val notificationAgeMs = System.currentTimeMillis() - notification.`when`
        if (notification.`when` > 0L && notificationAgeMs > MAX_NOTIFICATION_AGE_MS) return

        // Waktu ASLI notifikasi ini muncul di HP — dikirim ke server sebagai
        // posted_at, acuan waktu yang sah untuk matching (beda dari waktu
        // APK selesai memproses/mengirim, yang bisa telat kalau masuk retry
        // queue). Fallback ke waktu sekarang kalau `when` tidak valid (jarang
        // terjadi, tapi beberapa OEM/ROM bisa mengirim 0).
        val postedAtMs = if (notification.`when` > 0L) notification.`when` else System.currentTimeMillis()

        val extras = notification.extras ?: return

        val title = extras.getString(Notification.EXTRA_TITLE)
            ?: extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            ?: ""

        val textParts = buildList {
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.let(::add)
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.let(::add)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
                    ?.joinToString(" ")
                    ?.let(::add)
            }
            notification.tickerText?.toString()?.let(::add)
            extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.let(::add)
        }.distinct().joinToString(" ")

        val prefs = AppPreferences(applicationContext)
        val targetPkg = prefs.targetPackage.trim()

        // Strict package allowlist: only the configured package may be processed.
        // The default is id.dana; do not use contains(), because unrelated
        // packages can also include the word "dana" in their package name.
        val isTarget = targetPkg.isNotEmpty() &&
                pkgName.equals(targetPkg, ignoreCase = true)

        if (!isTarget) return

        // Parse notification
        val parsed = DanaNotificationParser.parse(title, textParts)
        if (!parsed.isValid) return

        _lastNotificationInfo.value = "${parsed.amountFormatted} dari ${parsed.sender}"

        serviceScope.launch {
            handleReceivedPayment(parsed, pkgName, prefs, sbn.key, postedAtMs)
        }
    }

    /**
     * Pindai notifikasi yang MASIH aktif di shade sekarang lewat
     * getActiveNotifications() dan proses ulang lewat jalur yang sama
     * seperti onNotificationPosted(). Ini lapisan cadangan: kalau
     * onNotificationPosted() sempat tidak terpanggil untuk satu notifikasi
     * (mis. listener baru saja rebind setelah sempat unbind di tengah jalan),
     * notifikasi itu tetap akan terbaca di sini selama masih tampil di shade.
     * Aman dipanggil berkali-kali — deduplikasi tetap lewat mekanisme yang
     * sama di handleReceivedPayment (kunci judul+isi, window 5 menit).
     */
    private fun scanActiveNotifications() {
        try {
            val active = activeNotifications ?: return
            for (sbn in active) {
                processStatusBarNotification(sbn)
            }
        } catch (_: Exception) {
            // getActiveNotifications() bisa throw kalau listener belum benar-benar
            // ter-bind ke sistem; abaikan saja, giliran berikutnya akan coba lagi.
        }
    }

    private var rescanJob: Job? = null

    /** Ulangi scanActiveNotifications() berkala sebagai jaring pengaman tambahan. */
    private fun startActiveNotificationRescan() {
        if (rescanJob?.isActive == true) return
        rescanJob = serviceScope.launch {
            while (true) {
                delay(ACTIVE_NOTIFICATION_RESCAN_MS)
                scanActiveNotifications()
            }
        }
    }

    // Dedup untuk mencegah satu notifikasi Android diproses dua kali.
    // Tidak ada transaksi yang disimpan di storage lokal; riwayat sepenuhnya berasal dari server.
    // Cache ini SEKARANG dipersist ke SharedPreferences (lihat loadPersistedDedupCache /
    // persistDedupCache) - sebelumnya hanya di memori, jadi ke-reset tiap kali proses
    // service ini restart (app di-update, di-kill sistem, reboot, watchdog rebind, dsb).
    // Akibatnya notifikasi DANA lama yang masih ada di shade dan ikut terbaca ulang oleh
    // scanActiveNotifications() saat listener baru connect, dianggap "baru" lagi karena
    // cache-nya kosong, lalu tercatat sebagai pembayaran valid untuk kedua kalinya.
    private val paymentMutex = Mutex()
    private val recentNotificationKeys = LinkedHashMap<String, Long>()
    private val DEDUP_WINDOW_MS = 30 * 60 * 1000L

    private fun loadPersistedDedupCache() {
        try {
            val store = getSharedPreferences(DEDUP_PREFS, Context.MODE_PRIVATE)
            val obj = JSONObject(store.getString(DEDUP_KEY, "{}") ?: "{}")
            val now = System.currentTimeMillis()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val ts = obj.optLong(key, 0L)
                if (ts > 0L && now - ts <= DEDUP_WINDOW_MS) {
                    recentNotificationKeys[key] = ts
                }
            }
        } catch (_: Exception) {
            // Cache korup/tidak terbaca - aman untuk mulai dari kosong, worst case
            // beberapa notifikasi lama sempat diproses ulang sekali lagi.
        }
    }

    private fun persistDedupCache() {
        try {
            val store = getSharedPreferences(DEDUP_PREFS, Context.MODE_PRIVATE)
            val obj = JSONObject()
            for ((key, ts) in recentNotificationKeys) obj.put(key, ts)
            store.edit().putString(DEDUP_KEY, obj.toString()).apply()
        } catch (_: Exception) { }
    }

    private suspend fun handleReceivedPayment(
        parsed: ParsedDanaPayment,
        pkgName: String,
        prefs: AppPreferences,
        notificationKey: String,
        postedAtMs: Long
    ) {
        val isDuplicate = paymentMutex.withLock {
            val now = System.currentTimeMillis()
            recentNotificationKeys.entries.removeIf { now - it.value > DEDUP_WINDOW_MS }
            // PENTING: sbn.key (notificationKey) ditentukan dari ID/tag notifikasi
            // Android, BUKAN dari isinya. Kalau DANA Bisnis me-reuse slot ID yang
            // sama untuk notifikasi "pembayaran masuk" berikutnya (update notif
            // lama, bukan bikin baru), sbn.key transaksi kedua bisa IDENTIK dengan
            // transaksi pertama yang baru saja lunas — padahal isinya (nominal/
            // pesan) sudah beda. Kalau kunci dedup cuma pakai sbn.key mentah,
            // transaksi kedua ini salah dianggap duplikat dan DIBUANG total
            // (tidak dikirim ke server, tidak masuk antrean retry) sampai window
            // dedup 30 menit di bawah habis. Inilah penyebab verifikasi terasa
            // lambat/nge-jeda setelah membuat transaksi baru tepat setelah
            // transaksi sebelumnya sukses.
            // Fix: gabungkan sbn.key dengan nominal + hash isi pesan, supaya
            // notifikasi dengan isi BERBEDA tetap dianggap event baru walau ID
            // sistemnya sama, sementara notifikasi yang benar-benar SAMA persis
            // (mis. terbaca ulang oleh scanActiveNotifications) tetap dianggap
            // duplikat seperti sebelumnya.
            val key = if (notificationKey.isNotBlank())
                "$notificationKey|${parsed.amount}|${parsed.rawMessage.hashCode()}"
            else "${parsed.amount}|${parsed.rawTitle}|${parsed.rawMessage}"
            if (recentNotificationKeys.containsKey(key)) true
            else {
                recentNotificationKeys[key] = now
                persistDedupCache()
                false
            }
        }
        if (isDuplicate) return

        // Pop-up & suara HANYA untuk notifikasi yang masih segar. Notifikasi lama yang terbaca
        // ulang (rescan setelah listener connect ulang / jendela dedup habis) tetap dikirim ke
        // server, tapi TIDAK diumumkan lagi seolah-olah pembayaran baru masuk.
        val isFresh = System.currentTimeMillis() - postedAtMs <= LOCAL_ALERT_MAX_AGE_MS
        val alertId = PAYMENT_NOTIFICATION_BASE_ID + (System.currentTimeMillis() % 10000).toInt()

        // Umpan balik lokal tidak menunggu server, TAPI isinya netral: HP ini cuma tahu ada
        // notifikasi DANA masuk — belum tahu apakah cocok dengan permintaan pembayaran pending.
        // Kata "berhasil/terverifikasi" baru dipakai setelah server menjawab matched:true.
        if (isFresh && prefs.paymentAlertEnabled) {
            showPaymentNotification(parsed, alertId, PaymentAlertState.CHECKING)
        }

        if (prefs.apiKey.isBlank()) {
            if (isFresh && prefs.ttsAlertEnabled) {
                speakPaymentAlert("Notifikasi pembayaran ${parsed.amountFormatted} terdeteksi, belum bisa diverifikasi ke server.")
            }
            return
        }

        val result = WebhookDispatcher.dispatchPayment(
            targetUrl = "https://novanet.uno/api/webhook/dana-notification",
            deviceKey = prefs.apiKey,
            headerName = "X-Api-Key",
            amount = parsed.amount,
            amountFormatted = parsed.amountFormatted,
            sender = parsed.sender,
            paymentType = parsed.paymentType,
            rawTitle = parsed.rawTitle,
            rawMessage = parsed.rawMessage,
            timestamp = System.currentTimeMillis(),
            formattedTime = parsed.formattedDate,
            packageName = pkgName,
            notificationKey = notificationKey,
            postedAtMs = postedAtMs
        )
        val verdict = verdictOf(result)
        when (verdict) {
            ServerVerdict.MATCHED -> {
                NovanetApiClient.postDeviceStatus(
                    apiKey = prefs.apiKey,
                    deviceName = DeviceInfoUtil.deviceName(),
                    ipAddress = DeviceInfoUtil.localIpAddress(),
                    batteryPercent = DeviceInfoUtil.batteryPercent(applicationContext).let { if (it < 0) 0 else it }
                )
            }
            // Server SUDAH menerima notifikasinya tapi tidak ada permintaan pending yang cocok
            // (tercatat di tab "Notifikasi" dashboard untuk dicek manual). JANGAN diantre ulang:
            // mengirim ulang notifikasi yang sama beberapa detik kemudian bisa "menyambar"
            // permintaan pending yang baru dibuat sesudahnya dan salah memverifikasinya.
            ServerVerdict.UNMATCHED -> Unit
            // Hanya kegagalan pengiriman yang sebenarnya (jaringan/server error) yang diantre.
            ServerVerdict.FAILED -> enqueuePayment(parsed, pkgName, notificationKey, postedAtMs)
        }

        if (isFresh) {
            if (prefs.paymentAlertEnabled) {
                showPaymentNotification(
                    parsed, alertId,
                    when (verdict) {
                        ServerVerdict.MATCHED -> PaymentAlertState.MATCHED
                        ServerVerdict.UNMATCHED -> PaymentAlertState.UNMATCHED
                        ServerVerdict.FAILED -> PaymentAlertState.FAILED
                    }
                )
            }
            if (prefs.ttsAlertEnabled) {
                speakPaymentAlert(
                    when (verdict) {
                        ServerVerdict.MATCHED ->
                            "Pembayaran ${parsed.amountFormatted} dari ${parsed.sender} berhasil diverifikasi."
                        ServerVerdict.UNMATCHED ->
                            "Ada uang masuk ${parsed.amountFormatted}, tetapi tidak ada permintaan pembayaran yang cocok."
                        ServerVerdict.FAILED ->
                            "Notifikasi pembayaran ${parsed.amountFormatted} terdeteksi, belum bisa diverifikasi ke server."
                    }
                )
            }
        }
    }

    private enum class ServerVerdict { MATCHED, UNMATCHED, FAILED }

    private enum class PaymentAlertState { CHECKING, MATCHED, UNMATCHED, FAILED }

    /**
     * Baca jawaban server. FAILED = pengiriman gagal (HTTP error/jaringan) → boleh dicoba lagi.
     * UNMATCHED = server menerima tapi tidak ada pending yang cocok → final, tidak dicoba lagi.
     * Diparse sebagai JSON (bukan mencari teks `"matched":true`) supaya spasi/urutan field
     * di respons server tidak bisa membuat hasil terbaca salah.
     */
    private fun verdictOf(result: WebhookResult): ServerVerdict {
        if (!result.isSuccess) return ServerVerdict.FAILED
        val body = result.responseBody.orEmpty()
        val matched = try {
            JSONObject(body).optBoolean("matched", false)
        } catch (_: Exception) {
            body.replace(" ", "").contains("\"matched\":true")
        }
        return if (matched) ServerVerdict.MATCHED else ServerVerdict.UNMATCHED
    }

    private fun enqueuePayment(parsed: ParsedDanaPayment, packageName: String, notificationKey: String, postedAtMs: Long) {
        try {
            val store = getSharedPreferences(QUEUE_PREFS, Context.MODE_PRIVATE)
            val current = JSONArray(store.getString(QUEUE_KEY, "[]"))
            if (current.length() >= MAX_QUEUE_SIZE) current.remove(0)
            current.put(JSONObject().apply {
                put("amount", parsed.amount)
                put("amount_formatted", parsed.amountFormatted)
                put("sender", parsed.sender)
                put("payment_type", parsed.paymentType)
                put("raw_title", parsed.rawTitle)
                put("raw_message", parsed.rawMessage)
                put("formatted_time", parsed.formattedDate)
                put("package_name", packageName)
                // Key notifikasi Android asli (sbn.key), dipakai server buat dedup
                // ID = key + waktu posting. Fallback ke kombinasi lama kalau kosong
                // (jarang terjadi, tapi jaga-jaga).
                put("notification_key", notificationKey.ifBlank { "${parsed.amount}|${parsed.rawTitle}|${parsed.rawMessage}" })
                // Waktu ASLI notifikasi muncul — dipertahankan lewat antrean retry
                // supaya percobaan kirim ulang tetap memakai waktu posting yang
                // sama persis (bukan waktu retry-nya), sesuai kontrak matching di
                // server.
                put("posted_at_ms", postedAtMs)
                put("retry_count", 0)
                put("next_retry_at", 0L) // 0 = boleh dicoba di siklus retry berikutnya
            })
            store.edit().putString(QUEUE_KEY, current.toString()).apply()
        } catch (_: Exception) { }
    }

    private fun startPendingQueueRetry() {
        serviceScope.launch {
            while (true) {
                retryPendingQueue()
                delay(QUEUE_RETRY_INTERVAL_MS)
            }
        }
    }

    private suspend fun retryPendingQueue() {
        val apiKey = AppPreferences(applicationContext).apiKey
        if (apiKey.isBlank()) return
        val store = getSharedPreferences(QUEUE_PREFS, Context.MODE_PRIVATE)
        val source = try { JSONArray(store.getString(QUEUE_KEY, "[]")) } catch (_: Exception) { JSONArray() }
        if (source.length() == 0) return
        val now = System.currentTimeMillis()
        val remaining = JSONArray()
        for (i in 0 until source.length()) {
            val item = source.optJSONObject(i) ?: continue

            // Hormati jadwal backoff: item yang jadwal ulangnya belum tiba
            // dibiarkan dulu di antrean tanpa memakai kuota request/percobaan.
            val nextRetryAt = item.optLong("next_retry_at", 0L)
            if (nextRetryAt > now) {
                remaining.put(item)
                continue
            }

            val result = WebhookDispatcher.dispatchPayment(
                targetUrl = "https://novanet.uno/api/webhook/dana-notification",
                deviceKey = apiKey,
                headerName = "X-Api-Key",
                amount = item.optLong("amount"),
                amountFormatted = item.optString("amount_formatted"),
                sender = item.optString("sender"),
                paymentType = item.optString("payment_type"),
                rawTitle = item.optString("raw_title"),
                rawMessage = item.optString("raw_message"),
                timestamp = System.currentTimeMillis(),
                formattedTime = item.optString("formatted_time"),
                packageName = item.optString("package_name"),
                notificationKey = item.optString("notification_key"),
                // Item lama (dari sebelum field ini ada) tidak punya posted_at_ms
                // tersimpan — optLong default ke 0L, WebhookDispatcher lalu
                // fallback sendiri ke `timestamp` (lihat default param-nya).
                postedAtMs = item.optLong("posted_at_ms", 0L).let { if (it > 0L) it else System.currentTimeMillis() }
            )
            // Hanya kegagalan pengiriman yang dicoba lagi; "tidak ada pending yang cocok" itu final.
            if (verdictOf(result) == ServerVerdict.FAILED) {
                // The popup and TTS were already emitted when the DANA
                // notification first arrived; retry only completes the
                // server dispatch and must not alert the user twice.
                val attemptsSoFar = item.optInt("retry_count", 0) + 1
                if (attemptsSoFar >= MAX_RETRY_ATTEMPTS) {
                    // Sudah dicoba berkali-kali (mis. API key dicabut/tidak valid
                    // permanen) - berhenti mencoba supaya tidak menghabiskan
                    // request & baterai selamanya untuk item yang tidak akan
                    // pernah berhasil. Beri tahu operator lewat notifikasi lokal
                    // supaya pembayaran ini tidak hilang diam-diam dan bisa
                    // dicocokkan manual di dashboard.
                    showQueueGiveUpNotification(item)
                } else {
                    item.put("retry_count", attemptsSoFar)
                    item.put("next_retry_at", now + backoffDelayMs(attemptsSoFar))
                    remaining.put(item)
                }
            }
        }
        store.edit().putString(QUEUE_KEY, remaining.toString()).apply()
    }

    /**
     * Exponential backoff: 30s, 1m, 2m, 4m, 8m, 16m, 32m, lalu mentok di
     * MAX_BACKOFF_MS (30 menit) sampai MAX_RETRY_ATTEMPTS tercapai.
     */
    private fun backoffDelayMs(attemptCount: Int): Long {
        val base = QUEUE_RETRY_INTERVAL_MS * (1L shl (attemptCount - 1).coerceAtMost(20))
        return base.coerceAtMost(MAX_BACKOFF_MS)
    }

    private fun showQueueGiveUpNotification(item: JSONObject) {
        try {
            val amountFormatted = item.optString("amount_formatted", "?")
            val sender = item.optString("sender", "-")
            val notificationId = QUEUE_GIVE_UP_NOTIFICATION_BASE_ID +
                (item.hashCode() % 1000).let { if (it < 0) -it else it }
            // Channel "Peringatan Sistem" (terpisah dari "Pembayaran Masuk") supaya peringatan
            // gagal-kirim tetap muncul walau user membisukan pop-up pembayaran biasa.
            NotificationHelper.post(
                this,
                notificationId,
                NotificationHelper.alertBuilder(
                    context = this,
                    channelId = NotificationHelper.CHANNEL_ALERT,
                    title = "⚠️ Gagal kirim ke server",
                    text = "$amountFormatted dari $sender belum tercatat di server",
                    bigText = "$amountFormatted dari $sender gagal dikirim setelah $MAX_RETRY_ATTEMPTS percobaan. " +
                        "Cek koneksi/API key, lalu cocokkan transaksi ini secara manual di dashboard.",
                    requestCode = notificationId,
                    category = NotificationCompat.CATEGORY_ERROR
                ).build()
            )
        } catch (_: Exception) { }
    }

    private fun showPaymentNotification(
        parsed: ParsedDanaPayment,
        notificationId: Int,
        state: PaymentAlertState
    ) {
        try {
            val who = "${parsed.amountFormatted} dari ${parsed.sender}"
            val (title, text, big) = when (state) {
                PaymentAlertState.CHECKING -> Triple(
                    "🔎 Notifikasi pembayaran terdeteksi",
                    "$who — memeriksa ke server...",
                    "$who\n🏦 ${parsed.paymentType}\n🛰️ Memeriksa apakah cocok dengan permintaan pembayaran pending..."
                )
                PaymentAlertState.MATCHED -> Triple(
                    "✅ Pembayaran terverifikasi",
                    "$who cocok dengan permintaan pembayaran",
                    "$who\n🏦 ${parsed.paymentType}\n✅ Cocok dengan permintaan pembayaran pending dan sudah dilunasi di server."
                )
                PaymentAlertState.UNMATCHED -> Triple(
                    "⚠️ Tidak ada permintaan yang cocok",
                    "$who — TIDAK diverifikasi",
                    "$who\n🏦 ${parsed.paymentType}\n⚠️ Tidak ada permintaan pembayaran pending dengan nominal ini, jadi tidak ada transaksi yang dilunasi. Cek tab Notifikasi di dashboard."
                )
                PaymentAlertState.FAILED -> Triple(
                    "📡 Belum terkirim ke server",
                    "$who — belum diverifikasi",
                    "$who\n🏦 ${parsed.paymentType}\n📡 Gagal menghubungi server. Akan dicoba lagi otomatis."
                )
            }
            NotificationHelper.post(
                this,
                notificationId,
                NotificationHelper.alertBuilder(
                    context = this,
                    channelId = NotificationHelper.CHANNEL_PAYMENT,
                    title = title,
                    text = text,
                    bigText = big,
                    requestCode = notificationId
                ).build()
            )
        } catch (_: Exception) {}
    }

    private fun speakPaymentAlert(sentence: String) {
        if (!isTtsReady || textToSpeech == null) return
        try {
            textToSpeech?.speak(sentence, TextToSpeech.QUEUE_FLUSH, null, "dana_alert_${System.currentTimeMillis()}")
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        reconnectHandler.removeCallbacksAndMessages(null)
        rescanJob?.cancel()
        rescanJob = null
        serviceScope.cancel()
        super.onDestroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        _isServiceConnected.value = false
    }

    companion object {
        private const val PAYMENT_NOTIFICATION_BASE_ID = 12000
        // Pop-up/suara lokal hanya untuk notifikasi yang usianya di bawah ini (lihat handleReceivedPayment).
        private const val LOCAL_ALERT_MAX_AGE_MS = 5 * 60 * 1000L
        private const val QUEUE_PREFS = "novanet_pending_payment_queue"
        private const val QUEUE_KEY = "items"
        private const val DEDUP_PREFS = "novanet_processed_notification_keys"
        private const val DEDUP_KEY = "keys"
        // Notifikasi yang usianya (Notification.EXTRA "when") lebih tua dari ini
        // saat pertama kali diproses langsung dibuang tanpa dikirim ke server
        // sama sekali — murni buat efisiensi (skip leftover shade lama), BUKAN
        // lapisan keamanan lagi (itu sekarang tugas server, lihat komentar di
        // processStatusBarNotification() & findPendingByAmount di backend).
        private const val MAX_NOTIFICATION_AGE_MS = 24 * 60 * 60 * 1000L
        private const val MAX_QUEUE_SIZE = 100
        private const val QUEUE_RETRY_INTERVAL_MS = 30 * 1000L
        private const val MAX_RETRY_ATTEMPTS = 8
        private const val MAX_BACKOFF_MS = 30 * 60 * 1000L
        private const val QUEUE_GIVE_UP_NOTIFICATION_BASE_ID = 13000
        private const val LISTENER_REBIND_DELAY_MS = 1_500L
        private const val ACTIVE_NOTIFICATION_RESCAN_MS = 5 * 60 * 1000L
        private val reconnectHandler = Handler(Looper.getMainLooper())
        private val _isServiceConnected = MutableStateFlow(false)
        val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()

        private val _lastNotificationInfo = MutableStateFlow<String?>(null)
        val lastNotificationInfo: StateFlow<String?> = _lastNotificationInfo.asStateFlow()

        fun isNotificationAccessGranted(context: Context): Boolean {
            val pkgName = context.packageName
            val flat = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false

            val names = flat.split(":")
            for (name in names) {
                val cn = ComponentName.unflattenFromString(name)
                if (cn != null && cn.packageName == pkgName) {
                    return true
                }
            }
            return false
        }

        /**
         * Minta sistem re-bind service listener ini sekarang juga, dibanding
         * menunggu jadwal rebind otomatis Android yang kadang lambat.
         * requestRebind() butuh Android 7 (N) ke atas dan bisa throw kalau
         * dipanggil dalam kondisi tak terduga - dibungkus try/catch supaya
         * pemanggil (watchdog/listener sendiri) tetap aman kalau gagal.
         */
        fun requestRebindSafely(context: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
            try {
                NotificationListenerService.requestRebind(
                    ComponentName(context, DanaNotificationListenerService::class.java)
                )
            } catch (_: Exception) {
            }
        }
    }
}
