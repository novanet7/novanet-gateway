package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.data.api.DeviceInfoUtil
import com.example.data.api.NovanetApiClient
import com.example.data.pref.AppPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.cancel
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class DanaNotificationListenerService : NotificationListenerService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false

    override fun onCreate() {
        super.onCreate()
        initTts()
        createPaymentNotificationChannel()
        loadPersistedDedupCache()
        startPendingQueueRetry()
    }

    private fun initTts() {
        try {
            textToSpeech = TextToSpeech(applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val result = textToSpeech?.setLanguage(Locale("id", "ID"))
                    isTtsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                            result != TextToSpeech.LANG_NOT_SUPPORTED
                }
            }
        } catch (_: Exception) {
            isTtsReady = false
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        _isServiceConnected.value = true
        // Backup layer: begitu listener (re)connect, ada kemungkinan notifikasi
        // pembayaran sudah masuk SEBELUM listener ini tersambung (mis. baru
        // saja rebind setelah sempat terputus) sehingga onNotificationPosted()
        // tidak pernah dipanggil untuk notifikasi itu. Pindai notifikasi yang
        // MASIH ada di shade sekarang supaya tidak ada pembayaran yang lolos.
        scanActiveNotifications()
        startActiveNotificationRescan()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        _isServiceConnected.value = false
        rescanJob?.cancel()
        rescanJob = null
        // Sistem kadang meng-unbind listener ini diam-diam (RAM rendah, OEM
        // agresif, dsb.) dan jadwal rebind otomatis Android sendiri bisa
        // lambat. Minta rebind lebih cepat daripada menunggu WatchdogWorker
        // (yang baru jalan tiap ±15 menit).
        reconnectHandler.removeCallbacksAndMessages(null)
        reconnectHandler.postDelayed({
            requestRebindSafely(applicationContext)
        }, LISTENER_REBIND_DELAY_MS)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return
        processStatusBarNotification(sbn)
    }

    /**
     * Logika parse + dispatch bersama, dipakai baik oleh callback normal
     * (onNotificationPosted, real-time) maupun oleh pemindaian cadangan
     * (scanActiveNotifications, dipanggil saat listener connect/reconnect
     * dan berkala) supaya perilakunya identik di kedua jalur.
     */
    private fun processStatusBarNotification(sbn: StatusBarNotification) {
        val pkgName = sbn.packageName ?: ""
        val notification = sbn.notification ?: return

        // Never process notifications emitted by this listener application itself.
        // This remains safe even if the configured target package is changed later.
        if (pkgName.equals(applicationContext.packageName, ignoreCase = true)) return

        // Android (atau DANA sendiri) bisa membuat SATU notifikasi "ringkasan"
        // yang menggabungkan beberapa notifikasi individual jadi satu (FLAG_GROUP_SUMMARY) —
        // isinya gabungan beberapa baris transaksi lama+baru. Kalau ini ikut
        // diparse, satu ringkasan bisa kebaca sebagai pembayaran baru
        // (biasanya nominal transaksi PALING AWAL di grup itu), padahal
        // masing-masing notifikasi individunya SUDAH diproses sendiri-sendiri
        // lewat pemanggilan onNotificationPosted() yang terpisah. Abaikan
        // ringkasan grup ini sepenuhnya supaya tidak jadi transaksi hantu.
        if (notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        // Jaring pengaman tambahan: kalau notifikasi ini sudah TUA (jauh lebih
        // tua dari jeda wajar antara pembayaran masuk dan diproses), abaikan.
        // Ini menangkap kasus notifikasi DANA lama yang masih nangkring di
        // shade (belum di-dismiss user/OS) lalu ikut terbaca ulang oleh
        // scanActiveNotifications() saat listener baru (re)connect setelah
        // aplikasi/servicenya sempat restart - tanpa ini, notifikasi lama
        // tsb bisa lolos jadi "pembayaran baru" kalau cache dedup di memori
        // kebetulan juga baru saja ter-reset (mis. proses baru saja mati).
        val notificationAgeMs = System.currentTimeMillis() - notification.`when`
        if (notification.`when` > 0L && notificationAgeMs > MAX_NOTIFICATION_AGE_MS) return

        val extras = notification.extras ?: return

        val title = extras.getString(Notification.EXTRA_TITLE)
            ?: extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            ?: ""

        val textParts = buildList {
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.let(::add)
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.let(::add)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
                    ?.joinToString(" ")
                    ?.let(::add)
            }
            notification.tickerText?.toString()?.let(::add)
            extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.let(::add)
        }.distinct().joinToString(" ")

        val prefs = AppPreferences(applicationContext)
        val targetPkg = prefs.targetPackage.trim()

        // Strict package allowlist: only the configured package may be processed.
        // The default is id.dana; do not use contains(), because unrelated
        // packages can also include the word "dana" in their package name.
        val isTarget = targetPkg.isNotEmpty() &&
                pkgName.equals(targetPkg, ignoreCase = true)

        if (!isTarget) return

        // Parse notification
        val parsed = DanaNotificationParser.parse(title, textParts)
        if (!parsed.isValid) return

        _lastNotificationInfo.value = "${parsed.amountFormatted} dari ${parsed.sender}"

        serviceScope.launch {
            handleReceivedPayment(parsed, pkgName, prefs, sbn.key)
        }
    }

    /**
     * Pindai notifikasi yang MASIH aktif di shade sekarang lewat
     * getActiveNotifications() dan proses ulang lewat jalur yang sama
     * seperti onNotificationPosted(). Ini lapisan cadangan: kalau
     * onNotificationPosted() sempat tidak terpanggil untuk satu notifikasi
     * (mis. listener baru saja rebind setelah sempat unbind di tengah jalan),
     * notifikasi itu tetap akan terbaca di sini selama masih tampil di shade.
     * Aman dipanggil berkali-kali — deduplikasi tetap lewat mekanisme yang
     * sama di handleReceivedPayment (kunci judul+isi, window 5 menit).
     */
    private fun scanActiveNotifications() {
        try {
            val active = activeNotifications ?: return
            for (sbn in active) {
                processStatusBarNotification(sbn)
            }
        } catch (_: Exception) {
            // getActiveNotifications() bisa throw kalau listener belum benar-benar
            // ter-bind ke sistem; abaikan saja, giliran berikutnya akan coba lagi.
        }
    }

    private var rescanJob: Job? = null

    /** Ulangi scanActiveNotifications() berkala sebagai jaring pengaman tambahan. */
    private fun startActiveNotificationRescan() {
        if (rescanJob?.isActive == true) return
        rescanJob = serviceScope.launch {
            while (true) {
                delay(ACTIVE_NOTIFICATION_RESCAN_MS)
                scanActiveNotifications()
            }
        }
    }

    // Dedup untuk mencegah satu notifikasi Android diproses dua kali.
    // Tidak ada transaksi yang disimpan di storage lokal; riwayat sepenuhnya berasal dari server.
    // Cache ini SEKARANG dipersist ke SharedPreferences (lihat loadPersistedDedupCache /
    // persistDedupCache) - sebelumnya hanya di memori, jadi ke-reset tiap kali proses
    // service ini restart (app di-update, di-kill sistem, reboot, watchdog rebind, dsb).
    // Akibatnya notifikasi DANA lama yang masih ada di shade dan ikut terbaca ulang oleh
    // scanActiveNotifications() saat listener baru connect, dianggap "baru" lagi karena
    // cache-nya kosong, lalu tercatat sebagai pembayaran valid untuk kedua kalinya.
    private val paymentMutex = Mutex()
    private val recentNotificationKeys = LinkedHashMap<String, Long>()
    private val DEDUP_WINDOW_MS = 30 * 60 * 1000L

    private fun loadPersistedDedupCache() {
        try {
            val store = getSharedPreferences(DEDUP_PREFS, Context.MODE_PRIVATE)
            val obj = JSONObject(store.getString(DEDUP_KEY, "{}") ?: "{}")
            val now = System.currentTimeMillis()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val ts = obj.optLong(key, 0L)
                if (ts > 0L && now - ts <= DEDUP_WINDOW_MS) {
                    recentNotificationKeys[key] = ts
                }
            }
        } catch (_: Exception) {
            // Cache korup/tidak terbaca - aman untuk mulai dari kosong, worst case
            // beberapa notifikasi lama sempat diproses ulang sekali lagi.
        }
    }

    private fun persistDedupCache() {
        try {
            val store = getSharedPreferences(DEDUP_PREFS, Context.MODE_PRIVATE)
            val obj = JSONObject()
            for ((key, ts) in recentNotificationKeys) obj.put(key, ts)
            store.edit().putString(DEDUP_KEY, obj.toString()).apply()
        } catch (_: Exception) { }
    }

    private suspend fun handleReceivedPayment(
        parsed: ParsedDanaPayment,
        pkgName: String,
        prefs: AppPreferences,
        notificationKey: String
    ) {
        val isDuplicate = paymentMutex.withLock {
            val now = System.currentTimeMillis()
            recentNotificationKeys.entries.removeIf { now - it.value > DEDUP_WINDOW_MS }
            val key = if (notificationKey.isNotBlank()) notificationKey
            else "${parsed.amount}|${parsed.rawTitle}|${parsed.rawMessage}"
            if (recentNotificationKeys.containsKey(key)) true
            else {
                recentNotificationKeys[key] = now
                persistDedupCache()
                false
            }
        }
        if (isDuplicate) return

        // Local feedback must not wait for the webhook/server response.
        // Network latency can be several seconds, while the user expects the
        // Android popup and optional TTS alert immediately after DANA posts a
        // valid notification. Server dispatch continues below in the same
        // background coroutine and does not block this local alert.
        if (prefs.paymentAlertEnabled) {
            showPaymentNotification(parsed, System.currentTimeMillis())
        }
        if (prefs.ttsAlertEnabled) {
            speakPaymentAlert(parsed.amountFormatted, parsed.sender)
        }

        if (prefs.apiKey.isNotBlank()) {
            val result = WebhookDispatcher.dispatchPayment(
                targetUrl = "https://novanet.uno/api/webhook/dana-notification",
                deviceKey = prefs.apiKey,
                headerName = "X-Api-Key",
                amount = parsed.amount,
                amountFormatted = parsed.amountFormatted,
                sender = parsed.sender,
                paymentType = parsed.paymentType,
                rawTitle = parsed.rawTitle,
                rawMessage = parsed.rawMessage,
                timestamp = System.currentTimeMillis(),
                formattedTime = parsed.formattedDate,
                packageName = pkgName,
                notificationKey = notificationKey
            )
            val matched = result.isSuccess && result.responseBody?.contains("\"matched\":true") == true
            if (matched) {
                NovanetApiClient.postDeviceStatus(
                    apiKey = prefs.apiKey,
                    deviceName = DeviceInfoUtil.deviceName(),
                    ipAddress = DeviceInfoUtil.localIpAddress(),
                    batteryPercent = DeviceInfoUtil.batteryPercent(applicationContext).let { if (it < 0) 0 else it }
                )
            } else {
                enqueuePayment(parsed, pkgName)
            }
        }
    }

    private fun enqueuePayment(parsed: ParsedDanaPayment, packageName: String) {
        try {
            val store = getSharedPreferences(QUEUE_PREFS, Context.MODE_PRIVATE)
            val current = JSONArray(store.getString(QUEUE_KEY, "[]"))
            if (current.length() >= MAX_QUEUE_SIZE) current.remove(0)
            current.put(JSONObject().apply {
                put("amount", parsed.amount)
                put("amount_formatted", parsed.amountFormatted)
                put("sender", parsed.sender)
                put("payment_type", parsed.paymentType)
                put("raw_title", parsed.rawTitle)
                put("raw_message", parsed.rawMessage)
                put("formatted_time", parsed.formattedDate)
                put("package_name", packageName)
                put("notification_key", "${parsed.amount}|${parsed.rawTitle}|${parsed.rawMessage}")
                put("retry_count", 0)
                put("next_retry_at", 0L) // 0 = boleh dicoba di siklus retry berikutnya
            })
            store.edit().putString(QUEUE_KEY, current.toString()).apply()
        } catch (_: Exception) { }
    }

    private fun startPendingQueueRetry() {
        serviceScope.launch {
            while (true) {
                retryPendingQueue()
                delay(QUEUE_RETRY_INTERVAL_MS)
            }
        }
    }

    private suspend fun retryPendingQueue() {
        val apiKey = AppPreferences(applicationContext).apiKey
        if (apiKey.isBlank()) return
        val store = getSharedPreferences(QUEUE_PREFS, Context.MODE_PRIVATE)
        val source = try { JSONArray(store.getString(QUEUE_KEY, "[]")) } catch (_: Exception) { JSONArray() }
        if (source.length() == 0) return
        val now = System.currentTimeMillis()
        val remaining = JSONArray()
        for (i in 0 until source.length()) {
            val item = source.optJSONObject(i) ?: continue

            // Hormati jadwal backoff: item yang jadwal ulangnya belum tiba
            // dibiarkan dulu di antrean tanpa memakai kuota request/percobaan.
            val nextRetryAt = item.optLong("next_retry_at", 0L)
            if (nextRetryAt > now) {
                remaining.put(item)
                continue
            }

            val result = WebhookDispatcher.dispatchPayment(
                targetUrl = "https://novanet.uno/api/webhook/dana-notification",
                deviceKey = apiKey,
                headerName = "X-Api-Key",
                amount = item.optLong("amount"),
                amountFormatted = item.optString("amount_formatted"),
                sender = item.optString("sender"),
                paymentType = item.optString("payment_type"),
                rawTitle = item.optString("raw_title"),
                rawMessage = item.optString("raw_message"),
                timestamp = System.currentTimeMillis(),
                formattedTime = item.optString("formatted_time"),
                packageName = item.optString("package_name"),
                notificationKey = item.optString("notification_key")
            )
            val matched = result.isSuccess && result.responseBody?.contains("\"matched\":true") == true
            if (!matched && !result.isSuccess) {
                // The popup and TTS were already emitted when the DANA
                // notification first arrived; retry only completes the
                // server dispatch and must not alert the user twice.
                val attemptsSoFar = item.optInt("retry_count", 0) + 1
                if (attemptsSoFar >= MAX_RETRY_ATTEMPTS) {
                    // Sudah dicoba berkali-kali (mis. API key dicabut/tidak valid
                    // permanen) - berhenti mencoba supaya tidak menghabiskan
                    // request & baterai selamanya untuk item yang tidak akan
                    // pernah berhasil. Beri tahu operator lewat notifikasi lokal
                    // supaya pembayaran ini tidak hilang diam-diam dan bisa
                    // dicocokkan manual di dashboard.
                    showQueueGiveUpNotification(item)
                } else {
                    item.put("retry_count", attemptsSoFar)
                    item.put("next_retry_at", now + backoffDelayMs(attemptsSoFar))
                    remaining.put(item)
                }
            }
        }
        store.edit().putString(QUEUE_KEY, remaining.toString()).apply()
    }

    /**
     * Exponential backoff: 30s, 1m, 2m, 4m, 8m, 16m, 32m, lalu mentok di
     * MAX_BACKOFF_MS (30 menit) sampai MAX_RETRY_ATTEMPTS tercapai.
     */
    private fun backoffDelayMs(attemptCount: Int): Long {
        val base = QUEUE_RETRY_INTERVAL_MS * (1L shl (attemptCount - 1).coerceAtMost(20))
        return base.coerceAtMost(MAX_BACKOFF_MS)
    }

    private fun showQueueGiveUpNotification(item: JSONObject) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED
            ) return
            val amountFormatted = item.optString("amount_formatted", "?")
            val sender = item.optString("sender", "-")
            val openAppIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = android.app.PendingIntent.getActivity(
                this,
                item.hashCode(),
                openAppIntent,
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
            )
            val notification = NotificationCompat.Builder(this, PAYMENT_CHANNEL_ID)
                .setSmallIcon(com.example.R.mipmap.ic_launcher)
                .setContentTitle("⚠️ Gagal kirim ke server")
                .setContentText("$amountFormatted dari $sender belum tercatat di server")
                .setStyle(
                    NotificationCompat.BigTextStyle().bigText(
                        "$amountFormatted dari $sender gagal dikirim setelah $MAX_RETRY_ATTEMPTS percobaan. " +
                            "Cek koneksi/API key, lalu cocokkan transaksi ini secara manual di dashboard."
                    )
                )
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ERROR)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()
            NotificationManagerCompat.from(this).notify(
                QUEUE_GIVE_UP_NOTIFICATION_BASE_ID + (item.hashCode() % 1000).let { if (it < 0) -it else it },
                notification
            )
        } catch (_: Exception) { }
    }
    private fun createPaymentNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            PAYMENT_CHANNEL_ID,
            "Pembayaran Masuk",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Peringatan saat pembayaran DANA berhasil terdeteksi"
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 250, 120, 350)
            setShowBadge(true)
        }
        getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
    }

    private fun showPaymentNotification(parsed: ParsedDanaPayment, transactionId: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED
            ) return

            val openAppIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = android.app.PendingIntent.getActivity(
                this,
                transactionId.toInt(),
                openAppIntent,
                android.app.PendingIntent.FLAG_IMMUTABLE or
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT
            )
            val notification = NotificationCompat.Builder(this, PAYMENT_CHANNEL_ID)
                .setSmallIcon(com.example.R.mipmap.ic_launcher)
                .setContentTitle("💰 Pembayaran terdeteksi")
                .setContentText("✅ ${parsed.amountFormatted} dari ${parsed.sender}")
                .setStyle(
                    NotificationCompat.BigTextStyle().bigText(
                        "✅ ${parsed.amountFormatted} dari ${parsed.sender}\n" +
                            "🏦 ${parsed.paymentType}\n🛰️ Sedang dikirim ke server Novanet..."
                    )
                )
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setShowWhen(true)
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setContentIntent(pendingIntent)
                .build()

            NotificationManagerCompat.from(this).notify(
                PAYMENT_NOTIFICATION_BASE_ID + (transactionId % 10000).toInt(),
                notification
            )
        } catch (_: SecurityException) {
            // Izin POST_NOTIFICATIONS belum diberikan; listener tetap berjalan.
        } catch (_: Exception) {}
    }

    private fun speakPaymentAlert(amountStr: String, sender: String) {
        if (!isTtsReady || textToSpeech == null) return
        try {
            val spokenText = "Pembayaran $amountStr dari $sender berhasil diterima."
            textToSpeech?.speak(spokenText, TextToSpeech.QUEUE_FLUSH, null, "dana_alert_${System.currentTimeMillis()}")
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        reconnectHandler.removeCallbacksAndMessages(null)
        rescanJob?.cancel()
        rescanJob = null
        serviceScope.cancel()
        super.onDestroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        _isServiceConnected.value = false
    }

    companion object {
        private const val PAYMENT_CHANNEL_ID = "novanet_payment_alerts"
        private const val PAYMENT_NOTIFICATION_BASE_ID = 12000
        private const val QUEUE_PREFS = "novanet_pending_payment_queue"
        private const val QUEUE_KEY = "items"
        private const val DEDUP_PREFS = "novanet_processed_notification_keys"
        private const val DEDUP_KEY = "keys"
        // Notifikasi yang usianya (Notification.EXTRA "when") lebih tua dari ini saat
        // pertama kali diproses dianggap basi/leftover dari sesi sebelumnya, bukan
        // pembayaran baru - lihat komentar di processStatusBarNotification().
        private const val MAX_NOTIFICATION_AGE_MS = 10 * 60 * 1000L
        private const val MAX_QUEUE_SIZE = 100
        private const val QUEUE_RETRY_INTERVAL_MS = 30 * 1000L
        private const val MAX_RETRY_ATTEMPTS = 8
        private const val MAX_BACKOFF_MS = 30 * 60 * 1000L
        private const val QUEUE_GIVE_UP_NOTIFICATION_BASE_ID = 13000
        private const val LISTENER_REBIND_DELAY_MS = 1_500L
        private const val ACTIVE_NOTIFICATION_RESCAN_MS = 5 * 60 * 1000L
        private val reconnectHandler = Handler(Looper.getMainLooper())
        private val _isServiceConnected = MutableStateFlow(false)
        val isServiceConnected: StateFlow<Boolean> = _isServiceConnected.asStateFlow()

        private val _lastNotificationInfo = MutableStateFlow<String?>(null)
        val lastNotificationInfo: StateFlow<String?> = _lastNotificationInfo.asStateFlow()

        fun isNotificationAccessGranted(context: Context): Boolean {
            val pkgName = context.packageName
            val flat = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false

            val names = flat.split(":")
            for (name in names) {
                val cn = ComponentName.unflattenFromString(name)
                if (cn != null && cn.packageName == pkgName) {
                    return true
                }
            }
            return false
        }

        /**
         * Minta sistem re-bind service listener ini sekarang juga, dibanding
         * menunggu jadwal rebind otomatis Android yang kadang lambat.
         * requestRebind() butuh Android 7 (N) ke atas dan bisa throw kalau
         * dipanggil dalam kondisi tak terduga - dibungkus try/catch supaya
         * pemanggil (watchdog/listener sendiri) tetap aman kalau gagal.
         */
        fun requestRebindSafely(context: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
            try {
                NotificationListenerService.requestRebind(
                    ComponentName(context, DanaNotificationListenerService::class.java)
                )
            } catch (_: Exception) {
            }
        }
    }
}
