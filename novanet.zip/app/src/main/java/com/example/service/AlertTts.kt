package com.example.service

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * TTS terpusat untuk semua notifikasi (FCM server + alert lokal).
 * - Menghormati pengaturan ttsAlertEnabled di AppPreferences (dicek pemanggil).
 * - Bahasa Indonesia, nada formal, rate & pitch disetel agar jelas.
 * - Instance aman dipanggil dari service / background thread.
 */
object AlertTts {
    private val busy = AtomicBoolean(false)

    /**
     * Bacakan teks formal. Jika masih berbicara, panggilan baru diabaikan
     * agar tidak saling tumpang tindih.
     */
    fun speak(context: Context, text: String) {
        val script = text.trim()
        if (script.isEmpty()) return
        if (!busy.compareAndSet(false, true)) return

        val appCtx = context.applicationContext
        var ttsRef: TextToSpeech? = null

        ttsRef = TextToSpeech(appCtx) { status ->
            val engine = ttsRef
            if (status != TextToSpeech.SUCCESS || engine == null) {
                busy.set(false)
                try {
                    engine?.shutdown()
                } catch (_: Exception) {
                }
                return@TextToSpeech
            }

            try {
                val id = Locale("id", "ID")
                val langResult = engine.setLanguage(id)
                if (langResult == TextToSpeech.LANG_MISSING_DATA ||
                    langResult == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    engine.setLanguage(Locale.getDefault())
                }

                // Nada formal, jelas, sedikit lebih pelan
                engine.setSpeechRate(0.90f)
                engine.setPitch(0.98f)

                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        release(engine)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        release(engine)
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        release(engine)
                    }
                })

                val uttered = engine.speak(
                    script,
                    TextToSpeech.QUEUE_FLUSH,
                    null,
                    "novanet_alert_${System.currentTimeMillis()}"
                )
                if (uttered == TextToSpeech.ERROR) {
                    release(engine)
                }
            } catch (_: Exception) {
                release(engine)
            }
        }
    }

    private fun release(engine: TextToSpeech?) {
        try {
            engine?.stop()
            engine?.shutdown()
        } catch (_: Exception) {
        }
        busy.set(false)
    }
}
