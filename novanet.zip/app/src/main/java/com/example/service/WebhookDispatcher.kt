package com.example.service

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.security.MessageDigest

data class WebhookResult(
    val isSuccess: Boolean,
    val statusCode: Int,
    val responseBody: String?,
    val errorMessage: String? = null,
    val latencyMs: Long = 0
)

object WebhookDispatcher {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    suspend fun dispatchPayment(
        targetUrl: String,
        deviceKey: String,
        headerName: String,
        amount: Long,
        amountFormatted: String,
        sender: String,
        paymentType: String,
        rawTitle: String,
        rawMessage: String,
        timestamp: Long,
        formattedTime: String,
        packageName: String,
        notificationKey: String = "",
        // Waktu ASLI notifikasi itu muncul di HP (Notification.when), BEDA
        // dari `timestamp` di atas (waktu dispatch/kirim ini dieksekusi,
        // yang bisa telat beberapa detik/menit kalau masuk retry queue).
        // Server pakai ini sebagai acuan waktu yang sah untuk matching
        // (lihat komentar di routes/webhook.ts backend). Fallback ke
        // `timestamp` kalau notifikasi tidak punya `when` yang valid.
        postedAtMs: Long = timestamp
    ): WebhookResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        try {
            if (targetUrl.isBlank()) {
                return@withContext WebhookResult(
                    isSuccess = false,
                    statusCode = 0,
                    responseBody = null,
                    errorMessage = "URL Webhook belum diisi di Pengaturan"
                )
            }

            val isNovanet = targetUrl.contains("novanet.uno") || targetUrl.contains("dana-notification")

            val payload = if (isNovanet) {
                JSONObject().apply {
                    put("amount", amount)
                    put("raw_text", "${rawTitle} - ${rawMessage}")
                    put("notification_key", notificationKey)
                    // Dedup ID = key notifikasi + waktu posting (bukan waktu kirim) —
                    // supaya retry/rescan notifikasi yang SAMA tetap dianggap duplikat,
                    // sementara dua notifikasi berbeda waktu posting (walau nominal
                    // sama) tetap dihitung sebagai dua event terpisah.
                    put("event_id", stableEventId(notificationKey, postedAtMs, amount))
                    put("posted_at", isoUtc(postedAtMs))
                    put("received_at", isoUtc(timestamp))
                }.toString()
            } else {
                JSONObject().apply {
                    put("event", "payment_received")
                    put("service", "DANA_BISNIS")
                    put("paymentType", paymentType)
                    put("amount", amount)
                    put("amountFormatted", amountFormatted)
                    put("sender", sender)
                    put("title", rawTitle)
                    put("message", rawMessage)
                    put("timestamp", timestamp)
                    put("formattedTime", formattedTime)
                    put("deviceId", deviceKey)
                    put("packageName", packageName)
                    put("isSimulated", false)
                }.toString()
            }

            val requestBody = payload.toRequestBody(JSON_MEDIA_TYPE)
            val requestBuilder = Request.Builder()
                .url(targetUrl)
                .post(requestBody)
                .header("Content-Type", "application/json")
                .header("User-Agent", "NovanetGateway/1.0 (Android)")

            if (deviceKey.isNotBlank()) {
                requestBuilder.header("X-Api-Key", deviceKey)
                if (headerName.isNotBlank() && headerName != "X-Api-Key") {
                    requestBuilder.header(headerName, deviceKey)
                }
            }

            val response = client.newCall(requestBuilder.build()).execute()
            val latency = System.currentTimeMillis() - startTime
            val code = response.code
            val body = response.body?.string()

            val isSuccess = response.isSuccessful
            WebhookResult(
                isSuccess = isSuccess,
                statusCode = code,
                responseBody = body,
                errorMessage = if (!isSuccess) "Server mengembalikan HTTP $code" else null,
                latencyMs = latency
            )
        } catch (e: Exception) {
            val latency = System.currentTimeMillis() - startTime
            WebhookResult(
                isSuccess = false,
                statusCode = -1,
                responseBody = null,
                errorMessage = e.localizedMessage ?: e.javaClass.simpleName,
                latencyMs = latency
            )
        }
    }

    private fun isoUtc(epochMs: Long): String =
        java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }.format(java.util.Date(epochMs))

    /** ID = key notifikasi + waktu posting, sesuai kontrak dedup di server. */
    private fun stableEventId(notificationKey: String, postedAtMs: Long, amount: Long): String {
        val input = "$notificationKey|$postedAtMs|$amount"
        return MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}
