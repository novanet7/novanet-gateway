package com.example.service

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

/** Kondisi satu notification channel (Android 8+). */
data class ChannelHealth(
    val id: String,
    val label: String,
    /** True bila channel ini memang dimaksudkan untuk pop-up/heads-up. */
    val expectsPopup: Boolean,
    val exists: Boolean,
    val importance: Int
) {
    val blocked: Boolean
        get() = exists && importance == NotificationManager.IMPORTANCE_NONE

    /** Heads-up (pop-up) hanya muncul kalau importance channel = HIGH ke atas. */
    val popupCapable: Boolean
        get() = exists && importance >= NotificationManager.IMPORTANCE_HIGH
}

/** Ringkasan kesehatan sistem notifikasi — dipakai halaman Pengaturan. */
data class NotificationHealth(
    /** Notifikasi aplikasi ini boleh tampil (izin runtime Android 13+ DAN tidak diblokir di setelan HP). */
    val appEnabled: Boolean,
    /** Android 13+: izin runtime POST_NOTIFICATIONS. Di bawah 13 selalu true. */
    val runtimePermissionGranted: Boolean,
    /** Mode Jangan Ganggu / Fokus sedang aktif (bisa menahan pop-up & suara). */
    val dndActive: Boolean,
    /** Kosong di Android 7 (API 24-25), karena belum ada konsep channel. */
    val channels: List<ChannelHealth>
) {
    val popupReady: Boolean
        get() = appEnabled && channels.filter { it.expectsPopup }.all { it.popupCapable }

    companion object {
        val Unknown = NotificationHealth(
            appEnabled = true,
            runtimePermissionGranted = true,
            dndActive = false,
            channels = emptyList()
        )
    }
}

/**
 * Satu-satunya tempat yang membuat channel & memposting notifikasi aplikasi,
 * supaya semua jenis notifikasi (pembayaran terdeteksi, pop-up FCM, peringatan
 * sistem, layanan 24/7) berperilaku seragam di semua versi Android 7 – 16:
 *
 * - API 24-25 : belum ada channel → heads-up ditentukan priority HIGH + defaults
 *               (suara/getar). Ditangani di [alertBuilder].
 * - API 26-32 : heads-up ditentukan IMPORTANCE channel (HIGH). Channel HARUS sudah
 *               terdaftar supaya muncul di Info Aplikasi → dibuat sejak
 *               [com.example.NovanetApp.onCreate], bukan menunggu notifikasi
 *               pertama.
 * - API 33+   : wajib izin runtime POST_NOTIFICATIONS.
 */
object NotificationHelper {

    // ID lama dipertahankan supaya pengaturan channel yang sudah ada di HP user tidak reset.
    const val CHANNEL_PAYMENT = "novanet_payment_alerts"
    const val CHANNEL_FCM = "novanet_fcm_events"
    const val CHANNEL_KEEP_ALIVE = "novanet_keep_alive_channel"

    // Channel baru: peringatan gagal-kirim & layanan berhenti dipisah dari
    // "Pembayaran Masuk" supaya kalau user membisukan pembayaran, peringatan
    // penting ini tidak ikut bisu.
    const val CHANNEL_ALERT = "novanet_system_alerts"

    private const val TEST_ID_BASE = 14000
    private const val TEST_STAGGER_MS = 3500L
    const val ID_SERVICE_TIMEOUT = 9022

    private val VIBRATION = longArrayOf(0, 250, 120, 350)

    private class Spec(
        val id: String,
        val name: String,
        val description: String,
        val importance: Int,
        val popup: Boolean
    )

    private val specs = listOf(
        Spec(
            CHANNEL_PAYMENT, "Pembayaran Masuk",
            "Pop-up saat pembayaran DANA berhasil terdeteksi di HP ini",
            NotificationManager.IMPORTANCE_HIGH, true
        ),
        Spec(
            CHANNEL_FCM, "Popup Pembayaran Novanet",
            "Permintaan pembayaran dan konfirmasi pembayaran Novanet dari server",
            NotificationManager.IMPORTANCE_HIGH, true
        ),
        Spec(
            CHANNEL_ALERT, "Peringatan Sistem",
            "Peringatan penting: gagal kirim ke server, layanan 24/7 berhenti",
            NotificationManager.IMPORTANCE_HIGH, true
        ),
        Spec(
            CHANNEL_KEEP_ALIVE, "Layanan Pemantau DANA 24/7",
            "Notifikasi senyap yang menjaga listener DANA tetap berjalan",
            NotificationManager.IMPORTANCE_LOW, false
        )
    )

    // ------------------------------------------------------------------
    // CHANNEL
    // ------------------------------------------------------------------

    /**
     * Daftarkan semua channel. Idempotent & murah — aman dipanggil berulang
     * (Application.onCreate, tiap service). Channel yang sudah ada TIDAK
     * di-reset: Android hanya memperbarui nama/deskripsinya, pilihan user
     * (suara, importance, blokir) tetap dihormati.
     */
    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        try {
            val nm = context.getSystemService(NotificationManager::class.java) ?: return
            val audio = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            for (spec in specs) {
                val channel = NotificationChannel(spec.id, spec.name, spec.importance).apply {
                    description = spec.description
                    setShowBadge(spec.popup)
                    if (spec.popup) {
                        enableVibration(true)
                        vibrationPattern = VIBRATION
                        enableLights(true)
                        lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                        setSound(Settings.System.DEFAULT_NOTIFICATION_URI, audio)
                    }
                }
                nm.createNotificationChannel(channel)
            }
        } catch (_: Exception) {
            // Jangan sampai pembuatan channel menjatuhkan aplikasi/service.
        }
    }

    // ------------------------------------------------------------------
    // STATUS
    // ------------------------------------------------------------------

    fun health(context: Context): NotificationHealth {
        val app = context.applicationContext
        val runtimeGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            app.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        val appEnabled = try {
            NotificationManagerCompat.from(app).areNotificationsEnabled()
        } catch (_: Exception) {
            runtimeGranted
        }
        val nm = app.getSystemService(NotificationManager::class.java)

        val dnd = try {
            val filter = nm?.currentInterruptionFilter
                ?: NotificationManager.INTERRUPTION_FILTER_UNKNOWN
            filter != NotificationManager.INTERRUPTION_FILTER_ALL &&
                filter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        } catch (_: Exception) {
            false
        }

        val channels = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
            specs.map { spec ->
                val ch = try {
                    nm.getNotificationChannel(spec.id)
                } catch (_: Exception) {
                    null
                }
                ChannelHealth(
                    id = spec.id,
                    label = spec.name,
                    expectsPopup = spec.popup,
                    exists = ch != null,
                    importance = ch?.importance ?: NotificationManager.IMPORTANCE_UNSPECIFIED
                )
            }
        } else {
            emptyList()
        }

        return NotificationHealth(
            appEnabled = appEnabled,
            runtimePermissionGranted = runtimeGranted,
            dndActive = dnd,
            channels = channels
        )
    }

    // ------------------------------------------------------------------
    // MEMBANGUN & MEMPOSTING
    // ------------------------------------------------------------------

    /**
     * Builder standar untuk notifikasi pop-up (heads-up). Di API 26+ sifat
     * pop-up ditentukan channel; di API 24-25 ditentukan priority + defaults
     * di sini.
     */
    fun alertBuilder(
        context: Context,
        channelId: String,
        title: String,
        text: String,
        bigText: String? = null,
        requestCode: Int = 0,
        category: String = NotificationCompat.CATEGORY_MESSAGE
    ): NotificationCompat.Builder {
        val app = context.applicationContext
        val openApp = Intent(app, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            app, requestCode, openApp,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = NotificationCompat.Builder(app, channelId)
            .setSmallIcon(R.drawable.ic_stat_novanet)
            .setColor(ContextCompat.getColor(app, R.color.novanet_notification_accent))
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText ?: text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(category)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setShowWhen(true)
            .setAutoCancel(true)
            .setContentIntent(pending)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            // Android 7.x: tanpa channel, heads-up butuh suara/getar dari defaults.
            builder.setDefaults(NotificationCompat.DEFAULT_ALL)
        }
        return builder
    }

    /**
     * Posting aman: memeriksa izin (Android 13+), menelan SecurityException,
     * dan mengembalikan true hanya bila benar-benar diserahkan ke sistem.
     */
    @SuppressLint("MissingPermission")
    fun post(context: Context, id: Int, notification: Notification): Boolean {
        val app = context.applicationContext
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            app.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) return false
        return try {
            ensureChannels(app)
            NotificationManagerCompat.from(app).notify(id, notification)
            true
        } catch (_: Exception) {
            false
        }
    }

    /** Layanan 24/7 dihentikan Android (batas waktu foreground service dataSync, Android 15+). */
    fun notifyServiceTimeout(context: Context) {
        val n = alertBuilder(
            context = context,
            channelId = CHANNEL_ALERT,
            title = "⏱️ Layanan 24/7 dihentikan Android",
            text = "Buka aplikasi sekali untuk menyalakan layanan latar belakang lagi.",
            bigText = "Android 15+ membatasi layanan latar belakang jenis sinkronisasi data (±6 jam). " +
                "Layanan dihentikan otomatis oleh sistem. Buka aplikasi sekali supaya layanan 24/7 menyala lagi.",
            requestCode = ID_SERVICE_TIMEOUT,
            category = NotificationCompat.CATEGORY_STATUS
        ).build()
        post(context, ID_SERVICE_TIMEOUT, n)
    }

    /**
     * Kirim satu notifikasi uji untuk tiap jenis pop-up (berjeda beberapa detik
     * supaya heads-up-nya tidak saling menimpa). Tidak menyentuh server.
     */
    fun sendTestNotifications(context: Context) {
        val app = context.applicationContext
        ensureChannels(app)
        val handler = Handler(Looper.getMainLooper())
        val tests = listOf(
            Triple(
                CHANNEL_PAYMENT,
                "🔎 [UJI] Notifikasi pembayaran terdeteksi",
                "Rp 10.000 dari Uji Coba — pop-up pembayaran dari HP ini"
            ),
            Triple(
                CHANNEL_FCM,
                "🔔 [UJI] Permintaan pembayaran baru",
                "💰 Rp10.000  •  🧾 Ref: UJI-001 — pop-up dari server Novanet"
            ),
            Triple(
                CHANNEL_ALERT,
                "⚠️ [UJI] Peringatan sistem",
                "Contoh peringatan penting (mis. gagal kirim ke server)"
            )
        )
        tests.forEachIndexed { index, (channel, title, text) ->
            handler.postDelayed({
                val id = TEST_ID_BASE + index
                post(app, id, alertBuilder(app, channel, title, text, requestCode = id).build())
            }, index * TEST_STAGGER_MS)
        }
    }

    // ------------------------------------------------------------------
    // MEMBUKA SETELAN SISTEM (dengan fallback aman)
    // ------------------------------------------------------------------

    private fun startSafely(context: Context, intent: Intent): Boolean {
        if (context !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { context.startActivity(intent) }.isSuccess
    }

    fun openAppDetails(context: Context) {
        startSafely(
            context,
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", context.packageName, null)
            }
        )
    }

    /** Setelan notifikasi aplikasi (izin, pop-up/banner, layar kunci, daftar channel). */
    fun openAppNotificationSettings(context: Context) {
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        } else {
            // Android 7.x: aksi lama, belum ada konstanta publiknya.
            Intent("android.settings.APP_NOTIFICATION_SETTINGS")
                .putExtra("app_package", context.packageName)
                .putExtra("app_uid", context.applicationInfo.uid)
        }
        if (!startSafely(context, intent)) openAppDetails(context)
    }

    /** Setelan satu channel (importance, suara, "muncul sebagai pop-up"). */
    fun openChannelSettings(context: Context, channelId: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            openAppNotificationSettings(context)
            return
        }
        val intent = Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            .putExtra(Settings.EXTRA_CHANNEL_ID, channelId)
        if (!startSafely(context, intent)) openAppNotificationSettings(context)
    }

    /** Setelan Jangan Ganggu / Fokus. */
    fun openDoNotDisturbSettings(context: Context) {
        // Aksi ini tidak punya konstanta publik; kalau tidak ada di ROM-nya, jatuh ke setelan suara.
        val opened = startSafely(context, Intent("android.settings.ZEN_MODE_SETTINGS"))
        if (!opened) startSafely(context, Intent(Settings.ACTION_SOUND_SETTINGS))
    }
}
