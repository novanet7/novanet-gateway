package com.example.service

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import id.novanet.listener.R

/** Kondisi satu notification channel (Android 8+). */
data class ChannelHealth(
    val id: String,
    val label: String,
    /** True bila channel ini memang dimaksudkan untuk pop-up/heads-up. */
    val expectsPopup: Boolean,
    val exists: Boolean,
    val importance: Int
) {
    val blocked: Boolean
        get() = exists && importance == NotificationManager.IMPORTANCE_NONE

    /** Heads-up (pop-up) hanya muncul kalau importance channel = HIGH ke atas. */
    val popupCapable: Boolean
        get() = exists && importance >= NotificationManager.IMPORTANCE_HIGH
}

/** Ringkasan kesehatan sistem notifikasi — dipakai halaman Pengaturan. */
data class NotificationHealth(
    /** Notifikasi aplikasi ini boleh tampil (izin runtime Android 13+ DAN tidak diblokir di setelan HP). */
    val appEnabled: Boolean,
    /** Android 13+: izin runtime POST_NOTIFICATIONS. Di bawah 13 selalu true. */
    val runtimePermissionGranted: Boolean,
    /** Kosong di Android 7 (API 24-25), karena belum ada konsep channel. */
    val channels: List<ChannelHealth>
) {
    val popupReady: Boolean
        get() = appEnabled && channels.filter { it.expectsPopup }.all { it.popupCapable }

    companion object {
        val Unknown = NotificationHealth(
            appEnabled = true,
            runtimePermissionGranted = true,
            channels = emptyList()
        )
    }
}

/**
 * Satu-satunya tempat yang membuat channel & memposting notifikasi aplikasi.
 *
 * Hanya ada DUA kategori notifikasi di Info Aplikasi:
 *  1. "Layanan Pemantau DANA 24/7" — notifikasi senyap penahan foreground service (tidak diubah).
 *  2. "Pop up notifikasi"          — SATU channel untuk semua pop-up. Judul & isi pop-up selalu
 *     dikirim dari server Novanet lewat FCM; APK hanya menampilkannya.
 *
 * Versi Android:
 * - API 24-25 : belum ada channel → heads-up ditentukan priority HIGH + defaults (suara/getar).
 * - API 26-32 : heads-up ditentukan IMPORTANCE channel (HIGH). Channel dibuat sejak
 *               [com.example.NovanetApp.onCreate] supaya sudah tampil di Info Aplikasi.
 * - API 33+   : wajib izin runtime POST_NOTIFICATIONS.
 */
object NotificationHelper {

    // ID channel pop-up memakai ID FCM lama supaya pengaturan yang sudah ada di HP user
    // (importance, suara, dll) tidak hilang — hanya namanya yang diperbarui.
    const val CHANNEL_POPUP = "novanet_fcm_events"
    const val CHANNEL_KEEP_ALIVE = "novanet_keep_alive_channel"

    // Channel lama yang digabung ke "Pop up notifikasi" → dihapus supaya di Info Aplikasi
    // tinggal 2 kategori. "fcm_fallback_notification_channel" = channel "Miscellaneous"
    // bawaan Firebase.
    private val LEGACY_CHANNEL_IDS = listOf(
        "novanet_payment_alerts",
        "novanet_system_alerts",
        "fcm_fallback_notification_channel"
    )

    private val VIBRATION = longArrayOf(0, 250, 120, 350)

    private class Spec(
        val id: String,
        val name: String,
        val description: String,
        val importance: Int,
        val popup: Boolean
    )

    private val specs = listOf(
        Spec(
            CHANNEL_POPUP, "Pop up notifikasi",
            "Pop-up dari server Novanet: permintaan pembayaran baru, pembayaran berhasil, dibatalkan, kedaluwarsa, dan peringatan",
            NotificationManager.IMPORTANCE_HIGH, true
        ),
        // Nama & deskripsi channel ini SENGAJA sama persis dengan versi sebelumnya.
        Spec(
            CHANNEL_KEEP_ALIVE, "Layanan Pemantau DANA 24/7",
            "Menjaga listener DANA tetap berjalan; notifikasi pembayaran memakai FCM",
            NotificationManager.IMPORTANCE_LOW, false
        )
    )

    // ------------------------------------------------------------------
    // CHANNEL
    // ------------------------------------------------------------------

    /**
     * Daftarkan semua channel. Idempotent & murah — aman dipanggil berulang
     * (Application.onCreate, tiap service). Channel yang sudah ada TIDAK
     * di-reset: Android hanya memperbarui nama/deskripsinya, pilihan user
     * (suara, importance, blokir) tetap dihormati.
     */
    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        try {
            val nm = context.getSystemService(NotificationManager::class.java) ?: return
            val audio = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            for (legacyId in LEGACY_CHANNEL_IDS) {
                try {
                    nm.deleteNotificationChannel(legacyId)
                } catch (_: Exception) {
                    // Channel lama tidak ada / tidak bisa dihapus — abaikan.
                }
            }
            for (spec in specs) {
                val channel = NotificationChannel(spec.id, spec.name, spec.importance).apply {
                    description = spec.description
                    setShowBadge(spec.popup)
                    if (spec.popup) {
                        enableVibration(true)
                        vibrationPattern = VIBRATION
                        enableLights(true)
                        lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                        setSound(Settings.System.DEFAULT_NOTIFICATION_URI, audio)
                    }
                }
                nm.createNotificationChannel(channel)
            }
        } catch (_: Exception) {
            // Jangan sampai pembuatan channel menjatuhkan aplikasi/service.
        }
    }

    // ------------------------------------------------------------------
    // STATUS
    // ------------------------------------------------------------------

    fun health(context: Context): NotificationHealth {
        val app = context.applicationContext
        val runtimeGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            app.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        val appEnabled = try {
            NotificationManagerCompat.from(app).areNotificationsEnabled()
        } catch (_: Exception) {
            runtimeGranted
        }
        val nm = app.getSystemService(NotificationManager::class.java)

        val channels = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
            specs.map { spec ->
                val ch = try {
                    nm.getNotificationChannel(spec.id)
                } catch (_: Exception) {
                    null
                }
                ChannelHealth(
                    id = spec.id,
                    label = spec.name,
                    expectsPopup = spec.popup,
                    exists = ch != null,
                    importance = ch?.importance ?: NotificationManager.IMPORTANCE_UNSPECIFIED
                )
            }
        } else {
            emptyList()
        }

        return NotificationHealth(
            appEnabled = appEnabled,
            runtimePermissionGranted = runtimeGranted,
            channels = channels
        )
    }

    // ------------------------------------------------------------------
    // MEMBANGUN & MEMPOSTING
    // ------------------------------------------------------------------

    /**
     * Tampilkan satu pop-up yang judul & isinya SEPENUHNYA dari server (FCM).
     * APK tidak menyusun/menambah teks apa pun. Mengembalikan true bila diserahkan ke sistem.
     */
    fun showServerPopup(context: Context, key: String, title: String, body: String): Boolean {
        val app = context.applicationContext
        val notificationId = key.hashCode()
        val openApp = Intent(app, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            app, notificationId, openApp,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = NotificationCompat.Builder(app, CHANNEL_POPUP)
            .setSmallIcon(R.drawable.ic_stat_novanet)
            .setColor(ContextCompat.getColor(app, R.color.novanet_notification_accent))
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setShowWhen(true)
            .setAutoCancel(true)
            .setContentIntent(pending)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            // Android 7.x: tanpa channel, heads-up butuh suara/getar dari defaults.
            builder.setDefaults(NotificationCompat.DEFAULT_ALL)
        }
        return post(app, notificationId, builder.build())
    }

    /**
     * Posting aman: memeriksa izin (Android 13+), menelan SecurityException,
     * dan mengembalikan true hanya bila benar-benar diserahkan ke sistem.
     */
    @SuppressLint("MissingPermission")
    private fun post(context: Context, id: Int, notification: Notification): Boolean {
        val app = context.applicationContext
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            app.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) return false
        return try {
            // Channel sudah didaftarkan di NovanetApp.onCreate (jalan lebih dulu di tiap proses).
            NotificationManagerCompat.from(app).notify(id, notification)
            true
        } catch (_: Exception) {
            false
        }
    }

    // ------------------------------------------------------------------
    // MEMBUKA SETELAN SISTEM (dengan fallback aman)
    // ------------------------------------------------------------------

    private fun startSafely(context: Context, intent: Intent): Boolean {
        if (context !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { context.startActivity(intent) }.isSuccess
    }

    fun openAppDetails(context: Context) {
        startSafely(
            context,
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", context.packageName, null)
            }
        )
    }

    /** Setelan notifikasi aplikasi (izin, pop-up/banner, layar kunci, daftar channel). */
    fun openAppNotificationSettings(context: Context) {
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        } else {
            // Android 7.x: aksi lama, belum ada konstanta publiknya.
            Intent("android.settings.APP_NOTIFICATION_SETTINGS")
                .putExtra("app_package", context.packageName)
                .putExtra("app_uid", context.applicationInfo.uid)
        }
        if (!startSafely(context, intent)) openAppDetails(context)
    }

    /** Setelan satu kategori notifikasi (importance, "muncul sebagai pop-up", suara). */
    fun openChannelSettings(context: Context, channelId: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            openAppNotificationSettings(context)
            return
        }
        val intent = Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            .putExtra(Settings.EXTRA_CHANNEL_ID, channelId)
        if (!startSafely(context, intent)) openAppNotificationSettings(context)
    }
}
