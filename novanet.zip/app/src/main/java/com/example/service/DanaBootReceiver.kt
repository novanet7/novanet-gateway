package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.pref.AppPreferences

class DanaBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            val prefs = AppPreferences(context)
            if (prefs.isLoggedIn && prefs.keepAliveEnabled) {
                DanaKeepAliveService.start(context)
                if (prefs.watchdogEnabled) WatchdogWorker.schedule(context)
            }
        }
    }
}
