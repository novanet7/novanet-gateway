package com.example.service

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.pref.AppPreferences
import java.util.concurrent.TimeUnit

/**
 * Worker berkala yang memastikan layanan 24/7 tetap "sehat" walaupun
 * sistem (terutama OEM agresif seperti MIUI/ColorOS/FuntouchOS) diam-diam
 * mematikan foreground service atau memutus binding notification listener.
 *
 * Dijalankan lewat WorkManager (bukan Handler/coroutine loop biasa) supaya
 * tetap dipanggil ulang oleh sistem sendiri walau proses aplikasi sudah
 * mati total di background - WorkManager punya mekanisme reschedule di
 * level OS (JobScheduler/AlarmManager) yang tidak ikut mati bersama proses.
 *
 * Tidak menggantikan DanaKeepAliveService (yang menjaga koneksi & heartbeat
 * detik-ke-detik) - worker ini cuma "penjaga" yang mengecek tiap ±15 menit
 * (interval minimum yang diizinkan WorkManager) dan menyalakan ulang kalau
 * ada yang mati.
 */
class WatchdogWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val appContext = applicationContext
        val prefs = AppPreferences(appContext)

        // Kalau user belum login atau memang sengaja mematikan layanan 24/7,
        // watchdog tidak boleh memaksa menyalakan apa pun.
        if (!prefs.isLoggedIn || !prefs.keepAliveEnabled) {
            return Result.success()
        }

        // 1) Pastikan foreground service heartbeat masih hidup.
        if (!DanaKeepAliveService.isRunning.value) {
            DanaKeepAliveService.start(appContext)
        }

        // 2) Kalau izin akses notifikasi sudah diberikan tapi listener-nya
        // sendiri tidak dalam status "connected" (unbind diam-diam oleh
        // sistem), minta sistem re-bind segera daripada menunggu jadwal
        // rebind otomatis Android yang bisa sangat lambat.
        val accessGranted = DanaNotificationListenerService.isNotificationAccessGranted(appContext)
        if (accessGranted && !DanaNotificationListenerService.isServiceConnected.value) {
            DanaNotificationListenerService.requestRebindSafely(appContext)
        }

        return Result.success()
    }

    companion object {
        private const val UNIQUE_WORK_NAME = "novanet_watchdog"

        /** Jadwalkan pengecekan berkala. Aman dipanggil berulang kali (idempotent). */
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<WatchdogWorker>(15, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        /** Panggil saat user mematikan toggle 24/7 secara eksplisit, atau saat logout. */
        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
        }
    }
}
