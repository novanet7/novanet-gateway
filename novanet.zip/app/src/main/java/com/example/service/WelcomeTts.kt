package com.example.service

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Selamat datang formal via Text-to-Speech saat user berhasil login.
 * Instance sekali pakai: init → speak → shutdown otomatis setelah selesai / gagal.
 * Tidak bergantung pada NotificationListenerService (yang mungkin belum aktif saat login).
 */
object WelcomeTts {
    private val busy = AtomicBoolean(false)

    /**
     * Ucapkan sambutan formal dengan nama user.
     * Aman dipanggil berkali-kali; kalau masih berbicara, panggilan baru diabaikan.
     */
    fun speakWelcome(context: Context, username: String) {
        if (!busy.compareAndSet(false, true)) return

        val name = username.trim().ifBlank { "pengguna" }
        val script = buildWelcomeScript(name)
        val appCtx = context.applicationContext

        var ttsRef: TextToSpeech? = null
        ttsRef = TextToSpeech(appCtx) { status ->
            val engine = ttsRef
            if (status != TextToSpeech.SUCCESS || engine == null) {
                busy.set(false)
                try {
                    engine?.shutdown()
                } catch (_: Exception) {
                }
                return@TextToSpeech
            }

            try {
                // Prioritas bahasa Indonesia; fallback ke default sistem.
                val id = Locale("id", "ID")
                val langResult = engine.setLanguage(id)
                if (langResult == TextToSpeech.LANG_MISSING_DATA ||
                    langResult == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    engine.setLanguage(Locale.getDefault())
                }

                // Nada formal, sedikit lebih pelan & jelas.
                engine.setSpeechRate(0.88f)
                engine.setPitch(0.98f)

                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        release(engine)
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        release(engine)
                    }
                    override fun onError(utteranceId: String?, errorCode: Int) {
                        release(engine)
                    }
                })

                val uttered = engine.speak(
                    script,
                    TextToSpeech.QUEUE_FLUSH,
                    null,
                    "novanet_welcome_${System.currentTimeMillis()}"
                )
                if (uttered == TextToSpeech.ERROR) {
                    release(engine)
                }
            } catch (_: Exception) {
                release(engine)
            }
        }
    }

    private fun release(engine: TextToSpeech?) {
        try {
            engine?.stop()
            engine?.shutdown()
        } catch (_: Exception) {
        }
        busy.set(false)
    }

    /**
     * Naskah formal & cukup panjang — disesuaikan untuk TTS bahasa Indonesia.
     * Nama user disisipkan secara natural.
     */
    private fun buildWelcomeScript(name: String): String {
        return """
            Selamat datang, $name.
            Terima kasih telah masuk ke Novanet Listener.
            Sistem pembayaran Anda telah siap digunakan.
            Pastikan layanan notifikasi dan izin yang diperlukan telah aktif,
            agar setiap transaksi dapat dipantau dengan baik.
            Semoga aktivitas pembayaran Anda berjalan lancar dan aman.
            Selamat bekerja.
        """.trimIndent().replace("\n", " ")
    }
}
