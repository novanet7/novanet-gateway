package com.example.service

import com.example.data.api.NovanetApiClient
import com.example.data.pref.AppPreferences
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.text.NumberFormat
import java.util.Locale

class NovanetFirebaseMessagingService : FirebaseMessagingService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onNewToken(token: String) {
        val prefs = AppPreferences(applicationContext)
        prefs.fcmToken = token
        if (prefs.isLoggedIn && prefs.apiKey.isNotBlank()) {
            scope.launch { NovanetApiClient.registerFcmToken(prefs.apiKey, token) }
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val prefs = AppPreferences(applicationContext)
        if (!prefs.isLoggedIn) return
        if (prefs.apiKey.isNotBlank()) {
            scope.launch { NovanetApiClient.registerFcmToken(prefs.apiKey, prefs.fcmToken) }
        }
        // FCM adalah kanal tunggal event pembayaran. Jaga layanan tetap hidup hanya bila 24/7 diaktifkan.
        val eventType = message.data["type"].orEmpty()
        _events.tryEmit(eventType)
        if (eventType.startsWith("transaction.")) showFallbackNotification(message)
        if (prefs.keepAliveEnabled) DanaKeepAliveService.start(applicationContext)
    }

    private fun showFallbackNotification(message: RemoteMessage) {
        // Channel sudah dibuat sejak NovanetApp.onCreate; dipanggil lagi di sini sebagai jaring
        // pengaman (idempotent) kalau proses ini dibangunkan FCM dalam kondisi tak biasa.
        NotificationHelper.ensureChannels(this)

        val amount = message.data["amount"].orEmpty()
        val status = message.data["status"].orEmpty()
        val eventType = message.data["type"].orEmpty()
        val reference = message.data["reference"].orEmpty().ifBlank { "-" }
        val transactionId = message.data["transaction_id"].orEmpty()
        val formattedAmount = amount.toLongOrNull()?.let {
            "Rp" + NumberFormat.getNumberInstance(Locale("id", "ID")).format(it)
        } ?: if (amount.isNotBlank()) "Rp$amount" else "-"
        val (title, body) = when {
            eventType == "transaction.created" ->
                "🔔 Permintaan pembayaran baru" to "💰 $formattedAmount  •  🧾 Ref: $reference"
            status == "paid" ->
                "✅ Pembayaran berhasil" to "💰 $formattedAmount  •  🧾 Ref: $reference"
            status == "cancelled" ->
                "❌ Pembayaran dibatalkan" to "💰 $formattedAmount  •  🧾 Ref: $reference"
            status == "expired" ->
                "⌛ Pembayaran kedaluwarsa" to "💰 $formattedAmount  •  🧾 Ref: $reference"
            else ->
                "🔄 Update pembayaran Novanet" to "💰 $formattedAmount  •  Status: $status"
        }
        val detail = "$body\n🆔 ID: ${transactionId.take(18)}"
        // ID dibedakan per tahap (dibuat / lunas / batal / kedaluwarsa). Kalau ID-nya sama untuk
        // satu transaksi, notifikasi "lunas" hanya MENGGANTI yang lama secara diam-diam dan
        // sebagian ROM tidak memunculkan pop-up lagi untuk notifikasi yang di-update.
        val notificationId = "$transactionId|$eventType|$status".hashCode()
        NotificationHelper.post(
            this,
            notificationId,
            NotificationHelper.alertBuilder(
                context = this,
                channelId = NotificationHelper.CHANNEL_FCM,
                title = title,
                text = body,
                bigText = detail,
                requestCode = notificationId
            ).build()
        )
    }

    companion object {
        private val _events = MutableSharedFlow<String>(extraBufferCapacity = 32)
        val events: SharedFlow<String> = _events.asSharedFlow()
    }
}
