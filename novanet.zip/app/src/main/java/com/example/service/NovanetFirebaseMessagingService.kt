package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import com.example.data.api.NovanetApiClient
import com.example.data.pref.AppPreferences
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.text.NumberFormat
import java.util.Locale

class NovanetFirebaseMessagingService : FirebaseMessagingService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onNewToken(token: String) {
        val prefs = AppPreferences(applicationContext)
        prefs.fcmToken = token
        if (prefs.isLoggedIn && prefs.apiKey.isNotBlank()) {
            scope.launch { NovanetApiClient.registerFcmToken(prefs.apiKey, token) }
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val prefs = AppPreferences(applicationContext)
        if (!prefs.isLoggedIn) return
        if (prefs.apiKey.isNotBlank()) {
            scope.launch { NovanetApiClient.registerFcmToken(prefs.apiKey, prefs.fcmToken) }
        }
        // FCM adalah kanal tunggal event pembayaran. Jaga layanan tetap hidup hanya bila 24/7 diaktifkan.
        val eventType = message.data["type"].orEmpty()
        _events.tryEmit(eventType)
        if (eventType.startsWith("transaction.")) showFallbackNotification(message)
        if (prefs.keepAliveEnabled) DanaKeepAliveService.start(applicationContext)
    }

    private fun showFallbackNotification(message: RemoteMessage) {
        val channelId = "novanet_fcm_events"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(
                NotificationChannel(channelId, "Popup Pembayaran Novanet", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Permintaan pembayaran dan konfirmasi pembayaran Novanet"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 250, 120, 350)
                    setShowBadge(true)
                }
            )
        }
        val amount = message.data["amount"].orEmpty()
        val status = message.data["status"].orEmpty()
        val eventType = message.data["type"].orEmpty()
        val reference = message.data["reference"].orEmpty().ifBlank { "-" }
        val transactionId = message.data["transaction_id"].orEmpty()
        val formattedAmount = amount.toLongOrNull()?.let {
            "Rp" + NumberFormat.getNumberInstance(Locale("id", "ID")).format(it)
        } ?: if (amount.isNotBlank()) "Rp$amount" else "-"
        val (title, body) = when {
            eventType == "transaction.created" ->
                "🔔 Permintaan pembayaran baru" to "💰 $formattedAmount  •  🧾 Ref: $reference"
            status == "paid" ->
                "✅ Pembayaran berhasil" to "💰 $formattedAmount  •  🧾 Ref: $reference"
            status == "cancelled" ->
                "❌ Pembayaran dibatalkan" to "💰 $formattedAmount  •  🧾 Ref: $reference"
            status == "expired" ->
                "⌛ Pembayaran kedaluwarsa" to "💰 $formattedAmount  •  🧾 Ref: $reference"
            else ->
                "🔄 Update pembayaran Novanet" to "💰 $formattedAmount  •  Status: $status"
        }
        val detail = "$body\n🆔 ID: ${transactionId.take(18)}"
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(this, message.data["transaction_id"].hashCode(), intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        try {
            NotificationManagerCompat.from(this).notify(
                message.data["transaction_id"].hashCode(),
                NotificationCompat.Builder(this, channelId)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(detail))
                    .setAutoCancel(true)
                    .setContentIntent(pending)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setShowWhen(true)
                    .setDefaults(NotificationCompat.DEFAULT_ALL)
                    .build()
            )
        } catch (_: SecurityException) { }
    }

    companion object {
        private val _events = MutableSharedFlow<String>(extraBufferCapacity = 32)
        val events: SharedFlow<String> = _events.asSharedFlow()
    }
}
