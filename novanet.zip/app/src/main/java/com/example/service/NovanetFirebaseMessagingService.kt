package com.example.service

import com.example.data.api.NovanetApiClient
import com.example.data.pref.AppPreferences
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

class NovanetFirebaseMessagingService : FirebaseMessagingService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onNewToken(token: String) {
        val prefs = AppPreferences(applicationContext)
        prefs.fcmToken = token
        // Selalu coba daftar ulang ke server saat token berganti (login atau refresh token).
        if (prefs.isLoggedIn && prefs.apiKey.isNotBlank() && token.isNotBlank()) {
            scope.launch {
                val result = NovanetApiClient.registerFcmToken(prefs.apiKey, token)
                // Retry sekali kalau gagal (jaringan jelek saat token baru keluar).
                if (!result.isSuccess) {
                    kotlinx.coroutines.delay(2000)
                    NovanetApiClient.registerFcmToken(prefs.apiKey, token)
                }
            }
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val prefs = AppPreferences(applicationContext)
        if (!prefs.isLoggedIn) return
        // Self-heal: pastikan token masih terdaftar di server setiap kali ada pesan masuk.
        if (prefs.apiKey.isNotBlank() && prefs.fcmToken.isNotBlank()) {
            scope.launch { NovanetApiClient.registerFcmToken(prefs.apiKey, prefs.fcmToken) }
        }
        // FCM adalah kanal tunggal event pembayaran. Jaga layanan tetap hidup hanya bila 24/7 diaktifkan.
        val eventType = message.data["type"].orEmpty()
        _events.tryEmit(eventType)
        showServerPopup(message)
        if (prefs.keepAliveEnabled) DanaKeepAliveService.start(applicationContext)
    }

    /**
     * Pop-up murni dari server: judul & isi diambil apa adanya dari payload FCM ("title", "body").
     * APK tidak menyusun teks sendiri. Pesan tanpa judul/isi (mis. event yang hanya menyegarkan
     * dashboard) tidak memunculkan pop-up.
     *
     * TTS:
     * - Teks diucapkan diambil dari field "tts_text" yang dikirim server (paling diprioritaskan).
     * - Jika tts_text kosong, fallback ke gabungan title + body.
     * - Menggunakan pengaturan yang sama dengan TTS dana masuk (ttsAlertEnabled).
     */
    private fun showServerPopup(message: RemoteMessage) {
        val prefs = AppPreferences(applicationContext)
        if (!prefs.paymentAlertEnabled) return

        val title = message.data["title"].orEmpty().trim()
        val body = message.data["body"].orEmpty().trim()
        if (title.isEmpty() && body.isEmpty()) return

        // "key" dari server = ID unik per kejadian → tiap tahap tampil sebagai pop-up sendiri
        // (permintaan baru, lunas, batal, kedaluwarsa) dan kiriman ganda dari FCM tidak dobel.
        val key = message.data["key"].orEmpty().ifBlank { "$title|$body" }
        NotificationHelper.showServerPopup(
            context = this,
            key = key,
            title = title.ifEmpty { body },
            body = body.ifEmpty { title }
        )

        // TTS untuk SEMUA notifikasi server (termasuk error) — dikontrol oleh togel yang sama
        if (prefs.ttsAlertEnabled) {
            val ttsText = message.data["tts_text"].orEmpty().trim()
            val spoken = when {
                ttsText.isNotEmpty() -> ttsText
                else -> listOf(title, body).filter { it.isNotEmpty() }.joinToString(". ")
            }
            if (spoken.isNotEmpty()) {
                AlertTts.speak(applicationContext, spoken)
            }
        }
    }

    companion object {
        private val _events = MutableSharedFlow<String>(extraBufferCapacity = 32)
        val events: SharedFlow<String> = _events.asSharedFlow()
    }
}
