package com.example.service

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.regex.Pattern

data class ParsedDanaPayment(
    val isValid: Boolean,
    val amount: Long,
    val amountFormatted: String,
    val sender: String,
    val paymentType: String,
    val rawTitle: String,
    val rawMessage: String,
    val formattedDate: String
)

object DanaNotificationParser {

    private val idLocale = Locale("id", "ID")
    private val currencyFormat = NumberFormat.getCurrencyInstance(idLocale).apply {
        maximumFractionDigits = 0
    }
    private val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm:ss 'WIB'", idLocale)

    // Regex patterns for amounts: e.g. Rp 50.000 or Rp. 50.000 or Rp50.000 or sebesar Rp 50.000
    private val amountRegex = Pattern.compile(
        """(?:Rp\.?|sebesar\s+Rp\.?|uang\s+Rp\.?|nominal\s+Rp\.?)\s*([0-9.,]+)""",
        Pattern.CASE_INSENSITIVE
    )

    // Regex patterns for sender:
    // "dari BUDI SANTOSO via QRIS" or "dari BUDI SANTOSO" or "from BUDI SANTOSO"
    // Sender diakhiri titik biasa (akhir kalimat notifikasi) — TAPI titik yang
    // langsung nempel di singkatan badan usaha umum Indonesia (PT/CV/UD/Tbk)
    // sengaja TIDAK dianggap pengakhir, supaya "dari PT. Sumber Rejeki via QRIS"
    // tidak kepotong jadi cuma "PT" saja (negative lookbehind di bawah).
    private val senderRegex = Pattern.compile(
        """(?:dari|from)\s+([A-Za-z0-9\s.]+?)(?:\s+via|\s+sebesar|\s+ke|\s+pada|\s+telah|(?<!\bPT)(?<!\bCV)(?<!\bUD)\.|$|\n)""",
        Pattern.CASE_INSENSITIVE
    )

    // Deteksi DANA Bisnis atau QRIS merchant
    private val danaBisnisRegex = Pattern.compile(
        """DANA\s*Bisnis|DANABisnis|DANA\s*Merchant""",
        Pattern.CASE_INSENSITIVE
    )

    // Kata-kata yang menandakan transaksi pengeluaran personal/promo (bukan uang masuk merchant)
    private val outgoingOrPromoMarkers = listOf(
        "berhasil bayar",
        "pembayaran ke",
        "berhasil kirim",
        "kirim uang berhasil",
        "kamu telah membayar",
        "pembayaran kamu berhasil",
        "pulsa berhasil",
        "tagihan berhasil",
        "top up berhasil",
        "isi saldo berhasil",
        "voucher",
        "promo",
        "cashback",
        "dana kaget"
    )

    fun parse(title: String, message: String): ParsedDanaPayment {
        val combinedText = "$title $message"
        val now = System.currentTimeMillis()
        val formattedTime = dateFormat.format(Date(now))

        // Cek apakah ada indikasi pembayaran keluar personal atau promo
        val isOutgoingOrPromo = outgoingOrPromoMarkers.any { combinedText.contains(it, ignoreCase = true) }

        // Cek apakah ada kata kunci uang masuk
        val isIncomingMoney = combinedText.contains("menerima", ignoreCase = true) ||
                combinedText.contains("pembayaran masuk", ignoreCase = true) ||
                combinedText.contains("saldo bertambah", ignoreCase = true) ||
                combinedText.contains("uang masuk", ignoreCase = true) ||
                combinedText.contains("diterima", ignoreCase = true) ||
                combinedText.contains("berhasil menerima", ignoreCase = true)

        // Wajib ada frasa eksplisit "DANA Bisnis"/"DANA Merchant" — TIDAK cukup
        // hanya kata "QRIS" saja. DANA Bisnis bukan app terpisah, dia mode/profil
        // bisnis di dalam app DANA yang sama (id.dana), dan akun DANA personal pun
        // bisa punya QRIS statis pribadi untuk terima uang dari teman. Notifikasi
        // uang masuk QRIS personal ("Rp50.000 diterima dari Budi via QRIS") TIDAK
        // pernah menyebut "DANA Bisnis" secara eksplisit, sedangkan notifikasi
        // bisnis asli SELALU menyebutnya. Kalau syarat ini dilonggarkan jadi
        // "QRIS saja cukup", transfer QRIS personal bisa salah terdeteksi sebagai
        // pembayaran bisnis dan dikirim ke server sebagai transaksi lunas.
        val isBusinessOrQris = danaBisnisRegex.matcher(combinedText).find()

        var extractedAmount: Long = 0
        val matcher = amountRegex.matcher(combinedText)
        if (matcher.find()) {
            val rawNum = matcher.group(1) ?: ""
            extractedAmount = cleanNumber(rawNum)
        }

        // Extract sender
        var senderName = "Pelanggan QRIS DANA"
        val senderMatcher = senderRegex.matcher(combinedText)
        if (senderMatcher.find()) {
            val candidate = senderMatcher.group(1)?.trim()
            if (!candidate.isNullOrBlank() && candidate.length > 1 &&
                !candidate.equals("DANA Bisnis", ignoreCase = true) &&
                !candidate.equals("DANA", ignoreCase = true)
            ) {
                senderName = candidate
            }
        } else if (combinedText.contains("QRIS", ignoreCase = true)) {
            senderName = "Pembayaran QRIS"
        }

        val paymentType = when {
            combinedText.contains("QRIS", ignoreCase = true) -> "QRIS DANA"
            danaBisnisRegex.matcher(combinedText).find() -> "DANA Bisnis"
            else -> "Pembayaran DANA"
        }

        // Syarat valid:
        // 1. Nominal > 0
        // 2. Transaksi berupa uang masuk (incoming)
        // 3. Terkait DANA Bisnis atau QRIS
        // 4. Bukan transaksi pengeluaran/promo
        val isValid = extractedAmount > 0 && isIncomingMoney && isBusinessOrQris && !isOutgoingOrPromo

        val formattedAmountStr = if (extractedAmount > 0) {
            formatRupiah(extractedAmount)
        } else {
            "Rp 0"
        }

        return ParsedDanaPayment(
            isValid = isValid,
            amount = extractedAmount,
            amountFormatted = formattedAmountStr,
            sender = senderName,
            paymentType = paymentType,
            rawTitle = title,
            rawMessage = message,
            formattedDate = formattedTime
        )
    }

    fun cleanNumber(raw: String): Long {
        var s = raw.trim()
        // Tangani format desimal sen Indonesia e.g. "50.000,00" atau "50000,00"
        if (s.matches(Regex(""".*,\d{1,2}$"""))) {
            s = s.substringBeforeLast(",")
        } else if (s.matches(Regex(""".*\.\d{2}$""")) && s.contains(",")) {
            // Tangani format US seperti "50,000.00"
            s = s.substringBeforeLast(".")
        }
        val digitsOnly = s.replace(".", "").replace(",", "").replace(" ", "").filter { it.isDigit() }
        return digitsOnly.toLongOrNull() ?: 0L
    }

    fun formatRupiah(amount: Long): String {
        return try {
            val formatted = NumberFormat.getNumberInstance(idLocale).format(amount)
            "Rp $formatted"
        } catch (_: Exception) {
            "Rp $amount"
        }
    }
}
