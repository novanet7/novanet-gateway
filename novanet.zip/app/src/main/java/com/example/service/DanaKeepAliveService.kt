package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.api.DeviceInfoUtil
import com.example.data.api.NovanetApiClient
import com.example.data.pref.AppPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Foreground service untuk heartbeat perangkat; event pembayaran diterima melalui FCM. */
class DanaKeepAliveService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var heartbeatJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startAsForeground()
        startHeartbeatLoop()
        _isRunning.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        startHeartbeatLoop()
        _isRunning.value = true
        return START_STICKY
    }

    override fun onDestroy() {
        heartbeatJob?.cancel()
        serviceScope.cancel()
        _isRunning.value = false
        super.onDestroy()
    }

    private fun startHeartbeatLoop() {
        if (heartbeatJob?.isActive == true) return
        heartbeatJob = serviceScope.launch {
            while (true) {
                val prefs = AppPreferences(applicationContext)
                if (prefs.apiKey.isNotBlank()) {
                    NovanetApiClient.postDeviceStatus(
                        apiKey = prefs.apiKey,
                        deviceName = DeviceInfoUtil.deviceName(),
                        ipAddress = DeviceInfoUtil.localIpAddress(),
                        batteryPercent = DeviceInfoUtil.batteryPercent(applicationContext).let { if (it < 0) 0 else it },
                        appVersion = DeviceInfoUtil.appVersion(applicationContext),
                        fcmRegistered = prefs.fcmToken.isNotBlank()
                    )
                }
                // Status aplikasi diperbarui berkala selama layanan aktif.
                delay(30 * 1000L)
            }
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        try {
            val serviceIntent = Intent(applicationContext, DanaKeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
            else startService(serviceIntent)
        } catch (_: Exception) { }
        super.onTaskRemoved(rootIntent)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Layanan Pemantau DANA 24/7",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Menjaga listener DANA tetap berjalan; notifikasi pembayaran memakai FCM"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    private fun startAsForeground() {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Pemantau DANA Aktif (24/7)")
            .setContentText("Aplikasi aktif dan menunggu notifikasi pembayaran")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pendingIntent)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else startForeground(NOTIFICATION_ID, notification)
    }

    companion object {
        const val CHANNEL_ID = "novanet_keep_alive_channel"
        const val NOTIFICATION_ID = 9021
        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        fun start(context: Context) {
            try {
                val intent = Intent(context, DanaKeepAliveService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
                else context.startService(intent)
            } catch (_: Exception) { }
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, DanaKeepAliveService::class.java))
                _isRunning.value = false
            } catch (_: Exception) { }
        }
    }
}
