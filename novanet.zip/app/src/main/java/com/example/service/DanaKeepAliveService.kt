package com.example.service

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import id.novanet.listener.R
import com.example.data.api.DeviceInfoUtil
import com.example.data.api.NovanetApiClient
import com.example.data.pref.AppPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Foreground service untuk heartbeat perangkat; event pembayaran diterima melalui FCM. */
class DanaKeepAliveService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var heartbeatJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startAsForeground()
        acquireWakeLock()
        startHeartbeatLoop()
        _isRunning.value = true
        // Dicatat sekali per siklus hidup service (bukan tiap onStartCommand)
        // supaya "berjalan sejak" di UI mencerminkan kapan proses ini benar-benar
        // baru dimulai, bukan ke-reset tiap kali sistem memanggil ulang start.
        _serviceStartElapsedRealtime.value = SystemClock.elapsedRealtime()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        acquireWakeLock()
        startHeartbeatLoop()
        _isRunning.value = true
        return START_STICKY
    }

    override fun onDestroy() {
        heartbeatJob?.cancel()
        serviceScope.cancel()
        releaseWakeLock()
        _isRunning.value = false
        _isWakeLockHeld.value = false
        _serviceStartElapsedRealtime.value = null
        super.onDestroy()
    }

    /**
     * PARTIAL_WAKE_LOCK menjaga CPU tetap menyala walau layar mati/HP idle,
     * supaya loop heartbeat & koneksi tidak ikut "tidur" saat Doze/App
     * Standby aktif. WAJIB dipasangkan dengan Foreground Service (sudah ada
     * lewat startAsForeground()) - WakeLock saja, tanpa foreground service,
     * tidak melindungi proses dari dibunuh sistem saat kehabisan memori,
     * cuma menjaga CPU-nya kalau prosesnya masih hidup.
     *
     * Sengaja dipasang dengan timeout (bukan acquire() tanpa batas) sebagai
     * jaring pengaman: kalau suatu saat service ini mati tidak wajar tanpa
     * sempat memanggil onDestroy() (mis. force-kill OEM tertentu), WakeLock
     * otomatis lepas sendiri setelah WAKE_LOCK_TIMEOUT_MS alih-alih terus
     * menyala tanpa batas dan menguras baterai pengguna selamanya. Selama
     * service & heartbeat loop masih hidup normal, timer ini terus diperbarui
     * setiap siklus heartbeat lewat renewWakeLock() sehingga efeknya tetap
     * menyala terus-menerus (24/7).
     */
    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "Novanet:KeepAliveWakeLock"
            ).apply {
                setReferenceCounted(false)
                acquire(WAKE_LOCK_TIMEOUT_MS)
            }
            _isWakeLockHeld.value = true
        } catch (e: Exception) {
            Log.w(TAG, "Gagal mengambil WakeLock, layanan tetap jalan tanpa itu", e)
            _isWakeLockHeld.value = false
        }
    }

    /** Perpanjang WakeLock di setiap siklus heartbeat supaya efektif menyala terus. */
    private fun renewWakeLock() {
        try {
            val current = wakeLock
            if (current != null && current.isHeld) {
                current.acquire(WAKE_LOCK_TIMEOUT_MS)
            } else {
                acquireWakeLock()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Gagal memperpanjang WakeLock", e)
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
            Log.w(TAG, "Gagal melepas WakeLock", e)
        }
        wakeLock = null
    }

    private fun startHeartbeatLoop() {
        if (heartbeatJob?.isActive == true) return
        heartbeatJob = serviceScope.launch {
            var cycle = 0
            while (true) {
                renewWakeLock()
                val prefs = AppPreferences(applicationContext)
                if (prefs.apiKey.isNotBlank()) {
                    NovanetApiClient.postDeviceStatus(
                        apiKey = prefs.apiKey,
                        deviceName = DeviceInfoUtil.deviceName(),
                        ipAddress = DeviceInfoUtil.localIpAddress(),
                        batteryPercent = DeviceInfoUtil.batteryPercent(applicationContext).let { if (it < 0) 0 else it },
                        appVersion = DeviceInfoUtil.appVersion(applicationContext),
                        fcmRegistered = prefs.fcmToken.isNotBlank()
                    )
                    // Setiap ~2 menit (4 siklus x 30s) pastikan token FCM masih terdaftar di server.
                    // Mencegah kasus token hilang dari Redis / belum pernah terkirim.
                    if (cycle % 4 == 0 && prefs.fcmToken.isNotBlank()) {
                        NovanetApiClient.registerFcmToken(prefs.apiKey, prefs.fcmToken)
                    }
                }
                cycle++
                // Status aplikasi diperbarui berkala selama layanan aktif. Status
                // hidup/mati di dashboard SEPENUHNYA ditentukan oleh heartbeat ini -
                // selama service (dan WakeLock-nya) hidup, status akan terus "online";
                // begitu service ini berhenti (dimatikan manual lewat Pengaturan atau
                // proses benar-benar mati), heartbeat berhenti dan dashboard akan
                // menganggap device offline. Tidak ada mekanisme lain yang menentukan
                // status ini.
                delay(30 * 1000L)
            }
        }
    }

    /**
     * Android 15+ (targetSdk 35+): foreground service bertipe dataSync dibatasi ±6 jam
     * per 24 jam. Saat batas habis sistem memanggil ini dan service WAJIB berhenti dalam
     * beberapa detik — kalau tidak, aplikasi di-crash (RemoteServiceException) dan
     * listener ikut mati. Berhenti dengan rapi; layanan dinyalakan lagi otomatis begitu
     * aplikasi dibuka (lihat checkPermission di ViewModel). Tidak ada pop-up lokal
     * karena semua teks pop-up berasal dari server.
     */
    override fun onTimeout(startId: Int, fgsType: Int) {
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        try {
            val serviceIntent = Intent(applicationContext, DanaKeepAliveService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
            else startService(serviceIntent)
        } catch (_: Exception) { }
        super.onTaskRemoved(rootIntent)
    }

    private fun createNotificationChannel() {
        NotificationHelper.ensureChannels(this)
    }

    private fun startAsForeground() {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_novanet)
            .setColor(ContextCompat.getColor(this, R.color.novanet_notification_accent))
            .setContentTitle("Pemantau DANA Aktif (24/7)")
            .setContentText("CPU terkunci aktif — berjalan terus sampai dimatikan manual di Pengaturan")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            // Android 12+: tanpa ini notifikasi foreground service baru muncul ±10 detik kemudian.
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(pendingIntent)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else startForeground(NOTIFICATION_ID, notification)
    }

    companion object {
        private const val TAG = "DanaKeepAliveService"
        const val CHANNEL_ID = NotificationHelper.CHANNEL_KEEP_ALIVE
        const val NOTIFICATION_ID = 9021
        // Diperpanjang tiap siklus heartbeat (30 detik) - nilai ini cuma jaring
        // pengaman kalau loop-nya berhenti tak terduga, bukan durasi hidup normal.
        private const val WAKE_LOCK_TIMEOUT_MS = 10 * 60 * 1000L
        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()
        private val _isWakeLockHeld = MutableStateFlow(false)
        val isWakeLockHeld: StateFlow<Boolean> = _isWakeLockHeld.asStateFlow()
        // SystemClock.elapsedRealtime() saat service ini mulai (null = tidak berjalan) —
        // dipakai UI buat hitung mundur "berjalan sejak" tanpa kena geser zona waktu.
        private val _serviceStartElapsedRealtime = MutableStateFlow<Long?>(null)
        val serviceStartElapsedRealtime: StateFlow<Long?> = _serviceStartElapsedRealtime.asStateFlow()

        fun start(context: Context) {
            try {
                val intent = Intent(context, DanaKeepAliveService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
                else context.startService(intent)
            } catch (_: Exception) { }
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, DanaKeepAliveService::class.java))
                _isRunning.value = false
                _isWakeLockHeld.value = false
                _serviceStartElapsedRealtime.value = null
            } catch (_: Exception) { }
        }
    }
}
