package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.example.data.pref.AppPreferences
import com.example.service.NotificationHelper
import com.example.ui.DanaListenerApp
import com.example.ui.DanaListenerViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: DanaListenerViewModel by viewModels {
        val prefs = AppPreferences(applicationContext)
        DanaListenerViewModel.Factory(prefs, applicationContext)
    }

    // true bila permintaan izin dipicu tombol di Pengaturan (bukan otomatis saat app dibuka).
    private var openSettingsIfDenied = false

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            viewModel.checkPermission(this)
            // Android 13+: setelah ditolak 2x sistem TIDAK lagi menampilkan dialog dan langsung
            // membalas "ditolak" — satu-satunya jalan tinggal setelan notifikasi aplikasi.
            if (!granted && openSettingsIfDenied &&
                !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)
            ) {
                NotificationHelper.openAppNotificationSettings(this)
            }
            openSettingsIfDenied = false
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Channel sudah dibuat di NovanetApp; ini jaring pengaman kalau proses dibuat ulang.
        NotificationHelper.ensureChannels(this)
        viewModel.checkPermission(this)
        requestNotificationPermission(fromUser = false)

        setContent {
            MyApplicationTheme {
                DanaListenerApp(
                    viewModel = viewModel,
                    onRequestNotificationPermission = { requestNotificationPermission(fromUser = true) }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkPermission(this)
    }

    /**
     * - Android 13+ & izin belum ada  → tampilkan dialog izin sistem.
     * - Selain itu (izin sudah ada, atau Android 7-12 yang tidak punya izin runtime) dan
     *   dipicu user → buka setelan notifikasi aplikasi (izin/blokir, pop-up/banner, channel).
     */
    private fun requestNotificationPermission(fromUser: Boolean) {
        val needsRuntimePermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsRuntimePermission) {
            openSettingsIfDenied = fromUser
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else if (fromUser) {
            NotificationHelper.openAppNotificationSettings(this)
        }
    }
}
