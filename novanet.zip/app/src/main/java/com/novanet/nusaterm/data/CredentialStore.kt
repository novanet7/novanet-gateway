package com.novanet.nusaterm.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Menyimpan password, private key (PEM), dan passphrase secara terenkripsi
 * menggunakan Android Keystore, terpisah per ID host.
 */
class CredentialStore(context: Context) {

    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            "nusaterm_credentials",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun savePassword(hostId: Long, password: String) {
        prefs.edit().putString(keyFor(hostId, "password"), password).apply()
    }

    fun getPassword(hostId: Long): String? = prefs.getString(keyFor(hostId, "password"), null)

    fun savePrivateKey(hostId: Long, pem: String) {
        prefs.edit().putString(keyFor(hostId, "private_key"), pem).apply()
    }

    fun getPrivateKey(hostId: Long): String? = prefs.getString(keyFor(hostId, "private_key"), null)

    fun savePassphrase(hostId: Long, passphrase: String) {
        prefs.edit().putString(keyFor(hostId, "passphrase"), passphrase).apply()
    }

    fun getPassphrase(hostId: Long): String? = prefs.getString(keyFor(hostId, "passphrase"), null)

    fun clearFor(hostId: Long) {
        prefs.edit()
            .remove(keyFor(hostId, "password"))
            .remove(keyFor(hostId, "private_key"))
            .remove(keyFor(hostId, "passphrase"))
            .apply()
    }

    private fun keyFor(hostId: Long, field: String) = "host_${hostId}_$field"
}
