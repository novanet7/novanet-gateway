package com.novanet.nusaterm.terminal

/**
 * Interpreter urutan escape ANSI/VT100 yang umum dipakai shell (bash, zsh, vim ringan,
 * htop sederhana, dsb). Tidak 100% mendukung xterm penuh, tetapi cukup untuk
 * penggunaan terminal SSH sehari-hari: warna, pergerakan kursor, hapus layar/baris.
 */
class TerminalEmulator(rows: Int, cols: Int) {

    val buffer = TerminalBuffer(rows, cols)

    /** Dinaikkan setiap kali buffer berubah, dipakai UI untuk memicu recomposition. */
    var revision: Long = 0
        private set

    private var curFg = -1
    private var curBg = -1
    private var bold = false
    private var underline = false
    private var reverse = false

    private enum class State { NORMAL, ESCAPE, CSI, OSC }
    private var state = State.NORMAL
    private val paramBuilder = StringBuilder()

    fun resize(rows: Int, cols: Int) {
        buffer.resize(rows, cols)
        revision++
    }

    fun feed(text: CharSequence) {
        for (ch in text) {
            feedChar(ch)
        }
        revision++
    }

    private fun feedChar(ch: Char) {
        when (state) {
            State.NORMAL -> handleNormal(ch)
            State.ESCAPE -> handleEscape(ch)
            State.CSI -> handleCsi(ch)
            State.OSC -> handleOsc(ch)
        }
    }

    private fun handleNormal(ch: Char) {
        when (ch) {
            '\u001B' -> state = State.ESCAPE
            '\n' -> newLine()
            '\r' -> buffer.cursorCol = 0
            '\b' -> if (buffer.cursorCol > 0) buffer.cursorCol--
            '\t' -> {
                val next = ((buffer.cursorCol / 8) + 1) * 8
                buffer.cursorCol = next.coerceAtMost(buffer.cols - 1)
            }
            '\u0007' -> { /* bell - abaikan */ }
            else -> printChar(ch)
        }
    }

    private fun handleEscape(ch: Char) {
        when (ch) {
            '[' -> { paramBuilder.clear(); state = State.CSI }
            ']' -> { paramBuilder.clear(); state = State.OSC }
            '7' -> { buffer.savedCursorRow = buffer.cursorRow; buffer.savedCursorCol = buffer.cursorCol; state = State.NORMAL }
            '8' -> { buffer.cursorRow = buffer.savedCursorRow; buffer.cursorCol = buffer.savedCursorCol; state = State.NORMAL }
            'c' -> { buffer.eraseScreen(); buffer.cursorRow = 0; buffer.cursorCol = 0; state = State.NORMAL }
            else -> state = State.NORMAL
        }
    }

    private fun handleOsc(ch: Char) {
        // OSC (judul jendela dsb) diabaikan isinya, cukup tunggu terminator.
        if (ch == '\u0007' || ch == '\u001B') {
            state = State.NORMAL
        }
    }

    private fun handleCsi(ch: Char) {
        if (ch in '0'..'9' || ch == ';' || ch == '?') {
            paramBuilder.append(ch)
            return
        }
        // ch sekarang adalah "final byte" dari urutan CSI
        val params = paramBuilder.toString()
        val hasPrivatePrefix = params.startsWith("?")
        val nums = params.removePrefix("?")
            .split(";")
            .mapNotNull { it.toIntOrNull() }

        fun p(index: Int, default: Int): Int = nums.getOrNull(index)?.takeIf { it != 0 } ?: default

        when (ch) {
            'A' -> buffer.cursorRow = (buffer.cursorRow - p(0, 1)).coerceAtLeast(0)
            'B' -> buffer.cursorRow = (buffer.cursorRow + p(0, 1)).coerceAtMost(buffer.rows - 1)
            'C' -> buffer.cursorCol = (buffer.cursorCol + p(0, 1)).coerceAtMost(buffer.cols - 1)
            'D' -> buffer.cursorCol = (buffer.cursorCol - p(0, 1)).coerceAtLeast(0)
            'H', 'f' -> {
                val row = (nums.getOrNull(0) ?: 1) - 1
                val col = (nums.getOrNull(1) ?: 1) - 1
                buffer.cursorRow = row.coerceIn(0, buffer.rows - 1)
                buffer.cursorCol = col.coerceIn(0, buffer.cols - 1)
            }
            'J' -> when (nums.getOrNull(0) ?: 0) {
                0 -> { buffer.eraseLine(buffer.cursorRow, buffer.cursorCol, buffer.cols - 1)
                       for (r in buffer.cursorRow + 1 until buffer.rows) buffer.eraseLine(r) }
                1 -> { buffer.eraseLine(buffer.cursorRow, 0, buffer.cursorCol)
                       for (r in 0 until buffer.cursorRow) buffer.eraseLine(r) }
                2, 3 -> buffer.eraseScreen()
            }
            'K' -> when (nums.getOrNull(0) ?: 0) {
                0 -> buffer.eraseLine(buffer.cursorRow, buffer.cursorCol, buffer.cols - 1)
                1 -> buffer.eraseLine(buffer.cursorRow, 0, buffer.cursorCol)
                2 -> buffer.eraseLine(buffer.cursorRow)
            }
            'X' -> buffer.eraseLine(buffer.cursorRow, buffer.cursorCol, (buffer.cursorCol + p(0, 1) - 1).coerceAtMost(buffer.cols - 1))
            's' -> { buffer.savedCursorRow = buffer.cursorRow; buffer.savedCursorCol = buffer.cursorCol }
            'u' -> { buffer.cursorRow = buffer.savedCursorRow; buffer.cursorCol = buffer.savedCursorCol }
            'm' -> applySgr(nums)
            'h', 'l' -> { /* mode set/reset (mis. alternate screen, cursor visibility) - diabaikan di MVP */ }
            else -> { /* urutan lain diabaikan */ }
        }
        state = State.NORMAL
    }

    private fun applySgr(nums: List<Int>) {
        if (nums.isEmpty()) {
            resetSgr()
            return
        }
        var i = 0
        while (i < nums.size) {
            val code = nums[i]
            when {
                code == 0 -> resetSgr()
                code == 1 -> bold = true
                code == 4 -> underline = true
                code == 7 -> reverse = true
                code == 22 -> bold = false
                code == 24 -> underline = false
                code == 27 -> reverse = false
                code == 39 -> curFg = -1
                code == 49 -> curBg = -1
                code in 30..37 -> curFg = code - 30
                code in 90..97 -> curFg = code - 90 + 8
                code in 40..47 -> curBg = code - 40
                code in 100..107 -> curBg = code - 100 + 8
                code == 38 && nums.getOrNull(i + 1) == 5 -> {
                    curFg = nums.getOrNull(i + 2) ?: curFg
                    i += 2
                }
                code == 48 && nums.getOrNull(i + 1) == 5 -> {
                    curBg = nums.getOrNull(i + 2) ?: curBg
                    i += 2
                }
            }
            i++
        }
    }

    private fun resetSgr() {
        curFg = -1
        curBg = -1
        bold = false
        underline = false
        reverse = false
    }

    private fun printChar(ch: Char) {
        if (buffer.cursorCol >= buffer.cols) {
            buffer.cursorCol = 0
            newLine()
        }
        buffer.grid[buffer.cursorRow][buffer.cursorCol] = Cell(ch, curFg, curBg, bold, underline, reverse)
        buffer.cursorCol++
    }

    private fun newLine() {
        if (buffer.cursorRow == buffer.rows - 1) {
            buffer.scrollUp()
        } else {
            buffer.cursorRow++
        }
    }
}
