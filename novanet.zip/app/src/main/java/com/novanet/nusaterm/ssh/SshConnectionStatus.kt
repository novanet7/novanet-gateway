package com.novanet.nusaterm.ssh

enum class SshConnectionStatus {
    CONNECTING,
    CONNECTED,
    DISCONNECTED,
    FAILED
}
