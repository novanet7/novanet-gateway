package com.novanet.nusaterm.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.novanet.nusaterm.data.HostRepository
import com.novanet.nusaterm.ssh.SshConnectionStatus
import com.novanet.nusaterm.ssh.SshSession
import com.novanet.nusaterm.ssh.SshUserInteraction
import com.novanet.nusaterm.terminal.TerminalEmulator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class TerminalViewModel(
    application: Application,
    private val repository: HostRepository,
    private val hostId: Long
) : AndroidViewModel(application) {

    val userInteraction = SshUserInteraction()
    val terminal = TerminalEmulator(rows = 30, cols = 80)

    var status by mutableStateOf(SshConnectionStatus.CONNECTING)
        private set

    var errorMessage by mutableStateOf<String?>(null)
        private set

    var hostLabel by mutableStateOf("")
        private set

    /** Dinaikkan tiap ada output baru agar Compose tahu harus menggambar ulang layar. */
    var renderTick by mutableStateOf(0L)
        private set

    /** Saran command berdasarkan riwayat yang pernah diketik di host ini (autocomplete). */
    var suggestions by mutableStateOf<List<String>>(emptyList())
        private set

    private var session: SshSession? = null

    /** Buffer lokal baris yang sedang diketik pengguna, dipakai untuk riwayat & autocomplete. */
    private val currentLine = StringBuilder()

    fun start(initialCols: Int, initialRows: Int) {
        terminal.resize(initialRows, initialCols)
        viewModelScope.launch {
            val profile = repository.getHost(hostId)
            if (profile == null) {
                status = SshConnectionStatus.FAILED
                errorMessage = "Profil host tidak ditemukan."
                return@launch
            }
            hostLabel = profile.label

            val knownHosts = File(getApplication<Application>().filesDir, "known_hosts")
            val newSession = SshSession(
                knownHostsFile = knownHosts,
                userInteraction = userInteraction,
                onOutput = { chars, len ->
                    viewModelScope.launch(Dispatchers.Main) {
                        terminal.feed(String(chars, 0, len))
                        renderTick++
                    }
                },
                onStatusChange = { newStatus, message ->
                    viewModelScope.launch(Dispatchers.Main) {
                        status = newStatus
                        if (message != null) errorMessage = message
                    }
                }
            )
            session = newSession

            try {
                newSession.connect(
                    profile = profile,
                    password = repository.getPassword(hostId),
                    privateKeyPem = repository.getPrivateKey(hostId),
                    passphrase = repository.getPassphrase(hostId),
                    cols = initialCols,
                    rows = initialRows
                )
            } catch (e: Exception) {
                status = SshConnectionStatus.FAILED
                errorMessage = e.message ?: "Gagal terhubung"
            }
        }
    }

    fun sendInput(text: String) {
        session?.write(text)
        trackCommandBuffer(text)
    }

    /**
     * Melengkapi baris yang sedang diketik dengan salah satu [suggestions] yang dipilih
     * pengguna (mis. sudah ketik "npm", tap saran "npm install" -> sisanya diketikkan otomatis).
     */
    fun acceptSuggestion(fullCommand: String) {
        val typed = currentLine.toString()
        if (fullCommand.length > typed.length && fullCommand.startsWith(typed)) {
            sendInput(fullCommand.substring(typed.length))
        }
    }

    /** Melacak baris yang sedang diketik dari setiap potongan input yang dikirim ke shell. */
    private fun trackCommandBuffer(text: String) {
        when {
            text == "\r" || text == "\n" -> {
                val command = currentLine.toString().trim()
                currentLine.clear()
                suggestions = emptyList()
                if (command.isNotEmpty()) {
                    viewModelScope.launch { repository.recordCommand(hostId, command) }
                }
            }
            text == "\u007F" -> { // backspace
                if (currentLine.isNotEmpty()) currentLine.deleteCharAt(currentLine.length - 1)
                refreshSuggestions()
            }
            text == "\u0003" -> { // Ctrl+C - baris dibatalkan
                currentLine.clear()
                suggestions = emptyList()
            }
            text.startsWith("\u001B") -> {
                // Urutan escape (panah, Esc, dll) - tidak memengaruhi buffer baris.
            }
            else -> {
                currentLine.append(text)
                refreshSuggestions()
            }
        }
    }

    private fun refreshSuggestions() {
        val prefix = currentLine.toString()
        if (prefix.isBlank()) {
            suggestions = emptyList()
            return
        }
        viewModelScope.launch {
            suggestions = repository.getSuggestions(hostId, prefix)
        }
    }

    fun onResize(cols: Int, rows: Int) {
        terminal.resize(rows, cols)
        session?.resize(cols, rows)
        renderTick++
    }

    fun answerHostKeyPrompt(accept: Boolean) {
        userInteraction.answer(accept)
    }

    fun reconnect(cols: Int, rows: Int) {
        errorMessage = null
        currentLine.clear()
        suggestions = emptyList()
        start(cols, rows)
    }

    override fun onCleared() {
        super.onCleared()
        session?.disconnect()
    }

    class Factory(
        private val application: Application,
        private val repository: HostRepository,
        private val hostId: Long
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
            return TerminalViewModel(application, repository, hostId) as T
        }
    }
}
