package com.novanet.nusaterm.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface CommandHistoryDao {

    @Query("SELECT * FROM command_history WHERE hostId = :hostId AND command = :command LIMIT 1")
    suspend fun find(hostId: Long, command: String): CommandHistoryEntity?

    @Insert
    suspend fun insert(entity: CommandHistoryEntity): Long

    @Update
    suspend fun update(entity: CommandHistoryEntity)

    /**
     * Menyarankan command yang pernah diketik di host ini, diawali [prefixPattern]
     * (mis. "npm%"). Diurutkan dari yang paling sering & paling baru dipakai.
     */
    @Query(
        "SELECT * FROM command_history WHERE hostId = :hostId AND command LIKE :prefixPattern ESCAPE '\\' " +
            "ORDER BY useCount DESC, lastUsedAt DESC LIMIT :limit"
    )
    suspend fun suggest(hostId: Long, prefixPattern: String, limit: Int = 5): List<CommandHistoryEntity>
}
