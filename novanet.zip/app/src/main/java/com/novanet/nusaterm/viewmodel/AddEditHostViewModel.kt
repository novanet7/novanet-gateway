package com.novanet.nusaterm.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.novanet.nusaterm.data.HostProfile
import com.novanet.nusaterm.data.HostRepository
import com.novanet.nusaterm.data.SshAuthType
import kotlinx.coroutines.launch

class AddEditHostViewModel(
    private val repository: HostRepository,
    private val editingHostId: Long?
) : ViewModel() {

    var label by mutableStateOf("")
    var hostname by mutableStateOf("")
    var port by mutableStateOf("22")
    var username by mutableStateOf("")
    var authType by mutableStateOf(SshAuthType.PASSWORD)
    var password by mutableStateOf("")
    var privateKeyPem by mutableStateOf("")
    var passphrase by mutableStateOf("")

    var isLoaded by mutableStateOf(editingHostId == null)
        private set

    var saveError by mutableStateOf<String?>(null)
        private set

    init {
        editingHostId?.let { id ->
            viewModelScope.launch {
                repository.getHost(id)?.let { profile ->
                    label = profile.label
                    hostname = profile.hostname
                    port = profile.port.toString()
                    username = profile.username
                    authType = profile.authType
                    password = repository.getPassword(id) ?: ""
                    privateKeyPem = repository.getPrivateKey(id) ?: ""
                    passphrase = repository.getPassphrase(id) ?: ""
                }
                isLoaded = true
            }
        }
    }

    fun isValid(): Boolean {
        if (label.isBlank() || hostname.isBlank() || username.isBlank()) return false
        if (port.toIntOrNull() == null) return false
        return when (authType) {
            SshAuthType.PASSWORD -> password.isNotBlank()
            SshAuthType.PRIVATE_KEY -> privateKeyPem.isNotBlank()
        }
    }

    fun save(onSaved: () -> Unit) {
        if (!isValid()) {
            saveError = "Lengkapi semua kolom wajib terlebih dahulu."
            return
        }
        saveError = null
        viewModelScope.launch {
            val profile = HostProfile(
                id = editingHostId ?: 0,
                label = label.trim(),
                hostname = hostname.trim(),
                port = port.toIntOrNull() ?: 22,
                username = username.trim(),
                authType = authType
            )
            repository.saveHost(
                profile = profile,
                password = password.takeIf { authType == SshAuthType.PASSWORD },
                privateKeyPem = privateKeyPem.takeIf { authType == SshAuthType.PRIVATE_KEY },
                passphrase = passphrase.takeIf { authType == SshAuthType.PRIVATE_KEY }
            )
            onSaved()
        }
    }

    class Factory(
        private val repository: HostRepository,
        private val editingHostId: Long?
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AddEditHostViewModel(repository, editingHostId) as T
        }
    }
}
