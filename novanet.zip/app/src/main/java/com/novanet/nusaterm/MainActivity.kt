package com.novanet.nusaterm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.novanet.nusaterm.ui.screens.AddEditHostScreen
import com.novanet.nusaterm.ui.screens.HostListScreen
import com.novanet.nusaterm.ui.screens.TerminalScreen
import com.novanet.nusaterm.ui.theme.NusaTermTheme
import com.novanet.nusaterm.viewmodel.AddEditHostViewModel
import com.novanet.nusaterm.viewmodel.HostListViewModel
import com.novanet.nusaterm.viewmodel.TerminalViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = (application as NusaTermApp).hostRepository

        setContent {
            NusaTermTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()

                    NavHost(navController = navController, startDestination = "hosts") {
                        composable("hosts") {
                            val vm: HostListViewModel = viewModel(factory = HostListViewModel.Factory(repository))
                            HostListScreen(
                                viewModel = vm,
                                onAddHost = { navController.navigate("host_form") },
                                onEditHost = { id -> navController.navigate("host_form?hostId=$id") },
                                onConnect = { id -> navController.navigate("terminal/$id") }
                            )
                        }

                        composable(
                            route = "host_form?hostId={hostId}",
                            arguments = listOf(navArgument("hostId") {
                                type = NavType.StringType
                                nullable = true
                                defaultValue = null
                            })
                        ) { backStackEntry ->
                            val hostId = backStackEntry.arguments?.getString("hostId")?.toLongOrNull()
                            val vm: AddEditHostViewModel = viewModel(
                                factory = AddEditHostViewModel.Factory(repository, hostId)
                            )
                            AddEditHostScreen(
                                viewModel = vm,
                                onDone = { navController.popBackStack() },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(
                            route = "terminal/{hostId}",
                            arguments = listOf(navArgument("hostId") { type = NavType.LongType })
                        ) { backStackEntry ->
                            val hostId = backStackEntry.arguments?.getLong("hostId") ?: 0L
                            val vm: TerminalViewModel = viewModel(
                                factory = TerminalViewModel.Factory(application, repository, hostId)
                            )
                            TerminalScreen(
                                viewModel = vm,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
