package com.novanet.nusaterm.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface HostDao {
    @Query("SELECT * FROM host_profiles ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<HostProfile>>

    @Query("SELECT * FROM host_profiles WHERE id = :id")
    suspend fun getById(id: Long): HostProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(profile: HostProfile): Long

    @Update
    suspend fun update(profile: HostProfile)

    @Delete
    suspend fun delete(profile: HostProfile)
}
