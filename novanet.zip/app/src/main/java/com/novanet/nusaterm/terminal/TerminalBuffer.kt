package com.novanet.nusaterm.terminal

data class Cell(
    var char: Char = ' ',
    var fg: Int = -1,     // -1 = warna default
    var bg: Int = -1,     // -1 = transparan / default
    var bold: Boolean = false,
    var underline: Boolean = false,
    var reverse: Boolean = false
)

/**
 * Grid karakter terminal berukuran [rows] x [cols] beserta scrollback buffer.
 * Bukan thread-safe secara ketat; semua mutasi dilakukan dari satu coroutine
 * pembaca stream SSH, lalu dibaca ulang dari Compose lewat snapshot state.
 */
class TerminalBuffer(var rows: Int, var cols: Int) {

    var grid: Array<Array<Cell>> = Array(rows) { Array(cols) { Cell() } }
        private set

    val scrollback: ArrayDeque<Array<Cell>> = ArrayDeque()
    private val maxScrollback = 2000

    var cursorRow = 0
    var cursorCol = 0

    var savedCursorRow = 0
    var savedCursorCol = 0

    fun resize(newRows: Int, newCols: Int) {
        if (newRows == rows && newCols == cols) return
        val newGrid = Array(newRows) { r ->
            Array(newCols) { c ->
                if (r < rows && c < cols) grid[r][c] else Cell()
            }
        }
        grid = newGrid
        rows = newRows
        cols = newCols
        cursorRow = cursorRow.coerceIn(0, rows - 1)
        cursorCol = cursorCol.coerceIn(0, cols - 1)
    }

    fun clear() {
        grid = Array(rows) { Array(cols) { Cell() } }
        cursorRow = 0
        cursorCol = 0
    }

    /** Menggeser seluruh baris ke atas satu kali, baris teratas masuk scrollback. */
    fun scrollUp() {
        if (scrollback.size >= maxScrollback) scrollback.removeFirst()
        scrollback.addLast(grid[0])
        for (r in 0 until rows - 1) {
            grid[r] = grid[r + 1]
        }
        grid[rows - 1] = Array(cols) { Cell() }
    }

    fun eraseLine(row: Int, fromCol: Int = 0, toCol: Int = cols - 1) {
        for (c in fromCol..toCol) {
            if (c in 0 until cols) grid[row][c] = Cell()
        }
    }

    fun eraseScreen() {
        grid = Array(rows) { Array(cols) { Cell() } }
    }
}
