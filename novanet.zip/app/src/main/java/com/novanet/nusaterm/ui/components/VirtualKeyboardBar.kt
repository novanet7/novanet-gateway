package com.novanet.nusaterm.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable

private data class QuickKey(val label: String, val send: String)

private val quickKeys = listOf(
    QuickKey("Esc", "\u001B"),
    QuickKey("Tab", "\t"),
    QuickKey("Ctrl+C", "\u0003"),
    QuickKey("Ctrl+D", "\u0004"),
    QuickKey("Ctrl+Z", "\u001A"),
    QuickKey("Ctrl+L", "\u000C"),
    QuickKey("Ctrl+U", "\u0015"),
    QuickKey("Ctrl+A", "\u0001"),
    QuickKey("\u2191", "\u001B[A"),
    QuickKey("\u2193", "\u001B[B"),
    QuickKey("\u2190", "\u001B[D"),
    QuickKey("\u2192", "\u001B[C"),
    QuickKey("Home", "\u001B[H"),
    QuickKey("End", "\u001B[F"),
    QuickKey("PgUp", "\u001B[5~"),
    QuickKey("PgDn", "\u001B[6~"),
    QuickKey("/", "/"),
    QuickKey("-", "-"),
    QuickKey("|", "|"),
    QuickKey("~", "~"),
)

@Composable
fun VirtualKeyboardBar(
    onSend: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(
            modifier = Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            quickKeys.forEach { key ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .height(38.dp)
                        .clickable { onSend(key.send) }
                ) {
                    Box(
                        modifier = Modifier.padding(horizontal = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = key.label,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}
