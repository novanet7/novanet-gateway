package com.novanet.nusaterm.terminal

import androidx.compose.ui.graphics.Color

/** Palet 16 warna ANSI standar, ditata agar nyaman dibaca di layar gelap. */
object AnsiColor {
    val normal = arrayOf(
        Color(0xFF1E1E2E), // 0 black
        Color(0xFFE06C75), // 1 red
        Color(0xFF98C379), // 2 green
        Color(0xFFE5C07B), // 3 yellow
        Color(0xFF61AFEF), // 4 blue
        Color(0xFFC678DD), // 5 magenta
        Color(0xFF56B6C2), // 6 cyan
        Color(0xFFD4D4D4), // 7 white
    )
    val bright = arrayOf(
        Color(0xFF5A5A70), // 8 bright black
        Color(0xFFEF8A94), // 9 bright red
        Color(0xFFB5E890), // 10 bright green
        Color(0xFFF0D590), // 11 bright yellow
        Color(0xFF8AC6FF), // 12 bright blue
        Color(0xFFDFA0F0), // 13 bright magenta
        Color(0xFF7FE0EC), // 14 bright cyan
        Color(0xFFFFFFFF), // 15 bright white
    )

    val defaultForeground = Color(0xFFE4E4E7)
    val defaultBackground = Color(0xFF0B1120)

    fun fromIndex(index: Int): Color = when {
        index in 0..7 -> normal[index]
        index in 8..15 -> bright[index - 8]
        else -> defaultForeground
    }
}
