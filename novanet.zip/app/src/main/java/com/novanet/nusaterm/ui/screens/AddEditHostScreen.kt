package com.novanet.nusaterm.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.novanet.nusaterm.data.SshAuthType
import com.novanet.nusaterm.viewmodel.AddEditHostViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditHostScreen(
    viewModel: AddEditHostViewModel,
    onDone: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (viewModel.isLoaded && viewModel.label.isNotEmpty()) "Edit Host" else "Host Baru") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                }
            )
        }
    ) { padding ->
        if (!viewModel.isLoaded) return@Scaffold

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = viewModel.label,
                onValueChange = { viewModel.label = it },
                label = { Text("Nama koneksi") },
                placeholder = { Text("Misal: VPS Produksi") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = viewModel.hostname,
                onValueChange = { viewModel.hostname = it },
                label = { Text("Hostname / Alamat IP") },
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = viewModel.port,
                    onValueChange = { viewModel.port = it.filter { c -> c.isDigit() } },
                    label = { Text("Port") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(0.35f)
                )
                OutlinedTextField(
                    value = viewModel.username,
                    onValueChange = { viewModel.username = it },
                    label = { Text("Username") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Text("Metode Autentikasi", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = viewModel.authType == SshAuthType.PASSWORD,
                    onClick = { viewModel.authType = SshAuthType.PASSWORD },
                    label = { Text("Password") }
                )
                FilterChip(
                    selected = viewModel.authType == SshAuthType.PRIVATE_KEY,
                    onClick = { viewModel.authType = SshAuthType.PRIVATE_KEY },
                    label = { Text("Private Key") }
                )
            }

            if (viewModel.authType == SshAuthType.PASSWORD) {
                OutlinedTextField(
                    value = viewModel.password,
                    onValueChange = { viewModel.password = it },
                    label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                OutlinedTextField(
                    value = viewModel.privateKeyPem,
                    onValueChange = { viewModel.privateKeyPem = it },
                    label = { Text("Private Key (format PEM, tempel isi file)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                )
                OutlinedTextField(
                    value = viewModel.passphrase,
                    onValueChange = { viewModel.passphrase = it },
                    label = { Text("Passphrase (opsional)") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            viewModel.saveError?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Button(
                onClick = { viewModel.save(onDone) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Simpan Koneksi")
            }
        }
    }
}
