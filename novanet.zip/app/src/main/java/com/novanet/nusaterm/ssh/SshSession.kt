package com.novanet.nusaterm.ssh

import com.jcraft.jsch.ChannelShell
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import com.jcraft.jsch.UserInfo
import com.novanet.nusaterm.data.HostProfile
import com.novanet.nusaterm.data.SshAuthType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStream

class SshSession(
    private val knownHostsFile: File,
    private val userInteraction: SshUserInteraction,
    private val onOutput: (CharArray, Int) -> Unit,
    private val onStatusChange: (SshConnectionStatus, String?) -> Unit
) {
    private var session: Session? = null
    private var channel: ChannelShell? = null
    private var writer: OutputStream? = null
    private var readerJob: Job? = null
    private val ioScope = CoroutineScope(Dispatchers.IO)

    suspend fun connect(
        profile: HostProfile,
        password: String?,
        privateKeyPem: String?,
        passphrase: String?,
        cols: Int,
        rows: Int
    ): Unit = withContext(Dispatchers.IO) {
        onStatusChange(SshConnectionStatus.CONNECTING, null)
        try {
            if (!knownHostsFile.exists()) {
                knownHostsFile.parentFile?.mkdirs()
                knownHostsFile.createNewFile()
            }

            val jsch = JSch()
            jsch.setKnownHosts(knownHostsFile.absolutePath)

            if (profile.authType == SshAuthType.PRIVATE_KEY && privateKeyPem != null) {
                jsch.addIdentity(
                    "host_${profile.id}",
                    privateKeyPem.toByteArray(Charsets.UTF_8),
                    null,
                    passphrase?.toByteArray(Charsets.UTF_8)
                )
            }

            val newSession = jsch.getSession(profile.username, profile.hostname, profile.port)
            newSession.userInfo = object : UserInfo {
                override fun getPassphrase(): String? = passphrase
                override fun getPassword(): String? = password
                override fun promptPassword(message: String?): Boolean = password != null
                override fun promptPassphrase(message: String?): Boolean = true
                override fun promptYesNo(message: String?): Boolean =
                    userInteraction.requestHostKeyConfirmation(
                        message ?: "Host key tidak dikenal. Lanjutkan koneksi?"
                    )
                override fun showMessage(message: String?) { /* tidak dipakai */ }
            }
            newSession.setConfig("StrictHostKeyChecking", "ask")
            newSession.setConfig("PreferredAuthentications", "publickey,password,keyboard-interactive")
            if (profile.authType == SshAuthType.PASSWORD) {
                newSession.setPassword(password)
            }
            newSession.timeout = 15000
            newSession.connect(15000)
            session = newSession

            val shellChannel = newSession.openChannel("shell") as ChannelShell
            shellChannel.setPtyType("xterm-256color")
            shellChannel.setPtySize(cols, rows, cols * 8, rows * 16)
            val input = shellChannel.inputStream
            writer = shellChannel.outputStream
            shellChannel.connect(10000)
            channel = shellChannel

            onStatusChange(SshConnectionStatus.CONNECTED, null)

            readerJob = ioScope.launch {
                val isr = InputStreamReader(input, Charsets.UTF_8)
                val charBuf = CharArray(4096)
                try {
                    while (true) {
                        val n = isr.read(charBuf)
                        if (n < 0) break
                        onOutput(charBuf, n)
                    }
                } catch (e: Exception) {
                    // stream ditutup, umumnya karena disconnect() dipanggil
                } finally {
                    onStatusChange(SshConnectionStatus.DISCONNECTED, null)
                }
            }
        } catch (e: Exception) {
            onStatusChange(SshConnectionStatus.FAILED, e.message ?: "Gagal terhubung ke host")
            throw e
        }
    }

    fun write(text: String) {
        try {
            writer?.write(text.toByteArray(Charsets.UTF_8))
            writer?.flush()
        } catch (e: Exception) {
            // koneksi mungkin sudah tertutup, abaikan
        }
    }

    fun resize(cols: Int, rows: Int) {
        try {
            channel?.setPtySize(cols, rows, cols * 8, rows * 16)
        } catch (e: Exception) { }
    }

    fun disconnect() {
        readerJob?.cancel()
        try { channel?.disconnect() } catch (e: Exception) { }
        try { session?.disconnect() } catch (e: Exception) { }
        onStatusChange(SshConnectionStatus.DISCONNECTED, null)
    }
}
