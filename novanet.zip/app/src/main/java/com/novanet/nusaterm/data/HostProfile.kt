package com.novanet.nusaterm.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class SshAuthType {
    PASSWORD,
    PRIVATE_KEY
}

/**
 * Data non-rahasia sebuah koneksi SSH tersimpan.
 * Kredensial (password, private key, passphrase) TIDAK disimpan di sini,
 * melainkan di [com.novanet.nusaterm.data.CredentialStore] yang terenkripsi.
 */
@Entity(tableName = "host_profiles")
data class HostProfile(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val label: String,
    val hostname: String,
    val port: Int = 22,
    val username: String,
    val authType: SshAuthType,
    val createdAt: Long = System.currentTimeMillis()
)
