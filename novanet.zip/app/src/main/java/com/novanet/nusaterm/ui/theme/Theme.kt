package com.novanet.nusaterm.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val NusaDarkColors = darkColorScheme(
    primary = AccentTeal,
    secondary = AccentBlue,
    background = BgDeep,
    surface = BgSurface,
    surfaceVariant = BgSurfaceAlt,
    onPrimary = BgDeep,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = DangerRed
)

@Composable
fun NusaTermTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NusaDarkColors,
        typography = NusaTypography,
        content = content
    )
}
