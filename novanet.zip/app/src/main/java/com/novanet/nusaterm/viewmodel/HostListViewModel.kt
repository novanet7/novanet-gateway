package com.novanet.nusaterm.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.novanet.nusaterm.data.HostProfile
import com.novanet.nusaterm.data.HostRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HostListViewModel(private val repository: HostRepository) : ViewModel() {

    val hosts: StateFlow<List<HostProfile>> = repository.observeHosts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun deleteHost(profile: HostProfile) {
        viewModelScope.launch { repository.deleteHost(profile) }
    }

    class Factory(private val repository: HostRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HostListViewModel(repository) as T
        }
    }
}
