package com.novanet.nusaterm.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.novanet.nusaterm.ssh.SshConnectionStatus
import com.novanet.nusaterm.ui.components.CommandSuggestionBar
import com.novanet.nusaterm.ui.components.TerminalView
import com.novanet.nusaterm.ui.components.VirtualKeyboardBar
import com.novanet.nusaterm.viewmodel.TerminalViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalComposeUiApi::class)
@Composable
fun TerminalScreen(
    viewModel: TerminalViewModel,
    onBack: () -> Unit
) {
    val hostKeyPrompt by viewModel.userInteraction.prompt.collectAsState()
    val focusRequester = remember { FocusRequester() }
    var fieldValue by remember { mutableStateOf(TextFieldValue("")) }
    var started by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(viewModel.hostLabel.ifEmpty { "Terminal" })
                        Text(
                            statusLabel(viewModel.status),
                            style = MaterialTheme.typography.bodyMedium,
                            color = statusColor(viewModel.status)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                },
                actions = {
                    if (viewModel.status == SshConnectionStatus.FAILED || viewModel.status == SshConnectionStatus.DISCONNECTED) {
                        IconButton(onClick = { viewModel.reconnect(80, 30) }) {
                            Icon(Icons.Filled.Refresh, contentDescription = "Sambungkan ulang")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(4.dp)
            ) {
                TerminalView(
                    terminal = viewModel.terminal,
                    renderTick = viewModel.renderTick,
                    modifier = Modifier
                        .fillMaxSize()
                        .focusRequester(focusRequester)
                        .onKeyEvent { event ->
                            if (event.type == KeyEventType.KeyDown) {
                                when (event.key) {
                                    Key.Backspace -> { viewModel.sendInput("\u007F"); true }
                                    Key.Enter, Key.NumPadEnter -> { viewModel.sendInput("\r"); true }
                                    else -> false
                                }
                            } else false
                        },
                    onMeasured = { cols, rows ->
                        if (!started) {
                            started = true
                            viewModel.start(cols, rows)
                        } else {
                            viewModel.onResize(cols, rows)
                        }
                    }
                )

                // Kolom input tak terlihat yang menampung IME (papan ketik) untuk mengirim karakter.
                BasicTextField(
                    value = fieldValue,
                    onValueChange = { new ->
                        val added = new.text
                        if (added.isNotEmpty()) {
                            viewModel.sendInput(added)
                        }
                        fieldValue = TextFieldValue("")
                    },
                    modifier = Modifier
                        .size(1.dp)
                        .focusRequester(focusRequester),
                    textStyle = TextStyle.Default,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { viewModel.sendInput("\r") })
                )
            }

            CommandSuggestionBar(
                suggestions = viewModel.suggestions,
                onPick = { viewModel.acceptSuggestion(it) }
            )
            VirtualKeyboardBar(onSend = { viewModel.sendInput(it) })
        }
    }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    hostKeyPrompt?.let { prompt ->
        AlertDialog(
            onDismissRequest = { viewModel.answerHostKeyPrompt(false) },
            title = { Text("Verifikasi Host Key") },
            text = { Text(prompt.message) },
            confirmButton = {
                TextButton(onClick = { viewModel.answerHostKeyPrompt(true) }) {
                    Text("Terima & Lanjutkan")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.answerHostKeyPrompt(false) }) {
                    Text("Tolak")
                }
            }
        )
    }
}

@Composable
private fun statusLabel(status: SshConnectionStatus): String = when (status) {
    SshConnectionStatus.CONNECTING -> "Menghubungkan..."
    SshConnectionStatus.CONNECTED -> "Terhubung"
    SshConnectionStatus.DISCONNECTED -> "Terputus"
    SshConnectionStatus.FAILED -> "Gagal terhubung"
}

@Composable
private fun statusColor(status: SshConnectionStatus) = when (status) {
    SshConnectionStatus.CONNECTED -> MaterialTheme.colorScheme.primary
    SshConnectionStatus.FAILED -> MaterialTheme.colorScheme.error
    else -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
}
