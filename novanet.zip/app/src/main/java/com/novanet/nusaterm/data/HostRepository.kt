package com.novanet.nusaterm.data

import kotlinx.coroutines.flow.Flow

class HostRepository(
    private val dao: HostDao,
    private val credentialStore: CredentialStore,
    private val commandHistoryDao: CommandHistoryDao
) {
    fun observeHosts(): Flow<List<HostProfile>> = dao.observeAll()

    suspend fun getHost(id: Long): HostProfile? = dao.getById(id)

    /** Menyimpan profil host beserta kredensialnya (password / key / passphrase). */
    suspend fun saveHost(
        profile: HostProfile,
        password: String?,
        privateKeyPem: String?,
        passphrase: String?
    ): Long {
        val id = dao.upsert(profile)
        val effectiveId = if (profile.id != 0L) profile.id else id

        when (profile.authType) {
            SshAuthType.PASSWORD -> {
                password?.let { credentialStore.savePassword(effectiveId, it) }
            }
            SshAuthType.PRIVATE_KEY -> {
                privateKeyPem?.let { credentialStore.savePrivateKey(effectiveId, it) }
                if (!passphrase.isNullOrEmpty()) {
                    credentialStore.savePassphrase(effectiveId, passphrase)
                }
            }
        }
        return effectiveId
    }

    suspend fun deleteHost(profile: HostProfile) {
        dao.delete(profile)
        credentialStore.clearFor(profile.id)
    }

    fun getPassword(hostId: Long): String? = credentialStore.getPassword(hostId)
    fun getPrivateKey(hostId: Long): String? = credentialStore.getPrivateKey(hostId)
    fun getPassphrase(hostId: Long): String? = credentialStore.getPassphrase(hostId)

    /** Dipanggil setiap pengguna menekan Enter di terminal, menyimpan/menaikkan skor command tsb. */
    suspend fun recordCommand(hostId: Long, command: String) {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return
        val existing = commandHistoryDao.find(hostId, trimmed)
        if (existing != null) {
            commandHistoryDao.update(
                existing.copy(useCount = existing.useCount + 1, lastUsedAt = System.currentTimeMillis())
            )
        } else {
            commandHistoryDao.insert(CommandHistoryEntity(hostId = hostId, command = trimmed))
        }
    }

    /** Menyarankan command yang pernah diketik di host ini, dimulai dengan [prefix]. */
    suspend fun getSuggestions(hostId: Long, prefix: String): List<String> {
        if (prefix.isBlank()) return emptyList()
        val escaped = prefix.replace("%", "\\%").replace("_", "\\_")
        return commandHistoryDao.suggest(hostId, "$escaped%")
            .map { it.command }
            .filterNot { it == prefix }
    }
}
