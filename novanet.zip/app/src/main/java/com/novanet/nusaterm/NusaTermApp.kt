package com.novanet.nusaterm

import android.app.Application
import com.novanet.nusaterm.data.AppDatabase
import com.novanet.nusaterm.data.CredentialStore
import com.novanet.nusaterm.data.HostRepository

class NusaTermApp : Application() {

    lateinit var hostRepository: HostRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = AppDatabase.getInstance(this)
        val credentialStore = CredentialStore(this)
        hostRepository = HostRepository(db.hostDao(), credentialStore, db.commandHistoryDao())
    }
}
