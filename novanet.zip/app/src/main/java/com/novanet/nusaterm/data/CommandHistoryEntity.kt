package com.novanet.nusaterm.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Menyimpan command yang pernah diketik pengguna di suatu host, dipakai untuk
 * fitur autocomplete/prediksi (mis. ketik "npm" -> disarankan "npm install").
 */
@Entity(tableName = "command_history")
data class CommandHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val hostId: Long,
    val command: String,
    val useCount: Int = 1,
    val lastUsedAt: Long = System.currentTimeMillis()
)
