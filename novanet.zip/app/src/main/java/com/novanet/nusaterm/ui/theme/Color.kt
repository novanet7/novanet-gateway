package com.novanet.nusaterm.ui.theme

import androidx.compose.ui.graphics.Color

val BgDeep = Color(0xFF0B1120)
val BgSurface = Color(0xFF141C2E)
val BgSurfaceAlt = Color(0xFF1B2438)
val AccentTeal = Color(0xFF22D3A5)
val AccentBlue = Color(0xFF61AFEF)
val TextPrimary = Color(0xFFE4E4E7)
val TextSecondary = Color(0xFF8B95A8)
val DangerRed = Color(0xFFE06C75)
val WarningYellow = Color(0xFFE5C07B)
