package com.novanet.nusaterm.ssh

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.concurrent.SynchronousQueue

data class HostKeyPrompt(val message: String)

/**
 * JSch memanggil UserInfo.promptYesNo() secara sinkron di thread background saat
 * bertemu host key baru/berubah. Kelas ini menjembatani panggilan blocking tsb
 * ke dialog Compose di UI thread, lalu menunggu jawaban pengguna.
 */
class SshUserInteraction {
    private val _prompt = MutableStateFlow<HostKeyPrompt?>(null)
    val prompt: StateFlow<HostKeyPrompt?> = _prompt

    private val answerQueue = SynchronousQueue<Boolean>()

    /** Dipanggil dari thread background JSch - memblokir sampai pengguna menjawab. */
    fun requestHostKeyConfirmation(message: String): Boolean {
        _prompt.value = HostKeyPrompt(message)
        val answer = answerQueue.take()
        _prompt.value = null
        return answer
    }

    /** Dipanggil dari UI saat pengguna menekan tombol Terima/Tolak pada dialog. */
    fun answer(accept: Boolean) {
        answerQueue.offer(accept)
    }
}
