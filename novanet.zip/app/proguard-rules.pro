# Aturan ProGuard/R8 khusus proyek ini bisa ditambahkan di sini.
-keep class com.jcraft.jsch.** { *; }
