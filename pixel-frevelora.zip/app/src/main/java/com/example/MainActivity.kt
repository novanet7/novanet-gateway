package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.game.ui.GameScreen
import com.example.game.ui.TitleScreen
import com.example.ui.theme.MyApplicationTheme

enum class AppScreen {
    TITLE,
    GAME
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0F172A)
                ) {
                    var currentScreen by remember { mutableStateOf(AppScreen.TITLE) }

                    when (currentScreen) {
                        AppScreen.TITLE -> {
                            TitleScreen(
                                onStartGame = { currentScreen = AppScreen.GAME }
                            )
                        }
                        AppScreen.GAME -> {
                            BackHandler {
                                currentScreen = AppScreen.TITLE
                            }
                            GameScreen(
                                onExitToTitle = { currentScreen = AppScreen.TITLE }
                            )
                        }
                    }
                }
            }
        }
    }
}
