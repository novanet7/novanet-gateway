package com.example.game.world

import com.example.game.items.Item
import com.example.game.items.ItemRegistry

enum class TileCategory {
    FLOOR,
    SOLID,
    NATURAL_RESOURCE,
    STRUCTURE,
    CROP
}

enum class ToolRequirement {
    NONE,
    AXE,
    PICKAXE,
    HOE
}

data class TileType(
    val id: String,
    val name: String,
    val category: TileCategory,
    val isSolid: Boolean = false,
    val isWater: Boolean = false,
    val lightEmission: Int = 0, // 0 to 10
    val hardness: Int = 1, // hits required without tool
    val requiredTool: ToolRequirement = ToolRequirement.NONE,
    val minToolTier: Int = 0,
    val dropItem: (() -> Item)? = null,
    val dropCountMin: Int = 1,
    val dropCountMax: Int = 1,
    // Rendering tints
    val primaryColor: Long = 0xFF557A2B,
    val secondaryColor: Long = 0xFF3E5A1C,
    val accentColor: Long = 0xFF2A3D13
)

object TileRegistry {
    // --- FLOORS / TERRAIN ---
    val GRASS = TileType(
        id = "grass",
        name = "Rumput Hijau",
        category = TileCategory.FLOOR,
        primaryColor = 0xFF4CAF50,
        secondaryColor = 0xFF388E3C,
        accentColor = 0xFF2E7D32
    )

    val DIRT = TileType(
        id = "dirt",
        name = "Tanah (Dirt)",
        category = TileCategory.FLOOR,
        dropItem = { ItemRegistry.STONE },
        primaryColor = 0xFF795548,
        secondaryColor = 0xFF5D4037,
        accentColor = 0xFF4E342E
    )

    val SAND = TileType(
        id = "sand",
        name = "Pasir Gurun",
        category = TileCategory.FLOOR,
        primaryColor = 0xFFE6C280,
        secondaryColor = 0xFFD4AA6A,
        accentColor = 0xFFC29655
    )

    val WATER = TileType(
        id = "water",
        name = "Air Jernih",
        category = TileCategory.FLOOR,
        isWater = true,
        isSolid = true, // need bridge or boat
        primaryColor = 0xFF2196F3,
        secondaryColor = 0xFF1976D2,
        accentColor = 0xFF64B5F6
    )

    val STONE_FLOOR = TileType(
        id = "stone_floor",
        name = "Lantai Batu",
        category = TileCategory.FLOOR,
        primaryColor = 0xFF9E9E9E,
        secondaryColor = 0xFF757575,
        accentColor = 0xFF616161
    )

    val WOOD_FLOOR = TileType(
        id = "wood_floor",
        name = "Lantai Kayu",
        category = TileCategory.FLOOR,
        dropItem = { ItemRegistry.WOOD_FLOOR },
        primaryColor = 0xFFA0522D,
        secondaryColor = 0xFF8B4513,
        accentColor = 0xFF6A340D
    )

    val SNOW = TileType(
        id = "snow",
        name = "Salju Dingin",
        category = TileCategory.FLOOR,
        primaryColor = 0xFFECEFF1,
        secondaryColor = 0xFFCFD8DC,
        accentColor = 0xFFB0BEC5
    )

    val LAVA = TileType(
        id = "lava",
        name = "Lava Membara",
        category = TileCategory.FLOOR,
        isSolid = true,
        lightEmission = 9,
        primaryColor = 0xFFFF5722,
        secondaryColor = 0xFFE64A19,
        accentColor = 0xFFFFAB00
    )

    // --- FARMLAND & CROPS ---
    val FARMLAND = TileType(
        id = "farmland",
        name = "Lahan Pertanian",
        category = TileCategory.FLOOR,
        primaryColor = 0xFF4E342E,
        secondaryColor = 0xFF3E2723,
        accentColor = 0xFF2E1C18
    )

    val CROP_WHEAT_READY = TileType(
        id = "crop_wheat",
        name = "Gandum Siap Panen",
        category = TileCategory.CROP,
        dropItem = { ItemRegistry.WHEAT },
        dropCountMin = 1,
        dropCountMax = 2,
        primaryColor = 0xFFFFD700,
        secondaryColor = 0xFFDAA520,
        accentColor = 0xFFB8860B
    )

    // --- NATURAL SOLID RESOURCES ---
    val TREE_OAK = TileType(
        id = "tree_oak",
        name = "Pohon Ek (Oak)",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 4,
        requiredTool = ToolRequirement.AXE,
        dropItem = { ItemRegistry.WOOD },
        dropCountMin = 2,
        dropCountMax = 4,
        primaryColor = 0xFF2E7D32,
        secondaryColor = 0xFF1B5E20,
        accentColor = 0xFF5D4037
    )

    val TREE_PINE = TileType(
        id = "tree_pine",
        name = "Pohon Pinus (Pine)",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 4,
        requiredTool = ToolRequirement.AXE,
        dropItem = { ItemRegistry.WOOD },
        dropCountMin = 3,
        dropCountMax = 4,
        primaryColor = 0xFF1E4620,
        secondaryColor = 0xFF0E2A10,
        accentColor = 0xFF4E342E
    )

    val TREE_BIRCH = TileType(
        id = "tree_birch",
        name = "Pohon Birch (Betula)",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 4,
        requiredTool = ToolRequirement.AXE,
        dropItem = { ItemRegistry.WOOD },
        dropCountMin = 2,
        dropCountMax = 4,
        primaryColor = 0xFFFFF9C4,
        secondaryColor = 0xFFE0E0E0,
        accentColor = 0xFF212121
    )

    val TREE_CHERRY = TileType(
        id = "tree_cherry",
        name = "Pohon Sakura (Cherry Blossom)",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 4,
        requiredTool = ToolRequirement.AXE,
        dropItem = { ItemRegistry.WOOD },
        dropCountMin = 2,
        dropCountMax = 4,
        primaryColor = 0xFFF48FB1,
        secondaryColor = 0xFFEC407A,
        accentColor = 0xFF4E342E
    )

    val TREE_AUTUMN = TileType(
        id = "tree_autumn",
        name = "Pohon Maple Emas (Autumn)",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 4,
        requiredTool = ToolRequirement.AXE,
        dropItem = { ItemRegistry.WOOD },
        dropCountMin = 2,
        dropCountMax = 4,
        primaryColor = 0xFFFF7043,
        secondaryColor = 0xFFFF5722,
        accentColor = 0xFFBF360C
    )

    val TREE_WILLOW = TileType(
        id = "tree_willow",
        name = "Pohon Dedalu Purba (Willow)",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 5,
        requiredTool = ToolRequirement.AXE,
        dropItem = { ItemRegistry.WOOD },
        dropCountMin = 3,
        dropCountMax = 5,
        primaryColor = 0xFF558B2F,
        secondaryColor = 0xFF33691E,
        accentColor = 0xFF2E7D32
    )

    val CACTUS = TileType(
        id = "cactus",
        name = "Kaktus Gurun",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 2,
        dropItem = { ItemRegistry.FIBER },
        dropCountMin = 2,
        dropCountMax = 3,
        primaryColor = 0xFF43A047,
        secondaryColor = 0xFF2E7D32,
        accentColor = 0xFF1B5E20
    )

    val ROCK_BOULDER = TileType(
        id = "rock_boulder",
        name = "Batu Granit Besar",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 5,
        requiredTool = ToolRequirement.PICKAXE,
        dropItem = { ItemRegistry.STONE },
        dropCountMin = 2,
        dropCountMax = 4,
        primaryColor = 0xFF757575,
        secondaryColor = 0xFF616161,
        accentColor = 0xFF424242
    )

    val ROCK_MOSSY = TileType(
        id = "rock_mossy",
        name = "Batu Sungai Berlumut",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 5,
        requiredTool = ToolRequirement.PICKAXE,
        dropItem = { ItemRegistry.STONE },
        dropCountMin = 2,
        dropCountMax = 4,
        primaryColor = 0xFF4CAF50,
        secondaryColor = 0xFF607D8B,
        accentColor = 0xFF37474F
    )

    val ROCK_SLATE = TileType(
        id = "rock_slate",
        name = "Batu Sabak Hitam (Slate)",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 6,
        requiredTool = ToolRequirement.PICKAXE,
        dropItem = { ItemRegistry.STONE },
        dropCountMin = 2,
        dropCountMax = 4,
        primaryColor = 0xFF263238,
        secondaryColor = 0xFF37474F,
        accentColor = 0xFF455A64
    )

    val ROCK_CRYSTAL = TileType(
        id = "rock_crystal",
        name = "Batu Kristal Ametis",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 8,
        requiredTool = ToolRequirement.PICKAXE,
        minToolTier = 1,
        dropItem = { ItemRegistry.RUBY },
        dropCountMin = 1,
        dropCountMax = 2,
        primaryColor = 0xFFAB47BC,
        secondaryColor = 0xFF7B1FA2,
        accentColor = 0xFF4A148C
    )

    val COAL_ORE = TileType(
        id = "coal_ore",
        name = "Urat Batu Bara",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 6,
        requiredTool = ToolRequirement.PICKAXE,
        minToolTier = 1,
        dropItem = { ItemRegistry.COAL },
        dropCountMin = 1,
        dropCountMax = 3,
        primaryColor = 0xFF424242,
        secondaryColor = 0xFF212121,
        accentColor = 0xFF000000
    )

    val IRON_ORE = TileType(
        id = "iron_ore",
        name = "Urat Besi Murni",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 8,
        requiredTool = ToolRequirement.PICKAXE,
        minToolTier = 2,
        dropItem = { ItemRegistry.IRON_ORE },
        dropCountMin = 1,
        dropCountMax = 2,
        primaryColor = 0xFF8D6E63,
        secondaryColor = 0xFFD7CCC8,
        accentColor = 0xFFBCAAA4
    )

    val GOLD_ORE = TileType(
        id = "gold_ore",
        name = "Urat Emas Berkilau",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 10,
        requiredTool = ToolRequirement.PICKAXE,
        minToolTier = 2,
        dropItem = { ItemRegistry.GOLD_ORE },
        dropCountMin = 1,
        dropCountMax = 2,
        primaryColor = 0xFFFFD700,
        secondaryColor = 0xFF616161,
        accentColor = 0xFFFFEA00
    )

    val DIAMOND_ORE = TileType(
        id = "diamond_ore",
        name = "Geoda Berlian",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 14,
        requiredTool = ToolRequirement.PICKAXE,
        minToolTier = 3,
        dropItem = { ItemRegistry.DIAMOND },
        dropCountMin = 1,
        dropCountMax = 1,
        primaryColor = 0xFF00E5FF,
        secondaryColor = 0xFF424242,
        accentColor = 0xFFE0F7FA
    )

    val RUBY_ORE = TileType(
        id = "ruby_ore",
        name = "Kristal Ruby Merah",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = true,
        hardness = 12,
        requiredTool = ToolRequirement.PICKAXE,
        minToolTier = 3,
        dropItem = { ItemRegistry.RUBY },
        dropCountMin = 1,
        dropCountMax = 1,
        primaryColor = 0xFFFF1744,
        secondaryColor = 0xFF424242,
        accentColor = 0xFFFF80AB
    )

    val BERRY_BUSH = TileType(
        id = "berry_bush",
        name = "Semak Buah Beri",
        category = TileCategory.NATURAL_RESOURCE,
        isSolid = false,
        hardness = 1,
        dropItem = { ItemRegistry.BERRY },
        dropCountMin = 2,
        dropCountMax = 4,
        primaryColor = 0xFF2E7D32,
        secondaryColor = 0xFFC2185B,
        accentColor = 0xFFE91E63
    )

    // --- STRUCTURES & PLACED TILES ---
    val WOOD_WALL = TileType(
        id = "wood_wall",
        name = "Dinding Kayu",
        category = TileCategory.STRUCTURE,
        isSolid = true,
        hardness = 6,
        requiredTool = ToolRequirement.AXE,
        dropItem = { ItemRegistry.WOOD_WALL },
        primaryColor = 0xFF8B5A2B,
        secondaryColor = 0xFF5C3A21,
        accentColor = 0xFF3D2513
    )

    val STONE_WALL = TileType(
        id = "stone_wall",
        name = "Dinding Batu",
        category = TileCategory.STRUCTURE,
        isSolid = true,
        hardness = 10,
        requiredTool = ToolRequirement.PICKAXE,
        dropItem = { ItemRegistry.STONE_WALL },
        primaryColor = 0xFF616161,
        secondaryColor = 0xFF424242,
        accentColor = 0xFF212121
    )

    val TORCH = TileType(
        id = "torch",
        name = "Obor",
        category = TileCategory.STRUCTURE,
        isSolid = false,
        lightEmission = 8,
        dropItem = { ItemRegistry.TORCH },
        primaryColor = 0xFFFF9800,
        secondaryColor = 0xFFFFEB3B,
        accentColor = 0xFF795548
    )

    val CAMPFIRE = TileType(
        id = "campfire",
        name = "Api Unggun",
        category = TileCategory.STRUCTURE,
        isSolid = true,
        lightEmission = 9,
        dropItem = { ItemRegistry.CAMPFIRE },
        primaryColor = 0xFFFF5722,
        secondaryColor = 0xFFFFC107,
        accentColor = 0xFF5D4037
    )

    val WORKBENCH = TileType(
        id = "workbench",
        name = "Meja Kerja",
        category = TileCategory.STRUCTURE,
        isSolid = true,
        hardness = 4,
        dropItem = { ItemRegistry.WORKBENCH },
        primaryColor = 0xFF8D6E63,
        secondaryColor = 0xFFD7CCC8,
        accentColor = 0xFF4E342E
    )

    val FURNACE = TileType(
        id = "furnace",
        name = "Tungku Pelebur",
        category = TileCategory.STRUCTURE,
        isSolid = true,
        hardness = 6,
        lightEmission = 5,
        dropItem = { ItemRegistry.FURNACE },
        primaryColor = 0xFF424242,
        secondaryColor = 0xFFFF5722,
        accentColor = 0xFF212121
    )

    val CHEST = TileType(
        id = "chest",
        name = "Peti Harta Karun",
        category = TileCategory.STRUCTURE,
        isSolid = true,
        hardness = 4,
        dropItem = { ItemRegistry.CHEST },
        primaryColor = 0xFF8B4513,
        secondaryColor = 0xFFFFD700,
        accentColor = 0xFF5C2E0C
    )

    val BED = TileType(
        id = "bed",
        name = "Tempat Tidur",
        category = TileCategory.STRUCTURE,
        isSolid = true,
        hardness = 3,
        dropItem = { ItemRegistry.BED },
        primaryColor = 0xFFD32F2F,
        secondaryColor = 0xFFFFFFFF,
        accentColor = 0xFF5D4037
    )

    val CIVILIZATION_TOTEM = TileType(
        id = "civilization_totem",
        name = "Totem Peradaban Fr3velora",
        category = TileCategory.STRUCTURE,
        isSolid = true,
        hardness = 20,
        lightEmission = 10,
        dropItem = { ItemRegistry.CIVILIZATION_TOTEM },
        primaryColor = 0xFFFFD700,
        secondaryColor = 0xFF9C27B0,
        accentColor = 0xFF00E5FF
    )

    val WATCHTOWER = TileType(
        id = "watchtower",
        name = "Menara Pengawas",
        category = TileCategory.STRUCTURE,
        isSolid = true,
        hardness = 15,
        lightEmission = 6,
        dropItem = { ItemRegistry.WATCHTOWER },
        primaryColor = 0xFF607D8B,
        secondaryColor = 0xFF455A64,
        accentColor = 0xFFFF5722
    )

    val QUARRY_STATION = TileType(
        id = "quarry_station",
        name = "Tambang Otomatis",
        category = TileCategory.STRUCTURE,
        isSolid = true,
        hardness = 12,
        dropItem = { ItemRegistry.QUARRY_STATION },
        primaryColor = 0xFF37474F,
        secondaryColor = 0xFF90A4AE,
        accentColor = 0xFFFFD54F
    )

    private val allTiles = listOf(
        GRASS, DIRT, SAND, WATER, STONE_FLOOR, WOOD_FLOOR, SNOW, LAVA, FARMLAND, CROP_WHEAT_READY,
        TREE_OAK, TREE_PINE, TREE_BIRCH, TREE_CHERRY, TREE_AUTUMN, TREE_WILLOW,
        CACTUS, ROCK_BOULDER, ROCK_MOSSY, ROCK_SLATE, ROCK_CRYSTAL,
        COAL_ORE, IRON_ORE, GOLD_ORE, DIAMOND_ORE, RUBY_ORE, BERRY_BUSH,
        WOOD_WALL, STONE_WALL, TORCH, CAMPFIRE, WORKBENCH, FURNACE, CHEST, BED,
        CIVILIZATION_TOTEM, WATCHTOWER, QUARRY_STATION
    )

    private val tileMap = allTiles.associateBy { it.id }

    fun getTile(id: String): TileType = tileMap[id] ?: GRASS
}
