package com.example.game.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.GameEngine
import com.example.game.renderer.PixelRenderer
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

enum class ModalScreen {
    NONE,
    INVENTORY,
    CRAFTING,
    CIVILIZATION,
    QUESTS,
    BOSS_SUMMON,
    SETTINGS
}

@Composable
fun GameScreen(
    onExitToTitle: () -> Unit
) {
    val context = LocalContext.current
    val engine = remember { GameEngine(context) }
    var activeModal by remember { mutableStateOf(ModalScreen.NONE) }
    var joystickDirX by remember { mutableFloatStateOf(0f) }
    var joystickDirY by remember { mutableFloatStateOf(0f) }
    val animTimeState = remember { mutableFloatStateOf(0f) }
    val uiTick by engine.uiTick.collectAsState()

    val density = LocalDensity.current
    val tileSizePx = with(density) { 44.dp.toPx() }

    // Real-time 60FPS Game Loop
    LaunchedEffect(Unit) {
        var lastTime = System.nanoTime()
        while (isActive) {
            val now = System.nanoTime()
            val deltaSeconds = ((now - lastTime) / 1_000_000_000.0).toFloat().coerceIn(0.001f, 0.05f)
            lastTime = now

            animTimeState.floatValue += deltaSeconds

            // Apply player movement from virtual joystick
            engine.movePlayer(joystickDirX, joystickDirY, deltaSeconds)

            // Update entire game engine
            engine.update(deltaSeconds)

            delay(16) // ~60 FPS
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Game Canvas with World Rendering & Direct Tap Interactions
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { tapOffset ->
                        val centerX = size.width / 2f
                        val centerY = size.height / 2f
                        val worldTapX = engine.player.x + (tapOffset.x - centerX) / tileSizePx
                        val worldTapY = engine.player.y + (tapOffset.y - centerY) / tileSizePx

                        val tx = worldTapX.toInt()
                        val ty = worldTapY.toInt()

                        // Check if tapping a block near player
                        val distSq = (tx - engine.player.x) * (tx - engine.player.x) + (ty - engine.player.y) * (ty - engine.player.y)
                        if (distSq <= 12f) {
                            val feature = engine.getFeatureTile(tx, ty)
                            if (feature != null) {
                                engine.mineBlock(tx, ty, feature, engine.player.getEquippedItem()?.item)
                            } else {
                                val equipped = engine.player.getEquippedItem()
                                if (equipped?.item?.placesTileId != null) {
                                    val placeTile = com.example.game.world.TileRegistry.getTile(equipped.item.placesTileId)
                                    if (placeTile.category == com.example.game.world.TileCategory.FLOOR) {
                                        engine.setBaseTile(tx, ty, placeTile)
                                    } else {
                                        engine.setFeatureTile(tx, ty, placeTile)
                                    }
                                    equipped.count--
                                    if (equipped.count <= 0) {
                                        engine.player.hotbar[engine.player.selectedHotbarIndex] = null
                                    }
                                    engine.soundManager.playCraftSuccess()
                                }
                            }
                        }
                    }
                }
        ) {
            val animTime = animTimeState.floatValue
            PixelRenderer.renderWorld(
                drawScope = this,
                engine = engine,
                tileSize = tileSizePx,
                animTime = animTime
            )
        }

        // HUD & On-Screen Controls (Cleanly throttled via uiTick to eliminate CPU starvation)
        key(uiTick) {
            GameHud(
                engine = engine,
                onOpenInventory = { activeModal = ModalScreen.INVENTORY },
                onOpenCrafting = { activeModal = ModalScreen.CRAFTING },
                onOpenCivilization = { activeModal = ModalScreen.CIVILIZATION },
                onOpenQuests = { activeModal = ModalScreen.QUESTS },
                onOpenSettings = { activeModal = ModalScreen.SETTINGS },
                onSummonBoss = { activeModal = ModalScreen.BOSS_SUMMON },
                onAttackMine = { engine.performAttackOrMine() },
                onInteractPlace = {
                    val openedModal = engine.interactOrPlace()
                    if (openedModal && engine.civilization.isFounded) {
                        activeModal = ModalScreen.CIVILIZATION
                    }
                },
                onDash = { engine.triggerDash() },
                onEat = { engine.consumeEquippedItem() },
                onJoystickMove = { nx, ny ->
                    joystickDirX = nx
                    joystickDirY = ny
                }
            )
        }

        // Modal Dialogs
        when (activeModal) {
            ModalScreen.INVENTORY -> InventoryModal(engine = engine, onDismiss = { activeModal = ModalScreen.NONE })
            ModalScreen.CRAFTING -> CraftingModal(engine = engine, onDismiss = { activeModal = ModalScreen.NONE })
            ModalScreen.CIVILIZATION -> CivilizationModal(engine = engine, onDismiss = { activeModal = ModalScreen.NONE })
            ModalScreen.QUESTS -> QuestsModal(engine = engine, onDismiss = { activeModal = ModalScreen.NONE })
            ModalScreen.BOSS_SUMMON -> BossSummonModal(engine = engine, onDismiss = { activeModal = ModalScreen.NONE })
            ModalScreen.SETTINGS -> SettingsModal(engine = engine, onDismiss = { activeModal = ModalScreen.NONE })
            ModalScreen.NONE -> { /* No modal */ }
        }

        // Game Over Overlay
        if (engine.player.hp <= 0) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xCC000000)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("KAMU TERKAPAR!", color = Color(0xFFFF1744), fontSize = 28.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Black)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Monster malam terlalu buas... Bersiaplah lebih kuat!", color = Color.White, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = {
                            engine.player.hp = engine.player.maxHp
                            engine.player.hunger = 100f
                            engine.player.stamina = 100f
                            engine.player.x = 0f
                            engine.player.y = 0f
                            engine.soundManager.playLevelUp()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                    ) {
                        Text("Bangkit Kembali di Titik Awal", fontSize = 15.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                    }
                }
            }
        }
    }
}
