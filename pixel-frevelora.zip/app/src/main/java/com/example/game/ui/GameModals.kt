package com.example.game.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.game.GameEngine
import com.example.game.civilization.Civilization
import com.example.game.entity.Player
import com.example.game.entity.VillagerRole
import com.example.game.items.*

// ================= INVENTORY & EQUIPMENT MODAL =================
@Composable
fun InventoryModal(
    engine: GameEngine,
    onDismiss: () -> Unit
) {
    val player = engine.player
    var selectedItemIndex by remember { mutableStateOf<Int?>(null) }
    var isHotbarSelected by remember { mutableStateOf(false) }

    val selectedStack = if (isHotbarSelected) {
        selectedItemIndex?.let { player.hotbar.getOrNull(it) }
    } else {
        selectedItemIndex?.let { player.inventory.getOrNull(it) }
    }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.92f)
                .testTag("inventory_modal")
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF1E293B),
                border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF64748B))
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_wood_panel_1790890850211),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        alpha = 0.22f
                    )

                    Column(modifier = Modifier.padding(14.dp)) {
                        // Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Backpack, contentDescription = null, tint = Color(0xFFFFD54F), modifier = Modifier.size(20.dp))
                                Text(
                                    text = "Tas Petualang & Perlengkapan Fr3velora",
                                    color = Color(0xFFFFD54F),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            // Left: Equipment Paperdoll
                            Column(
                                modifier = Modifier
                                    .width(130.dp)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xEE0F172A))
                                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp))
                                    .padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.SpaceAround
                            ) {
                                EquipmentSlotView(label = "Helm", stack = player.equippedHelmet)
                                EquipmentSlotView(label = "Zirah", stack = player.equippedChest)
                                EquipmentSlotView(label = "Sepatu", stack = player.equippedBoots)

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Pertahanan: ${player.getTotalDefense()}", color = Color(0xFF64B5F6), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    val wep = player.getEquippedItem()
                                    Text("Serangan: ${wep?.item?.attackDamage ?: 4}", color = Color(0xFFFF5252), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            // Right: Inventory Grid (27 slots) & Actions
                            Column(modifier = Modifier.weight(1f)) {
                                LazyVerticalGrid(
                                    columns = GridCells.Fixed(9),
                                    modifier = Modifier.weight(1f),
                                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                                    verticalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    itemsIndexed(player.inventory) { idx, stack ->
                                        val isSelected = !isHotbarSelected && selectedItemIndex == idx
                                        ItemSlotBox(
                                            stack = stack,
                                            isSelected = isSelected,
                                            onClick = {
                                                selectedItemIndex = idx
                                                isHotbarSelected = false
                                            }
                                        )
                                    }
                                }

                                if (selectedStack != null) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        color = Color(0xEE0F172A),
                                        shape = RoundedCornerShape(8.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "${selectedStack.item.name} (${selectedStack.count}x)",
                                                    color = Color(0xFFFFD54F),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1
                                                )
                                                Text(
                                                    text = selectedStack.item.description,
                                                    color = Color(0xFFCBD5E1),
                                                    fontSize = 9.sp,
                                                    maxLines = 1
                                                )
                                            }

                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                if (selectedStack.item.category == ItemCategory.FOOD || selectedStack.item.category == ItemCategory.POTION) {
                                                    Button(
                                                        onClick = {
                                                            player.hunger = kotlin.math.min(100f, player.hunger + selectedStack.item.hungerRestore)
                                                            player.hp = kotlin.math.min(player.maxHp, player.hp + selectedStack.item.hpRestore)
                                                            selectedStack.count--
                                                            if (selectedStack.count <= 0) {
                                                                if (isHotbarSelected) player.hotbar[selectedItemIndex!!] = null
                                                                else player.inventory[selectedItemIndex!!] = null
                                                                selectedItemIndex = null
                                                            }
                                                            engine.soundManager.playEat()
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF43A047)),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                    ) {
                                                        Text("Makan", fontSize = 10.sp)
                                                    }
                                                }

                                                if (selectedStack.item.category in listOf(ItemCategory.ARMOR_HEAD, ItemCategory.ARMOR_CHEST, ItemCategory.ARMOR_LEGS)) {
                                                    Button(
                                                        onClick = {
                                                            player.equipArmor(selectedStack)
                                                            if (isHotbarSelected) player.hotbar[selectedItemIndex!!] = null
                                                            else player.inventory[selectedItemIndex!!] = null
                                                            selectedItemIndex = null
                                                            engine.soundManager.playCraftSuccess()
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5)),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                    ) {
                                                        Text("Pakai", fontSize = 10.sp)
                                                    }
                                                }

                                                Button(
                                                    onClick = {
                                                        engine.droppedItems.add(
                                                            com.example.game.entity.DroppedItem(
                                                                x = player.x + 0.5f,
                                                                y = player.y + 0.5f,
                                                                itemStack = selectedStack.copyStack()
                                                            )
                                                        )
                                                        if (isHotbarSelected) player.hotbar[selectedItemIndex!!] = null
                                                        else player.inventory[selectedItemIndex!!] = null
                                                        selectedItemIndex = null
                                                        engine.soundManager.playMine()
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935)),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                                ) {
                                                    Text("Buang", fontSize = 10.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ================= CRAFTING MODAL =================
@Composable
fun CraftingModal(
    engine: GameEngine,
    onDismiss: () -> Unit
) {
    val categories = listOf("Semua", "Dasar", "Alat", "Senjata", "Zirah", "Bangunan", "Peleburan", "Peradaban", "Makanan")
    var selectedCategory by remember { mutableStateOf("Semua") }

    val filteredRecipes = remember(selectedCategory, engine.uiTick.collectAsState().value) {
        CraftingRegistry.recipes.filter {
            selectedCategory == "Semua" || it.category == selectedCategory
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.92f)
                .testTag("crafting_modal")
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF1E293B),
                border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFFFB8C00))
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_wood_panel_1790890850211),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        alpha = 0.22f
                    )

                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Build, contentDescription = null, tint = Color(0xFFFFD54F), modifier = Modifier.size(20.dp))
                                Text(
                                    text = "Meja Kriya & Perakitan Fr3velora",
                                    color = Color(0xFFFFD54F),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        ScrollableTabRow(
                            selectedTabIndex = categories.indexOf(selectedCategory),
                            edgePadding = 0.dp,
                            containerColor = Color(0xCC0F172A),
                            contentColor = Color(0xFFFFD54F)
                        ) {
                            categories.forEach { cat ->
                                Tab(
                                    selected = selectedCategory == cat,
                                    onClick = { selectedCategory = cat },
                                    text = { Text(cat, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(filteredRecipes) { recipe ->
                                val canCraft = recipe.canCraft(engine.player.getAllItems())
                                RecipeCard(recipe = recipe, canCraft = canCraft) {
                                    if (canCraft) {
                                        for (ing in recipe.ingredients) {
                                            engine.player.removeIngredients(ing.item.id, ing.count)
                                        }
                                        engine.player.addItem(recipe.result.copyStack())
                                        engine.soundManager.playCraftSuccess()
                                        engine.addFloatingText(engine.player.x, engine.player.y - 1f, "+${recipe.result.count} ${recipe.result.item.name}", 0xFF69F0AE)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ================= CIVILIZATION MODAL =================
@Composable
fun CivilizationModal(
    engine: GameEngine,
    onDismiss: () -> Unit
) {
    val civ = engine.civilization

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.92f)
                .testTag("civilization_modal")
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF1E293B),
                border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF7E57C2))
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_wood_panel_1790890850211),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        alpha = 0.22f
                    )

                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Castle, contentDescription = null, tint = Color(0xFFFFD700), modifier = Modifier.size(22.dp))
                                Column {
                                    Text(
                                        text = civ.name,
                                        color = Color(0xFFFFD700),
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = civ.levelTitle,
                                        color = Color(0xFFCE93D8),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                            IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (!civ.isFounded) {
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = Color(0xDD0F172A),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Peradaban Belum Didirikan!", color = Color(0xFFFF5252), fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Rakit dan pasang 'Totem Peradaban Fr3velora' (10 Kayu, 10 Batu, 2 Batangan Besi) di tanah untuk mendirikan desa perdanamu!",
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        } else {
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = Color(0xDD0F172A),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Kayu: ${civ.stockpile.wood}", color = Color(0xFFD7CCC8), fontSize = 11.sp)
                                        Text("Batu: ${civ.stockpile.stone}", color = Color(0xFFB0BEC5), fontSize = 11.sp)
                                        Text("Makanan: ${civ.stockpile.food}", color = Color(0xFFA5D6A7), fontSize = 11.sp)
                                        Text("Besi: ${civ.stockpile.iron}", color = Color(0xFF90CAF9), fontSize = 11.sp)
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Button(
                                        onClick = {
                                            val player = engine.player
                                            if (civ.stockpile.wood > 0) player.addItem(ItemStack(ItemRegistry.WOOD, civ.stockpile.wood))
                                            if (civ.stockpile.stone > 0) player.addItem(ItemStack(ItemRegistry.STONE, civ.stockpile.stone))
                                            if (civ.stockpile.food > 0) player.addItem(ItemStack(ItemRegistry.BREAD, civ.stockpile.food))
                                            if (civ.stockpile.iron > 0) player.addItem(ItemStack(ItemRegistry.IRON_INGOT, civ.stockpile.iron))
                                            if (civ.stockpile.gold > 0) player.addItem(ItemStack(ItemRegistry.GOLD_INGOT, civ.stockpile.gold))
                                            if (civ.stockpile.diamond > 0) player.addItem(ItemStack(ItemRegistry.DIAMOND, civ.stockpile.diamond))

                                            civ.stockpile.wood = 0
                                            civ.stockpile.stone = 0
                                            civ.stockpile.food = 0
                                            civ.stockpile.iron = 0
                                            civ.stockpile.gold = 0
                                            civ.stockpile.diamond = 0

                                            engine.soundManager.playPickup()
                                            engine.addFloatingText(player.x, player.y - 1f, "Hasil Lumbung Diklaim!", 0xFFFFD700)
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                        contentPadding = PaddingValues(vertical = 4.dp)
                                    ) {
                                        Text("Klaim Semua Hasil Lumbung ke Tas", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text("Daftar Warga (${civ.villagers.size}/${civ.populationMax}):", color = Color(0xFF94A3B8), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(3.dp))

                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                items(civ.villagers) { v ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(6.dp),
                                        color = Color(0xCC0F172A)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(v.role.clothesColor))
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Column {
                                                Text("${v.name} (${v.role.title})", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                Text(v.role.perkDescription, color = Color(0xFF94A3B8), fontSize = 9.sp)
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            val canUpgrade = civ.canUpgrade()
                            Button(
                                onClick = {
                                    if (civ.upgrade()) {
                                        engine.soundManager.playLevelUp()
                                        engine.addFloatingText(engine.player.x, engine.player.y - 1f, "PERADABAN NAIK KE LEVEL ${civ.level}!", 0xFFFFD700)
                                    }
                                },
                                enabled = canUpgrade,
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF6A1B9A),
                                    disabledContainerColor = Color(0xFF334155)
                                ),
                                contentPadding = PaddingValues(vertical = 4.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Tingkatkan Level Peradaban (Lv.${civ.level + 1})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("Syarat: ${civ.getUpgradeRequirements()}", fontSize = 9.sp, color = Color(0xFFFFD54F))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ================= BOSS SUMMON MODAL WITH ARTWORK =================
@Composable
fun BossSummonModal(
    engine: GameEngine,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .fillMaxHeight(0.88f)
                .testTag("boss_summon_modal")
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF1E293B),
                border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFFE53935))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.LocalFireDepartment, contentDescription = null, tint = Color(0xFFFF5252), modifier = Modifier.size(22.dp))
                            Text(
                                text = "Tantangan Boss: Naga Purba Fr3velora",
                                color = Color(0xFFFF5252),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Boss Artwork Banner
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .border(1.2.dp, Color(0xFFFF5252), RoundedCornerShape(10.dp))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_boss_dragon_1790890864007),
                            contentDescription = "Naga Purba",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Transparent, Color(0xAA1E293B))
                                    )
                                )
                        )
                        Text(
                            text = "HP: 800 • Serangan: 45 (Semburan Api Ungu)",
                            color = Color(0xFFFFD54F),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Hadiah Kemenangan: Inti Kekuatan Purba, 5x Berlian Murni, 10x Batangan Emas, dan membuka resep 'Fr3velora God Blade'!",
                        color = Color(0xFFCBD5E1),
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    Button(
                        onClick = {
                            engine.summonWorldBoss()
                            onDismiss()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFFEA00), modifier = Modifier.size(18.dp))
                            Text(
                                text = "BANGKITKAN NAGA PURBA SEKARANG",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

// ================= QUESTS MODAL =================
@Composable
fun QuestsModal(
    engine: GameEngine,
    onDismiss: () -> Unit
) {
    val quests = listOf(
        Pair("gather_wood", "Penebang Rimba: Kumpulkan Kayu Hutan"),
        Pair("craft_pickaxe", "Perkakas Pertama: Buat Alat Beliung atau Kapak"),
        Pair("mine_iron", "Zaman Besi: Tambang dan Lebur Bijih Besi"),
        Pair("found_civilization", "Pendiri Bangsa: Tancapkan Totem Peradaban Fr3velora")
    )

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .fillMaxHeight(0.85f)
                .testTag("quests_modal")
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF1E293B),
                border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFFFDD835))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = Color(0xFFFFD54F), modifier = Modifier.size(20.dp))
                            Text(
                                text = "Misi Petualangan & Kejayaan",
                                color = Color(0xFFFFD54F),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(quests) { q ->
                            val isDone = engine.completedQuests.contains(q.first)
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF0F172A),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isDone) Color(0xFF4CAF50) else Color(0xFF334155)
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (isDone) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                        contentDescription = null,
                                        tint = if (isDone) Color(0xFF4CAF50) else Color(0xFF64748B),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(q.second, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text(if (isDone) "Selesai (+50 XP)" else "Hadiah: +50 XP", color = if (isDone) Color(0xFF81C784) else Color(0xFF94A3B8), fontSize = 9.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ================= SETTINGS MODAL =================
@Composable
fun SettingsModal(
    engine: GameEngine,
    onDismiss: () -> Unit
) {
    var isMuted by remember { mutableStateOf(engine.soundManager.isSoundMuted()) }
    var isHaptics by remember { mutableStateOf(engine.soundManager.isHapticsEnabled()) }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .testTag("settings_modal")
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF1E293B),
                border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF78909C))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Pengaturan Game",
                            color = Color(0xFFFFD54F),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Efek Suara 8-Bit", color = Color.White, fontSize = 12.sp)
                        Switch(
                            checked = !isMuted,
                            onCheckedChange = {
                                isMuted = engine.soundManager.toggleMute()
                            }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Getaran Haptic Feedback", color = Color.White, fontSize = 12.sp)
                        Switch(
                            checked = isHaptics,
                            onCheckedChange = {
                                isHaptics = engine.soundManager.toggleHaptics()
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF0F172A),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Text("Panduan Tombol:", color = Color(0xFFFFD54F), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("• Joystick Kiri Bawah: Berjalan 360°", color = Color(0xFFCBD5E1), fontSize = 10.sp)
                            Text("• Tombol SERANG: Serang monster / tebang pohon / tambang batu", color = Color(0xFFCBD5E1), fontSize = 10.sp)
                            Text("• Tombol PASANG: Bangun dinding / obor / meja kriya atau interaksi desa", color = Color(0xFFCBD5E1), fontSize = 10.sp)
                            Text("• Tombol DASH: Menghindar lincah", color = Color(0xFFCBD5E1), fontSize = 10.sp)
                            Text("• Tombol MAKAN: Memulihkan lapar & HP", color = Color(0xFFCBD5E1), fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}
