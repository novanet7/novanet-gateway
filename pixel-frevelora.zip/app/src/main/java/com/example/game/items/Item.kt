package com.example.game.items

enum class ItemCategory {
    MATERIAL,
    TOOL,
    WEAPON,
    RANGED,
    AMMO,
    ARMOR_HEAD,
    ARMOR_CHEST,
    ARMOR_LEGS,
    FOOD,
    POTION,
    BUILDING,
    CIVILIZATION
}

enum class ItemRarity {
    COMMON,
    UNCOMMON,
    RARE,
    EPIC,
    LEGENDARY
}

data class Item(
    val id: String,
    val name: String,
    val description: String,
    val category: ItemCategory,
    val rarity: ItemRarity = ItemRarity.COMMON,
    val maxStack: Int = 99,
    // Combat & Tool stats
    val attackDamage: Int = 0,
    val attackSpeed: Float = 1.0f,
    val attackRange: Float = 1.5f,
    val miningPower: Int = 0,
    val woodchoppingPower: Int = 0,
    val defense: Int = 0,
    // Survival stats
    val hungerRestore: Int = 0,
    val hpRestore: Int = 0,
    val staminaRestore: Int = 0,
    // Building & Tile placement
    val placesTileId: String? = null,
    // Icon color tints for procedural rendering
    val primaryColor: Long = 0xFFFFFFFF,
    val secondaryColor: Long = 0xFF888888,
    val iconSymbol: String = ""
)

data class ItemStack(
    val item: Item,
    var count: Int = 1,
    var durability: Int = 100,
    val maxDurability: Int = 100
) {
    fun canStackWith(other: ItemStack): Boolean {
        return item.id == other.item.id && count < item.maxStack
    }

    fun copyStack(): ItemStack {
        return ItemStack(item, count, durability, maxDurability)
    }
}
