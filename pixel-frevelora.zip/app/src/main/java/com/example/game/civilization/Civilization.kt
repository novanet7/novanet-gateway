package com.example.game.civilization

import com.example.game.entity.Villager
import com.example.game.entity.VillagerRole
import kotlin.math.min

data class CivilizationStockpile(
    var wood: Int = 0,
    var stone: Int = 0,
    var food: Int = 0,
    var iron: Int = 0,
    var gold: Int = 0,
    var diamond: Int = 0
)

class Civilization(
    var name: String = "Peradaban Fr3velora",
    var isFounded: Boolean = false,
    var totemX: Int = 0,
    var totemY: Int = 0,
    var level: Int = 1,
    var populationMax: Int = 3
) {
    val villagers: MutableList<Villager> = mutableListOf()
    val stockpile = CivilizationStockpile()
    var productionTimer: Float = 0f

    val levelTitle: String
        get() = when (level) {
            1 -> "Perkemahan Pengelana (Nomad Camp)"
            2 -> "Permukiman Perintis (Frontier Settlement)"
            3 -> "Kota Perdagangan (Thriving Town)"
            4 -> "Benteng Kerajaan (Citadel of Fr3velora)"
            else -> "Kekaisaran Akbar Fr3velora (Imperial Realm)"
        }

    fun foundCivilization(centerX: Int, centerY: Int) {
        isFounded = true
        totemX = centerX
        totemY = centerY
        level = 1
        populationMax = 3

        villagers.clear()
        // Welcome first villager: Farmer Bob
        villagers.add(
            Villager(
                name = "Bob Sang Petani",
                role = VillagerRole.FARMER,
                x = centerX + 1.5f,
                y = centerY.toFloat()
            )
        )
    }

    fun canUpgrade(): Boolean {
        return when (level) {
            1 -> stockpile.wood >= 15 && stockpile.stone >= 15
            2 -> stockpile.wood >= 35 && stockpile.stone >= 35 && stockpile.iron >= 5
            3 -> stockpile.stone >= 60 && stockpile.iron >= 15 && stockpile.gold >= 5
            4 -> stockpile.stone >= 100 && stockpile.iron >= 30 && stockpile.gold >= 15
            else -> false
        }
    }

    fun getUpgradeRequirements(): String {
        return when (level) {
            1 -> "15 Kayu, 15 Batu di Lumbung"
            2 -> "35 Kayu, 35 Batu, 5 Besi di Lumbung"
            3 -> "60 Batu, 15 Besi, 5 Emas di Lumbung"
            4 -> "100 Batu, 30 Besi, 15 Emas di Lumbung"
            else -> "Level Maksimal Tercapai!"
        }
    }

    fun upgrade(): Boolean {
        if (!canUpgrade()) return false
        when (level) {
            1 -> {
                stockpile.wood -= 15
                stockpile.stone -= 15
                level = 2
                populationMax = 5
                villagers.add(
                    Villager(
                        name = "Gorn Si Penambang",
                        role = VillagerRole.MINER,
                        x = totemX - 1.5f,
                        y = totemY.toFloat()
                    )
                )
            }
            2 -> {
                stockpile.wood -= 35
                stockpile.stone -= 35
                stockpile.iron -= 5
                level = 3
                populationMax = 8
                villagers.add(
                    Villager(
                        name = "Arya Pandai Besi",
                        role = VillagerRole.BLACKSMITH,
                        x = totemX.toFloat(),
                        y = totemY + 1.5f
                    )
                )
            }
            3 -> {
                stockpile.stone -= 60
                stockpile.iron -= 15
                stockpile.gold -= 5
                level = 4
                populationMax = 12
                villagers.add(
                    Villager(
                        name = "Ronald Prajurit Pelindung",
                        role = VillagerRole.GUARD,
                        x = totemX.toFloat(),
                        y = totemY - 1.5f
                    )
                )
            }
            4 -> {
                stockpile.stone -= 100
                stockpile.iron -= 30
                stockpile.gold -= 15
                level = 5
                populationMax = 20
                villagers.add(
                    Villager(
                        name = "Lyra Sang Penyembuh Agung",
                        role = VillagerRole.HEALER,
                        x = totemX + 1.2f,
                        y = totemY + 1.2f
                    )
                )
            }
        }
        return true
    }

    fun update(deltaSeconds: Float) {
        if (!isFounded) return

        productionTimer += deltaSeconds
        // Every 5 seconds, each villager produces resources based on their role!
        if (productionTimer >= 5.0f) {
            productionTimer = 0f
            for (v in villagers) {
                when (v.role) {
                    VillagerRole.FARMER -> {
                        stockpile.food += 2 + level
                    }
                    VillagerRole.MINER -> {
                        stockpile.stone += 2 + level
                        if (level >= 2) stockpile.iron += 1
                        if (level >= 4) stockpile.gold += 1
                        if (level >= 5 && Math.random() < 0.25) stockpile.diamond += 1
                    }
                    VillagerRole.BLACKSMITH -> {
                        stockpile.iron += 1 + (level / 2)
                    }
                    VillagerRole.GUARD -> {
                        // Guard helps protect perimeter
                    }
                    VillagerRole.HEALER -> {
                        // Healer generates vitality
                        stockpile.food += 1
                    }
                }
            }
        }
    }
}
