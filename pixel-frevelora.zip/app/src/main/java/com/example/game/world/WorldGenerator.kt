package com.example.game.world

import kotlin.math.floor
import kotlin.math.sin

/**
 * Procedural infinite world generator for Pixel Fr3velora.
 * Uses multi-octave pseudo-random gradient noise to generate continuous,
 * seamless biomes, rivers, mountain ranges, forests, and mineral clusters.
 */
class WorldGenerator(val seed: Long = 133742L) {

    companion object {
        const val CHUNK_SIZE = 16
    }

    // Biome definitions
    enum class Biome(val displayName: String, val ambientHue: Long) {
        PLAINS("Padang Rumput Fr3velora", 0xFF4CAF50),
        FOREST("Hutan Rimba (Deep Forest)", 0xFF2E7D32),
        DESERT("Gurun Pasir Panas (Sunken Desert)", 0xFFE6C280),
        TUNDRA("Puncak Salju Abadi (Frost Peaks)", 0xFFCFD8DC),
        MOUNTAINS("Pegunungan Batu & Tambang", 0xFF757575),
        MYSTIC("Hutan Mistis (Ancient Mystic)", 0xFF9C27B0)
    }

    fun getBiome(worldX: Int, worldY: Int): Biome {
        val temp = noise2D(worldX * 0.005, worldY * 0.005, seed + 101)
        val moisture = noise2D(worldX * 0.005, worldY * 0.005, seed + 202)
        val height = noise2D(worldX * 0.008, worldY * 0.008, seed + 303)

        return when {
            height > 0.55 -> Biome.MOUNTAINS
            temp < -0.35 -> Biome.TUNDRA
            temp > 0.45 && moisture < -0.2 -> Biome.DESERT
            moisture > 0.4 && temp > 0.1 -> Biome.MYSTIC
            moisture > 0.0 -> Biome.FOREST
            else -> Biome.PLAINS
        }
    }

    /**
     * Generates the natural base tile and feature tile for any coordinate (x, y)
     */
    fun generateTileAt(worldX: Int, worldY: Int): Pair<TileType, TileType?> {
        val biome = getBiome(worldX, worldY)
        val riverNoise = kotlin.math.abs(noise2D(worldX * 0.02, worldY * 0.02, seed + 505))
        val detailNoise = noise2D(worldX * 0.15, worldY * 0.15, seed + 606)
        val oreNoise = noise2D(worldX * 0.25, worldY * 0.25, seed + 707)

        // Clear a spawn safe circle around (0,0)
        val distFromSpawnSq = worldX * worldX + worldY * worldY
        val isSpawnCenter = distFromSpawnSq < 16

        // Rivers & ponds
        if (riverNoise < 0.035 && !isSpawnCenter) {
            return Pair(TileRegistry.WATER, null)
        }

        return when (biome) {
            Biome.DESERT -> {
                val base = TileRegistry.SAND
                val feature = when {
                    isSpawnCenter -> null
                    detailNoise > 0.65 -> TileRegistry.CACTUS
                    detailNoise < -0.7 -> TileRegistry.ROCK_SLATE
                    oreNoise > 0.75 -> TileRegistry.GOLD_ORE
                    else -> null
                }
                Pair(base, feature)
            }
            Biome.TUNDRA -> {
                val base = TileRegistry.SNOW
                val feature = when {
                    isSpawnCenter -> null
                    detailNoise > 0.52 -> TileRegistry.TREE_PINE
                    detailNoise in 0.35..0.45 -> TileRegistry.ROCK_SLATE
                    oreNoise > 0.72 -> TileRegistry.IRON_ORE
                    detailNoise < -0.65 -> TileRegistry.ROCK_CRYSTAL
                    else -> null
                }
                Pair(base, feature)
            }
            Biome.MOUNTAINS -> {
                val base = TileRegistry.STONE_FLOOR
                val feature = when {
                    isSpawnCenter -> null
                    oreNoise > 0.82 -> TileRegistry.DIAMOND_ORE
                    oreNoise in 0.70..0.82 -> TileRegistry.ROCK_CRYSTAL
                    oreNoise in 0.58..0.70 -> TileRegistry.RUBY_ORE
                    oreNoise in 0.45..0.58 -> TileRegistry.IRON_ORE
                    detailNoise > 0.45 -> TileRegistry.TREE_PINE
                    detailNoise in 0.25..0.45 -> TileRegistry.COAL_ORE
                    detailNoise in -0.1..0.15 -> TileRegistry.ROCK_SLATE
                    detailNoise < -0.4 -> TileRegistry.ROCK_BOULDER
                    else -> null
                }
                Pair(base, feature)
            }
            Biome.MYSTIC -> {
                val base = TileRegistry.GRASS
                val treePick = ((worldX * 31 + worldY * 17) and 3)
                val feature = when {
                    isSpawnCenter -> null
                    oreNoise > 0.78 -> TileRegistry.DIAMOND_ORE
                    oreNoise > 0.65 -> TileRegistry.ROCK_CRYSTAL
                    detailNoise > 0.4 -> when (treePick) {
                        0 -> TileRegistry.TREE_CHERRY
                        1 -> TileRegistry.TREE_WILLOW
                        2 -> TileRegistry.TREE_AUTUMN
                        else -> TileRegistry.TREE_OAK
                    }
                    detailNoise < -0.45 -> TileRegistry.ROCK_MOSSY
                    detailNoise in -0.3..-0.15 -> TileRegistry.BERRY_BUSH
                    else -> null
                }
                Pair(base, feature)
            }
            Biome.FOREST -> {
                val base = TileRegistry.GRASS
                val treeVariant = ((worldX * 47 + worldY * 13) and 3)
                val feature = when {
                    isSpawnCenter -> null
                    detailNoise > 0.35 -> when (treeVariant) {
                        0 -> TileRegistry.TREE_OAK
                        1 -> TileRegistry.TREE_AUTUMN
                        2 -> TileRegistry.TREE_BIRCH
                        else -> TileRegistry.TREE_WILLOW
                    }
                    detailNoise < -0.55 -> TileRegistry.BERRY_BUSH
                    detailNoise in -0.45..-0.35 -> TileRegistry.ROCK_MOSSY
                    oreNoise > 0.7 -> TileRegistry.COAL_ORE
                    detailNoise in -0.2..-0.1 -> TileRegistry.ROCK_BOULDER
                    else -> null
                }
                Pair(base, feature)
            }
            Biome.PLAINS -> {
                val base = TileRegistry.GRASS
                val treeType = ((worldX * 19 + worldY * 23) and 3)
                val rockType = ((worldX * 7 + worldY * 41) and 1)
                val feature = when {
                    isSpawnCenter -> null
                    detailNoise > 0.58 -> when (treeType) {
                        0 -> TileRegistry.TREE_OAK
                        1 -> TileRegistry.TREE_BIRCH
                        2 -> TileRegistry.TREE_CHERRY
                        else -> TileRegistry.TREE_OAK
                    }
                    detailNoise < -0.6 -> TileRegistry.BERRY_BUSH
                    oreNoise > 0.78 -> TileRegistry.COAL_ORE
                    detailNoise in 0.2..0.3 -> if (rockType == 0) TileRegistry.ROCK_BOULDER else TileRegistry.ROCK_MOSSY
                    else -> null
                }
                Pair(base, feature)
            }
        }
    }

    // Multi-octave 2D value/gradient noise approximation
    private fun noise2D(x: Double, y: Double, s: Long): Double {
        val x0 = floor(x).toInt()
        val y0 = floor(y).toInt()
        val x1 = x0 + 1
        val y1 = y0 + 1

        val sx = smoothstep(x - x0)
        val sy = smoothstep(y - y0)

        val n0 = dotGridGradient(x0, y0, x, y, s)
        val n1 = dotGridGradient(x1, y0, x, y, s)
        val ix0 = interpolate(n0, n1, sx)

        val n2 = dotGridGradient(x0, y1, x, y, s)
        val n3 = dotGridGradient(x1, y1, x, y, s)
        val ix1 = interpolate(n2, n3, sx)

        return interpolate(ix0, ix1, sy)
    }

    private fun smoothstep(t: Double): Double {
        return t * t * (3 - 2 * t)
    }

    private fun interpolate(a0: Double, a1: Double, w: Double): Double {
        return (1.0 - w) * a0 + w * a1
    }

    private fun dotGridGradient(ix: Int, iy: Int, x: Double, y: Double, s: Long): Double {
        // Pseudo random angle from coordinate hash
        val h = (ix * 374761393L + iy * 668265263L + s).hashCode()
        val angle = (h % 360) * (Math.PI / 180.0)
        val gx = kotlin.math.cos(angle)
        val gy = sin(angle)

        val dx = x - ix
        val dy = y - iy
        return (dx * gx + dy * gy)
    }
}
