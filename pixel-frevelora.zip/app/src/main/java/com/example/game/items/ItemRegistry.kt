package com.example.game.items

object ItemRegistry {

    // === RESOURCES & MATERIALS ===
    val WOOD = Item(
        id = "wood",
        name = "Kayu Hutan (Wood)",
        description = "Bahan dasar dari menebang pohon. Digunakan untuk membuat alat dan bangunan.",
        category = ItemCategory.MATERIAL,
        primaryColor = 0xFF8B5A2B,
        secondaryColor = 0xFF5C3A21,
        iconSymbol = "wood"
    )

    val STICK = Item(
        id = "stick",
        name = "Ranting (Stick)",
        description = "Gagang alat dan anak panah.",
        category = ItemCategory.MATERIAL,
        primaryColor = 0xFFA0522D,
        secondaryColor = 0xFF6B3E26,
        iconSymbol = "stick"
    )

    val FIBER = Item(
        id = "fiber",
        name = "Serat Tumbuhan (Fiber)",
        description = "Dipetik dari semak belukar. Untuk membuat tali dan pakaian.",
        category = ItemCategory.MATERIAL,
        primaryColor = 0xFF6B8E23,
        secondaryColor = 0xFF556B2F,
        iconSymbol = "fiber"
    )

    val STONE = Item(
        id = "stone",
        name = "Batu (Stone)",
        description = "Ditambang dari batu dan tebing. Kokoh untuk fondasi perkakas dan kastil.",
        category = ItemCategory.MATERIAL,
        primaryColor = 0xFF808080,
        secondaryColor = 0xFF505050,
        iconSymbol = "stone"
    )

    val FLINT = Item(
        id = "flint",
        name = "Batu Api (Flint)",
        description = "Batu tajam untuk mata panah dan memicu api.",
        category = ItemCategory.MATERIAL,
        primaryColor = 0xFF363636,
        secondaryColor = 0xFF1C1C1C,
        iconSymbol = "flint"
    )

    val COAL = Item(
        id = "coal",
        name = "Batu Bara (Coal)",
        description = "Bahan bakar tungku pelebur dan pembuatan obor.",
        category = ItemCategory.MATERIAL,
        primaryColor = 0xFF222222,
        secondaryColor = 0xFF111111,
        iconSymbol = "coal"
    )

    val IRON_ORE = Item(
        id = "iron_ore",
        name = "Bijih Besi (Iron Ore)",
        description = "Mineral mentah dari tambang. Leburkan di furnace menjadi batangan besi.",
        category = ItemCategory.MATERIAL,
        primaryColor = 0xFFD2B48C,
        secondaryColor = 0xFF8B7355,
        iconSymbol = "ore"
    )

    val IRON_INGOT = Item(
        id = "iron_ingot",
        name = "Batangan Besi (Iron Ingot)",
        description = "Besi murni berkualitas tinggi untuk senjata dan baju zirah.",
        category = ItemCategory.MATERIAL,
        rarity = ItemRarity.UNCOMMON,
        primaryColor = 0xFFE0E0E0,
        secondaryColor = 0xFFA0A0A0,
        iconSymbol = "ingot"
    )

    val GOLD_ORE = Item(
        id = "gold_ore",
        name = "Bijih Emas (Gold Ore)",
        description = "Mineral berkilau langka.",
        category = ItemCategory.MATERIAL,
        rarity = ItemRarity.RARE,
        primaryColor = 0xFFFFD700,
        secondaryColor = 0xFFB8860B,
        iconSymbol = "ore"
    )

    val GOLD_INGOT = Item(
        id = "gold_ingot",
        name = "Batangan Emas (Gold Ingot)",
        description = "Emas murni untuk artefak peradaban dan mahkota Fr3velora.",
        category = ItemCategory.MATERIAL,
        rarity = ItemRarity.RARE,
        primaryColor = 0xFFFFD700,
        secondaryColor = 0xFFDAA520,
        iconSymbol = "ingot"
    )

    val DIAMOND = Item(
        id = "diamond",
        name = "Berlian Murni (Diamond)",
        description = "Permata legendaris paling keras di kedalaman gua.",
        category = ItemCategory.MATERIAL,
        rarity = ItemRarity.EPIC,
        primaryColor = 0xFF00FFFF,
        secondaryColor = 0xFF00BFFF,
        iconSymbol = "gem"
    )

    val RUBY = Item(
        id = "ruby",
        name = "Batu Delima Merah (Ruby)",
        description = "Kristal api langka dengan kekuatan sihir misterius.",
        category = ItemCategory.MATERIAL,
        rarity = ItemRarity.EPIC,
        primaryColor = 0xFFFF1493,
        secondaryColor = 0xFFC71585,
        iconSymbol = "gem"
    )

    val ANCIENT_ESSENCE = Item(
        id = "ancient_essence",
        name = "Fr3velora Ancient Relic",
        description = "Inti kekuatan peradaban kuno yang hilang.",
        category = ItemCategory.MATERIAL,
        rarity = ItemRarity.LEGENDARY,
        primaryColor = 0xFF9932CC,
        secondaryColor = 0xFF4B0082,
        iconSymbol = "relic"
    )

    val LEATHER = Item(
        id = "leather",
        name = "Kulit Hewan (Leather)",
        description = "Didapat dari berburu hewan liar.",
        category = ItemCategory.MATERIAL,
        primaryColor = 0xFF8B4513,
        secondaryColor = 0xFF5C2E0C,
        iconSymbol = "leather"
    )

    val BONE = Item(
        id = "bone",
        name = "Tulang Monster (Bone)",
        description = "Sisa pertarungan dengan skeleton.",
        category = ItemCategory.MATERIAL,
        primaryColor = 0xFFF5F5DC,
        secondaryColor = 0xFFDCDCDC,
        iconSymbol = "bone"
    )

    val SLIME_GEL = Item(
        id = "slime_gel",
        name = "Gel Lendir (Slime Gel)",
        description = "Cairan lengket dari monster slime untuk ramuan.",
        category = ItemCategory.MATERIAL,
        primaryColor = 0xFF32CD32,
        secondaryColor = 0xFF228B22,
        iconSymbol = "gel"
    )

    // === TOOLS ===
    val WOOD_PICKAXE = Item(
        id = "wood_pickaxe",
        name = "Beliung Kayu (Wood Pickaxe)",
        description = "Alat gali dasar untuk menambang batu dan batubara.",
        category = ItemCategory.TOOL,
        miningPower = 1,
        attackDamage = 3,
        attackSpeed = 1.0f,
        primaryColor = 0xFF8B5A2B,
        iconSymbol = "pickaxe"
    )

    val STONE_PICKAXE = Item(
        id = "stone_pickaxe",
        name = "Beliung Batu (Stone Pickaxe)",
        description = "Cukup kuat untuk menambang bijih besi.",
        category = ItemCategory.TOOL,
        miningPower = 2,
        attackDamage = 5,
        attackSpeed = 1.1f,
        primaryColor = 0xFF808080,
        iconSymbol = "pickaxe"
    )

    val IRON_PICKAXE = Item(
        id = "iron_pickaxe",
        name = "Beliung Besi (Iron Pickaxe)",
        description = "Menambang emas dan berlian dengan cepat.",
        category = ItemCategory.TOOL,
        rarity = ItemRarity.UNCOMMON,
        miningPower = 3,
        attackDamage = 8,
        attackSpeed = 1.25f,
        primaryColor = 0xFFE0E0E0,
        iconSymbol = "pickaxe"
    )

    val DIAMOND_PICKAXE = Item(
        id = "diamond_pickaxe",
        name = "Beliung Berlian (Diamond Pickaxe)",
        description = "Dapat menghancurkan batu obsidian dan segala mineral terkeras!",
        category = ItemCategory.TOOL,
        rarity = ItemRarity.EPIC,
        miningPower = 4,
        attackDamage = 14,
        attackSpeed = 1.5f,
        primaryColor = 0xFF00FFFF,
        iconSymbol = "pickaxe"
    )

    val WOOD_AXE = Item(
        id = "wood_axe",
        name = "Kapak Kayu (Wood Axe)",
        description = "Menebang pohon untuk mengumpulkan balok kayu.",
        category = ItemCategory.TOOL,
        woodchoppingPower = 1,
        attackDamage = 4,
        primaryColor = 0xFF8B5A2B,
        iconSymbol = "axe"
    )

    val STONE_AXE = Item(
        id = "stone_axe",
        name = "Kapak Batu (Stone Axe)",
        description = "Menebang pohon lebih cepat.",
        category = ItemCategory.TOOL,
        woodchoppingPower = 2,
        attackDamage = 7,
        primaryColor = 0xFF808080,
        iconSymbol = "axe"
    )

    val IRON_AXE = Item(
        id = "iron_axe",
        name = "Kapak Besi (Iron Axe)",
        description = "Menebang pohon kuno dan kayu keras dengan sangat cepat.",
        category = ItemCategory.TOOL,
        rarity = ItemRarity.UNCOMMON,
        woodchoppingPower = 3,
        attackDamage = 11,
        primaryColor = 0xFFE0E0E0,
        iconSymbol = "axe"
    )

    val HOE = Item(
        id = "hoe",
        name = "Cangkul Tani (Farming Hoe)",
        description = "Mencangkul tanah menjadi lahan pertanian subur.",
        category = ItemCategory.TOOL,
        attackDamage = 2,
        primaryColor = 0xFFCD853F,
        iconSymbol = "hoe"
    )

    // === WEAPONS ===
    val WOOD_CLUB = Item(
        id = "wood_club",
        name = "Pentungan Kayu (Wood Club)",
        description = "Senjata darurat melawan binatang buas malam hari.",
        category = ItemCategory.WEAPON,
        attackDamage = 5,
        attackRange = 1.4f,
        primaryColor = 0xFF8B4513,
        iconSymbol = "club"
    )

    val STONE_SWORD = Item(
        id = "stone_sword",
        name = "Pedang Batu (Stone Sword)",
        description = "Pedang tajam dengan tebasan yang mantap.",
        category = ItemCategory.WEAPON,
        attackDamage = 9,
        attackRange = 1.6f,
        primaryColor = 0xFF808080,
        iconSymbol = "sword"
    )

    val IRON_SWORD = Item(
        id = "iron_sword",
        name = "Pedang Besi (Iron Sword)",
        description = "Pedang kesatria peradaban yang tajam dan mematikan.",
        category = ItemCategory.WEAPON,
        rarity = ItemRarity.UNCOMMON,
        attackDamage = 16,
        attackRange = 1.8f,
        attackSpeed = 1.2f,
        primaryColor = 0xFFE0E0E0,
        iconSymbol = "sword"
    )

    val DIAMOND_SWORD = Item(
        id = "diamond_sword",
        name = "Pedang Berlian (Diamond Blade)",
        description = "Tebasan maut membelah armor monster.",
        category = ItemCategory.WEAPON,
        rarity = ItemRarity.EPIC,
        attackDamage = 26,
        attackRange = 2.0f,
        attackSpeed = 1.3f,
        primaryColor = 0xFF00FFFF,
        iconSymbol = "sword"
    )

    val FR3VELORA_RELIC_BLADE = Item(
        id = "fr3velora_relic_blade",
        name = "Fr3velora God Blade",
        description = "Pedang legendaris penguasa Fr3velora. Membakar dan menebas segala musuh!",
        category = ItemCategory.WEAPON,
        rarity = ItemRarity.LEGENDARY,
        attackDamage = 45,
        attackRange = 2.4f,
        attackSpeed = 1.5f,
        primaryColor = 0xFFFF4500,
        secondaryColor = 0xFFFFD700,
        iconSymbol = "sword_legend"
    )

    // === RANGED & AMMO ===
    val WOOD_BOW = Item(
        id = "wood_bow",
        name = "Busur Panah (Hunting Bow)",
        description = "Menembakkan anak panah jarak jauh dengan presisi tinggi.",
        category = ItemCategory.RANGED,
        attackDamage = 12,
        attackRange = 8.0f,
        primaryColor = 0xFF8B5A2B,
        iconSymbol = "bow"
    )

    val DRAGON_CROSSBOW = Item(
        id = "dragon_crossbow",
        name = "Fr3velora Crossbow",
        description = "Busur silang berdaya tembak dahsyat dengan panah api!",
        category = ItemCategory.RANGED,
        rarity = ItemRarity.EPIC,
        attackDamage = 28,
        attackRange = 10.0f,
        primaryColor = 0xFFFF6347,
        iconSymbol = "bow"
    )

    val ARROW = Item(
        id = "arrow",
        name = "Anak Panah (Arrow)",
        description = "Amunisi untuk busur panah.",
        category = ItemCategory.AMMO,
        maxStack = 99,
        primaryColor = 0xFFD2B48C,
        iconSymbol = "arrow"
    )

    // === ARMOR ===
    val LEATHER_CAP = Item(
        id = "leather_cap",
        name = "Topi Kulit (Leather Cap)",
        description = "Pelindung kepala ringan.",
        category = ItemCategory.ARMOR_HEAD,
        defense = 2,
        primaryColor = 0xFF8B4513,
        iconSymbol = "helm"
    )

    val LEATHER_TUNIC = Item(
        id = "leather_tunic",
        name = "Baju Zirah Kulit (Leather Tunic)",
        description = "Rompi kulit tebal untuk melindungi dada.",
        category = ItemCategory.ARMOR_CHEST,
        defense = 4,
        primaryColor = 0xFF8B4513,
        iconSymbol = "chest"
    )

    val LEATHER_BOOTS = Item(
        id = "leather_boots",
        name = "Sepatu Bot Kulit (Leather Boots)",
        description = "Sepatu nyaman untuk menjelajahi hutan.",
        category = ItemCategory.ARMOR_LEGS,
        defense = 2,
        primaryColor = 0xFF8B4513,
        iconSymbol = "boots"
    )

    val IRON_HELMET = Item(
        id = "iron_helmet",
        name = "Helm Besi (Iron Helmet)",
        description = "Pelindung kepala prajurit peradaban.",
        category = ItemCategory.ARMOR_HEAD,
        rarity = ItemRarity.UNCOMMON,
        defense = 6,
        primaryColor = 0xFFC0C0C0,
        iconSymbol = "helm"
    )

    val IRON_CHESTPLATE = Item(
        id = "iron_chestplate",
        name = "Baju Zirah Besi (Iron Chestplate)",
        description = "Baju pelindung baja yang kokoh.",
        category = ItemCategory.ARMOR_CHEST,
        rarity = ItemRarity.UNCOMMON,
        defense = 12,
        primaryColor = 0xFFC0C0C0,
        iconSymbol = "chest"
    )

    val IRON_BOOTS = Item(
        id = "iron_boots",
        name = "Sepatu Bot Besi (Iron Boots)",
        description = "Melindungi kaki dari jebakan dan serangan monster.",
        category = ItemCategory.ARMOR_LEGS,
        rarity = ItemRarity.UNCOMMON,
        defense = 5,
        primaryColor = 0xFFC0C0C0,
        iconSymbol = "boots"
    )

    val FR3VELORA_CROWN = Item(
        id = "fr3velora_crown",
        name = "Mahkota Raja Fr3velora",
        description = "Mahkota emas permata kaisar peradaban. Memberikan pertahanan dan karisma absolut!",
        category = ItemCategory.ARMOR_HEAD,
        rarity = ItemRarity.LEGENDARY,
        defense = 18,
        primaryColor = 0xFFFFD700,
        secondaryColor = 0xFF00FFFF,
        iconSymbol = "crown"
    )

    // === FOOD & MEDICINE ===
    val BERRY = Item(
        id = "berry",
        name = "Buah Beri Liar (Wild Berries)",
        description = "Manis dan segar. Memulihkan sedikit rasa lapar.",
        category = ItemCategory.FOOD,
        hungerRestore = 15,
        hpRestore = 5,
        primaryColor = 0xFFFF1493,
        iconSymbol = "berry"
    )

    val APPLE = Item(
        id = "apple",
        name = "Apel Merah (Red Apple)",
        description = "Jatuh dari dedaunan pohon oak.",
        category = ItemCategory.FOOD,
        hungerRestore = 25,
        hpRestore = 10,
        primaryColor = 0xFFFF0000,
        iconSymbol = "apple"
    )

    val RAW_MEAT = Item(
        id = "raw_meat",
        name = "Daging Mentah (Raw Meat)",
        description = "Daging segar dari buruan. Masak di api unggun agar tidak sakit perut!",
        category = ItemCategory.FOOD,
        hungerRestore = 15,
        hpRestore = 0,
        primaryColor = 0xFFCD5C5C,
        iconSymbol = "meat"
    )

    val COOKED_STEAK = Item(
        id = "cooked_steak",
        name = "Steak Panggang (Cooked Steak)",
        description = "Daging bakar lezat penuh energi!",
        category = ItemCategory.FOOD,
        rarity = ItemRarity.UNCOMMON,
        hungerRestore = 50,
        hpRestore = 35,
        staminaRestore = 40,
        primaryColor = 0xFF8B4513,
        iconSymbol = "steak"
    )

    val WHEAT_SEEDS = Item(
        id = "wheat_seeds",
        name = "Bibit Gandum (Wheat Seeds)",
        description = "Tanam di tanah yang sudah dicangkul untuk bertani.",
        category = ItemCategory.MATERIAL,
        primaryColor = 0xFF9ACD32,
        iconSymbol = "seeds"
    )

    val WHEAT = Item(
        id = "wheat",
        name = "Gandum Panen (Wheat)",
        description = "Hasil panen petani untuk membuat roti.",
        category = ItemCategory.MATERIAL,
        primaryColor = 0xFFDAA520,
        iconSymbol = "wheat"
    )

    val BREAD = Item(
        id = "bread",
        name = "Roti Hangat (Fresh Bread)",
        description = "Roti gandum lezat penunda lapar.",
        category = ItemCategory.FOOD,
        hungerRestore = 40,
        hpRestore = 15,
        primaryColor = 0xFFDEB887,
        iconSymbol = "bread"
    )

    val HEALTH_POTION = Item(
        id = "health_potion",
        name = "Ramuan Penyembuh (Health Potion)",
        description = "Menyembuhkan 50 poin darah seketika!",
        category = ItemCategory.POTION,
        rarity = ItemRarity.UNCOMMON,
        hpRestore = 50,
        primaryColor = 0xFFFF0055,
        iconSymbol = "potion"
    )

    // === BUILDING & CIVILIZATION STRUCTURES ===
    val WOOD_WALL = Item(
        id = "wood_wall",
        name = "Dinding Kayu (Wood Wall)",
        description = "Benteng pertahanan sederhana untuk rumah.",
        category = ItemCategory.BUILDING,
        placesTileId = "wood_wall",
        primaryColor = 0xFF8B5A2B,
        iconSymbol = "wall"
    )

    val STONE_WALL = Item(
        id = "stone_wall",
        name = "Dinding Batu (Stone Wall)",
        description = "Dinding batu kokoh tahan serangan monster malam.",
        category = ItemCategory.BUILDING,
        placesTileId = "stone_wall",
        primaryColor = 0xFF808080,
        iconSymbol = "wall"
    )

    val WOOD_FLOOR = Item(
        id = "wood_floor",
        name = "Lantai Kayu (Wood Floor)",
        description = "Lantai papan kayu rapi untuk pemukiman.",
        category = ItemCategory.BUILDING,
        placesTileId = "wood_floor",
        primaryColor = 0xFFCD853F,
        iconSymbol = "floor"
    )

    val TORCH = Item(
        id = "torch",
        name = "Obor (Torch)",
        description = "Menerangi malam gelap dan mencegah monster spawn di dekatnya.",
        category = ItemCategory.BUILDING,
        placesTileId = "torch",
        primaryColor = 0xFFFFA500,
        iconSymbol = "torch"
    )

    val CAMPFIRE = Item(
        id = "campfire",
        name = "Api Unggun (Campfire)",
        description = "Tempat memasak daging dan menghangatkan diri.",
        category = ItemCategory.BUILDING,
        placesTileId = "campfire",
        primaryColor = 0xFFFF4500,
        iconSymbol = "campfire"
    )

    val WORKBENCH = Item(
        id = "workbench",
        name = "Meja Kerja (Crafting Table)",
        description = "Membuka resep perkakas, senjata, dan bangunan tingkat lanjut.",
        category = ItemCategory.BUILDING,
        placesTileId = "workbench",
        primaryColor = 0xFFB8860B,
        iconSymbol = "table"
    )

    val FURNACE = Item(
        id = "furnace",
        name = "Tungku Pelebur (Furnace)",
        description = "Melebur bijih besi, emas, dan memasak hidangan lezat.",
        category = ItemCategory.BUILDING,
        placesTileId = "furnace",
        primaryColor = 0xFF696969,
        iconSymbol = "furnace"
    )

    val CHEST = Item(
        id = "chest",
        name = "Peti Penyimpanan (Chest)",
        description = "Menyimpan hingga puluhan tumpukan barang berharga.",
        category = ItemCategory.BUILDING,
        placesTileId = "chest",
        primaryColor = 0xFF8B4513,
        iconSymbol = "chest"
    )

    val BED = Item(
        id = "bed",
        name = "Tempat Tidur (Bed)",
        description = "Tidur untuk melewati malam yang berbahaya dan memulihkan HP.",
        category = ItemCategory.BUILDING,
        placesTileId = "bed",
        primaryColor = 0xFFDC143C,
        iconSymbol = "bed"
    )

    val CIVILIZATION_TOTEM = Item(
        id = "civilization_totem",
        name = "Totem Peradaban Fr3velora",
        description = "Tancapkan untuk mendirikan permukiman! Menarik penduduk desa, petani, dan penjaga kota.",
        category = ItemCategory.CIVILIZATION,
        rarity = ItemRarity.EPIC,
        placesTileId = "civilization_totem",
        primaryColor = 0xFFFFD700,
        secondaryColor = 0xFF9400D3,
        iconSymbol = "totem"
    )

    val WATCHTOWER = Item(
        id = "watchtower",
        name = "Menara Pengawas (Watchtower)",
        description = "Menara pertahanan otomatis yang menembak monster mendekat!",
        category = ItemCategory.CIVILIZATION,
        rarity = ItemRarity.RARE,
        placesTileId = "watchtower",
        primaryColor = 0xFF708090,
        iconSymbol = "tower"
    )

    val QUARRY_STATION = Item(
        id = "quarry_station",
        name = "Tambang Otomatis (Auto Quarry)",
        description = "Fasilitas peradaban yang menambang batu dan mineral secara berkala.",
        category = ItemCategory.CIVILIZATION,
        rarity = ItemRarity.RARE,
        placesTileId = "quarry_station",
        primaryColor = 0xFF4682B4,
        iconSymbol = "quarry"
    )

    // Lookup table
    private val allItems = listOf(
        WOOD, STICK, FIBER, STONE, FLINT, COAL, IRON_ORE, IRON_INGOT, GOLD_ORE, GOLD_INGOT,
        DIAMOND, RUBY, ANCIENT_ESSENCE, LEATHER, BONE, SLIME_GEL,
        WOOD_PICKAXE, STONE_PICKAXE, IRON_PICKAXE, DIAMOND_PICKAXE,
        WOOD_AXE, STONE_AXE, IRON_AXE, HOE,
        WOOD_CLUB, STONE_SWORD, IRON_SWORD, DIAMOND_SWORD, FR3VELORA_RELIC_BLADE,
        WOOD_BOW, DRAGON_CROSSBOW, ARROW,
        LEATHER_CAP, LEATHER_TUNIC, LEATHER_BOOTS,
        IRON_HELMET, IRON_CHESTPLATE, IRON_BOOTS, FR3VELORA_CROWN,
        BERRY, APPLE, RAW_MEAT, COOKED_STEAK, WHEAT_SEEDS, WHEAT, BREAD, HEALTH_POTION,
        WOOD_WALL, STONE_WALL, WOOD_FLOOR, TORCH, CAMPFIRE, WORKBENCH, FURNACE, CHEST, BED,
        CIVILIZATION_TOTEM, WATCHTOWER, QUARRY_STATION
    )

    private val itemMap = allItems.associateBy { it.id }

    fun getItem(id: String): Item = itemMap[id] ?: WOOD
}
