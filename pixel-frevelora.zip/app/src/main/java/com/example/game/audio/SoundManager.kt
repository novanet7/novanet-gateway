package com.example.game.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

/**
 * Procedural 8-bit retro sound synthesizer using Android AudioTrack.
 * Generates crisp, nostalgic chiptune sound effects in real time without external asset files.
 */
class SoundManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Default)
    private var isMuted = false
    private var hapticsEnabled = true

    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    fun toggleMute(): Boolean {
        isMuted = !isMuted
        return isMuted
    }

    fun isSoundMuted(): Boolean = isMuted

    fun toggleHaptics(): Boolean {
        hapticsEnabled = !hapticsEnabled
        return hapticsEnabled
    }

    fun isHapticsEnabled(): Boolean = hapticsEnabled

    private val activeTrackCount = java.util.concurrent.atomic.AtomicInteger(0)

    private fun playTone(freqs: FloatArray, durationsMs: IntArray, waveType: WaveType = WaveType.SQUARE, volume: Float = 0.4f) {
        if (isMuted) return
        if (activeTrackCount.get() >= 2) return // Throttle concurrent sounds to prevent system AudioTrack exhaustion
        activeTrackCount.incrementAndGet()
        scope.launch {
            var track: AudioTrack? = null
            try {
                val sampleRate = 22050
                var totalDurationMs = 0
                for (d in durationsMs) totalDurationMs += d
                val totalSamples = (sampleRate * (totalDurationMs / 1000f)).toInt()
                if (totalSamples <= 0) return@launch

                val buffer = ShortArray(totalSamples)
                var currentSample = 0

                for (i in freqs.indices) {
                    val freq = freqs[i]
                    val durationMs = durationsMs[i]
                    val samples = (sampleRate * (durationMs / 1000f)).toInt()

                    for (s in 0 until samples) {
                        if (currentSample >= totalSamples) break
                        val t = s.toDouble() / sampleRate
                        val rawSample = when (waveType) {
                            WaveType.SQUARE -> if (sin(2.0 * PI * freq * t) > 0) 1.0 else -1.0
                            WaveType.SINE -> sin(2.0 * PI * freq * t)
                            WaveType.TRIANGLE -> {
                                val period = sampleRate / freq
                                2.0 * kotlin.math.abs(2.0 * ((s % period) / period) - 1.0) - 1.0
                            }
                            WaveType.NOISE -> (Math.random() * 2.0) - 1.0
                        }
                        // Envelope decay to prevent popping
                        val decay = 1.0 - (s.toDouble() / samples)
                        buffer[currentSample++] = (rawSample * decay * volume * Short.MAX_VALUE).toInt().toShort()
                    }
                }

                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(buffer, 0, buffer.size)
                track.play()
                // Clean up track after play
                kotlinx.coroutines.delay(totalDurationMs.toLong() + 30)
                track.stop()
            } catch (_: Throwable) {
                // Ignore audio failure gracefully
            } finally {
                try {
                    track?.release()
                } catch (_: Throwable) {}
                activeTrackCount.decrementAndGet()
            }
        }
    }

    fun vibrate(durationMs: Long = 30) {
        if (!hapticsEnabled || vibrator == null) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    // Sound FX
    fun playMine() {
        playTone(floatArrayOf(440f, 660f), intArrayOf(30, 40), WaveType.TRIANGLE, 0.35f)
        vibrate(25)
    }

    fun playChop() {
        playTone(floatArrayOf(220f, 180f), intArrayOf(40, 50), WaveType.SQUARE, 0.35f)
        vibrate(30)
    }

    fun playHit() {
        playTone(floatArrayOf(150f, 100f), intArrayOf(50, 70), WaveType.NOISE, 0.5f)
        vibrate(50)
    }

    fun playAttackSwing() {
        playTone(floatArrayOf(580f, 320f), intArrayOf(25, 45), WaveType.TRIANGLE, 0.25f)
    }

    fun playBowShoot() {
        playTone(floatArrayOf(300f, 650f, 900f), intArrayOf(30, 30, 40), WaveType.TRIANGLE, 0.4f)
        vibrate(35)
    }

    fun playPickup() {
        playTone(floatArrayOf(523.25f, 659.25f, 783.99f), intArrayOf(40, 40, 60), WaveType.SQUARE, 0.25f)
    }

    fun playCraftSuccess() {
        playTone(
            floatArrayOf(440f, 554.37f, 659.25f, 880f),
            intArrayOf(60, 60, 60, 140),
            WaveType.TRIANGLE,
            0.4f
        )
        vibrate(40)
    }

    fun playLevelUp() {
        playTone(
            floatArrayOf(330f, 440f, 550f, 660f, 880f),
            intArrayOf(80, 80, 80, 80, 200),
            WaveType.SQUARE,
            0.45f
        )
        vibrate(80)
    }

    fun playEat() {
        playTone(floatArrayOf(300f, 400f, 320f, 450f), intArrayOf(40, 40, 40, 50), WaveType.SINE, 0.3f)
    }

    fun playHurt() {
        playTone(floatArrayOf(220f, 140f, 90f), intArrayOf(50, 70, 90), WaveType.SQUARE, 0.6f)
        vibrate(100)
    }

    fun playVillagerTalk() {
        playTone(floatArrayOf(400f, 520f), intArrayOf(50, 80), WaveType.SINE, 0.3f)
    }

    fun playBossRoar() {
        playTone(floatArrayOf(100f, 80f, 70f, 60f), intArrayOf(100, 120, 150, 200), WaveType.NOISE, 0.7f)
        vibrate(150)
    }

    enum class WaveType {
        SQUARE, SINE, TRIANGLE, NOISE
    }
}
