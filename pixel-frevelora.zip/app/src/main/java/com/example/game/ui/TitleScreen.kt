package com.example.game.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

@Composable
fun TitleScreen(
    onStartGame: () -> Unit
) {
    var showGuideDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Half: Hero Banner Card with Rustic Stick Border
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1E293B)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        Image(
                            painter = painterResource(id = R.drawable.img_ui_banner_1790890808577),
                            contentDescription = "Pixel Fr3velora Banner",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color.Transparent, Color(0x880F172A), Color(0xEE0F172A))
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "PIXEL FR3VELORA",
                                color = Color(0xFFFFD700),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.5.sp,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Survival Dunia Tanpa Batas & Peradaban",
                                color = Color(0xFF81C784),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
                RusticStickBorder(hasLeaves = true)
            }

            // Right Half: Actions & Features List
            Column(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.Center
            ) {
                // Primary Start Button
                Box(modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = onStartGame,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("start_game_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFFFFD54F), modifier = Modifier.size(22.dp))
                            Text(
                                text = "MULAI PETUALANGAN",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                    }
                    RusticStickBorder(hasLeaves = false)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Guide Button
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { showGuideDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("guide_button"),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF64748B))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, tint = Color(0xFFFFD54F), modifier = Modifier.size(16.dp))
                            Text(
                                text = "Panduan Bertahan Hidup",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                    RusticStickBorder(hasLeaves = false)
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Features
                FeatureCard(
                    icon = Icons.Default.Explore,
                    title = "Dunia Tanpa Batas & Sungai Realistik",
                    desc = "Eksplorasi bioma tak terhingga dengan tebing sungai pendek, air bergelombang dinamis, pepohonan rimbun, dan bebatuan 3D."
                )

                Spacer(modifier = Modifier.height(6.dp))

                FeatureCard(
                    icon = Icons.Default.Castle,
                    title = "Peradaban Fr3velora & Warga Desa",
                    desc = "Tancapkan Totem Desa, rekrut Petani, Penambang, Pandai Besi, dan Prajurit untuk menghasilkan sumber daya otomatis."
                )
            }
        }

        // Guide Dialog
        if (showGuideDialog) {
            AlertDialog(
                onDismissRequest = { showGuideDialog = false },
                title = {
                    Text("Panduan Petualang Pixel Fr3velora", color = Color(0xFFFFD54F), fontWeight = FontWeight.Bold)
                },
                text = {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        Text("1. Kontrol Horizontal:", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Gunakan joystick di kiri bawah untuk berjalan 360°. Tekan tombol SERANG di kanan bawah untuk menebang pohon dan menambang batu.", color = Color(0xFFCBD5E1), fontSize = 11.sp)

                        Spacer(modifier = Modifier.height(4.dp))
                        Text("2. Kriya & Makanan:", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Buka tombol 'Rakit' untuk membuat beliung batu, obor, api unggun, dan senjata. Tekan 'MAKAN' untuk memulihkan lapar.", color = Color(0xFFCBD5E1), fontSize = 11.sp)

                        Spacer(modifier = Modifier.height(4.dp))
                        Text("3. Sungai & Alam:", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Waspadai tebing pendek di tepi sungai dan nikmati pemandangan air bergelombang. Siapkan pedang saat malam tiba!", color = Color(0xFFCBD5E1), fontSize = 11.sp)
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showGuideDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                    ) {
                        Text("Mengerti & Siap!")
                    }
                },
                containerColor = Color(0xFF1E293B)
            )
        }
    }
}

@Composable
fun FeatureCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String
) {
    Box(modifier = Modifier.fillMaxWidth()) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFF1E293B)
        ) {
            Row(
                modifier = Modifier.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color(0xFFFFD54F),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(desc, color = Color(0xFF94A3B8), fontSize = 9.5.sp, lineHeight = 13.sp)
                }
            }
        }
        RusticStickBorder(hasLeaves = false)
    }
}
