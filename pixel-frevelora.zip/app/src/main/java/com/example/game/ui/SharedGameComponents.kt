package com.example.game.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.items.CraftingRecipe
import com.example.game.items.ItemStack

@Composable
fun HotbarSlotView(
    slotIndex: Int,
    stack: ItemStack?,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (isSelected) Color(0xFFFFD700) else Color(0xFF475569)
    val bgColor = if (isSelected) Color(0xFF334155) else Color(0xFF0F172A)

    Box(
        modifier = Modifier
            .padding(horizontal = 2.dp)
            .size(36.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(if (isSelected) 2.dp else 1.dp, borderColor, RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .testTag("hotbar_slot_$slotIndex"),
        contentAlignment = Alignment.Center
    ) {
        if (stack != null) {
            ItemPixelSprite(item = stack.item, size = 24.dp)
            if (stack.count > 1) {
                Text(
                    text = stack.count.toString(),
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 2.dp, bottom = 1.dp)
                )
            }
        }
    }
}

@Composable
fun EquipmentSlotView(label: String, stack: ItemStack?) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Color(0xFF94A3B8), fontSize = 9.sp)
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFF1E293B))
                .border(1.dp, Color(0xFF475569), RoundedCornerShape(6.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (stack != null) {
                ItemPixelSprite(item = stack.item, size = 24.dp)
            } else {
                Text("-", color = Color(0xFF64748B), fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun ItemSlotBox(
    stack: ItemStack?,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (isSelected) Color(0xFFFFD700) else Color(0xFF334155)
    val bgColor = if (isSelected) Color(0xFF475569) else Color(0xFF0F172A)

    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(if (isSelected) 2.dp else 1.dp, borderColor, RoundedCornerShape(6.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (stack != null) {
            ItemPixelSprite(item = stack.item, size = 24.dp)
            if (stack.count > 1) {
                Text(
                    text = stack.count.toString(),
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 2.dp, bottom = 1.dp)
                )
            }
        }
    }
}

@Composable
fun RecipeCard(
    recipe: CraftingRecipe,
    canCraft: Boolean,
    onCraft: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF0F172A),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (canCraft) Color(0xFF4CAF50) else Color(0xFF334155)
        )
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF1E293B)),
                contentAlignment = Alignment.Center
            ) {
                ItemPixelSprite(item = recipe.result.item, size = 26.dp)
                if (recipe.result.count > 1) {
                    Text(
                        text = recipe.result.count.toString(),
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 1.dp, bottom = 1.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = recipe.name,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = recipe.ingredients.joinToString(", ") { "${it.count}x ${it.item.name.substringBefore(" (")}" },
                    color = if (canCraft) Color(0xFF81C784) else Color(0xFF94A3B8),
                    fontSize = 10.sp
                )
            }

            Button(
                onClick = onCraft,
                enabled = canCraft,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF43A047),
                    disabledContainerColor = Color(0xFF334155)
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
            ) {
                Text("Rakit", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
