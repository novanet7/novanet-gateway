package com.example.game.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.game.GameEngine
import com.example.game.entity.Direction
import com.example.game.items.ItemCategory
import com.example.game.items.ItemStack

private data class SmartContextData(
    val promptText: String,
    val icon: ImageVector,
    val attackBtnLabel: String,
    val interactBtnLabel: String
)

@Composable
fun GameHud(
    engine: GameEngine,
    onOpenInventory: () -> Unit,
    onOpenCrafting: () -> Unit,
    onOpenCivilization: () -> Unit,
    onOpenQuests: () -> Unit,
    onOpenSettings: () -> Unit,
    onSummonBoss: () -> Unit,
    onAttackMine: () -> Unit,
    onInteractPlace: () -> Unit,
    onDash: () -> Unit,
    onEat: () -> Unit,
    onJoystickMove: (Float, Float) -> Unit
) {
    val player = engine.player
    val dayTime = engine.dayCycleTime
    val isNight = dayTime < 0.22f || dayTime > 0.78f
    val currentBiome = engine.worldGen.getBiome(player.x.toInt(), player.y.toInt())

    // 1. SMART CONTEXT DETECTION (Calculates what player is looking at)
    val (facingDx, facingDy) = when (player.facing) {
        Direction.UP -> Pair(0, -1)
        Direction.DOWN -> Pair(0, 1)
        Direction.LEFT -> Pair(-1, 0)
        Direction.RIGHT -> Pair(1, 0)
    }
    val targetTx = (player.x + facingDx * 1.1f).toInt()
    val targetTy = (player.y + facingDy * 1.1f).toInt()
    val targetFeature = engine.getFeatureTile(targetTx, targetTy)
    val targetBase = engine.getBaseTile(targetTx, targetTy)

    val nearbyMob = engine.mobs.firstOrNull {
        kotlin.math.hypot(it.x - player.x, it.y - player.y) < 2.0f
    }
    val nearbyVillager = if (engine.civilization.isFounded) {
        engine.civilization.villagers.firstOrNull {
            kotlin.math.hypot(it.x - player.x, it.y - player.y) < 2.2f
        }
    } else null

    val smartContext = when {
        nearbyMob != null -> SmartContextData(
            promptText = "⚔️ Musuh Terdeteksi! Serang & Tekan DASH untuk menghindar!",
            icon = Icons.Default.SportsKabaddi,
            attackBtnLabel = "SERANG",
            interactBtnLabel = "AKSI"
        )
        nearbyVillager != null -> SmartContextData(
            promptText = "💬 ${nearbyVillager.name} (${nearbyVillager.role.name}) — Siap diajak bicara!",
            icon = Icons.Default.RecordVoiceOver,
            attackBtnLabel = "SERANG",
            interactBtnLabel = "BICARA"
        )
        targetFeature != null -> when {
            targetFeature.id.startsWith("tree_") -> SmartContextData(
                promptText = "🪓 [TEBANG] ${targetFeature.name} — Dapatkan Kayu & Dahan",
                icon = Icons.Default.Nature,
                attackBtnLabel = "TEBANG",
                interactBtnLabel = "PASANG"
            )
            targetFeature.id.startsWith("rock_") || targetFeature.id.endsWith("_ore") -> SmartContextData(
                promptText = "⛏️ [TAMBANG] ${targetFeature.name} — Dapatkan Batu & Mineral",
                icon = Icons.Default.Terrain,
                attackBtnLabel = "TAMBANG",
                interactBtnLabel = "PASANG"
            )
            targetFeature.id == "crop_wheat" -> SmartContextData(
                promptText = "🌾 [PANEN] Gandum Siap Panen",
                icon = Icons.Default.Grass,
                attackBtnLabel = "SERANG",
                interactBtnLabel = "PANEN"
            )
            targetFeature.id == "chest" -> SmartContextData(
                promptText = "📦 [BUKA] Peti Harta & Penyimpanan",
                icon = Icons.Default.Inventory2,
                attackBtnLabel = "SERANG",
                interactBtnLabel = "BUKA"
            )
            targetFeature.id in listOf("workbench", "furnace", "civilization_totem") -> SmartContextData(
                promptText = "🏛️ [INTERAKSI] Gunakan ${targetFeature.name}",
                icon = Icons.Default.Build,
                attackBtnLabel = "SERANG",
                interactBtnLabel = "PAKAI"
            )
            else -> SmartContextData(
                promptText = "🎯 Objek: ${targetFeature.name}",
                icon = Icons.Default.TouchApp,
                attackBtnLabel = "SERANG",
                interactBtnLabel = "PASANG"
            )
        }
        targetBase.isWater -> SmartContextData(
            promptText = "💧 Air Sungai Jernih — Ambil Air / Memancing",
            icon = Icons.Default.WaterDrop,
            attackBtnLabel = "SERANG",
            interactBtnLabel = "AMBIL"
        )
        player.getEquippedItem()?.item?.category == ItemCategory.BUILDING -> SmartContextData(
            promptText = "🔨 [PASANG] Letakkan ${player.getEquippedItem()?.item?.name} di Tanah",
            icon = Icons.Default.Handyman,
            attackBtnLabel = "SERANG",
            interactBtnLabel = "PASANG"
        )
        player.hunger < 70f && player.hotbar.any { it?.item?.category == ItemCategory.FOOD } -> SmartContextData(
            promptText = "🍖 Tekan tombol MAKAN untuk memulihkan lapar & darah!",
            icon = Icons.Default.Restaurant,
            attackBtnLabel = "SERANG",
            interactBtnLabel = "PASANG"
        )
        else -> SmartContextData(
            promptText = "🌲 Jelajahi Fr3velora: Tebang pohon, tambang batu, dan bangun desa!",
            icon = Icons.Default.Explore,
            attackBtnLabel = "SERANG",
            interactBtnLabel = "PASANG"
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {

        // ================= TOP BAR (MODERN RPG HUD) =================
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            // Top Left: Sleek Minimalist Explorer Badge
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xCC0F172A),
                border = androidx.compose.foundation.BorderStroke(1.2.dp, Color(0xFF475569)),
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Player Avatar Icon
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(Color(0xFF2563EB), Color(0xFF1E3A8A))
                                )
                            )
                            .border(1.5.dp, Color(0xFFFFD700), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Lv.${player.level}",
                            color = Color(0xFFFFD700),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = if (isNight) Icons.Default.Bedtime else Icons.Default.WbSunny,
                                contentDescription = null,
                                tint = if (isNight) Color(0xFF90CAF9) else Color(0xFFFFD54F),
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "Hari ${engine.dayNumber} (${if (isNight) "Malam" else "Siang"})",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = currentBiome.displayName.substringBefore(" ("),
                            color = Color(currentBiome.ambientHue),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Top Right: Floating Menu Pill Bar
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xCC0F172A),
                border = androidx.compose.foundation.BorderStroke(1.2.dp, Color(0xFF475569)),
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ModernMenuButton(
                        icon = Icons.Default.Backpack,
                        label = "Tas",
                        tint = Color(0xFF4CAF50),
                        tag = "inventory_btn",
                        onClick = onOpenInventory
                    )
                    ModernMenuButton(
                        icon = Icons.Default.Build,
                        label = "Rakit",
                        tint = Color(0xFFFB8C00),
                        tag = "crafting_btn",
                        onClick = onOpenCrafting
                    )
                    ModernMenuButton(
                        icon = Icons.Default.Castle,
                        label = if (engine.civilization.isFounded) "Desa Lv.${engine.civilization.level}" else "Desa",
                        tint = Color(0xFFFFD700),
                        tag = "civilization_btn",
                        onClick = onOpenCivilization
                    )
                    ModernMenuButton(
                        icon = Icons.Default.EmojiEvents,
                        label = "Misi",
                        tint = Color(0xFFFDD835),
                        tag = "quests_btn",
                        onClick = onOpenQuests
                    )
                    ModernMenuButton(
                        icon = Icons.Default.LocalFireDepartment,
                        label = "Boss",
                        tint = Color(0xFFE53935),
                        tag = "boss_btn",
                        onClick = onSummonBoss
                    )
                    ModernMenuButton(
                        icon = Icons.Default.Settings,
                        label = "Opsi",
                        tint = Color(0xFF90A4AE),
                        tag = "settings_btn",
                        onClick = onOpenSettings
                    )
                }
            }
        }

        // ================= BOTTOM CONTROLS (HORIZONTAL LANDSCAPE) =================

        // Bottom Left: Virtual Joystick
        VirtualJoystick(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 20.dp, bottom = 12.dp),
            onMove = onJoystickMove
        )

        // Bottom Center: Smart Helper Pill + Heart Health Bar (Darah) + Vitals + Hotbar
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // SMART CONTEXT HELPER PILL
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xDD0F172A),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF64748B)),
                shadowElevation = 6.dp,
                modifier = Modifier.padding(bottom = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = smartContext.icon,
                        contentDescription = null,
                        tint = Color(0xFFFFD700),
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = smartContext.promptText,
                        color = Color.White,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // PRIMARY VITALS & HOTBAR CONTAINER
            Surface(
                modifier = Modifier.widthIn(max = 480.dp),
                shape = RoundedCornerShape(14.dp),
                color = Color(0xEE0F172A),
                border = androidx.compose.foundation.BorderStroke(1.2.dp, Color(0xFF475569)),
                shadowElevation = 10.dp
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Row 1: Heart Containers (Bar Darah dengan Logo Hati) + Satiety & Stamina
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Heart Icons Row (Darah)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            val totalHearts = 10
                            val hpPerHeart = player.maxHp.toFloat() / totalHearts
                            for (i in 0 until totalHearts) {
                                val heartThreshold = (i + 1) * hpPerHeart
                                val isFull = player.hp >= heartThreshold
                                val isHalf = player.hp >= (i * hpPerHeart + hpPerHeart / 2) && !isFull
                                Icon(
                                    imageVector = if (isFull || isHalf) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = "Hati Darah",
                                    tint = if (isFull) Color(0xFFFF1744) else if (isHalf) Color(0xFFFF5252) else Color(0xFF475569),
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${player.hp}/${player.maxHp}",
                                color = Color(0xFFFF5252),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        // Hunger & Stamina badges
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Restaurant,
                                    contentDescription = "Lapar",
                                    tint = Color(0xFFFF9800),
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "${player.hunger.toInt()}%",
                                    color = Color(0xFFFFB74D),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = "Stamina",
                                    tint = Color(0xFF00E5FF),
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "${player.stamina.toInt()}%",
                                    color = Color(0xFF80DEEA),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    // Active Item Name Tooltip
                    val activeItem = player.getEquippedItem()
                    Text(
                        text = activeItem?.let { "${it.item.name} (${it.count}x)" } ?: "Tangan Kosong",
                        color = Color(0xFFFFD54F),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    // 9 Hotbar Slots
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        for (i in 0 until 9) {
                            val stack = player.hotbar[i]
                            val isSelected = player.selectedHotbarIndex == i
                            HotbarSlotView(
                                slotIndex = i,
                                stack = stack,
                                isSelected = isSelected,
                                onClick = { player.selectedHotbarIndex = i }
                            )
                        }
                    }
                }
            }
        }

        // Bottom Right: High Quality RPG Action Buttons with Dynamic Labels
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            // Secondary Quick Actions (Dash & Eat)
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // DASH BUTTON
                QuickSkillButton(
                    icon = Icons.Default.FastForward,
                    text = "DASH",
                    glowColor = Color(0xFF00E5FF),
                    tag = "dash_button",
                    onClick = onDash
                )

                // EAT BUTTON
                QuickSkillButton(
                    icon = Icons.Default.LocalDining,
                    text = "MAKAN",
                    glowColor = Color(0xFF4CAF50),
                    tag = "eat_button",
                    onClick = onEat
                )
            }

            // INTERACT / PLACE BUTTON (With Dynamic Label)
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .clickable { onInteractPlace() }
                    .testTag("interact_button")
                    .shadow(6.dp, CircleShape)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_interact_btn_1790890836856),
                    contentDescription = smartContext.interactBtnLabel,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Text(
                    text = smartContext.interactBtnLabel,
                    color = Color.White,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 3.dp)
                )
            }

            // PRIMARY ATTACK / MINE / CHOP BUTTON (With Dynamic Label)
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .clickable { onAttackMine() }
                    .testTag("attack_button")
                    .shadow(10.dp, CircleShape)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_attack_btn_1790890822300),
                    contentDescription = smartContext.attackBtnLabel,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Text(
                    text = smartContext.attackBtnLabel,
                    color = Color(0xFFFFEB3B),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 4.dp)
                )
            }
        }
    }
}

@Composable
fun ModernProgressBar(
    current: Int,
    max: Int,
    barColor: Color,
    label: String,
    icon: ImageVector
) {
    val fraction = (current.toFloat() / max).coerceIn(0f, 1f)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = barColor,
            modifier = Modifier.size(11.dp)
        )
        Box(
            modifier = Modifier
                .width(80.dp)
                .height(7.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color(0xFF1E293B))
                .border(0.8.dp, Color(0xFF334155), RoundedCornerShape(3.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction)
                    .background(
                        Brush.horizontalGradient(
                            listOf(barColor.copy(alpha = 0.7f), barColor)
                        )
                    )
            )
        }
        Text(
            text = "$current",
            color = Color.White,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun ModernMenuButton(
    icon: ImageVector,
    label: String,
    tint: Color,
    tag: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .testTag(tag),
        color = Color(0xFF1E293B),
        border = androidx.compose.foundation.BorderStroke(1.dp, tint.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = label,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun QuickSkillButton(
    icon: ImageVector,
    text: String,
    glowColor: Color,
    tag: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .size(46.dp)
            .clickable { onClick() }
            .testTag(tag),
        shape = CircleShape,
        color = Color(0xEE1E293B),
        border = androidx.compose.foundation.BorderStroke(2.dp, glowColor),
        shadowElevation = 6.dp
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = text,
                tint = glowColor,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = text,
                color = Color.White,
                fontSize = 7.5.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}
