package com.example.game.entity

import com.example.game.items.Item
import com.example.game.items.ItemCategory
import com.example.game.items.ItemRegistry
import com.example.game.items.ItemStack
import java.util.UUID

enum class Direction {
    UP, RIGHT, DOWN, LEFT
}

enum class MobType(
    val displayName: String,
    val maxHp: Int,
    val damage: Int,
    val speed: Float,
    val isHostile: Boolean,
    val isBoss: Boolean = false,
    val size: Float = 0.8f,
    val bodyColor: Long = 0xFF4CAF50
) {
    RABBIT("Kelinci Hutan", 15, 0, 1.8f, false, size = 0.5f, bodyColor = 0xFFECEFF1),
    BOAR("Babi Hutan Liar", 40, 8, 1.2f, false, size = 0.8f, bodyColor = 0xFF6D4C41),
    SLIME_GREEN("Slime Rumput", 35, 10, 0.9f, true, size = 0.7f, bodyColor = 0xFF4CAF50),
    SLIME_RED("Slime Magma", 55, 16, 1.1f, true, size = 0.8f, bodyColor = 0xFFFF5722),
    SHADOW_ZOMBIE("Zombie Malam", 70, 18, 1.0f, true, size = 0.9f, bodyColor = 0xFF37474F),
    SKELETON_ARCHER("Pemanah Tulang", 50, 14, 1.0f, true, size = 0.9f, bodyColor = 0xFFE0E0E0),
    CAVE_GOLEM("Golem Batu Kuno", 180, 28, 0.6f, true, size = 1.3f, bodyColor = 0xFF616161),
    FR3VELORA_DRAGON_BOSS("Naga Purba Fr3velora", 800, 45, 1.2f, true, isBoss = true, size = 2.4f, bodyColor = 0xFF7B1FA2)
}

data class Mob(
    val id: String = UUID.randomUUID().toString(),
    val type: MobType,
    var x: Float,
    var y: Float,
    var hp: Int = type.maxHp,
    var facing: Direction = Direction.DOWN,
    var stateTime: Float = 0f,
    var attackCooldown: Float = 0f,
    var moveAngle: Float = 0f,
    var moveTimer: Float = 0f,
    var isHurt: Boolean = false,
    var hurtTimer: Float = 0f
)

enum class VillagerRole(
    val title: String,
    val perkDescription: String,
    val clothesColor: Long
) {
    FARMER("Petani Subur", "Otomatis menanam dan memanen gandum/makanan ke lumbung desa.", 0xFF8BC34A),
    MINER("Penambang Ahli", "Menghasilkan batu, batubara, dan bijih besi secara berkala.", 0xFFFF9800),
    BLACKSMITH("Pandai Besi", "Memperbaiki senjata dan meningkatkan efisiensi peleburan.", 0xFF795548),
    GUARD("Prajurit Penjaga", "Menyerang monster yang mendekati pemukiman.", 0xFF607D8B),
    HEALER("Penyembuh Desa", "Memancarkan aura pemulihan darah bagi pemain dan warga.", 0xFF00BCD4)
}

data class Villager(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val role: VillagerRole,
    var x: Float,
    var y: Float,
    var hp: Int = 100,
    var produceTimer: Float = 0f,
    var facing: Direction = Direction.DOWN
)

data class Projectile(
    val id: String = UUID.randomUUID().toString(),
    var x: Float,
    var y: Float,
    val vx: Float,
    val vy: Float,
    val damage: Int,
    val isFromPlayer: Boolean,
    val isFire: Boolean = false,
    var lifeRemaining: Float = 2.0f
)

data class DroppedItem(
    val id: String = UUID.randomUUID().toString(),
    var x: Float,
    var y: Float,
    val itemStack: ItemStack,
    var floatAnim: Float = 0f
)

data class FloatingEffect(
    val id: String = UUID.randomUUID().toString(),
    var x: Float,
    var y: Float,
    val text: String,
    val color: Long,
    var lifeRemaining: Float = 1.0f
)
