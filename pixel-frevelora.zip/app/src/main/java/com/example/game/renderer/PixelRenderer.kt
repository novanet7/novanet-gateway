package com.example.game.renderer

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.example.game.GameEngine
import com.example.game.entity.*
import com.example.game.world.TileType
import kotlin.math.*

/**
 * Asset-based world renderer for Pixel Fr3velora.
 *
 * OLD SYSTEM (removed): thousands of lines of procedural drawRect / drawOval pixel art.
 * NEW SYSTEM: everything is drawn from ImageBitmap assets via SpriteAssets.
 *
 * How it works (like normal pixel games):
 * 1. Tiles → SpriteAssets.getTileSprite(tile)  → drawImage
 * 2. Player → hero sprite from drawable
 * 3. Boss  → dragon sprite from drawable
 * 4. Other mobs / features → cached generated pixel bitmaps (or real PNGs if you add them)
 *
 * To fully customize visuals: just drop PNG files into res/drawable named:
 *   tile_grass.png, tile_water.png, mob_boar.png, player_idle.png, etc.
 * They will be loaded automatically.
 */
object PixelRenderer {

    fun renderWorld(
        drawScope: DrawScope,
        engine: GameEngine,
        tileSize: Float,
        animTime: Float
    ) {
        // Ensure assets are ready (safe to call every frame – init is idempotent)
        SpriteAssets.init(engine.context)

        val canvasWidth = drawScope.size.width
        val canvasHeight = drawScope.size.height
        val player = engine.player
        val cameraCenterX = canvasWidth / 2f
        val cameraCenterY = canvasHeight / 2f

        fun worldToScreen(wx: Float, wy: Float): Offset {
            val sx = cameraCenterX + (wx - player.x) * tileSize
            val sy = cameraCenterY + (wy - player.y) * tileSize
            return Offset(sx, sy)
        }

        val visibleTilesX = (canvasWidth / tileSize).toInt() / 2 + 3
        val visibleTilesY = (canvasHeight / tileSize).toInt() / 2 + 4

        val minTx = (player.x - visibleTilesX).toInt()
        val maxTx = (player.x + visibleTilesX).toInt()
        val minTy = (player.y - visibleTilesY).toInt()
        val maxTy = (player.y + visibleTilesY).toInt()

        // 1. Base terrain – pure sprite drawing
        for (ty in minTy..maxTy) {
            for (tx in minTx..maxTx) {
                val screenPos = worldToScreen(tx.toFloat(), ty.toFloat())
                val baseTile = engine.getBaseTile(tx, ty)
                drawTerrainSprite(drawScope, baseTile, screenPos.x, screenPos.y, tileSize, animTime, tx, ty)
            }
        }

        // 2. Target cursor (lightweight overlay, not content)
        drawSmartTargetCursor(drawScope, engine, tileSize, animTime, ::worldToScreen)

        // 3. Features / structures (position-based variety + subtle anim)
        for (ty in minTy..maxTy) {
            for (tx in minTx..maxTx) {
                val feature = engine.getFeatureTile(tx, ty) ?: continue
                val screenPos = worldToScreen(tx.toFloat(), ty.toFloat())
                drawFeatureSprite(drawScope, feature, screenPos.x, screenPos.y, tileSize, animTime, tx, ty)
            }
        }

        // 4. Dropped items
        for (drop in engine.droppedItems) {
            val sp = worldToScreen(drop.x, drop.y)
            drawDroppedItem(drawScope, drop, sp.x, sp.y, tileSize)
        }

        // 5. Villagers
        if (engine.civilization.isFounded) {
            for (v in engine.civilization.villagers) {
                val sp = worldToScreen(v.x, v.y)
                drawVillagerSprite(drawScope, v, sp.x, sp.y, tileSize, animTime)
            }
        }

        // 6. Mobs (boss uses real dragon asset)
        for (mob in engine.mobs) {
            val sp = worldToScreen(mob.x, mob.y)
            drawMobSprite(drawScope, mob, sp.x, sp.y, tileSize, animTime)
        }

        // 7. Player (uses real hero asset)
        val playerScreenPos = worldToScreen(player.x, player.y)
        drawPlayerSprite(drawScope, player, playerScreenPos.x, playerScreenPos.y, tileSize, animTime)

        // 8. Projectiles
        for (proj in engine.projectiles) {
            val sp = worldToScreen(proj.x, proj.y)
            drawProjectile(drawScope, proj, sp.x, sp.y, tileSize)
        }

        // 9. Lighting overlay
        drawLightingOverlay(drawScope, engine, tileSize, ::worldToScreen)

        // 10. Floating text
        for (eff in engine.floatingEffects) {
            val sp = worldToScreen(eff.x, eff.y)
            drawFloatingText(drawScope, eff, sp.x, sp.y)
        }
    }

    // -------------------------------------------------------------------------
    // Terrain – asset based
    // -------------------------------------------------------------------------
    private fun drawTerrainSprite(
        drawScope: DrawScope,
        tile: TileType,
        x: Float,
        y: Float,
        size: Float,
        animTime: Float,
        tx: Int,
        ty: Int
    ) {
        // Animated water / lava, or static variant based on world position
        val sprite = if (tile.isWater || tile.id.contains("lava")) {
            SpriteAssets.getAnimatedTile(tile, animTime, tx, ty)
        } else {
            SpriteAssets.getTileSprite(tile, tx, ty)
        }
        drawScope.drawImage(
            image = sprite,
            dstOffset = IntOffset(x.roundToInt(), y.roundToInt()),
            dstSize = IntSize(size.roundToInt(), size.roundToInt())
        )
    }

    // -------------------------------------------------------------------------
    // Features (trees, rocks, buildings, crops…)
    // -------------------------------------------------------------------------
    private fun drawFeatureSprite(
        drawScope: DrawScope,
        feature: TileType,
        x: Float,
        y: Float,
        size: Float,
        animTime: Float,
        tx: Int,
        ty: Int
    ) {
        val sprite = SpriteAssets.getFeatureSprite(feature, tx, ty, animTime)

        // Slight vertical offset for 2.5D feel
        val drawY = y - size * 0.15f
        val drawH = size * 1.25f

        drawScope.drawImage(
            image = sprite,
            dstOffset = IntOffset(x.roundToInt(), drawY.roundToInt()),
            dstSize = IntSize(size.roundToInt(), drawH.roundToInt())
        )

        // Soft ground shadow under feature
        drawScope.drawOval(
            Color(0x44000000),
            Offset(x + size * 0.15f, y + size * 0.85f),
            Size(size * 0.7f, size * 0.25f)
        )
    }

    // -------------------------------------------------------------------------
    // Player – uses the real hero asset
    // -------------------------------------------------------------------------
    private fun drawPlayerSprite(
        drawScope: DrawScope,
        player: Player,
        x: Float,
        y: Float,
        size: Float,
        animTime: Float
    ) {
        // Animated walk / idle frame from photo asset
        val sprite = SpriteAssets.getPlayerFrame(player.isMoving, player.walkAnimTime)
            ?: SpriteAssets.getPlayerSprite()

        // Contact shadow
        drawScope.drawOval(
            Color(0x55000000),
            Offset(x + size * 0.15f, y + size * 0.82f),
            Size(size * 0.7f, size * 0.22f)
        )

        if (sprite != null) {
            val bob = if (player.isMoving) {
                abs(sin(player.walkAnimTime * 12f)) * size * 0.04f
            } else {
                sin(animTime * 2.5f) * size * 0.015f
            }

            // Flip horizontally when facing left
            val flip = player.facing == Direction.LEFT
            if (flip) {
                drawScope.withTransform({
                    scale(scaleX = -1f, scaleY = 1f, pivot = Offset(x + size / 2f, y + size / 2f))
                }) {
                    drawImage(
                        image = sprite,
                        dstOffset = IntOffset(x.roundToInt(), (y - bob).roundToInt()),
                        dstSize = IntSize(size.roundToInt(), size.roundToInt())
                    )
                }
            } else {
                drawScope.drawImage(
                    image = sprite,
                    dstOffset = IntOffset(x.roundToInt(), (y - bob).roundToInt()),
                    dstSize = IntSize(size.roundToInt(), size.roundToInt())
                )
            }
        } else {
            drawScope.drawRect(Color(0xFF2563EB), Offset(x + size * 0.25f, y + size * 0.2f), Size(size * 0.5f, size * 0.6f))
            drawScope.drawRect(Color(0xFFFFCC80), Offset(x + size * 0.3f, y), Size(size * 0.4f, size * 0.3f))
        }

        // Tiny direction indicator
        val dirOffset = when (player.facing) {
            Direction.UP -> Offset(size * 0.5f, size * 0.05f)
            Direction.DOWN -> Offset(size * 0.5f, size * 0.95f)
            Direction.LEFT -> Offset(size * 0.05f, size * 0.5f)
            Direction.RIGHT -> Offset(size * 0.95f, size * 0.5f)
        }
        drawScope.drawCircle(Color(0xAAFFD700), size * 0.06f, Offset(x + dirOffset.x, y + dirOffset.y))
    }

    // -------------------------------------------------------------------------
    // Mobs – boss uses real dragon asset, others use generated / named sprites
    // -------------------------------------------------------------------------
    private fun drawMobSprite(
        drawScope: DrawScope,
        mob: Mob,
        x: Float,
        y: Float,
        size: Float,
        animTime: Float
    ) {
        val mobSize = size * mob.type.size
        val ox = x + (size - mobSize) / 2f
        val oy = y + (size - mobSize) / 2f

        // Shadow
        drawScope.drawOval(
            Color(0x55000000),
            Offset(ox + mobSize * 0.1f, oy + mobSize * 0.8f),
            Size(mobSize * 0.8f, mobSize * 0.25f)
        )

        // Animated mob sprite (boss = real dragon photo, others = multi-frame assets)
        val sprite = SpriteAssets.getMobSprite(mob.type.name, animTime + mob.stateTime)

        if (sprite != null) {
            val bob = sin(animTime * 4f + mob.stateTime) * mobSize * 0.03f
            drawScope.drawImage(
                image = sprite,
                dstOffset = IntOffset(ox.roundToInt(), (oy + bob).roundToInt()),
                dstSize = IntSize(mobSize.roundToInt(), mobSize.roundToInt())
            )
        } else {
            val color = Color(mob.type.bodyColor)
            val bob = sin(animTime * 5f + mob.stateTime) * 2f
            when (mob.type) {
                MobType.RABBIT -> {
                    drawScope.drawOval(color, Offset(ox + mobSize * 0.2f, oy + mobSize * 0.35f + bob), Size(mobSize * 0.6f, mobSize * 0.5f))
                    drawScope.drawOval(color, Offset(ox + mobSize * 0.25f, oy + mobSize * 0.1f + bob), Size(mobSize * 0.5f, mobSize * 0.35f))
                }
                MobType.BOAR -> {
                    drawScope.drawOval(color, Offset(ox, oy + mobSize * 0.25f + bob), Size(mobSize, mobSize * 0.6f))
                    drawScope.drawRect(Color(0xFF3E2723), Offset(ox + mobSize * 0.7f, oy + mobSize * 0.35f + bob), Size(mobSize * 0.25f, mobSize * 0.15f))
                }
                MobType.SLIME_GREEN, MobType.SLIME_RED -> {
                    drawScope.drawOval(color, Offset(ox + mobSize * 0.1f, oy + mobSize * 0.3f + bob), Size(mobSize * 0.8f, mobSize * 0.6f))
                    drawScope.drawCircle(Color.White, mobSize * 0.08f, Offset(ox + mobSize * 0.35f, oy + mobSize * 0.45f + bob))
                    drawScope.drawCircle(Color.White, mobSize * 0.08f, Offset(ox + mobSize * 0.6f, oy + mobSize * 0.45f + bob))
                }
                MobType.SHADOW_ZOMBIE, MobType.SKELETON_ARCHER -> {
                    drawScope.drawRect(color, Offset(ox + mobSize * 0.25f, oy + mobSize * 0.2f + bob), Size(mobSize * 0.5f, mobSize * 0.7f))
                    drawScope.drawRect(color, Offset(ox + mobSize * 0.3f, oy + bob), Size(mobSize * 0.4f, mobSize * 0.25f))
                }
                MobType.CAVE_GOLEM -> {
                    drawScope.drawRect(color, Offset(ox, oy + mobSize * 0.15f + bob), Size(mobSize, mobSize * 0.85f))
                }
                MobType.FR3VELORA_DRAGON_BOSS -> {
                    // Should have been caught by sprite, but just in case
                    drawScope.drawRect(color, Offset(ox, oy + bob), Size(mobSize, mobSize))
                }
            }
        }

        // HP bar
        if (mob.hp < mob.type.maxHp) {
            val barW = mobSize * 0.9f
            val barH = size * 0.08f
            val hpFrac = (mob.hp.toFloat() / mob.type.maxHp).coerceIn(0f, 1f)
            val barX = ox + (mobSize - barW) / 2f
            val barY = oy - size * 0.15f
            drawScope.drawRect(Color(0x88000000), Offset(barX, barY), Size(barW, barH))
            drawScope.drawRect(Color(0xFFFF1744), Offset(barX, barY), Size(barW * hpFrac, barH))
        }
    }

    // -------------------------------------------------------------------------
    // Villagers
    // -------------------------------------------------------------------------
    private fun drawVillagerSprite(
        drawScope: DrawScope,
        v: Villager,
        x: Float,
        y: Float,
        size: Float,
        animTime: Float
    ) {
        val clothes = Color(v.role.clothesColor)
        val bob = sin(animTime * 3f + v.hashCode() * 0.1f) * size * 0.02f

        // Shadow
        drawScope.drawOval(Color(0x44000000), Offset(x + size * 0.2f, y + size * 0.85f), Size(size * 0.6f, size * 0.18f))

        // Simple body (can be replaced later with villager_*.png)
        drawScope.drawRect(clothes, Offset(x + size * 0.3f, y + size * 0.35f + bob), Size(size * 0.4f, size * 0.45f))
        drawScope.drawRect(Color(0xFFFFCC80), Offset(x + size * 0.32f, y + size * 0.1f + bob), Size(size * 0.36f, size * 0.28f))
        // Legs
        drawScope.drawRect(Color(0xFF3E2723), Offset(x + size * 0.32f, y + size * 0.75f + bob), Size(size * 0.12f, size * 0.2f))
        drawScope.drawRect(Color(0xFF3E2723), Offset(x + size * 0.56f, y + size * 0.75f + bob), Size(size * 0.12f, size * 0.2f))
    }

    // -------------------------------------------------------------------------
    // Dropped items, projectiles, UI helpers
    // -------------------------------------------------------------------------
    private fun drawDroppedItem(
        drawScope: DrawScope,
        drop: DroppedItem,
        x: Float,
        y: Float,
        size: Float
    ) {
        val s = size * 0.45f
        val bob = sin(System.currentTimeMillis() / 300.0 + drop.x * 2).toFloat() * size * 0.05f
        val color = Color(drop.itemStack.item.primaryColor)
        drawScope.drawRect(color, Offset(x + (size - s) / 2f, y + (size - s) / 2f + bob), Size(s, s))
        drawScope.drawRect(Color.White.copy(alpha = 0.4f), Offset(x + (size - s) / 2f, y + (size - s) / 2f + bob), Size(s * 0.35f, s * 0.35f))
    }

    private fun drawProjectile(
        drawScope: DrawScope,
        proj: Projectile,
        x: Float,
        y: Float,
        size: Float
    ) {
        val s = size * 0.25f
        val col = if (proj.isFire) Color(0xFFFF5722) else Color(0xFFFFD700)
        drawScope.drawCircle(col, s, Offset(x + size * 0.5f, y + size * 0.5f))
        if (proj.isFire) {
            drawScope.drawCircle(Color(0xFFFFEB3B), s * 0.5f, Offset(x + size * 0.5f, y + size * 0.5f))
        }
    }

    private fun drawSmartTargetCursor(
        drawScope: DrawScope,
        engine: GameEngine,
        tileSize: Float,
        animTime: Float,
        worldToScreen: (Float, Float) -> Offset
    ) {
        val player = engine.player
        val (targetTx, targetTy) = when (player.facing) {
            Direction.UP -> Pair(player.x.toInt(), (player.y - 1f).toInt())
            Direction.DOWN -> Pair(player.x.toInt(), (player.y + 1f).toInt())
            Direction.LEFT -> Pair((player.x - 1f).toInt(), player.y.toInt())
            Direction.RIGHT -> Pair((player.x + 1f).toInt(), player.y.toInt())
        }

        val targetScreen = worldToScreen(targetTx.toFloat(), targetTy.toFloat())
        val p = tileSize / 16f
        val pulse = (sin(animTime * 6f) * 0.25f + 0.75f).coerceIn(0.5f, 1f)
        val bracketCol = Color(0xFFFFD700).copy(alpha = pulse)

        val tx = targetScreen.x
        val ty = targetScreen.y
        val bLen = p * 4f
        val bThick = p * 1.2f

        // Four corner brackets
        drawScope.drawRect(bracketCol, Offset(tx, ty), Size(bLen, bThick))
        drawScope.drawRect(bracketCol, Offset(tx, ty), Size(bThick, bLen))
        drawScope.drawRect(bracketCol, Offset(tx + tileSize - bLen, ty), Size(bLen, bThick))
        drawScope.drawRect(bracketCol, Offset(tx + tileSize - bThick, ty), Size(bThick, bLen))
        drawScope.drawRect(bracketCol, Offset(tx, ty + tileSize - bThick), Size(bLen, bThick))
        drawScope.drawRect(bracketCol, Offset(tx, ty + tileSize - bLen), Size(bThick, bLen))
        drawScope.drawRect(bracketCol, Offset(tx + tileSize - bLen, ty + tileSize - bThick), Size(bLen, bThick))
        drawScope.drawRect(bracketCol, Offset(tx + tileSize - bThick, ty + tileSize - bLen), Size(bThick, bLen))
    }

    private fun drawLightingOverlay(
        drawScope: DrawScope,
        engine: GameEngine,
        tileSize: Float,
        worldToScreen: (Float, Float) -> Offset
    ) {
        val t = engine.dayCycleTime
        // Night darkness
        val nightStrength = when {
            t < 0.2f || t > 0.85f -> 0.55f
            t < 0.3f -> (0.3f - t) / 0.1f * 0.55f
            t > 0.75f -> (t - 0.75f) / 0.1f * 0.55f
            else -> 0f
        }
        if (nightStrength > 0.02f) {
            drawScope.drawRect(
                Color(0xFF0A1628).copy(alpha = nightStrength),
                Offset.Zero,
                drawScope.size
            )
        }
    }

    private fun drawFloatingText(
        drawScope: DrawScope,
        eff: FloatingEffect,
        x: Float,
        y: Float
    ) {
        // Simple colored rect + we rely on Compose text elsewhere if needed.
        // For canvas we just draw a small marker.
        val col = Color(eff.color)
        drawScope.drawCircle(col, 6f, Offset(x, y - (1f - eff.lifeRemaining) * 30f))
    }
}
