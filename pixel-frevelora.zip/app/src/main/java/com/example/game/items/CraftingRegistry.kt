package com.example.game.items

enum class CraftingStation {
    HANDS,
    WORKBENCH,
    FURNACE,
    CIVILIZATION_TOTEM
}

data class CraftingIngredient(
    val item: Item,
    val count: Int
)

data class CraftingRecipe(
    val id: String,
    val name: String,
    val result: ItemStack,
    val ingredients: List<CraftingIngredient>,
    val requiredStation: CraftingStation = CraftingStation.HANDS,
    val category: String = "Survival"
) {
    fun canCraft(inventory: List<ItemStack?>): Boolean {
        for (ingredient in ingredients) {
            val totalInInventory = inventory.filterNotNull()
                .filter { it.item.id == ingredient.item.id }
                .sumOf { it.count }
            if (totalInInventory < ingredient.count) {
                return false
            }
        }
        return true
    }
}

object CraftingRegistry {
    val recipes: List<CraftingRecipe> = listOf(
        // === BASIC SURVIVAL & HANDS ===
        CraftingRecipe(
            id = "stick_craft",
            name = "Ranting (Sticks)",
            result = ItemStack(ItemRegistry.STICK, 4),
            ingredients = listOf(CraftingIngredient(ItemRegistry.WOOD, 1)),
            requiredStation = CraftingStation.HANDS,
            category = "Dasar"
        ),
        CraftingRecipe(
            id = "torch_craft",
            name = "Obor (Torches)",
            result = ItemStack(ItemRegistry.TORCH, 4),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.STICK, 1),
                CraftingIngredient(ItemRegistry.COAL, 1)
            ),
            requiredStation = CraftingStation.HANDS,
            category = "Dasar"
        ),
        CraftingRecipe(
            id = "campfire_craft",
            name = "Api Unggun (Campfire)",
            result = ItemStack(ItemRegistry.CAMPFIRE, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.WOOD, 5),
                CraftingIngredient(ItemRegistry.STONE, 3)
            ),
            requiredStation = CraftingStation.HANDS,
            category = "Dasar"
        ),
        CraftingRecipe(
            id = "workbench_craft",
            name = "Meja Kerja (Crafting Table)",
            result = ItemStack(ItemRegistry.WORKBENCH, 1),
            ingredients = listOf(CraftingIngredient(ItemRegistry.WOOD, 4)),
            requiredStation = CraftingStation.HANDS,
            category = "Dasar"
        ),
        CraftingRecipe(
            id = "wood_club_craft",
            name = "Pentungan Kayu",
            result = ItemStack(ItemRegistry.WOOD_CLUB, 1),
            ingredients = listOf(CraftingIngredient(ItemRegistry.WOOD, 4)),
            requiredStation = CraftingStation.HANDS,
            category = "Senjata"
        ),
        CraftingRecipe(
            id = "wood_pickaxe_craft",
            name = "Beliung Kayu",
            result = ItemStack(ItemRegistry.WOOD_PICKAXE, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.WOOD, 3),
                CraftingIngredient(ItemRegistry.STICK, 2)
            ),
            requiredStation = CraftingStation.HANDS,
            category = "Alat"
        ),
        CraftingRecipe(
            id = "wood_axe_craft",
            name = "Kapak Kayu",
            result = ItemStack(ItemRegistry.WOOD_AXE, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.WOOD, 3),
                CraftingIngredient(ItemRegistry.STICK, 2)
            ),
            requiredStation = CraftingStation.HANDS,
            category = "Alat"
        ),

        // === WORKBENCH RECIPES: TOOLS & WEAPONS ===
        CraftingRecipe(
            id = "stone_pickaxe_craft",
            name = "Beliung Batu",
            result = ItemStack(ItemRegistry.STONE_PICKAXE, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.STONE, 4),
                CraftingIngredient(ItemRegistry.STICK, 2)
            ),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Alat"
        ),
        CraftingRecipe(
            id = "stone_axe_craft",
            name = "Kapak Batu",
            result = ItemStack(ItemRegistry.STONE_AXE, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.STONE, 3),
                CraftingIngredient(ItemRegistry.STICK, 2)
            ),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Alat"
        ),
        CraftingRecipe(
            id = "stone_sword_craft",
            name = "Pedang Batu",
            result = ItemStack(ItemRegistry.STONE_SWORD, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.STONE, 3),
                CraftingIngredient(ItemRegistry.STICK, 1)
            ),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Senjata"
        ),
        CraftingRecipe(
            id = "hoe_craft",
            name = "Cangkul Pertanian",
            result = ItemStack(ItemRegistry.HOE, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.STONE, 2),
                CraftingIngredient(ItemRegistry.STICK, 2)
            ),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Alat"
        ),
        CraftingRecipe(
            id = "wood_bow_craft",
            name = "Busur Panah Berburu",
            result = ItemStack(ItemRegistry.WOOD_BOW, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.STICK, 3),
                CraftingIngredient(ItemRegistry.FIBER, 3)
            ),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Senjata"
        ),
        CraftingRecipe(
            id = "arrow_craft",
            name = "Anak Panah x8",
            result = ItemStack(ItemRegistry.ARROW, 8),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.STICK, 2),
                CraftingIngredient(ItemRegistry.FLINT, 1)
            ),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Senjata"
        ),
        CraftingRecipe(
            id = "furnace_craft",
            name = "Tungku Pelebur (Furnace)",
            result = ItemStack(ItemRegistry.FURNACE, 1),
            ingredients = listOf(CraftingIngredient(ItemRegistry.STONE, 8)),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Bangunan"
        ),
        CraftingRecipe(
            id = "chest_craft",
            name = "Peti Penyimpanan",
            result = ItemStack(ItemRegistry.CHEST, 1),
            ingredients = listOf(CraftingIngredient(ItemRegistry.WOOD, 8)),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Bangunan"
        ),
        CraftingRecipe(
            id = "bed_craft",
            name = "Tempat Tidur Nyaman",
            result = ItemStack(ItemRegistry.BED, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.WOOD, 4),
                CraftingIngredient(ItemRegistry.FIBER, 4)
            ),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Bangunan"
        ),
        CraftingRecipe(
            id = "wood_wall_craft",
            name = "Dinding Kayu x4",
            result = ItemStack(ItemRegistry.WOOD_WALL, 4),
            ingredients = listOf(CraftingIngredient(ItemRegistry.WOOD, 2)),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Bangunan"
        ),
        CraftingRecipe(
            id = "stone_wall_craft",
            name = "Dinding Batu x4",
            result = ItemStack(ItemRegistry.STONE_WALL, 4),
            ingredients = listOf(CraftingIngredient(ItemRegistry.STONE, 2)),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Bangunan"
        ),
        CraftingRecipe(
            id = "wood_floor_craft",
            name = "Lantai Kayu x4",
            result = ItemStack(ItemRegistry.WOOD_FLOOR, 4),
            ingredients = listOf(CraftingIngredient(ItemRegistry.WOOD, 2)),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Bangunan"
        ),

        // === ARMOR ===
        CraftingRecipe(
            id = "leather_cap_craft",
            name = "Topi Kulit",
            result = ItemStack(ItemRegistry.LEATHER_CAP, 1),
            ingredients = listOf(CraftingIngredient(ItemRegistry.LEATHER, 4)),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Zirah"
        ),
        CraftingRecipe(
            id = "leather_tunic_craft",
            name = "Baju Zirah Kulit",
            result = ItemStack(ItemRegistry.LEATHER_TUNIC, 1),
            ingredients = listOf(CraftingIngredient(ItemRegistry.LEATHER, 7)),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Zirah"
        ),
        CraftingRecipe(
            id = "leather_boots_craft",
            name = "Sepatu Kulit",
            result = ItemStack(ItemRegistry.LEATHER_BOOTS, 1),
            ingredients = listOf(CraftingIngredient(ItemRegistry.LEATHER, 4)),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Zirah"
        ),

        // === FURNACE SMELTING & COOKING ===
        CraftingRecipe(
            id = "iron_smelt",
            name = "Lebur Batangan Besi",
            result = ItemStack(ItemRegistry.IRON_INGOT, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.IRON_ORE, 1),
                CraftingIngredient(ItemRegistry.COAL, 1)
            ),
            requiredStation = CraftingStation.FURNACE,
            category = "Peleburan"
        ),
        CraftingRecipe(
            id = "gold_smelt",
            name = "Lebur Batangan Emas",
            result = ItemStack(ItemRegistry.GOLD_INGOT, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.GOLD_ORE, 1),
                CraftingIngredient(ItemRegistry.COAL, 1)
            ),
            requiredStation = CraftingStation.FURNACE,
            category = "Peleburan"
        ),
        CraftingRecipe(
            id = "cook_steak",
            name = "Panggang Steak Lezat",
            result = ItemStack(ItemRegistry.COOKED_STEAK, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.RAW_MEAT, 1),
                CraftingIngredient(ItemRegistry.WOOD, 1)
            ),
            requiredStation = CraftingStation.FURNACE,
            category = "Makanan"
        ),
        CraftingRecipe(
            id = "bake_bread",
            name = "Panggang Roti Gandum",
            result = ItemStack(ItemRegistry.BREAD, 1),
            ingredients = listOf(CraftingIngredient(ItemRegistry.WHEAT, 3)),
            requiredStation = CraftingStation.FURNACE,
            category = "Makanan"
        ),
        CraftingRecipe(
            id = "brew_health_pot",
            name = "Ramuan Penyembuh HP",
            result = ItemStack(ItemRegistry.HEALTH_POTION, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.BERRY, 3),
                CraftingIngredient(ItemRegistry.SLIME_GEL, 1)
            ),
            requiredStation = CraftingStation.FURNACE,
            category = "Makanan"
        ),

        // === ADVANCED IRON & DIAMOND GEAR (WORKBENCH) ===
        CraftingRecipe(
            id = "iron_pickaxe_craft",
            name = "Beliung Besi Kuat",
            result = ItemStack(ItemRegistry.IRON_PICKAXE, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.IRON_INGOT, 3),
                CraftingIngredient(ItemRegistry.STICK, 2)
            ),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Alat"
        ),
        CraftingRecipe(
            id = "iron_axe_craft",
            name = "Kapak Besi Tajam",
            result = ItemStack(ItemRegistry.IRON_AXE, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.IRON_INGOT, 3),
                CraftingIngredient(ItemRegistry.STICK, 2)
            ),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Alat"
        ),
        CraftingRecipe(
            id = "iron_sword_craft",
            name = "Pedang Baja Ksatria",
            result = ItemStack(ItemRegistry.IRON_SWORD, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.IRON_INGOT, 2),
                CraftingIngredient(ItemRegistry.STICK, 1)
            ),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Senjata"
        ),
        CraftingRecipe(
            id = "iron_helmet_craft",
            name = "Helm Pelindung Besi",
            result = ItemStack(ItemRegistry.IRON_HELMET, 1),
            ingredients = listOf(CraftingIngredient(ItemRegistry.IRON_INGOT, 4)),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Zirah"
        ),
        CraftingRecipe(
            id = "iron_chestplate_craft",
            name = "Baju Zirah Besi Tangguh",
            result = ItemStack(ItemRegistry.IRON_CHESTPLATE, 1),
            ingredients = listOf(CraftingIngredient(ItemRegistry.IRON_INGOT, 8)),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Zirah"
        ),
        CraftingRecipe(
            id = "iron_boots_craft",
            name = "Sepatu Bot Besi",
            result = ItemStack(ItemRegistry.IRON_BOOTS, 1),
            ingredients = listOf(CraftingIngredient(ItemRegistry.IRON_INGOT, 4)),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Zirah"
        ),
        CraftingRecipe(
            id = "diamond_pickaxe_craft",
            name = "Beliung Berlian Murni",
            result = ItemStack(ItemRegistry.DIAMOND_PICKAXE, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.DIAMOND, 3),
                CraftingIngredient(ItemRegistry.STICK, 2)
            ),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Alat"
        ),
        CraftingRecipe(
            id = "diamond_sword_craft",
            name = "Pedang Perang Berlian",
            result = ItemStack(ItemRegistry.DIAMOND_SWORD, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.DIAMOND, 2),
                CraftingIngredient(ItemRegistry.STICK, 1)
            ),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Senjata"
        ),

        // === CIVILIZATION CRAFTING (FOUNDING A KINGDOM) ===
        CraftingRecipe(
            id = "totem_craft",
            name = "Totem Peradaban Fr3velora",
            result = ItemStack(ItemRegistry.CIVILIZATION_TOTEM, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.WOOD, 10),
                CraftingIngredient(ItemRegistry.STONE, 10),
                CraftingIngredient(ItemRegistry.IRON_INGOT, 2)
            ),
            requiredStation = CraftingStation.WORKBENCH,
            category = "Peradaban"
        ),
        CraftingRecipe(
            id = "watchtower_craft",
            name = "Menara Pengawas Otomatis",
            result = ItemStack(ItemRegistry.WATCHTOWER, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.WOOD, 15),
                CraftingIngredient(ItemRegistry.STONE, 15),
                CraftingIngredient(ItemRegistry.IRON_INGOT, 3)
            ),
            requiredStation = CraftingStation.CIVILIZATION_TOTEM,
            category = "Peradaban"
        ),
        CraftingRecipe(
            id = "quarry_craft",
            name = "Tambang Otomatis Peradaban",
            result = ItemStack(ItemRegistry.QUARRY_STATION, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.STONE, 25),
                CraftingIngredient(ItemRegistry.IRON_INGOT, 5),
                CraftingIngredient(ItemRegistry.COAL, 5)
            ),
            requiredStation = CraftingStation.CIVILIZATION_TOTEM,
            category = "Peradaban"
        ),
        CraftingRecipe(
            id = "dragon_crossbow_craft",
            name = "Fr3velora Crossbow Api",
            result = ItemStack(ItemRegistry.DRAGON_CROSSBOW, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.IRON_INGOT, 6),
                CraftingIngredient(ItemRegistry.RUBY, 2),
                CraftingIngredient(ItemRegistry.FIBER, 4)
            ),
            requiredStation = CraftingStation.CIVILIZATION_TOTEM,
            category = "Senjata"
        ),
        CraftingRecipe(
            id = "fr3velora_crown_craft",
            name = "Mahkota Kaisar Fr3velora",
            result = ItemStack(ItemRegistry.FR3VELORA_CROWN, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.GOLD_INGOT, 8),
                CraftingIngredient(ItemRegistry.DIAMOND, 3),
                CraftingIngredient(ItemRegistry.RUBY, 2)
            ),
            requiredStation = CraftingStation.CIVILIZATION_TOTEM,
            category = "Zirah"
        ),
        CraftingRecipe(
            id = "god_blade_craft",
            name = "Fr3velora God Blade",
            result = ItemStack(ItemRegistry.FR3VELORA_RELIC_BLADE, 1),
            ingredients = listOf(
                CraftingIngredient(ItemRegistry.DIAMOND_SWORD, 1),
                CraftingIngredient(ItemRegistry.ANCIENT_ESSENCE, 1),
                CraftingIngredient(ItemRegistry.RUBY, 3),
                CraftingIngredient(ItemRegistry.GOLD_INGOT, 5)
            ),
            requiredStation = CraftingStation.CIVILIZATION_TOTEM,
            category = "Senjata"
        )
    )
}
