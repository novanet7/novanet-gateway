package com.example.game.renderer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.R
import com.example.game.world.TileType
import com.example.game.world.TileRegistry
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.random.Random

/**
 * Super asset system – photo/sprite based, animated, high variety.
 *
 * - Real photo assets (hero, dragon) from drawable.
 * - Every tile type has 5 visual variants so rocks / grass / trees never look identical.
 * - Animated frames for water, lava, fire, player, mobs.
 * - Drop real PNGs (tile_grass.png, tile_grass_1.png, mob_boar_0.png …) to override.
 */
object SpriteAssets {

    private val cache = ConcurrentHashMap<String, ImageBitmap>()
    private val animCache = ConcurrentHashMap<String, List<ImageBitmap>>()
    private var initialized = false
    private var appContext: Context? = null

    var heroSprite: ImageBitmap? = null
        private set
    var bossDragonSprite: ImageBitmap? = null
        private set
    var woodPanel: ImageBitmap? = null
        private set
    var uiBanner: ImageBitmap? = null
        private set

    private var playerWalkFrames: List<ImageBitmap> = emptyList()
    private var playerIdleFrame: ImageBitmap? = null

    fun init(context: Context) {
        if (initialized) return
        appContext = context.applicationContext

        heroSprite = loadDrawable(R.drawable.img_hero_pixel_sprite_1790892460516)
        bossDragonSprite = loadDrawable(R.drawable.img_boss_dragon_1790890864007)
        woodPanel = loadDrawable(R.drawable.img_wood_panel_1790890850211)
        uiBanner = loadDrawable(R.drawable.img_ui_banner_1790890808577)

        buildPlayerAnimations()
        pregenerateWorldAssets()
        initialized = true
    }

    // ------------------------------------------------------------------
    // Public API
    // ------------------------------------------------------------------

    fun getTileSprite(tile: TileType, worldX: Int = 0, worldY: Int = 0): ImageBitmap {
        val variant = variantIndex(tile.id, worldX, worldY)
        val key = "tile_${tile.id}_v$variant"
        cache[key]?.let { return it }

        getSprite("tile_${tile.id}_$variant")?.let {
            cache[key] = it
            return it
        }
        getSprite("tile_${tile.id}")?.let {
            cache[key] = it
            return it
        }

        val generated = generateRichTile(tile, variant, worldX, worldY)
        cache[key] = generated
        return generated
    }

    fun getAnimatedTile(tile: TileType, animTime: Float, worldX: Int = 0, worldY: Int = 0): ImageBitmap {
        val frames = getOrCreateAnimFrames(tile)
        if (frames.isEmpty()) return getTileSprite(tile, worldX, worldY)
        val speed = when {
            tile.isWater -> 3.5f
            tile.id.contains("lava") || tile.id.contains("fire") || tile.id.contains("camp") -> 5f
            else -> 2f
        }
        val idx = ((animTime * speed) + worldX * 0.3f + worldY * 0.2f).toInt().mod(frames.size)
        return frames[idx]
    }

    fun getPlayerFrame(isMoving: Boolean, walkAnimTime: Float): ImageBitmap? {
        if (isMoving && playerWalkFrames.isNotEmpty()) {
            val idx = ((walkAnimTime * 10f).toInt()).mod(playerWalkFrames.size)
            return playerWalkFrames[idx]
        }
        return playerIdleFrame ?: heroSprite
    }

    fun getMobSprite(mobTypeId: String, animTime: Float = 0f): ImageBitmap? {
        val raw = mobTypeId.lowercase()
        if (raw.contains("dragon") || raw.contains("boss")) return bossDragonSprite

        // Map enum-style names to our PNG names
        val key = when {
            raw.contains("rabbit") -> "rabbit"
            raw.contains("boar") -> "boar"
            raw.contains("slime") && raw.contains("red") -> "slime_red"
            raw.contains("slime") -> "slime_green"
            raw.contains("zombie") || raw.contains("shadow") -> "zombie"
            raw.contains("skeleton") -> "skeleton"
            raw.contains("golem") -> "golem"
            else -> raw.replace("mobtype.", "").replace(" ", "_")
        }

        // Prefer multi-frame PNGs
        val framesKey = "mobframes_$key"
        val frames = animCache.getOrPut(framesKey) {
            val loaded = (0..2).mapNotNull { getSprite("mob_${key}_$it") }
            if (loaded.isNotEmpty()) loaded
            else listOfNotNull(getSprite("mob_$key")).ifEmpty {
                listOf(
                    generateMobBody(key, 0),
                    generateMobBody(key, 1),
                    generateMobBody(key, 2)
                )
            }
        }
        if (frames.isEmpty()) return null
        val idx = ((animTime * 4f).toInt()).mod(frames.size)
        return frames[idx]
    }

    fun getFeatureSprite(feature: TileType, worldX: Int, worldY: Int, animTime: Float = 0f): ImageBitmap {
        val variant = variantIndex(feature.id, worldX, worldY)
        // Try dedicated feature_ / tile_ assets first
        getSprite("feature_${feature.id}_$variant")?.let { return it }
        getSprite("feature_${feature.id}")?.let { return it }
        getSprite("tile_${feature.id}_$variant")?.let { return it }
        getSprite("tile_${feature.id}")?.let { return it }

        if (feature.id.startsWith("tree_") || feature.id.contains("bush") || feature.id.contains("cactus")) {
            val frames = getOrCreateFeatureAnim(feature)
            if (frames.isNotEmpty()) {
                val idx = ((animTime * 1.2f) + worldX * 0.1f).toInt().mod(frames.size)
                return frames[idx]
            }
        }
        return getTileSprite(feature, worldX, worldY)
    }

    fun getSprite(name: String): ImageBitmap? {
        cache[name]?.let { return it }
        val ctx = appContext ?: return null
        val resId = ctx.resources.getIdentifier(name, "drawable", ctx.packageName)
        if (resId != 0) {
            loadDrawable(resId)?.let {
                cache[name] = it
                return it
            }
        }
        return null
    }

    fun getPlayerSprite(): ImageBitmap? = playerIdleFrame ?: heroSprite

    // ------------------------------------------------------------------
    // Loading & generation
    // ------------------------------------------------------------------

    private fun loadDrawable(resId: Int): ImageBitmap? {
        return try {
            val ctx = appContext ?: return null
            val opts = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inScaled = false
            }
            val bmp = BitmapFactory.decodeResource(ctx.resources, resId, opts) ?: return null
            val target = if (bmp.width > 192) {
                val scale = 128f / bmp.width
                Bitmap.createScaledBitmap(
                    bmp,
                    (bmp.width * scale).toInt().coerceAtLeast(32),
                    (bmp.height * scale).toInt().coerceAtLeast(32),
                    true
                )
            } else bmp
            target.asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }

    private fun variantIndex(id: String, wx: Int, wy: Int): Int {
        val h = (wx * 73856093) xor (wy * 19349663) xor id.hashCode()
        return abs(h) % 5
    }

    private fun buildPlayerAnimations() {
        // Prefer crisp pixel player frames we just installed
        val idle = getSprite("player_idle") ?: getSprite("player")
        val walks = (0..3).mapNotNull { getSprite("player_walk_$it") }
        if (idle != null) {
            playerIdleFrame = idle
            playerWalkFrames = if (walks.size >= 2) walks else listOf(idle, idle, idle, idle)
            return
        }
        // Fallback to the large hero photo
        val base = heroSprite ?: return
        playerIdleFrame = base
        playerWalkFrames = listOf(base, base, base, base)
    }

    private fun pregenerateWorldAssets() {
        val tiles = listOf(
            TileRegistry.GRASS, TileRegistry.DIRT, TileRegistry.SAND, TileRegistry.WATER,
            TileRegistry.STONE_FLOOR, TileRegistry.WOOD_FLOOR, TileRegistry.SNOW, TileRegistry.LAVA,
            TileRegistry.FARMLAND, TileRegistry.ROCK_BOULDER, TileRegistry.ROCK_MOSSY,
            TileRegistry.ROCK_SLATE, TileRegistry.ROCK_CRYSTAL, TileRegistry.TREE_OAK,
            TileRegistry.TREE_PINE, TileRegistry.COAL_ORE, TileRegistry.IRON_ORE
        )
        for (t in tiles) {
            for (v in 0..4) {
                val key = "tile_${t.id}_v$v"
                if (!cache.containsKey(key)) {
                    cache[key] = generateRichTile(t, v, v * 17, v * 31)
                }
            }
        }
        getOrCreateAnimFrames(TileRegistry.WATER)
        getOrCreateAnimFrames(TileRegistry.LAVA)
    }

    private fun getOrCreateAnimFrames(tile: TileType): List<ImageBitmap> {
        val key = "anim_${tile.id}"
        animCache[key]?.let { return it }

        // Prefer real PNG frames installed in drawable
        val fromAssets = when {
            tile.isWater -> (0..5).mapNotNull { getSprite("tile_water_$it") }
            tile.id.contains("lava") -> (0..4).mapNotNull { getSprite("tile_lava_$it") }
            tile.id.contains("camp") || tile.id.contains("torch") || tile.id.contains("fire") ->
                listOfNotNull(getSprite("tile_campfire"), getSprite("tile_torch"))
            else -> emptyList()
        }
        if (fromAssets.isNotEmpty()) {
            animCache[key] = fromAssets
            return fromAssets
        }

        val frames = when {
            tile.isWater -> (0..5).map { generateWaterFrame(it) }
            tile.id.contains("lava") -> (0..4).map { generateLavaFrame(it) }
            tile.id.contains("camp") || tile.id.contains("torch") || tile.id.contains("fire") ->
                (0..3).map { generateFireFrame(it) }
            else -> emptyList()
        }
        if (frames.isNotEmpty()) animCache[key] = frames
        return frames
    }

    private fun getOrCreateFeatureAnim(feature: TileType): List<ImageBitmap> {
        val key = "featanim_${feature.id}"
        animCache[key]?.let { return it }
        val base = generateRichTile(feature, 0, 0, 0)
        val frames = listOf(base, base, base)
        animCache[key] = frames
        return frames
    }

    // ------------------------------------------------------------------
    // Rich generators – distinct look per type + variant
    // ------------------------------------------------------------------

    private fun generateRichTile(tile: TileType, variant: Int, wx: Int, wy: Int): ImageBitmap {
        val size = 48
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint().apply { isAntiAlias = false; style = Paint.Style.FILL }
        val rnd = Random((tile.id.hashCode() * 31 + variant * 97 + wx * 13 + wy * 7).toLong())

        val primary = (tile.primaryColor and 0xFFFFFFFFL).toInt()
        val secondary = (tile.secondaryColor and 0xFFFFFFFFL).toInt()
        val accent = (tile.accentColor and 0xFFFFFFFFL).toInt()

        when {
            tile.isWater -> drawWaterBase(c, p, size, variant)
            tile.id.contains("lava") -> drawLavaBase(c, p, size, variant)
            tile.id.startsWith("tree_") -> drawTree(c, p, size, tile, variant, rnd)
            tile.id.startsWith("rock_") || tile.id.contains("ore") -> drawRock(c, p, size, tile, variant, rnd)
            tile.id.contains("grass") -> drawGrass(c, p, size, variant, rnd, primary, secondary, accent)
            tile.id.contains("dirt") || tile.id.contains("farm") -> drawDirt(c, p, size, variant, rnd, primary, secondary)
            tile.id.contains("sand") -> drawSand(c, p, size, variant, rnd, primary, secondary)
            tile.id.contains("snow") -> drawSnow(c, p, size, variant, rnd)
            tile.id.contains("wood") -> drawWood(c, p, size, variant, primary, secondary, accent)
            tile.id.contains("stone") -> drawStoneFloor(c, p, size, variant, rnd, primary, secondary)
            tile.id.contains("bush") || tile.id.contains("cactus") || tile.id.contains("crop") ->
                drawPlant(c, p, size, tile, variant, rnd)
            tile.id.contains("torch") || tile.id.contains("camp") -> drawTorch(c, p, size, variant)
            tile.id.contains("chest") || tile.id.contains("furnace") || tile.id.contains("workbench") ||
                tile.id.contains("bed") || tile.id.contains("wall") || tile.id.contains("totem") ||
                tile.id.contains("tower") || tile.id.contains("quarry") ->
                drawStructure(c, p, size, tile, variant, primary, secondary, accent)
            else -> {
                p.color = primary
                c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), p)
                noiseOverlay(c, p, size, secondary, rnd, 12)
            }
        }
        return bmp.asImageBitmap()
    }

    private fun drawWaterBase(c: Canvas, p: Paint, size: Int, frame: Int) {
        p.color = 0xFF0D47A1.toInt()
        c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), p)
        p.color = 0xFF1565C0.toInt()
        c.drawRect(0f, 0f, size.toFloat(), size * 0.65f, p)
        p.color = 0xFF0288D1.toInt()
        c.drawRect(0f, 0f, size.toFloat(), size * 0.35f, p)
        p.color = 0x4481D4FA
        val shift = frame * 3
        for (i in 0..3) {
            val y = ((i * 11 + shift) % (size - 8)).toFloat()
            c.drawOval((-4 + i * 5).toFloat(), y, (size / 2f + i * 4), y + 10f, p)
        }
        p.color = 0x66FFFFFF
        c.drawCircle((size * 0.3f + frame * 2) % size, size * 0.4f, 2.5f, p)
        c.drawCircle((size * 0.7f - frame) % size, size * 0.6f, 2f, p)
    }

    private fun generateWaterFrame(frame: Int): ImageBitmap {
        val size = 48
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint().apply { isAntiAlias = false; style = Paint.Style.FILL }
        drawWaterBase(c, p, size, frame)
        return bmp.asImageBitmap()
    }

    private fun drawLavaBase(c: Canvas, p: Paint, size: Int, frame: Int) {
        p.color = 0xFFBF360C.toInt()
        c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), p)
        p.color = 0xFFE64A19.toInt()
        c.drawRect(2f, 2f, size - 2f, size - 2f, p)
        val rnd = Random(frame * 99L)
        for (i in 0..6) {
            p.color = if (i % 2 == 0) 0xFFFFAB00.toInt() else 0xFFFF5722.toInt()
            val cx = rnd.nextInt(size - 8) + 4f
            val cy = rnd.nextInt(size - 8) + 4f
            c.drawCircle(cx, cy, (3 + rnd.nextInt(4)).toFloat(), p)
        }
        p.color = 0xAAFFEB3B.toInt()
        c.drawCircle(size * 0.4f + frame, size * 0.5f, 4f, p)
    }

    private fun generateLavaFrame(frame: Int): ImageBitmap {
        val size = 48
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint().apply { isAntiAlias = false; style = Paint.Style.FILL }
        drawLavaBase(c, p, size, frame)
        return bmp.asImageBitmap()
    }

    private fun generateFireFrame(frame: Int): ImageBitmap {
        val size = 48
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint().apply { isAntiAlias = false; style = Paint.Style.FILL }
        p.color = 0xFF5D4037.toInt()
        c.drawRect(size * 0.3f, size * 0.7f, size * 0.7f, size * 0.95f, p)
        val h = 18 + frame * 3
        p.color = 0xFFFF5722.toInt()
        c.drawOval(size * 0.25f, size * 0.7f - h, size * 0.75f, size * 0.8f, p)
        p.color = 0xFFFFEB3B.toInt()
        c.drawOval(size * 0.35f, size * 0.55f - frame * 2, size * 0.65f, size * 0.75f, p)
        p.color = 0xFFFFFFFF.toInt()
        c.drawCircle(size * 0.5f, size * 0.5f - frame, 3f, p)
        return bmp.asImageBitmap()
    }

    private fun drawGrass(c: Canvas, p: Paint, size: Int, v: Int, rnd: Random, primary: Int, secondary: Int, accent: Int) {
        p.color = primary
        c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), p)
        p.color = secondary
        for (i in 0..8 + v) {
            val x = rnd.nextInt(size - 6).toFloat()
            val y = rnd.nextInt(size - 6).toFloat()
            c.drawRect(x, y, x + 5 + rnd.nextInt(4), y + 4 + rnd.nextInt(3), p)
        }
        p.color = accent
        for (i in 0..12) {
            val x = rnd.nextInt(size - 2).toFloat()
            val y = rnd.nextInt(size / 2, size - 2).toFloat()
            c.drawRect(x, y - 4 - rnd.nextInt(5), x + 1.5f, y, p)
        }
        if (v == 2 || v == 4) {
            p.color = if (v == 2) 0xFFFFEB3B.toInt() else 0xFFE91E63.toInt()
            c.drawCircle(size * 0.3f + v * 3, size * 0.4f, 2.5f, p)
        }
    }

    private fun drawDirt(c: Canvas, p: Paint, size: Int, v: Int, rnd: Random, primary: Int, secondary: Int) {
        p.color = primary
        c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), p)
        noiseOverlay(c, p, size, secondary, rnd, 18 + v * 2)
        p.color = 0xFF6D4C41.toInt()
        for (i in 0..4 + v) {
            c.drawCircle(rnd.nextInt(size).toFloat(), rnd.nextInt(size).toFloat(), 1.5f + rnd.nextInt(2), p)
        }
    }

    private fun drawSand(c: Canvas, p: Paint, size: Int, v: Int, rnd: Random, primary: Int, secondary: Int) {
        p.color = primary
        c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), p)
        p.color = secondary
        for (i in 0..15) {
            val x = rnd.nextInt(size).toFloat()
            val y = rnd.nextInt(size).toFloat()
            c.drawRect(x, y, x + 2, y + 1, p)
        }
        p.color = 0x33FFFFFF
        for (i in 0..3) {
            val y = (size / 4 * i + v * 2) % size
            c.drawRect(0f, y.toFloat(), size.toFloat(), y + 2f, p)
        }
    }

    private fun drawSnow(c: Canvas, p: Paint, size: Int, v: Int, rnd: Random) {
        p.color = 0xFFECEFF1.toInt()
        c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), p)
        p.color = 0xFFCFD8DC.toInt()
        noiseOverlay(c, p, size, 0xFFB0BEC5.toInt(), rnd, 10 + v)
        p.color = 0xAAFFFFFF.toInt()
        for (i in 0..5) {
            c.drawCircle(rnd.nextInt(size).toFloat(), rnd.nextInt(size).toFloat(), 1.2f, p)
        }
    }

    private fun drawWood(c: Canvas, p: Paint, size: Int, v: Int, primary: Int, secondary: Int, accent: Int) {
        p.color = primary
        c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), p)
        val plankH = size / 4
        for (row in 0..3) {
            p.color = if (row % 2 == 0) secondary else accent
            val y = row * plankH
            c.drawRect(0f, y.toFloat(), size.toFloat(), (y + plankH - 1).toFloat(), p)
            p.color = 0x44000000
            c.drawRect(0f, (y + plankH - 1).toFloat(), size.toFloat(), (y + plankH).toFloat(), p)
        }
        p.color = 0xFF9E9E9E.toInt()
        c.drawCircle(size * 0.25f + v, size * 0.5f, 1.5f, p)
        c.drawCircle(size * 0.75f - v, size * 0.5f, 1.5f, p)
    }

    private fun drawStoneFloor(c: Canvas, p: Paint, size: Int, v: Int, rnd: Random, primary: Int, secondary: Int) {
        p.color = primary
        c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), p)
        p.color = secondary
        val bw = size / 2
        val bh = size / 2
        for (row in 0..1) {
            for (col in 0..1) {
                val ox = if (row % 2 == 1) bw / 2 else 0
                val x = (col * bw + ox + v * 2) % size
                c.drawRect(x.toFloat(), (row * bh).toFloat(), (x + bw - 2).toFloat(), (row * bh + bh - 2).toFloat(), p)
            }
        }
        noiseOverlay(c, p, size, 0xFF616161.toInt(), rnd, 6)
    }

    private fun drawRock(c: Canvas, p: Paint, size: Int, tile: TileType, v: Int, rnd: Random) {
        val primary = (tile.primaryColor and 0xFFFFFFFFL).toInt()
        val secondary = (tile.secondaryColor and 0xFFFFFFFFL).toInt()
        val accent = (tile.accentColor and 0xFFFFFFFFL).toInt()

        p.color = primary
        val points = when {
            tile.id.contains("boulder") -> listOf(8 + v to 30, 14 to 12 + v, 28 to 8, 40 - v to 18, 42 to 36, 30 to 44, 12 to 42)
            tile.id.contains("mossy") -> listOf(6 to 28, 12 to 14, 26 to 10, 38 to 16, 44 to 32, 36 to 44, 10 to 40)
            tile.id.contains("slate") -> listOf(10 to 36, 10 to 14, 24 to 8, 40 to 12, 42 to 38, 28 to 46, 12 to 42)
            tile.id.contains("crystal") -> listOf(20 to 44, 8 to 24, 16 to 8, 28 to 4, 40 to 14, 42 to 32, 32 to 44)
            else -> listOf(10 to 30, 14 to 12, 30 to 8, 40 to 20, 38 to 40, 20 to 44)
        }
        for ((px, py) in points) {
            c.drawCircle(px.toFloat(), py.toFloat(), 8f + rnd.nextInt(4), p)
        }
        p.color = secondary
        c.drawCircle(size * 0.45f, size * 0.4f, 10f, p)

        when {
            tile.id.contains("mossy") -> {
                p.color = 0xFF558B2F.toInt()
                for (i in 0..6) c.drawCircle(rnd.nextInt(12, 36).toFloat(), rnd.nextInt(12, 36).toFloat(), 3f, p)
            }
            tile.id.contains("crystal") || tile.id.contains("ore") -> {
                p.color = accent
                for (i in 0..5) {
                    val x = rnd.nextInt(10, 38).toFloat()
                    val y = rnd.nextInt(10, 38).toFloat()
                    c.drawRect(x, y, x + 3, y + 6 + rnd.nextInt(4), p)
                }
                if (tile.id.contains("diamond") || tile.id.contains("crystal")) {
                    p.color = 0xAAFFFFFF.toInt()
                    c.drawCircle(size * 0.4f, size * 0.3f, 3f, p)
                }
                if (tile.id.contains("gold")) {
                    p.color = 0xFFFFD700.toInt()
                    c.drawCircle(size * 0.55f, size * 0.45f, 4f, p)
                }
                if (tile.id.contains("ruby")) {
                    p.color = 0xFFE53935.toInt()
                    c.drawCircle(size * 0.5f, size * 0.4f, 3.5f, p)
                }
                if (tile.id.contains("coal")) {
                    p.color = 0xFF212121.toInt()
                    c.drawCircle(size * 0.4f, size * 0.5f, 5f, p)
                }
            }
            else -> {
                p.color = accent
                c.drawCircle(size * 0.35f, size * 0.3f, 4f, p)
            }
        }
    }

    private fun drawTree(c: Canvas, p: Paint, size: Int, tile: TileType, v: Int, rnd: Random) {
        val trunk = (tile.accentColor and 0xFFFFFFFFL).toInt()
        val leaf = (tile.primaryColor and 0xFFFFFFFFL).toInt()
        val leafDark = (tile.secondaryColor and 0xFFFFFFFFL).toInt()

        p.color = trunk
        val trunkW = 6 + v % 3
        c.drawRect((size / 2 - trunkW / 2).toFloat(), size * 0.55f, (size / 2 + trunkW / 2).toFloat(), size * 0.95f, p)

        p.color = leaf
        when {
            tile.id.contains("pine") -> {
                for (layer in 0..2) {
                    val top = size * (0.1f + layer * 0.18f)
                    val bot = size * (0.4f + layer * 0.18f)
                    val half = 10f + layer * 4 + v
                    c.drawRect(size / 2 - half, top, size / 2 + half, bot, p)
                }
            }
            tile.id.contains("willow") -> {
                c.drawCircle(size * 0.5f, size * 0.35f, 16f + v, p)
                p.color = leafDark
                for (i in 0..5) c.drawRect(size * 0.2f + i * 5, size * 0.45f, size * 0.25f + i * 5, size * 0.75f, p)
            }
            tile.id.contains("cherry") -> {
                c.drawCircle(size * 0.5f, size * 0.32f, 15f, p)
                p.color = 0xFFF48FB1.toInt()
                for (i in 0..7) c.drawCircle(rnd.nextInt(12, 36).toFloat(), rnd.nextInt(12, 32).toFloat(), 2.5f, p)
            }
            tile.id.contains("autumn") -> {
                p.color = 0xFFE65100.toInt()
                c.drawCircle(size * 0.4f, size * 0.3f, 12f, p)
                p.color = 0xFFFF8F00.toInt()
                c.drawCircle(size * 0.6f, size * 0.28f, 11f, p)
                p.color = 0xFFFFCA28.toInt()
                c.drawCircle(size * 0.5f, size * 0.4f, 10f, p)
            }
            tile.id.contains("birch") -> {
                c.drawCircle(size * 0.5f, size * 0.3f, 14f, p)
                p.color = 0xFFFAFAFA.toInt()
                c.drawRect(size * 0.45f, size * 0.55f, size * 0.55f, size * 0.95f, p)
                p.color = 0xFF212121.toInt()
                for (i in 0..3) c.drawRect(size * 0.45f, size * (0.6f + i * 0.08f), size * 0.55f, size * (0.62f + i * 0.08f), p)
            }
            else -> {
                c.drawCircle(size * 0.5f, size * 0.32f, 16f + v % 3, p)
                p.color = leafDark
                c.drawCircle(size * 0.38f, size * 0.28f, 9f, p)
                c.drawCircle(size * 0.62f, size * 0.3f, 8f, p)
            }
        }
    }

    private fun drawPlant(c: Canvas, p: Paint, size: Int, tile: TileType, v: Int, rnd: Random) {
        val primary = (tile.primaryColor and 0xFFFFFFFFL).toInt()
        val secondary = (tile.secondaryColor and 0xFFFFFFFFL).toInt()
        if (tile.id.contains("cactus")) {
            p.color = 0xFF2E7D32.toInt()
            c.drawRect(size * 0.4f, size * 0.25f, size * 0.6f, size * 0.9f, p)
            c.drawRect(size * 0.2f, size * 0.4f, size * 0.4f, size * 0.55f, p)
            c.drawRect(size * 0.6f, size * 0.35f, size * 0.8f, size * 0.5f, p)
            p.color = 0xFFFFEB3B.toInt()
            c.drawCircle(size * 0.5f, size * 0.2f, 3f, p)
        } else if (tile.id.contains("crop")) {
            p.color = 0xFF8D6E63.toInt()
            c.drawRect(size * 0.45f, size * 0.5f, size * 0.55f, size * 0.9f, p)
            p.color = primary
            for (i in 0..4) c.drawRect(size * 0.3f + i * 4, size * 0.25f, size * 0.35f + i * 4, size * 0.55f, p)
            p.color = 0xFFFFD700.toInt()
            c.drawCircle(size * 0.5f, size * 0.2f, 5f, p)
        } else {
            p.color = secondary
            c.drawCircle(size * 0.5f, size * 0.55f, 14f, p)
            p.color = primary
            c.drawCircle(size * 0.4f, size * 0.45f, 8f, p)
            c.drawCircle(size * 0.6f, size * 0.48f, 7f, p)
            p.color = 0xFFE53935.toInt()
            for (i in 0..5) c.drawCircle(rnd.nextInt(16, 32).toFloat(), rnd.nextInt(20, 36).toFloat(), 2.2f, p)
        }
    }

    private fun drawTorch(c: Canvas, p: Paint, size: Int, v: Int) {
        p.color = 0xFF5D4037.toInt()
        c.drawRect(size * 0.42f, size * 0.45f, size * 0.58f, size * 0.95f, p)
        p.color = 0xFFFF5722.toInt()
        c.drawCircle(size * 0.5f, size * 0.35f, 7f + v % 2, p)
        p.color = 0xFFFFEB3B.toInt()
        c.drawCircle(size * 0.5f, size * 0.3f, 4f, p)
    }

    private fun drawStructure(c: Canvas, p: Paint, size: Int, tile: TileType, v: Int, primary: Int, secondary: Int, accent: Int) {
        p.color = primary
        c.drawRect(4f, 8f, size - 4f, size - 4f, p)
        p.color = secondary
        c.drawRect(8f, 12f, size - 8f, size - 8f, p)
        p.color = accent
        c.drawRect(size * 0.35f, size * 0.55f, size * 0.65f, size - 4f, p)
        p.color = 0xFF4E342E.toInt()
        c.drawRect(2f, 4f, size - 2f, 14f, p)
        if (tile.id.contains("chest")) {
            p.color = 0xFFFFD700.toInt()
            c.drawRect(size * 0.3f, size * 0.4f, size * 0.7f, size * 0.55f, p)
        }
        if (tile.id.contains("furnace")) {
            p.color = 0xFFFF5722.toInt()
            c.drawCircle(size * 0.5f, size * 0.5f, 6f, p)
        }
    }

    private fun generateMobBody(typeKey: String, frame: Int): ImageBitmap {
        val size = 48
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint().apply { isAntiAlias = false; style = Paint.Style.FILL }
        val bob = frame * 2

        when {
            typeKey.contains("rabbit") -> {
                p.color = 0xFFECEFF1.toInt()
                c.drawOval(12f, 18f + bob, 36f, 40f + bob, p)
                c.drawOval(16f, 8f + bob, 32f, 24f + bob, p)
                p.color = 0xFFFFCDD2.toInt()
                c.drawOval(14f, 4f + bob, 20f, 18f + bob, p)
                c.drawOval(28f, 4f + bob, 34f, 18f + bob, p)
                p.color = 0xFF212121.toInt()
                c.drawCircle(20f, 14f + bob, 2f, p)
                c.drawCircle(28f, 14f + bob, 2f, p)
            }
            typeKey.contains("boar") -> {
                p.color = 0xFF6D4C41.toInt()
                c.drawOval(4f, 16f + bob, 44f, 40f + bob, p)
                p.color = 0xFF4E342E.toInt()
                c.drawOval(32f, 14f + bob, 46f, 28f + bob, p)
                p.color = 0xFFFAFAFA.toInt()
                c.drawRect(40f, 20f + bob, 46f, 24f + bob, p)
            }
            typeKey.contains("slime") -> {
                val col = if (typeKey.contains("red")) 0xFFFF5722.toInt() else 0xFF4CAF50.toInt()
                p.color = col
                c.drawOval(8f, 16f + bob, 40f, 44f + bob, p)
                p.color = 0xAAFFFFFF.toInt()
                c.drawCircle(18f, 26f + bob, 4f, p)
                c.drawCircle(30f, 26f + bob, 4f, p)
                p.color = 0xFF212121.toInt()
                c.drawCircle(18f, 26f + bob, 2f, p)
                c.drawCircle(30f, 26f + bob, 2f, p)
            }
            typeKey.contains("zombie") || typeKey.contains("skeleton") -> {
                p.color = if (typeKey.contains("skeleton")) 0xFFE0E0E0.toInt() else 0xFF37474F.toInt()
                c.drawRect(16f, 12f + bob, 32f, 40f + bob, p)
                c.drawRect(14f, 4f + bob, 34f, 16f + bob, p)
                p.color = 0xFF212121.toInt()
                c.drawCircle(20f, 10f + bob, 2f, p)
                c.drawCircle(28f, 10f + bob, 2f, p)
            }
            typeKey.contains("golem") -> {
                p.color = 0xFF616161.toInt()
                c.drawRect(6f, 10f + bob, 42f, 44f + bob, p)
                p.color = 0xFF37474F.toInt()
                c.drawRect(12f, 4f + bob, 36f, 16f + bob, p)
                p.color = 0xFF00E5FF.toInt()
                c.drawRect(16f, 8f + bob, 32f, 12f + bob, p)
            }
            else -> {
                p.color = 0xFF9C27B0.toInt()
                c.drawRect(10f, 10f + bob, 38f, 40f + bob, p)
            }
        }
        return bmp.asImageBitmap()
    }

    private fun noiseOverlay(c: Canvas, p: Paint, size: Int, color: Int, rnd: Random, count: Int) {
        p.color = color
        for (i in 0 until count) {
            val x = rnd.nextInt(size).toFloat()
            val y = rnd.nextInt(size).toFloat()
            c.drawRect(x, y, x + 1 + rnd.nextInt(3), y + 1 + rnd.nextInt(2), p)
        }
    }

    fun clearCache() {
        cache.clear()
        animCache.clear()
        initialized = false
    }
}
