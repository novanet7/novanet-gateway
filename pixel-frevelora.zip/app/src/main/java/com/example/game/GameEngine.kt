package com.example.game

import android.content.Context
import com.example.game.audio.SoundManager
import com.example.game.civilization.Civilization
import com.example.game.entity.*
import com.example.game.items.Item
import com.example.game.items.ItemCategory
import com.example.game.items.ItemRegistry
import com.example.game.items.ItemStack
import com.example.game.world.TileCategory
import com.example.game.world.TileRegistry
import com.example.game.world.TileType
import com.example.game.world.WorldGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.*

class GameEngine(
    val context: Context,
    val soundManager: SoundManager = SoundManager(context)
) {
    val worldGen = WorldGenerator()
    val player = Player()
    val civilization = Civilization()

    // Modified tiles (broken blocks or player placed blocks) stored as (chunkX, chunkY, tileX, tileY)
    // Key: (worldX.toLong() shl 32) or (worldY.toLong() and 0xFFFFFFFFL)
    val modifiedBaseTiles = mutableMapOf<Long, TileType>()
    val modifiedFeatureTiles = mutableMapOf<Long, TileType?>()
    val blockDamageMap = mutableMapOf<Long, Int>()

    // Entities
    val mobs = mutableListOf<Mob>()
    val projectiles = mutableListOf<Projectile>()
    val droppedItems = mutableListOf<DroppedItem>()
    val floatingEffects = mutableListOf<FloatingEffect>()

    // Day / Night Cycle (0.0 to 1.0; 0.25 = sunrise, 0.5 = noon, 0.75 = sunset, 0.0 & 1.0 = midnight)
    var dayCycleTime: Float = 0.35f
    var dayNumber: Int = 1
    val dayDurationSeconds: Float = 180f // 3 minutes per in-game day

    // Spawn / Mob timers
    private var mobSpawnTimer: Float = 0f
    private var bossSpawned: Boolean = false

    // State flows for UI reactivity
    private var uiTimer: Float = 0f
    private val _uiTick = MutableStateFlow(0L)
    val uiTick = _uiTick.asStateFlow()

    // Quests / Achievements
    val completedQuests = mutableSetOf<String>()

    init {
        // Initial peaceful boars and bunnies near spawn
        spawnInitialFauna()
    }

    // High-performance World Chunk Cache to eliminate per-frame noise re-calculation
    class WorldChunk(val cx: Int, val cy: Int) {
        val baseTiles = Array(16) { arrayOfNulls<TileType>(16) }
        val featureTiles = Array(16) { arrayOfNulls<TileType>(16) }
    }

    private val chunkCache = mutableMapOf<Long, WorldChunk>()

    private fun getChunk(cx: Int, cy: Int): WorldChunk {
        val chunkKey = (cx.toLong() shl 32) or (cy.toLong() and 0xFFFFFFFFL)
        return chunkCache.getOrPut(chunkKey) {
            val chunk = WorldChunk(cx, cy)
            val startX = cx * 16
            val startY = cy * 16
            for (dx in 0 until 16) {
                for (dy in 0 until 16) {
                    val (base, feature) = worldGen.generateTileAt(startX + dx, startY + dy)
                    chunk.baseTiles[dx][dy] = base
                    chunk.featureTiles[dx][dy] = feature
                }
            }
            chunk
        }
    }

    private fun posKey(x: Int, y: Int): Long {
        return (x.toLong() shl 32) or (y.toLong() and 0xFFFFFFFFL)
    }

    fun getBaseTile(x: Int, y: Int): TileType {
        val key = posKey(x, y)
        val modified = modifiedBaseTiles[key]
        if (modified != null) return modified
        val cx = Math.floorDiv(x, 16)
        val cy = Math.floorDiv(y, 16)
        val dx = Math.floorMod(x, 16)
        val dy = Math.floorMod(y, 16)
        return getChunk(cx, cy).baseTiles[dx][dy] ?: TileRegistry.GRASS
    }

    fun getFeatureTile(x: Int, y: Int): TileType? {
        val key = posKey(x, y)
        if (modifiedFeatureTiles.containsKey(key)) {
            return modifiedFeatureTiles[key]
        }
        val cx = Math.floorDiv(x, 16)
        val cy = Math.floorDiv(y, 16)
        val dx = Math.floorMod(x, 16)
        val dy = Math.floorMod(y, 16)
        return getChunk(cx, cy).featureTiles[dx][dy]
    }

    fun setFeatureTile(x: Int, y: Int, tile: TileType?) {
        val key = posKey(x, y)
        modifiedFeatureTiles[key] = tile
        blockDamageMap.remove(key)
    }

    fun setBaseTile(x: Int, y: Int, tile: TileType) {
        val key = posKey(x, y)
        modifiedBaseTiles[key] = tile
    }

    fun isTileSolid(x: Int, y: Int): Boolean {
        val feature = getFeatureTile(x, y)
        if (feature != null && feature.isSolid) return true
        val base = getBaseTile(x, y)
        return base.isSolid
    }

    private fun spawnInitialFauna() {
        mobs.add(Mob(type = MobType.RABBIT, x = 3f, y = 2f))
        mobs.add(Mob(type = MobType.BOAR, x = -4f, y = 3f))
        mobs.add(Mob(type = MobType.RABBIT, x = -2f, y = -5f))
        mobs.add(Mob(type = MobType.BOAR, x = 6f, y = -3f))
    }

    fun update(deltaSeconds: Float) {
        // 1. Advance Day/Night Cycle
        dayCycleTime += deltaSeconds / dayDurationSeconds
        if (dayCycleTime >= 1.0f) {
            dayCycleTime -= 1.0f
            dayNumber++
            addFloatingText(player.x, player.y - 1.5f, "Hari ke-$dayNumber Telah Tiba!", 0xFFFFD700)
            soundManager.playLevelUp()
        }

        // 2. Update Player
        player.update(deltaSeconds)

        // 3. Update Civilization
        civilization.update(deltaSeconds)

        // 4. Update Mobs & Spawns
        updateMobs(deltaSeconds)

        // 5. Update Projectiles
        updateProjectiles(deltaSeconds)

        // 6. Update Dropped Items (Magnetism to player)
        updateDroppedItems(deltaSeconds)

        // 7. Update Floating effects
        val iter = floatingEffects.iterator()
        while (iter.hasNext()) {
            val eff = iter.next()
            eff.y -= 0.6f * deltaSeconds
            eff.lifeRemaining -= deltaSeconds
            if (eff.lifeRemaining <= 0f) iter.remove()
        }

        // Check quests
        checkQuests()

        uiTimer += deltaSeconds
        if (uiTimer >= 0.08f) { // ~12 FPS for UI HUD updates
            uiTimer = 0f
            _uiTick.value++
        }
    }

    private fun updateMobs(deltaSeconds: Float) {
        mobSpawnTimer += deltaSeconds
        val isNight = dayCycleTime < 0.22f || dayCycleTime > 0.78f

        // Spawn monsters at night or in distant wild
        if (mobSpawnTimer >= 5.0f && mobs.size < 18) {
            mobSpawnTimer = 0f
            val angle = Math.random() * PI * 2
            val dist = 12.0 + Math.random() * 8.0
            val spawnX = (player.x + cos(angle) * dist).toFloat()
            val spawnY = (player.y + sin(angle) * dist).toFloat()

            if (!isTileSolid(spawnX.toInt(), spawnY.toInt())) {
                if (isNight) {
                    val mType = when ((Math.random() * 4).toInt()) {
                        0 -> MobType.SHADOW_ZOMBIE
                        1 -> MobType.SKELETON_ARCHER
                        2 -> MobType.SLIME_RED
                        else -> MobType.SLIME_GREEN
                    }
                    mobs.add(Mob(type = mType, x = spawnX, y = spawnY))
                } else {
                    val mType = if (Math.random() < 0.6) MobType.RABBIT else MobType.BOAR
                    mobs.add(Mob(type = mType, x = spawnX, y = spawnY))
                }
            }
        }

        // Mob AI behaviors
        val mobIter = mobs.iterator()
        while (mobIter.hasNext()) {
            val mob = mobIter.next()
            mob.stateTime += deltaSeconds

            if (mob.isHurt) {
                mob.hurtTimer -= deltaSeconds
                if (mob.hurtTimer <= 0f) mob.isHurt = false
            }

            if (mob.attackCooldown > 0f) {
                mob.attackCooldown -= deltaSeconds
            }

            val dx = player.x - mob.x
            val dy = player.y - mob.y
            val distToPlayer = sqrt(dx * dx + dy * dy)

            if (mob.type.isHostile) {
                // Hostile aggro AI
                if (distToPlayer < 12.0f) {
                    // Face player
                    mob.facing = if (abs(dx) > abs(dy)) {
                        if (dx > 0) Direction.RIGHT else Direction.LEFT
                    } else {
                        if (dy > 0) Direction.DOWN else Direction.UP
                    }

                    // Move towards player
                    if (distToPlayer > 0.9f) {
                        val moveSpeed = mob.type.speed * deltaSeconds
                        val nextX = mob.x + (dx / distToPlayer) * moveSpeed
                        val nextY = mob.y + (dy / distToPlayer) * moveSpeed
                        if (!isTileSolid(nextX.toInt(), nextY.toInt())) {
                            mob.x = nextX
                            mob.y = nextY
                        }
                    }

                    // Attack player if in melee range
                    if (distToPlayer <= 1.2f && mob.attackCooldown <= 0f) {
                        mob.attackCooldown = 1.2f
                        val dmgTaken = player.takeDamage(mob.type.damage)
                        if (dmgTaken > 0) {
                            soundManager.playHurt()
                            addFloatingText(player.x, player.y - 0.5f, "-$dmgTaken", 0xFFFF0055)
                        }
                    }

                    // Skeleton ranged attack
                    if (mob.type == MobType.SKELETON_ARCHER && distToPlayer in 3.0f..9.0f && mob.attackCooldown <= 0f) {
                        mob.attackCooldown = 2.0f
                        val pVx = (dx / distToPlayer) * 7.0f
                        val pVy = (dy / distToPlayer) * 7.0f
                        projectiles.add(
                            Projectile(
                                x = mob.x,
                                y = mob.y,
                                vx = pVx,
                                vy = pVy,
                                damage = mob.type.damage,
                                isFromPlayer = false
                            )
                        )
                        soundManager.playBowShoot()
                    }
                }
            } else {
                // Passive animal wander AI
                mob.moveTimer -= deltaSeconds
                if (mob.moveTimer <= 0f) {
                    mob.moveTimer = 2.0f + (Math.random() * 3.0f).toFloat()
                    mob.moveAngle = (Math.random() * PI * 2).toFloat()
                }
                val speed = mob.type.speed * 0.4f * deltaSeconds
                val nextX = mob.x + cos(mob.moveAngle) * speed
                val nextY = mob.y + sin(mob.moveAngle) * speed
                if (!isTileSolid(nextX.toInt(), nextY.toInt())) {
                    mob.x = nextX
                    mob.y = nextY
                }
            }
        }
    }

    private fun updateProjectiles(deltaSeconds: Float) {
        val projIter = projectiles.iterator()
        while (projIter.hasNext()) {
            val p = projIter.next()
            p.x += p.vx * deltaSeconds
            p.y += p.vy * deltaSeconds
            p.lifeRemaining -= deltaSeconds

            // Check collision with solid tiles
            if (isTileSolid(p.x.toInt(), p.y.toInt())) {
                projIter.remove()
                continue
            }

            if (p.isFromPlayer) {
                // Hit mob
                var hitMob: Mob? = null
                for (m in mobs) {
                    val d = hypot(p.x - m.x, p.y - m.y)
                    if (d < m.type.size) {
                        hitMob = m
                        break
                    }
                }
                if (hitMob != null) {
                    damageMob(hitMob, p.damage)
                    projIter.remove()
                    continue
                }
            } else {
                // Hit player
                val d = hypot(p.x - player.x, p.y - player.y)
                if (d < 0.7f) {
                    val dmg = player.takeDamage(p.damage)
                    if (dmg > 0) {
                        soundManager.playHurt()
                        addFloatingText(player.x, player.y - 0.5f, "-$dmg", 0xFFFF0055)
                    }
                    projIter.remove()
                    continue
                }
            }

            if (p.lifeRemaining <= 0f) {
                projIter.remove()
            }
        }
    }

    private fun updateDroppedItems(deltaSeconds: Float) {
        val dropIter = droppedItems.iterator()
        while (dropIter.hasNext()) {
            val drop = dropIter.next()
            drop.floatAnim += deltaSeconds * 3f

            val dx = player.x - drop.x
            val dy = player.y - drop.y
            val dist = sqrt(dx * dx + dy * dy)

            // Magnet towards player if close
            if (dist < 2.5f) {
                val speed = 6.0f * deltaSeconds
                drop.x += (dx / dist) * speed
                drop.y += (dy / dist) * speed

                if (dist < 0.6f) {
                    if (player.addItem(drop.itemStack)) {
                        soundManager.playPickup()
                        addFloatingText(drop.x, drop.y - 0.5f, "+${drop.itemStack.count} ${drop.itemStack.item.name.substringBefore(" (")}", 0xFF69F0AE)
                        dropIter.remove()
                    }
                }
            }
        }
    }

    // === PLAYER ACTIONS ===

    fun movePlayer(dirX: Float, dirY: Float, deltaSeconds: Float) {
        if (dirX == 0f && dirY == 0f) {
            player.isMoving = false
            return
        }

        player.isMoving = true
        player.walkAnimTime += deltaSeconds

        val speed = if (player.isDashing) 7.5f else 3.8f
        val len = sqrt(dirX * dirX + dirY * dirY)
        val nx = dirX / len
        val ny = dirY / len

        // Update player facing direction
        player.facing = if (abs(nx) > abs(ny)) {
            if (nx > 0) Direction.RIGHT else Direction.LEFT
        } else {
            if (ny > 0) Direction.DOWN else Direction.UP
        }

        val stepX = nx * speed * deltaSeconds
        val stepY = ny * speed * deltaSeconds

        // Smooth sliding collision detection on X and Y separately
        val targetX = player.x + stepX
        if (!isTileSolid(targetX.toInt(), player.y.toInt())) {
            player.x = targetX
        }
        val targetY = player.y + stepY
        if (!isTileSolid(player.x.toInt(), targetY.toInt())) {
            player.y = targetY
        }
    }

    fun triggerDash(): Boolean {
        if (player.stamina < 20f || player.dashCooldown > 0f) return false
        player.stamina -= 20f
        player.isDashing = true
        player.dashTimer = 0.22f
        player.dashCooldown = 0.8f
        soundManager.playAttackSwing()
        return true
    }

    fun performAttackOrMine(): Boolean {
        player.isSwinging = true
        player.swingProgress = 0f

        val equipped = player.getEquippedItem()
        val item = equipped?.item

        // Determine target tile in front of player
        val (frontTileX, frontTileY) = getTileInFront()

        // 1. If ranged bow/crossbow equipped, shoot projectile!
        if (item?.category == ItemCategory.RANGED) {
            val hasArrow = player.getAllItems().any { it?.item?.id == ItemRegistry.ARROW.id }
            if (hasArrow) {
                player.removeIngredients(ItemRegistry.ARROW.id, 1)
                val (vx, vy) = when (player.facing) {
                    Direction.UP -> Pair(0f, -10f)
                    Direction.RIGHT -> Pair(10f, 0f)
                    Direction.DOWN -> Pair(0f, 10f)
                    Direction.LEFT -> Pair(-10f, 0f)
                }
                projectiles.add(
                    Projectile(
                        x = player.x,
                        y = player.y,
                        vx = vx,
                        vy = vy,
                        damage = item.attackDamage,
                        isFromPlayer = true,
                        isFire = item.id == ItemRegistry.DRAGON_CROSSBOW.id
                    )
                )
                soundManager.playBowShoot()
                return true
            } else {
                addFloatingText(player.x, player.y - 1f, "Butuh Anak Panah (Arrow)!", 0xFFFF5252)
                return false
            }
        }

        // 2. Check melee attack against nearby mobs
        var hitAnyMob = false
        val attackRange = item?.attackRange ?: 1.5f
        val damage = item?.attackDamage ?: 4

        for (mob in mobs) {
            val dx = mob.x - player.x
            val dy = mob.y - player.y
            val dist = hypot(dx, dy)
            if (dist <= attackRange) {
                // Verify facing angle
                val inFront = when (player.facing) {
                    Direction.UP -> dy < 0.2f
                    Direction.DOWN -> dy > -0.2f
                    Direction.LEFT -> dx < 0.2f
                    Direction.RIGHT -> dx > -0.2f
                }
                if (inFront) {
                    damageMob(mob, damage)
                    hitAnyMob = true
                }
            }
        }

        if (hitAnyMob) {
            soundManager.playHit()
            return true
        }

        // 3. Melee swing to mine or chop block in front
        val feature = getFeatureTile(frontTileX, frontTileY)
        if (feature != null && feature.hardness > 0) {
            mineBlock(frontTileX, frontTileY, feature, item)
            return true
        }

        soundManager.playAttackSwing()
        return false
    }

    private fun getTileInFront(): Pair<Int, Int> {
        val px = player.x
        val py = player.y
        return when (player.facing) {
            Direction.UP -> Pair(px.toInt(), (py - 1.0f).toInt())
            Direction.DOWN -> Pair(px.toInt(), (py + 1.0f).toInt())
            Direction.LEFT -> Pair((px - 1.0f).toInt(), py.toInt())
            Direction.RIGHT -> Pair((px + 1.0f).toInt(), py.toInt())
        }
    }

    fun mineBlock(x: Int, y: Int, tile: TileType, equippedItem: Item?) {
        val key = posKey(x, y)
        val currentDmg = blockDamageMap.getOrDefault(key, 0)

        // Calculate tool efficiency bonus
        val bonus = when (tile.requiredTool) {
            com.example.game.world.ToolRequirement.PICKAXE -> (equippedItem?.miningPower ?: 0) * 3 + 1
            com.example.game.world.ToolRequirement.AXE -> (equippedItem?.woodchoppingPower ?: 0) * 3 + 1
            else -> 2
        }

        val newDmg = currentDmg + bonus
        blockDamageMap[key] = newDmg

        if (tile.requiredTool == com.example.game.world.ToolRequirement.AXE) {
            soundManager.playChop()
        } else {
            soundManager.playMine()
        }

        if (newDmg >= tile.hardness * 3) {
            // Block broken!
            setFeatureTile(x, y, null)
            tile.dropItem?.let { dropProducer ->
                val drop = dropProducer()
                val count = tile.dropCountMin + (Math.random() * (tile.dropCountMax - tile.dropCountMin + 1)).toInt()
                droppedItems.add(
                    DroppedItem(
                        x = x + 0.5f,
                        y = y + 0.5f,
                        itemStack = ItemStack(drop, count)
                    )
                )
            }
            player.gainXp(5)
        }
    }

    fun damageMob(mob: Mob, damage: Int) {
        mob.hp -= damage
        mob.isHurt = true
        mob.hurtTimer = 0.3f
        addFloatingText(mob.x, mob.y - 0.6f, "-$damage", 0xFFFF1744)

        if (mob.hp <= 0) {
            // Mob defeated!
            onMobDefeated(mob)
            mobs.remove(mob)
        }
    }

    private fun onMobDefeated(mob: Mob) {
        soundManager.playLevelUp()
        val xpGain = if (mob.type.isBoss) 500 else if (mob.type.isHostile) 25 else 10
        val leveled = player.gainXp(xpGain)
        if (leveled) {
            addFloatingText(player.x, player.y - 1.2f, "LEVEL UP! Lv.${player.level}", 0xFFFFEA00)
        }

        // Drops
        when (mob.type) {
            MobType.RABBIT -> {
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.RAW_MEAT, 1)))
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.LEATHER, 1)))
            }
            MobType.BOAR -> {
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.RAW_MEAT, 2)))
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.LEATHER, 2)))
            }
            MobType.SLIME_GREEN -> {
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.SLIME_GEL, 2)))
            }
            MobType.SLIME_RED -> {
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.SLIME_GEL, 3)))
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.COAL, 1)))
            }
            MobType.SHADOW_ZOMBIE -> {
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.IRON_ORE, 1)))
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.COAL, 2)))
            }
            MobType.SKELETON_ARCHER -> {
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.BONE, 2)))
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.ARROW, 4)))
            }
            MobType.CAVE_GOLEM -> {
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.IRON_INGOT, 3)))
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.DIAMOND, 1)))
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.RUBY, 1)))
            }
            MobType.FR3VELORA_DRAGON_BOSS -> {
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.ANCIENT_ESSENCE, 2)))
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.DIAMOND, 5)))
                droppedItems.add(DroppedItem(x = mob.x, y = mob.y, itemStack = ItemStack(ItemRegistry.GOLD_INGOT, 10)))
                addFloatingText(player.x, player.y - 2f, "NAGA PURBA TELAH DIKALAHKAN!", 0xFFFFD700)
            }
        }
    }

    fun interactOrPlace(): Boolean {
        val (tx, ty) = getTileInFront()
        val equipped = player.getEquippedItem()
        val item = equipped?.item

        // 1. Interact with existing structure in front (Civilization Totem, Chest, Bed, Furnace, Workbench)
        val feature = getFeatureTile(tx, ty)
        if (feature != null) {
            when (feature.id) {
                TileRegistry.CIVILIZATION_TOTEM.id -> {
                    soundManager.playVillagerTalk()
                    return true // UI should open Civilization menu
                }
                TileRegistry.BED.id -> {
                    // Sleep to skip night
                    if (dayCycleTime < 0.25f || dayCycleTime > 0.75f) {
                        dayCycleTime = 0.28f // Morning
                        player.hp = player.maxHp
                        soundManager.playLevelUp()
                        addFloatingText(player.x, player.y - 1f, "Selamat Pagi! Darah Pulih Penuh", 0xFFFFD700)
                        return true
                    } else {
                        addFloatingText(player.x, player.y - 1f, "Hanya bisa tidur saat malam!", 0xFFB0BEC5)
                        return true
                    }
                }
                TileRegistry.BERRY_BUSH.id -> {
                    mineBlock(tx, ty, feature, item)
                    return true
                }
            }
        }

        // 2. Consume Food / Potion if in hand
        if (item?.category == ItemCategory.FOOD || item?.category == ItemCategory.POTION) {
            consumeEquippedItem()
            return true
        }

        // 3. Place structure / wall / floor from hotbar
        if (item?.placesTileId != null) {
            val placeTile = TileRegistry.getTile(item.placesTileId)
            if (placeTile.category == TileCategory.FLOOR) {
                setBaseTile(tx, ty, placeTile)
            } else {
                if (getFeatureTile(tx, ty) == null) {
                    setFeatureTile(tx, ty, placeTile)
                    // If placing civilization totem, found civilization!
                    if (placeTile.id == TileRegistry.CIVILIZATION_TOTEM.id) {
                        civilization.foundCivilization(tx, ty)
                        soundManager.playLevelUp()
                        addFloatingText(tx + 0.5f, ty - 0.5f, "PERADABAN FR3VELORA BERDIRI!", 0xFFFFD700)
                    }
                } else {
                    return false
                }
            }

            // Deduct 1 item from hotbar
            equipped.count--
            if (equipped.count <= 0) {
                player.hotbar[player.selectedHotbarIndex] = null
            }
            soundManager.playCraftSuccess()
            return true
        }

        // 4. Hoe farmland
        if (item?.id == ItemRegistry.HOE.id) {
            val base = getBaseTile(tx, ty)
            if (base.id == TileRegistry.GRASS.id || base.id == TileRegistry.DIRT.id) {
                setBaseTile(tx, ty, TileRegistry.FARMLAND)
                soundManager.playMine()
                return true
            }
        }

        return false
    }

    fun consumeEquippedItem() {
        val equipped = player.getEquippedItem() ?: return
        val item = equipped.item
        if (item.category == ItemCategory.FOOD || item.category == ItemCategory.POTION) {
            player.hunger = min(100f, player.hunger + item.hungerRestore)
            player.hp = min(player.maxHp, player.hp + item.hpRestore)
            player.stamina = min(100f, player.stamina + item.staminaRestore)

            equipped.count--
            if (equipped.count <= 0) {
                player.hotbar[player.selectedHotbarIndex] = null
            }
            soundManager.playEat()
            addFloatingText(player.x, player.y - 0.8f, "+${item.hungerRestore} Kenyang +${item.hpRestore} HP", 0xFF69F0AE)
        }
    }

    fun summonWorldBoss() {
        if (bossSpawned) return
        bossSpawned = true
        soundManager.playBossRoar()
        val boss = Mob(
            type = MobType.FR3VELORA_DRAGON_BOSS,
            x = player.x + 4f,
            y = player.y - 4f
        )
        mobs.add(boss)
        addFloatingText(player.x, player.y - 1.5f, "NAGA PURBA FR3VELORA BANGKIT!", 0xFFFF1744)
    }

    fun addFloatingText(x: Float, y: Float, text: String, color: Long) {
        floatingEffects.add(FloatingEffect(x = x, y = y, text = text, color = color))
    }

    private fun checkQuests() {
        val allItems = player.getAllItems().filterNotNull()
        if (!completedQuests.contains("gather_wood") && allItems.any { it.item.id == ItemRegistry.WOOD.id }) {
            completeQuest("gather_wood", "Penebang Rimba: Kumpulkan Kayu Hutan!")
        }
        if (!completedQuests.contains("craft_pickaxe") && allItems.any { it.item.category == ItemCategory.TOOL }) {
            completeQuest("craft_pickaxe", "Perkakas Pertama: Buat Alat Beliung atau Kapak!")
        }
        if (!completedQuests.contains("mine_iron") && allItems.any { it.item.id == ItemRegistry.IRON_ORE.id || it.item.id == ItemRegistry.IRON_INGOT.id }) {
            completeQuest("mine_iron", "Zaman Besi: Tambang dan Lebur Bijih Besi!")
        }
        if (!completedQuests.contains("found_civilization") && civilization.isFounded) {
            completeQuest("found_civilization", "Pendiri Bangsa: Tancapkan Totem Peradaban Fr3velora!")
        }
    }

    private fun completeQuest(questId: String, title: String) {
        completedQuests.add(questId)
        soundManager.playLevelUp()
        addFloatingText(player.x, player.y - 2.0f, "Misi Tercapai: $title", 0xFFFFD700)
        player.gainXp(50)
    }
}
