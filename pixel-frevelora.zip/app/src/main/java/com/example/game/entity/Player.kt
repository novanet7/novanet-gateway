package com.example.game.entity

import com.example.game.items.ItemCategory
import com.example.game.items.ItemRegistry
import com.example.game.items.ItemStack
import kotlin.math.min

class Player(
    var x: Float = 0f,
    var y: Float = 0f,
    var hp: Int = 100,
    var maxHp: Int = 100,
    var hunger: Float = 100f,
    var stamina: Float = 100f,
    var level: Int = 1,
    var xp: Int = 0,
    var facing: Direction = Direction.DOWN
) {
    val hotbar: Array<ItemStack?> = arrayOfNulls(9)
    val inventory: Array<ItemStack?> = arrayOfNulls(27)

    var equippedHelmet: ItemStack? = null
    var equippedChest: ItemStack? = null
    var equippedBoots: ItemStack? = null

    var selectedHotbarIndex: Int = 0

    // Animation & Combat state
    var isMoving: Boolean = false
    var walkAnimTime: Float = 0f
    var isSwinging: Boolean = false
    var swingProgress: Float = 0f // 0f to 1f
    var swingDuration: Float = 0.25f

    var isDashing: Boolean = false
    var dashTimer: Float = 0f
    var dashCooldown: Float = 0f

    var invulnerableTimer: Float = 0f
    var hungerDrainTimer: Float = 0f
    var staminaRegenTimer: Float = 0f

    init {
        // Starter survival pack
        hotbar[0] = ItemStack(ItemRegistry.WOOD_CLUB, 1)
        hotbar[1] = ItemStack(ItemRegistry.WOOD_PICKAXE, 1)
        hotbar[2] = ItemStack(ItemRegistry.WOOD_AXE, 1)
        hotbar[3] = ItemStack(ItemRegistry.APPLE, 5)
        hotbar[4] = ItemStack(ItemRegistry.TORCH, 4)
    }

    val xpForNextLevel: Int
        get() = level * 100

    fun getEquippedItem(): ItemStack? = hotbar[selectedHotbarIndex]

    fun getTotalDefense(): Int {
        var def = 0
        equippedHelmet?.let { def += it.item.defense }
        equippedChest?.let { def += it.item.defense }
        equippedBoots?.let { def += it.item.defense }
        return def
    }

    fun addItem(stack: ItemStack): Boolean {
        // 1. Try stacking into hotbar
        for (i in hotbar.indices) {
            val existing = hotbar[i]
            if (existing != null && existing.item.id == stack.item.id && existing.count < existing.item.maxStack) {
                val space = existing.item.maxStack - existing.count
                val toAdd = min(space, stack.count)
                existing.count += toAdd
                stack.count -= toAdd
                if (stack.count <= 0) return true
            }
        }

        // 2. Try stacking into inventory
        for (i in inventory.indices) {
            val existing = inventory[i]
            if (existing != null && existing.item.id == stack.item.id && existing.count < existing.item.maxStack) {
                val space = existing.item.maxStack - existing.count
                val toAdd = min(space, stack.count)
                existing.count += toAdd
                stack.count -= toAdd
                if (stack.count <= 0) return true
            }
        }

        // 3. Put into first empty hotbar slot
        for (i in hotbar.indices) {
            if (hotbar[i] == null) {
                hotbar[i] = stack.copyStack()
                return true
            }
        }

        // 4. Put into first empty inventory slot
        for (i in inventory.indices) {
            if (inventory[i] == null) {
                inventory[i] = stack.copyStack()
                return true
            }
        }

        return false // Inventory full
    }

    fun removeIngredients(itemId: String, countNeeded: Int) {
        var remaining = countNeeded
        // Check hotbar
        for (i in hotbar.indices) {
            val st = hotbar[i]
            if (st != null && st.item.id == itemId) {
                if (st.count <= remaining) {
                    remaining -= st.count
                    hotbar[i] = null
                } else {
                    st.count -= remaining
                    remaining = 0
                }
                if (remaining <= 0) return
            }
        }
        // Check inventory
        for (i in inventory.indices) {
            val st = inventory[i]
            if (st != null && st.item.id == itemId) {
                if (st.count <= remaining) {
                    remaining -= st.count
                    inventory[i] = null
                } else {
                    st.count -= remaining
                    remaining = 0
                }
                if (remaining <= 0) return
            }
        }
    }

    fun getAllItems(): List<ItemStack?> {
        val list = mutableListOf<ItemStack?>()
        list.addAll(hotbar)
        list.addAll(inventory)
        return list
    }

    fun equipArmor(stack: ItemStack): Boolean {
        when (stack.item.category) {
            ItemCategory.ARMOR_HEAD -> {
                val old = equippedHelmet
                equippedHelmet = stack.copyStack()
                return true
            }
            ItemCategory.ARMOR_CHEST -> {
                val old = equippedChest
                equippedChest = stack.copyStack()
                return true
            }
            ItemCategory.ARMOR_LEGS -> {
                val old = equippedBoots
                equippedBoots = stack.copyStack()
                return true
            }
            else -> return false
        }
    }

    fun gainXp(amount: Int): Boolean {
        xp += amount
        var leveledUp = false
        while (xp >= xpForNextLevel) {
            xp -= xpForNextLevel
            level++
            maxHp += 15
            hp = maxHp
            leveledUp = true
        }
        return leveledUp
    }

    fun takeDamage(rawDamage: Int): Int {
        if (invulnerableTimer > 0f) return 0
        val def = getTotalDefense()
        val finalDmg = kotlin.math.max(1, rawDamage - (def / 2))
        hp = kotlin.math.max(0, hp - finalDmg)
        invulnerableTimer = 0.6f
        return finalDmg
    }

    fun update(deltaSeconds: Float) {
        if (invulnerableTimer > 0f) {
            invulnerableTimer -= deltaSeconds
        }
        if (dashCooldown > 0f) {
            dashCooldown -= deltaSeconds
        }
        if (isDashing) {
            dashTimer -= deltaSeconds
            if (dashTimer <= 0f) isDashing = false
        }

        // Weapon swing
        if (isSwinging) {
            swingProgress += deltaSeconds / swingDuration
            if (swingProgress >= 1f) {
                isSwinging = false
                swingProgress = 0f
            }
        }

        // Hunger drain
        hungerDrainTimer += deltaSeconds
        if (hungerDrainTimer >= 4.0f) {
            hungerDrainTimer = 0f
            if (hunger > 0f) {
                hunger = kotlin.math.max(0f, hunger - 1f)
            } else {
                // Starvation damage
                takeDamage(2)
            }
            // Health regeneration if well-fed
            if (hunger >= 80f && hp < maxHp) {
                hp = min(maxHp, hp + 2)
            }
        }

        // Stamina regen
        staminaRegenTimer += deltaSeconds
        if (staminaRegenTimer >= 0.2f) {
            staminaRegenTimer = 0f
            if (stamina < 100f && !isDashing) {
                stamina = min(100f, stamina + 3f)
            }
        }
    }
}
