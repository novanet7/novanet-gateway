package com.example.game.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.game.items.Item
import com.example.game.items.ItemCategory
import com.example.game.items.ItemRegistry

/**
 * Authentic 16-bit pixel art sprite renderer for all items in Pixel Fr3velora.
 * Replaces plain flat colored squares with detailed, recognizable game icons.
 */
@Composable
fun ItemPixelSprite(
    item: Item,
    modifier: Modifier = Modifier,
    size: Dp = 24.dp
) {
    Box(modifier = modifier.size(size)) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val p = this.size.width / 16f
            drawItemSprite(this, item, p)
        }
    }
}

fun drawItemSprite(drawScope: DrawScope, item: Item, p: Float) {
    with(drawScope) {
        when {
            // === SWORDS & BLADES ===
            item.id.contains("sword") || item.id == ItemRegistry.FR3VELORA_RELIC_BLADE.id -> {
                val bladeCol = Color(item.primaryColor)
                val hiltCol = Color(0xFF5D4037)
                val guardCol = Color(if (item.id.contains("diamond") || item.id.contains("relic")) 0xFFFFD700 else 0xFF78909C)

                // 45 degree diagonal blade
                for (i in 0..7) {
                    drawRect(bladeCol, Offset((5 + i) * p, (10 - i) * p), Size(p * 2, p * 2))
                    drawRect(Color.White, Offset((5 + i) * p, (10 - i) * p), Size(p * 0.8f, p * 0.8f))
                }
                // Tip
                drawRect(bladeCol, Offset(13 * p, 2 * p), Size(p * 2, p * 2))
                drawRect(Color.White, Offset(13.5f * p, 2.5f * p), Size(p, p))

                // Crossguard
                drawRect(guardCol, Offset(3 * p, 11 * p), Size(p * 4, p * 2))
                drawRect(guardCol, Offset(5 * p, 9 * p), Size(p * 2, p * 4))

                // Handle & Pommel
                drawRect(hiltCol, Offset(2 * p, 13 * p), Size(p * 2, p * 2))
                drawRect(guardCol, Offset(1 * p, 14 * p), Size(p * 2, p * 2))

                // Relic glow aura
                if (item.id == ItemRegistry.FR3VELORA_RELIC_BLADE.id) {
                    drawRect(Color(0xFFFF5722), Offset(14 * p, 1 * p), Size(p * 1.5f, p * 1.5f))
                    drawRect(Color(0xFFFFD54F), Offset(10 * p, 4 * p), Size(p, p))
                }
            }

            // === WOOD CLUB ===
            item.id == ItemRegistry.WOOD_CLUB.id -> {
                // Curved thick wooden bat
                val woodDark = Color(0xFF4E342E)
                val woodMid = Color(0xFF6D4C41)
                val woodLight = Color(0xFF8D6E63)
                val metalBands = Color(0xFF90A4AE)

                // Thick head
                drawRect(woodDark, Offset(8 * p, 2 * p), Size(p * 5, p * 6))
                drawRect(woodMid, Offset(9 * p, 3 * p), Size(p * 3, p * 4))
                drawRect(woodLight, Offset(9.5f * p, 3.5f * p), Size(p * 2, p * 2))
                // Studs
                drawRect(metalBands, Offset(10 * p, 4 * p), Size(p, p))
                drawRect(metalBands, Offset(11 * p, 6 * p), Size(p, p))

                // Shaft & Grip
                drawRect(woodDark, Offset(5 * p, 7 * p), Size(p * 4, p * 4))
                drawRect(woodMid, Offset(6 * p, 8 * p), Size(p * 2, p * 3))
                drawRect(woodLight, Offset(3 * p, 11 * p), Size(p * 3, p * 4))
                drawRect(Color(0xFFD7CCC8), Offset(3 * p, 12 * p), Size(p * 3, p * 1.5f)) // Grip tape
            }

            // === PICKAXES ===
            item.id.contains("pickaxe") -> {
                val headCol = Color(item.primaryColor)
                val handleCol = Color(0xFF6D4C41)

                // Diagonal wooden shaft
                for (i in 0..8) {
                    drawRect(handleCol, Offset((3 + i) * p, (13 - i) * p), Size(p * 1.5f, p * 1.5f))
                }

                // Curved Pickaxe Head
                drawRect(headCol, Offset(7 * p, 2 * p), Size(p * 7, p * 2.5f))
                drawRect(headCol, Offset(12 * p, 3 * p), Size(p * 2.5f, p * 4))
                drawRect(headCol, Offset(5 * p, 3 * p), Size(p * 3, p * 3))
                // Sharp pick tips
                drawRect(Color.White, Offset(13 * p, 6 * p), Size(p * 1.5f, p * 1.5f))
                drawRect(Color.White, Offset(4 * p, 5 * p), Size(p * 1.5f, p * 1.5f))
            }

            // === AXES ===
            item.id.contains("axe") -> {
                val headCol = Color(item.primaryColor)
                val handleCol = Color(0xFF6D4C41)

                // Diagonal handle
                for (i in 0..8) {
                    drawRect(handleCol, Offset((3 + i) * p, (13 - i) * p), Size(p * 1.5f, p * 1.5f))
                }

                // Heavy Axe Blade
                drawRect(headCol, Offset(8 * p, 2 * p), Size(p * 5, p * 6))
                drawRect(Color.White, Offset(12 * p, 2 * p), Size(p * 1.5f, p * 6)) // Sharp edge
                drawRect(Color(0xFF37474F), Offset(8 * p, 3 * p), Size(p * 2, p * 4)) // Socket
            }

            // === BOW & CROSSBOW ===
            item.id.contains("bow") -> {
                val bowWood = Color(0xFF795548)
                val bowString = Color(0xFFE0E0E0)

                // Curved bow limbs
                drawRect(bowWood, Offset(4 * p, 2 * p), Size(p * 2.5f, p * 3))
                drawRect(bowWood, Offset(2 * p, 5 * p), Size(p * 2.5f, p * 6))
                drawRect(bowWood, Offset(4 * p, 11 * p), Size(p * 2.5f, p * 3))

                // Bowstring
                drawRect(bowString, Offset(6 * p, 3 * p), Size(p * 0.8f, p * 10))

                // Arrow nocked
                drawRect(Color(0xFFD7CCC8), Offset(4 * p, 7 * p), Size(p * 8, p * 1.2f))
                drawRect(Color(0xFFB0BEC5), Offset(12 * p, 6.5f * p), Size(p * 2, p * 2)) // Arrowhead
                drawRect(Color.White, Offset(3 * p, 6.5f * p), Size(p * 1.5f, p * 2)) // Fletching
            }

            // === ARROW ===
            item.id == ItemRegistry.ARROW.id -> {
                // Diagonal Arrow
                val shaftCol = Color(0xFFD7CCC8)
                for (i in 0..8) {
                    drawRect(shaftCol, Offset((3 + i) * p, (13 - i) * p), Size(p * 1.2f, p * 1.2f))
                }
                // Arrowhead (Stone/Flint)
                drawRect(Color(0xFF424242), Offset(11 * p, 3 * p), Size(p * 3, p * 3))
                drawRect(Color(0xFF9E9E9E), Offset(12 * p, 2 * p), Size(p * 2, p * 2))
                // Fletchings
                drawRect(Color.White, Offset(2 * p, 12 * p), Size(p * 3, p * 1.5f))
                drawRect(Color.White, Offset(3 * p, 13 * p), Size(p * 1.5f, p * 3))
            }

            // === APPLE ===
            item.id == ItemRegistry.APPLE.id -> {
                // Plump Red Apple
                drawRect(Color(0xFFD50000), Offset(4 * p, 4 * p), Size(p * 8, p * 9))
                drawRect(Color(0xFFFF1744), Offset(5 * p, 5 * p), Size(p * 6, p * 7))
                // Specular shine
                drawRect(Color.White, Offset(5 * p, 5 * p), Size(p * 2, p * 2))
                // Stem & Leaf
                drawRect(Color(0xFF5D4037), Offset(7 * p, 2 * p), Size(p * 1.5f, p * 3))
                drawRect(Color(0xFF4CAF50), Offset(8 * p, 2 * p), Size(p * 3, p * 2))
            }

            // === BERRY ===
            item.id == ItemRegistry.BERRY.id -> {
                drawRect(Color(0xFF880E4F), Offset(4 * p, 6 * p), Size(p * 5, p * 5))
                drawRect(Color(0xFFC2185B), Offset(5 * p, 7 * p), Size(p * 3, p * 3))
                drawRect(Color.White, Offset(5 * p, 7 * p), Size(p, p))

                drawRect(Color(0xFF880E4F), Offset(8 * p, 5 * p), Size(p * 5, p * 5))
                drawRect(Color(0xFFE91E63), Offset(9 * p, 6 * p), Size(p * 3, p * 3))
                drawRect(Color.White, Offset(9 * p, 6 * p), Size(p, p))

                drawRect(Color(0xFF4CAF50), Offset(7 * p, 3 * p), Size(p * 3, p * 2))
            }

            // === MEAT & STEAK ===
            item.id == ItemRegistry.RAW_MEAT.id || item.id == ItemRegistry.COOKED_STEAK.id -> {
                val meatCol = if (item.id == ItemRegistry.COOKED_STEAK.id) Color(0xFF5D4037) else Color(0xFFD32F2F)
                val fatCol = if (item.id == ItemRegistry.COOKED_STEAK.id) Color(0xFF8D6E63) else Color(0xFFFFCDD2)

                drawRect(meatCol, Offset(3 * p, 4 * p), Size(p * 10, p * 8))
                drawRect(fatCol, Offset(4 * p, 4 * p), Size(p * 8, p * 2))
                // Bone handle
                drawRect(Color.White, Offset(2 * p, 8 * p), Size(p * 3, p * 3))
                drawRect(Color(0xFFE0E0E0), Offset(1 * p, 9 * p), Size(p * 2, p * 2))
                if (item.id == ItemRegistry.COOKED_STEAK.id) {
                    // Grill marks
                    drawRect(Color(0xFF271B17), Offset(5 * p, 6 * p), Size(p * 6, p * 1.2f))
                    drawRect(Color(0xFF271B17), Offset(6 * p, 9 * p), Size(p * 5, p * 1.2f))
                }
            }

            // === BREAD ===
            item.id == ItemRegistry.BREAD.id -> {
                drawRect(Color(0xFF8D6E63), Offset(2 * p, 5 * p), Size(p * 12, p * 6))
                drawRect(Color(0xFFD7CCC8), Offset(3 * p, 4 * p), Size(p * 10, p * 6))
                drawRect(Color(0xFFFFB74D), Offset(3 * p, 5 * p), Size(p * 10, p * 4))
                // Crust scores
                drawRect(Color(0xFF5D4037), Offset(5 * p, 4 * p), Size(p * 1.5f, p * 4))
                drawRect(Color(0xFF5D4037), Offset(9 * p, 4 * p), Size(p * 1.5f, p * 4))
            }

            // === TORCH ===
            item.id == ItemRegistry.TORCH.id -> {
                // Diagonal wooden stick
                drawRect(Color(0xFF5D4037), Offset(3 * p, 8 * p), Size(p * 6, p * 7))
                drawRect(Color(0xFF795548), Offset(4 * p, 9 * p), Size(p * 4, p * 5))

                // Flaming head
                drawRect(Color(0xFFE65100), Offset(7 * p, 2 * p), Size(p * 6, p * 6))
                drawRect(Color(0xFFFF9800), Offset(8 * p, 3 * p), Size(p * 4, p * 4))
                drawRect(Color(0xFFFFEB3B), Offset(9 * p, 4 * p), Size(p * 2, p * 2))
                drawRect(Color.White, Offset(9.5f * p, 4.5f * p), Size(p, p))
            }

            // === CAMPFIRE ===
            item.id == ItemRegistry.CAMPFIRE.id -> {
                drawRect(Color(0xFF4E342E), Offset(2 * p, 10 * p), Size(p * 12, p * 3))
                drawRect(Color(0xFF5D4037), Offset(4 * p, 8 * p), Size(p * 8, p * 3))
                // Flame
                drawRect(Color(0xFFFF5722), Offset(5 * p, 3 * p), Size(p * 6, p * 6))
                drawRect(Color(0xFFFFC107), Offset(6 * p, 4 * p), Size(p * 4, p * 4))
                drawRect(Color.White, Offset(7 * p, 5 * p), Size(p * 2, p * 2))
            }

            // === WORKBENCH ===
            item.id == ItemRegistry.WORKBENCH.id -> {
                drawRect(Color(0xFF5D4037), Offset(2 * p, 4 * p), Size(p * 12, p * 10))
                drawRect(Color(0xFF8D6E63), Offset(3 * p, 5 * p), Size(p * 10, p * 4))
                // Grid pattern
                drawRect(Color(0xFF3E2723), Offset(6 * p, 5 * p), Size(p, p * 4))
                drawRect(Color(0xFF3E2723), Offset(9 * p, 5 * p), Size(p, p * 4))
                drawRect(Color(0xFFE0E0E0), Offset(4 * p, 6 * p), Size(p * 2, p * 1.5f))
            }

            // === FURNACE ===
            item.id == ItemRegistry.FURNACE.id -> {
                drawRect(Color(0xFF424242), Offset(2 * p, 2 * p), Size(p * 12, p * 12))
                drawRect(Color(0xFF616161), Offset(3 * p, 3 * p), Size(p * 10, p * 10))
                // Fire hole
                drawRect(Color(0xFF212121), Offset(5 * p, 7 * p), Size(p * 6, p * 5))
                drawRect(Color(0xFFFF5722), Offset(6 * p, 8 * p), Size(p * 4, p * 3))
                drawRect(Color(0xFFFFEB3B), Offset(7 * p, 9 * p), Size(p * 2, p * 2))
            }

            // === CHEST ===
            item.id == ItemRegistry.CHEST.id -> {
                drawRect(Color(0xFF5D4037), Offset(2 * p, 3 * p), Size(p * 12, p * 10))
                drawRect(Color(0xFF8D6E63), Offset(3 * p, 4 * p), Size(p * 10, p * 8))
                drawRect(Color(0xFF3E2723), Offset(2 * p, 7 * p), Size(p * 12, p * 1.5f))
                // Golden Lock
                drawRect(Color(0xFFFFD700), Offset(7 * p, 6.5f * p), Size(p * 2, p * 3))
            }

            // === BED ===
            item.id == ItemRegistry.BED.id -> {
                drawRect(Color(0xFF5D4037), Offset(1 * p, 4 * p), Size(p * 14, p * 9))
                drawRect(Color(0xFFD32F2F), Offset(5 * p, 5 * p), Size(p * 9, p * 7)) // Red blanket
                drawRect(Color.White, Offset(2 * p, 5 * p), Size(p * 3.5f, p * 5)) // Pillow
            }

            // === TOTEM ===
            item.id == ItemRegistry.CIVILIZATION_TOTEM.id -> {
                drawRect(Color(0xFFFFD700), Offset(4 * p, 1 * p), Size(p * 8, p * 14))
                drawRect(Color(0xFFB8860B), Offset(5 * p, 2 * p), Size(p * 6, p * 12))
                // Glowing Eye
                drawRect(Color(0xFF00E5FF), Offset(6 * p, 4 * p), Size(p * 4, p * 4))
                drawRect(Color.White, Offset(7 * p, 5 * p), Size(p * 2, p * 2))
            }

            // === GEMS & ORES ===
            item.id == ItemRegistry.DIAMOND.id || item.id == ItemRegistry.RUBY.id -> {
                val gemCol = if (item.id == ItemRegistry.DIAMOND.id) Color(0xFF00E5FF) else Color(0xFFFF1744)
                drawRect(gemCol, Offset(5 * p, 3 * p), Size(p * 6, p * 10))
                drawRect(gemCol, Offset(3 * p, 5 * p), Size(p * 10, p * 6))
                drawRect(Color.White, Offset(5 * p, 4 * p), Size(p * 2, p * 2))
            }

            // === INGOTS ===
            item.id.contains("ingot") -> {
                val ingotCol = Color(item.primaryColor)
                drawRect(Color(0xFF424242), Offset(3 * p, 6 * p), Size(p * 10, p * 6))
                drawRect(ingotCol, Offset(4 * p, 5 * p), Size(p * 8, p * 5))
                drawRect(Color.White, Offset(5 * p, 5.5f * p), Size(p * 6, p * 1.5f))
            }

            // === WOOD & STONES ===
            item.id == ItemRegistry.WOOD.id -> {
                // Log of wood
                drawRect(Color(0xFF3E2723), Offset(2 * p, 4 * p), Size(p * 12, p * 8))
                drawRect(Color(0xFF5D4037), Offset(3 * p, 5 * p), Size(p * 8, p * 6))
                // End rings
                drawRect(Color(0xFF8D6E63), Offset(10 * p, 5 * p), Size(p * 3, p * 6))
                drawRect(Color(0xFF3E2723), Offset(11 * p, 7 * p), Size(p * 1.2f, p * 2))
            }

            item.id == ItemRegistry.STONE.id -> {
                // Stone rock chunk
                drawRect(Color(0xFF424242), Offset(3 * p, 4 * p), Size(p * 10, p * 9))
                drawRect(Color(0xFF757575), Offset(4 * p, 5 * p), Size(p * 7, p * 6))
                drawRect(Color(0xFFB0BEC5), Offset(5 * p, 5 * p), Size(p * 3, p * 2))
            }

            // === POTION ===
            item.id.contains("potion") -> {
                drawRect(Color(0xFF90A4AE), Offset(6 * p, 2 * p), Size(p * 4, p * 3)) // Neck
                drawRect(Color(0xFF5D4037), Offset(6.5f * p, 1 * p), Size(p * 3, p * 1.5f)) // Cork
                drawRect(Color(0xFFE0E0E0), Offset(3 * p, 5 * p), Size(p * 10, p * 9)) // Bottle
                drawRect(Color(0xFFFF1744), Offset(4 * p, 7 * p), Size(p * 8, p * 6)) // Liquid
                drawRect(Color.White, Offset(4.5f * p, 7.5f * p), Size(p * 2, p * 2)) // Highlight
            }

            // === HELMET / CROWN ===
            item.id.contains("helm") || item.id == ItemRegistry.FR3VELORA_CROWN.id -> {
                val helmCol = Color(item.primaryColor)
                drawRect(helmCol, Offset(3 * p, 3 * p), Size(p * 10, p * 10))
                drawRect(Color(0xFF212121), Offset(5 * p, 7 * p), Size(p * 6, p * 3)) // Visor slit
                if (item.id == ItemRegistry.FR3VELORA_CROWN.id) {
                    drawRect(Color(0xFF00E5FF), Offset(7 * p, 4 * p), Size(p * 2, p * 2))
                }
            }

            // Fallback for other items
            else -> {
                drawRect(Color(item.primaryColor), Offset(4 * p, 4 * p), Size(p * 8, p * 8))
                drawRect(Color.White, Offset(5 * p, 5 * p), Size(p * 2, p * 2))
            }
        }
    }
}
