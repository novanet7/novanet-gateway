package com.example.game.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * Draws decorative rustic branches, wood sticks, and green vine leaves
 * along the borders and corners of panels and buttons.
 */
@Composable
fun RusticStickBorder(
    modifier: Modifier = Modifier,
    hasLeaves: Boolean = true
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val stickThickness = 4f

        val woodDark = Color(0xFF3E2723)
        val woodMedium = Color(0xFF5D4037)
        val woodLight = Color(0xFF8D6E63)
        val leafGreen = Color(0xFF4CAF50)
        val leafDark = Color(0xFF2E7D32)

        // Top stick
        drawRect(woodDark, Offset(6f, 1f), Size(w - 12f, stickThickness + 2f))
        drawRect(woodMedium, Offset(6f, 2f), Size(w - 12f, stickThickness))
        drawRect(woodLight, Offset(8f, 2f), Size(w - 16f, 1.5f))

        // Bottom stick
        drawRect(woodDark, Offset(6f, h - stickThickness - 3f), Size(w - 12f, stickThickness + 2f))
        drawRect(woodMedium, Offset(6f, h - stickThickness - 2f), Size(w - 12f, stickThickness))
        drawRect(woodLight, Offset(8f, h - stickThickness - 2f), Size(w - 16f, 1.5f))

        // Left stick
        drawRect(woodDark, Offset(1f, 6f), Size(stickThickness + 2f, h - 12f))
        drawRect(woodMedium, Offset(2f, 6f), Size(stickThickness, h - 12f))
        drawRect(woodLight, Offset(2f, 8f), Size(1.5f, h - 16f))

        // Right stick
        drawRect(woodDark, Offset(w - stickThickness - 3f, 6f), Size(stickThickness + 2f, h - 12f))
        drawRect(woodMedium, Offset(w - stickThickness - 2f, 6f), Size(stickThickness, h - 12f))
        drawRect(woodLight, Offset(w - stickThickness - 2f, 8f), Size(1.5f, h - 16f))

        // 4 Corner Knots / Branch Joints
        val knotSize = 9f
        // Top-Left Knot
        drawRect(woodDark, Offset(0f, 0f), Size(knotSize, knotSize))
        drawRect(woodMedium, Offset(1f, 1f), Size(knotSize - 2f, knotSize - 2f))
        drawRect(woodLight, Offset(2f, 2f), Size(2f, 2f))

        // Top-Right Knot
        drawRect(woodDark, Offset(w - knotSize, 0f), Size(knotSize, knotSize))
        drawRect(woodMedium, Offset(w - knotSize + 1f, 1f), Size(knotSize - 2f, knotSize - 2f))
        drawRect(woodLight, Offset(w - knotSize + 2f, 2f), Size(2f, 2f))

        // Bottom-Left Knot
        drawRect(woodDark, Offset(0f, h - knotSize), Size(knotSize, knotSize))
        drawRect(woodMedium, Offset(1f, h - knotSize + 1f), Size(knotSize - 2f, knotSize - 2f))
        drawRect(woodLight, Offset(2f, h - knotSize + 2f), Size(2f, 2f))

        // Bottom-Right Knot
        drawRect(woodDark, Offset(w - knotSize, h - knotSize), Size(knotSize, knotSize))
        drawRect(woodMedium, Offset(w - knotSize + 1f, h - knotSize + 1f), Size(knotSize - 2f, knotSize - 2f))
        drawRect(woodLight, Offset(w - knotSize + 2f, h - knotSize + 2f), Size(2f, 2f))

        // Decorative Vine Leaves sprouting from corners
        if (hasLeaves) {
            // Top-Left sprout
            drawOval(leafDark, Offset(knotSize - 1f, -2f), Size(7f, 4f))
            drawOval(leafGreen, Offset(knotSize, -1f), Size(5f, 3f))

            // Top-Right sprout
            drawOval(leafDark, Offset(w - knotSize - 6f, -2f), Size(7f, 4f))
            drawOval(leafGreen, Offset(w - knotSize - 5f, -1f), Size(5f, 3f))

            // Bottom-Left sprout
            drawOval(leafDark, Offset(-2f, h - knotSize - 5f), Size(4f, 7f))
            drawOval(leafGreen, Offset(-1f, h - knotSize - 4f), Size(3f, 5f))

            // Bottom-Right sprout
            drawOval(leafDark, Offset(w - knotSize - 5f, h - 2f), Size(7f, 4f))
            drawOval(leafGreen, Offset(w - knotSize - 4f, h - 2f), Size(5f, 3f))
        }
    }
}
