package com.example.game.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

@Composable
fun VirtualJoystick(
    modifier: Modifier = Modifier,
    onMove: (Float, Float) -> Unit
) {
    var thumbOffset by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = modifier
            .size(118.dp)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val delta = offset - center
                        val dist = delta.getDistance()
                        val maxR = size.width / 2f - 18f
                        thumbOffset = if (dist > maxR) {
                            delta * (maxR / dist)
                        } else delta

                        val nx = (thumbOffset.x / maxR).coerceIn(-1f, 1f)
                        val ny = (thumbOffset.y / maxR).coerceIn(-1f, 1f)
                        onMove(nx, ny)
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val delta = change.position - center
                        val dist = delta.getDistance()
                        val maxR = size.width / 2f - 18f
                        thumbOffset = if (dist > maxR) {
                            delta * (maxR / dist)
                        } else delta

                        val nx = (thumbOffset.x / maxR).coerceIn(-1f, 1f)
                        val ny = (thumbOffset.y / maxR).coerceIn(-1f, 1f)
                        onMove(nx, ny)
                    },
                    onDragEnd = {
                        thumbOffset = Offset.Zero
                        onMove(0f, 0f)
                    },
                    onDragCancel = {
                        thumbOffset = Offset.Zero
                        onMove(0f, 0f)
                    }
                )
            }
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val outerRadius = size.width / 2f - 8f

            // Outer Carved Wood Base Ring
            drawCircle(
                color = Color(0x991E293B),
                radius = outerRadius,
                center = center
            )
            // Rustic Wood Bark Rim
            drawCircle(
                color = Color(0xFF5D4037),
                radius = outerRadius,
                center = center,
                style = Stroke(width = 5f)
            )
            drawCircle(
                color = Color(0xFF8D6E63),
                radius = outerRadius - 3f,
                center = center,
                style = Stroke(width = 1.5f)
            )

            // 4 Compass Directional Branch Notches
            val tickLen = 7f
            drawLine(Color(0xFF81C784), center + Offset(0f, -outerRadius + 5f), center + Offset(0f, -outerRadius + 5f + tickLen), strokeWidth = 3f)
            drawLine(Color(0xFF81C784), center + Offset(0f, outerRadius - 5f), center + Offset(0f, outerRadius - 5f - tickLen), strokeWidth = 3f)
            drawLine(Color(0xFF81C784), center + Offset(-outerRadius + 5f, 0f), center + Offset(-outerRadius + 5f + tickLen, 0f), strokeWidth = 3f)
            drawLine(Color(0xFF81C784), center + Offset(outerRadius - 5f, 0f), center + Offset(outerRadius - 5f - tickLen, 0f), strokeWidth = 3f)

            // Inner Thumb Stick: Stone medallion with wood trim and center green emerald gem
            val thumbCenter = center + thumbOffset
            drawCircle(
                color = Color(0xFF3E2723),
                radius = 24f,
                center = thumbCenter
            )
            drawCircle(
                color = Color(0xFF2E7D32),
                radius = 20f,
                center = thumbCenter
            )
            drawCircle(
                color = Color(0xFF69F0AE),
                radius = 12f,
                center = thumbCenter
            )
            drawCircle(
                color = Color.White,
                radius = 3.5f,
                center = thumbCenter + Offset(-3f, -3f)
            )
        }
    }
}
