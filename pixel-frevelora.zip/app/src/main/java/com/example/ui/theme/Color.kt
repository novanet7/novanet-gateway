package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SurvivalGreen = Color(0xFF2E7D32)
val GoldAccent = Color(0xFFFFD700)
val DarkBackground = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val LightGreen = Color(0xFF69F0AE)
val HealthRed = Color(0xFFFF1744)
val ManaBlue = Color(0xFF00E5FF)
